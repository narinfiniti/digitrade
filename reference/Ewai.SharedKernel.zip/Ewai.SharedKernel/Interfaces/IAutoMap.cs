using AutoMapper;

namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// Maps Entity to Data Transfer Object and vice versa.
/// </summary>
/// <typeparam name="TEntity"></typeparam>
/// <typeparam name="TDto"></typeparam>
public interface IAutoMap<TEntity, TDto>
    where TEntity : class, new()
    where TDto : class, new()
{
    void CreateMap(Profile profile)
    {
        profile.CreateMap<TEntity, TDto>();
        profile.CreateMap<TDto, TEntity>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }
}