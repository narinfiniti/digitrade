﻿namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// ISoftDelete.
/// </summary>
public interface ISoftDelete
{
    bool IsDeleted { get; set; }
}