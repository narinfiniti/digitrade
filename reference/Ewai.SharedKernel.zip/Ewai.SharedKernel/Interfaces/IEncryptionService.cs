namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// IEncryptionService.
/// </summary>
public interface IEncryptionService
{
    Task<string> EncryptStringAsync(string text, string keyString);
    Task<string> DecryptStringAsync(string cipherText, string keyString);
}