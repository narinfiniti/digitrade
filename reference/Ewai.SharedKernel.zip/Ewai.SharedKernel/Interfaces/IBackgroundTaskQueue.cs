using Microsoft.Extensions.DependencyInjection;

namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// Abstraction for BackgroundTaskQueue service.
/// </summary>
public interface IBackgroundTaskQueue
{
    void QueueWorkItem(Func<CancellationToken, IServiceScope, Task> workItem);
    int GetCount();
    Task<Func<CancellationToken, IServiceScope, Task>> DequeueAsync(CancellationToken cancellationToken);
}