﻿using Ewai.SharedKernel.Models;

namespace Ewai.SharedKernel.Interfaces;

/// <summary>
///     ISmsSender.
/// </summary>
public interface ISmsSender
{
    Task SendAsync(TwilioSmsMessage smsMessage);
}