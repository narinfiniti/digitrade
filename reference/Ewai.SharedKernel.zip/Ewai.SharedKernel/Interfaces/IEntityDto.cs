﻿namespace Ewai.SharedKernel.Interfaces;

public interface IEntityDto<TKey> : IEntityDto
{
  TKey Id { get; set; }
}
public interface IEntityDto
{
}