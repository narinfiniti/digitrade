﻿namespace Ewai.SharedKernel.Interfaces;

/// <summary>A standard interface to add DateCreated property.</summary>
public interface IHasCreationDate
{
    /// <summary>DateCreated.</summary>
    DateTime DateCreated { get; }
}