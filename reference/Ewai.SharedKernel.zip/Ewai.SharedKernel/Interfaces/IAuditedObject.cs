﻿namespace Ewai.SharedKernel.Interfaces;

public interface IAuditedObject :
  ICreationAuditedObject,
  IModificationAuditedObject
{
}