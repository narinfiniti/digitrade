using MediatR;

namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// Abstraction for creating a command/query use-case.
/// </summary>
public interface IUseCase<out TInputModel, out TOutputModel> : IRequest<TOutputModel>
{
    TInputModel Model { get; }
}

/// <summary>
/// Abstraction for creating a command.
/// </summary>
public interface IUseCase<out TInputModel> : IRequest
{
    TInputModel Model { get; }
}