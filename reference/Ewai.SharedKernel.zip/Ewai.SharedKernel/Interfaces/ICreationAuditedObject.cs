﻿namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// This interface can be implemented to store creation information (who and when created).
/// </summary>
public interface ICreationAuditedObject : IHasCreationDate, IMayHaveCreator
{
}