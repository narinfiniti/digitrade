using System.Security.Claims;

namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// Abstraction to retrieve user's identity.
/// </summary>
public interface IUserProfileService
{
    bool IsAuthenticatedUser();
    bool IsBranchUser();
    bool IsBranchAdmin();
    bool IsTenantUser();
    bool IsTenantAdmin();
    bool IsSystemUser();
    bool IsSystemAdmin();
    bool IsSystemManager();
    bool IsSystemOperator();
    string[] GetUserRoles();
    string GetUserName();
    Guid? GetUserId(ClaimsPrincipal principal = null);
    Guid? GetBranchId(ClaimsPrincipal principal = null);
    Guid? GetTenantId(ClaimsPrincipal principal = null);
    (Guid?, string[], Guid?, Guid?) GetUserIdRolesBranchIdTenantId(ClaimsPrincipal principal = null);
}