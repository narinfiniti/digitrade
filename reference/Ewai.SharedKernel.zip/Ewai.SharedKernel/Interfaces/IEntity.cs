﻿namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// Marker abstraction for Domain entity type.
/// </summary>
public interface IEntity
{
    public bool Equals(object obj)
    {
        return obj is IEntity other && Equals(this, other);
    }
}

/// <summary>
/// Identity abstraction of Domain entity.
/// </summary>
public interface IEntity<TKey> where TKey : IEquatable<TKey>
{
    TKey Id { get; set; }

    public bool Equals(object obj)
    {
        return obj is IEntity<TKey> other && Id.Equals(other.Id);
    }

    public int GetHashCode()
    {
        return Id.GetHashCode();
    }
}