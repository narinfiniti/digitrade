﻿namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// A standard interface to add DeletionTime property to a class.
/// </summary>
public interface IHasModificationDate
{
  /// <summary>The last modified time for this entity.</summary>
  DateTime? DateModified { get; set; }
}