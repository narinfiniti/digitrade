﻿using FluentEmail.Core.Models;

namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// IMailingService.
/// </summary>
public interface IMailingService
{
    ValueTask SendEmailAsync(
        string toEmail,
        string subject,
        string textOrTemplateName,
        dynamic model,
        string fromEmail = null,
        Attachment[] attachments = null,
        CancellationToken cancellation = default);
}