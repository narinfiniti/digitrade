﻿using Microsoft.AspNetCore.Http;

namespace Ewai.SharedKernel.Interfaces;

public interface IBlobStorageService<T> where T : class
{
    ValueTask UploadBlobAsync(IFormFile image, string blobName, CancellationToken cancelToken = default);
    ValueTask UploadBlobAsync(Stream stream, string blobName, CancellationToken cancelToken = default);
    ValueTask RemoveBlobAsync(string blobName, CancellationToken cancelToken = default);
    ValueTask RemoveBlobsAsync(IEnumerable<string> blobNames, CancellationToken cancelToken = default);
    ValueTask<bool> ExistsBlobAsync(string blobName, CancellationToken cancelToken = default);

    ValueTask CopyBlobsAsync(string[] blobNames,
        string fromContainerName, string toContainerName, CancellationToken cancelToken = default);

    ValueTask ForEachBlobAsync(Func<string, Task> action, string containerName = null, CancellationToken cancel = default);
    ValueTask<Stream> DownloadBlobAsync(string blobName, CancellationToken cancelToken = default);

    ValueTask CopyBlobsInHierarchyAsync(IEnumerable<string> blobNames,
        string containerName,
        string toFolderPath,
        CancellationToken cancelToken);

    ValueTask CleanBlobsInHierarchyAsync(
        string fromContainerName,
        string prefix,
        string[] preserveBlobNames = null,
        CancellationToken cancellationToken = default);
}