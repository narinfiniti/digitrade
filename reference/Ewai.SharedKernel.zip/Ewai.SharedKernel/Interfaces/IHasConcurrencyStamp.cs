﻿namespace Ewai.SharedKernel.Interfaces;

public interface IHasConcurrencyStamp
{
    byte[] ConcurrencyStamp { get; set; }
}