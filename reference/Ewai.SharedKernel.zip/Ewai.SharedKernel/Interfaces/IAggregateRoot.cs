namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// Marker interface for aggregate root entity.
/// </summary>
public interface IAggregateRoot<TKey> : IEntity<TKey> where TKey : IEquatable<TKey>
{
}