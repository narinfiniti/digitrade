using System.Linq.Expressions;

namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// Abstraction for repository.
/// </summary>
public interface IRepository<TEntity, in TKey>
    where TEntity : class, IAggregateRoot<TKey>, new()
    where TKey : IEquatable<TKey>
{
    IUnitOfWork Uow { get; }
    ValueTask<TEntity> FindAsync(
        Expression<Func<TEntity, bool>> predicate,
        Expression<Func<TEntity, object>>[] includes = null);
    ValueTask<TEntity> ThrowIfNotFoundAsync(Expression<Func<TEntity, bool>> predicate);
    ValueTask<TEntity> AddAsync(TEntity entity);
    ValueTask<List<TEntity>> AddRangeAsync(List<TEntity> entities);
    ValueTask DeleteAsync(TKey id);
    ValueTask<TEntity> UpdateAsync(object id, TEntity entity);
    ValueTask<List<TEntity>> FindRangeAsync(
        Expression<Func<TEntity, bool>> predicate = null,
        Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
        Expression<Func<TEntity, object>>[] includes = null,
        int? skip = null,
        int? limit = null,
        bool tracking = false,
        CancellationToken cancel = default);
    ValueTask<bool> AnyAsync(
        Expression<Func<TEntity, bool>> predicate);
    ValueTask<long> CountAsync(
        Expression<Func<TEntity, bool>> predicate);
}