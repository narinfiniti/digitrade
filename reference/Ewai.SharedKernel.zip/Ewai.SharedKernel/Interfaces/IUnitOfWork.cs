namespace Ewai.SharedKernel.Interfaces;

/// <summary>
///     IUnitOfWork.
/// </summary>
/// <typeparam name="TContext"></typeparam>
public interface IUnitOfWork<out TContext> : IUnitOfWork
{
    TContext Context { get; }
    IRepository<TEntity, TKey> GetRepository<TEntity, TKey>()
        where TEntity : class, IAggregateRoot<TKey>, new()
        where TKey : IEquatable<TKey>;
}

public interface IUnitOfWork : IDisposable
{
    bool HasActiveTransaction { get; }
    void ValidateAggregateRootInvariantRules();
    ValueTask<int> SaveAsync(CancellationToken cancellation = default);

    ValueTask CommitAsync(Func<CancellationToken, Task> actionAsync,
        CancellationToken cancellationToken = default);

    Task<bool> SaveEntitiesAsync(CancellationToken cancellation = default);
    Task MigrateAsync(CancellationToken cancellationToken = default);
    Task<bool> CanConnectAsync(CancellationToken cancellationToken = default);
    Task<bool> HasPendingMigrationsAsync(CancellationToken cancellationToken = default);
}