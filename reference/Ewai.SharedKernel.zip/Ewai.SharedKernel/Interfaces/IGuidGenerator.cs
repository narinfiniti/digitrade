﻿namespace Ewai.SharedKernel.Interfaces;

public interface IGuidGenerator
{
    Guid Create();
}