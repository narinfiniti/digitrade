﻿namespace Ewai.SharedKernel.Interfaces;

/// <summary>
/// ICommonService.
/// </summary>
public interface IQrCodeService
{
    byte[] GetQrCodeBytes(string input);
}