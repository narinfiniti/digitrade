﻿using Ewai.SharedKernel.Models.Configs;

namespace Ewai.SharedKernel.Interfaces;

/// <summary>
///     ICommonService.
/// </summary>
public interface ICommonService : IDisposable
{
    Task<string> GetCsvAsync<T>(List<T> items, string delimiter = "|");
    ValueTask<string> GetPhoneNumberCountryAsync(string phoneNumber);
    bool IsValidPhoneNumber(string phoneNumber);
    bool IsValidEmail(string email);
    bool IsValidIpAddress(string ipAddressString);
    string GetRandomPassword(int letterSize, int digitLength, bool lowerCase = false);
    string GetFileExtension(Stream stream);
    public string GenerateRandomNumberString(int length);
    DateTime ConvertToSpecificTimeZone(DateTime dateTime, string zoneId);
    string GenerateInsertOrUpdateSql(object entity, string schema = "app",
        string tableName = null, bool needUpdate = true);
    IEnumerable<string> GenerateInsertOrUpdateSql(IEnumerable<object> entities, string schema = "app",
        int length = 4000, string tableName = null, bool needUpdate = true);
    Task<bool> IsInternetConnected(string host = "20.46.48.111", ushort port = 23517, int timeout = 200);
    bool IsDesktopConnected();
    string GenerateDeleteSql(object entity, string schema = "app", string tableName = null);
    IEnumerable<string> GenerateDeleteSql(IEnumerable<object> entities, string schema = "app",
        int length = 4000, string tableName = null);
    string GenerateUpdateSql(object entity, string schema = "app", string tableName = null);
    Task SaveFileToLocal(string path, Stream memoryStream, string fileName, CancellationToken cancellationToken);
    Task<Stream> GetFileFromLocal(string path, string fileName, CancellationToken cancel);
    Task DownloadToLocal(string path, IBlobStorageService<DefaultAwsS3Storage> blobService, string fileName);
    Guid GenerateIdFromBarcode(string barcode);
    void DeleteFileFromLocal(string path, string fileName);
}