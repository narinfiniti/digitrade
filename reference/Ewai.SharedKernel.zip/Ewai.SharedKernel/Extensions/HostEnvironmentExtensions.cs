﻿using Microsoft.Extensions.Hosting;

namespace Ewai.SharedKernel.Extensions;

/// <summary>
/// HttpResponseExtensions.
/// </summary>
public static class HostEnvironmentExtensions
{
    public static bool IsDevOrLocal(this IHostEnvironment env)
    {
        return env.IsLocalhost() || env.IsDevelopment();
    }
    public static bool IsLocalhost(this IHostEnvironment env)
    {
        return env.IsEnvironment("Localhost");
    }
    public static bool IsStagingOrProd(this IHostEnvironment env)
    {
        return env.IsStaging() || env.IsProduction();
    }
    public static bool IsDev(this IHostEnvironment env)
    {
        return env.IsEnvironment("Dev");
    }
    public static bool IsDesktop(this IHostEnvironment env)
    {
        return env.IsEnvironment("Desktop");
    }
}