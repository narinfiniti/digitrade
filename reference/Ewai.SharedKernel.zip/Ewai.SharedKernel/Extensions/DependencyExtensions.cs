using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using Amazon;
using Ewai.SharedKernel.Interfaces;
using Ewai.SharedKernel.Models;
using Ewai.SharedKernel.Models.Configs;
using Ewai.SharedKernel.Models.Mailing;
using Ewai.SharedKernel.Services;
using FileSignatures;
using FluentEmail.Core.Interfaces;
using FluentEmail.Razor;
using FluentEmail.Smtp;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using PhoneNumbers;

namespace Ewai.SharedKernel.Extensions;

public static class DependencyExtensions
{
    public static IServiceCollection AddSharedKernelInfra(this IServiceCollection services,
        IConfiguration config,
        IHostEnvironment env)
    {
        services.AddSingleton(RandomNumberGenerator.Create());
        services.AddSingleton<IGuidGenerator, SequentialGuidGenerator>();
        services.AddSingleton<IFileFormatInspector>(new FileFormatInspector());
        services.AddSingleton<ICommonService, CommonService>();

        services.AddHostedService<QueuedHostedService>();
        services.AddSingleton<IBackgroundTaskQueue, BackgroundTaskQueue>();
        services.AddSingleton(sp =>
        {
            var options = sp.GetRequiredService<IOptions<BlobStoring>>().Value;
            return new DefaultAzureStorage(options.DefaultAzureStorage);
        });
        services.AddSingleton(sp =>
        {
            var options = sp.GetRequiredService<IOptions<BlobStoring>>().Value;
            var awsRegion = new AwsRegion(options.DefaultAwsS3Storage.Region);
            var awsCredential = new AwsCredential(
                options.DefaultAwsS3Storage.AccessKeyId,
                options.DefaultAwsS3Storage.SecretAccessKey);
            var storage = new DefaultAwsS3Storage(awsRegion, awsCredential)
            {
                BaseUrl = options.DefaultAwsS3Storage.BaseUrl,
                BucketName = options.DefaultAwsS3Storage.BucketName
            };
            return storage;
        });

        services.AddTransient<IBlobStorageService<DefaultAzureStorage>, BlobAzureStorageService<DefaultAzureStorage>>();
        services.AddTransient<IBlobStorageService<DefaultAwsS3Storage>, BlobAwsS3StorageService<DefaultAwsS3Storage>>();
        services.AddTransient<PollyRetryPolicyService>();
        services.AddTransient<IUserProfileService, UserProfileService>();
        services.AddTransient<IEncryptionService, EncryptionService>();
        services.AddTransient(sp => PhoneNumberUtil.GetInstance());
        services.AddTransientMailingService<IMailingService, MailingService>(config);
        services.AddTransient<IQrCodeService, QrCodeService>();

        services.Configure<TwilioSmsOptions>(config.GetSection(nameof(TwilioSmsOptions)));
        services.AddTransient<ISmsSender, TwilioSmsSender>();

        return services;
    }

    private static void AddTransientMailingService<TIMailing, TMailing>(this IServiceCollection services,
        IConfiguration configuration)
        where TMailing : class, TIMailing
        where TIMailing : class
    {
        var section = configuration.GetSection(nameof(MailingOptions));
        var ops = new MailingOptions();
        section.Bind(ops);
        services.Configure<MailingOptions>(section);
        services
            .AddFluentEmail(ops.FromAddress, ops.FromDisplayName)
            .AddRazorRenderer();

        services.AddTransient<ITemplateRenderer>(p => new RazorRenderer());

        // services.AddTransient<FluentEmail.Core.Interfaces.ISender>(p =>
        //     new FluentEmail.SendGrid.SendGridSender(section["SendGridSender:ApiKey"]));
        //var graphSenderOptions = section.GetSection("GraphSenderOptions").Get<FluentEmail.Graph.GraphSenderOptions>();
        //services.AddTransient<FluentEmail.Core.Interfaces.ISender>(p => new FluentEmail.Graph.GraphSender(graphSenderOptions));

        services.AddTransient<ISender>(p =>
        {
            var o = p.GetRequiredService<IOptions<MailingOptions>>().Value;
            var smtpClient = new SmtpClient
            {
                Credentials = !string.IsNullOrEmpty(o.SmtpSender.Domain)
                    ? new NetworkCredential(o.SmtpSender.UserName, o.SmtpSender.Password, o.SmtpSender.Domain)
                    : new NetworkCredential(o.SmtpSender.UserName, o.SmtpSender.Password),
                Host = o.SmtpSender.Host,
                Port = o.SmtpSender.Port,

                EnableSsl = o.SmtpSender.EnableSsl,
                UseDefaultCredentials = o.SmtpSender.UseDefaultCredentials
            };
            return new SmtpSender(smtpClient);
        });
        services.AddTransient<TIMailing, TMailing>();
    }
}