﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Polly;

namespace Ewai.SharedKernel.Extensions;

public static class DbMigrationExtensions
{
    public static async Task MigrateAsync<TContext>(this IServiceProvider serviceProvider,
        IConfiguration config,
        Func<IServiceProvider, Task> seeder)
    {
        var logger = serviceProvider.GetRequiredService<ILogger<TContext>>();
        try
        {
            logger.LogInformation("Migrations started with: {DbContextName}", typeof(TContext).Name);

            var retryCount = config.GetValue<int>("AppOptions:DbConnRetryCount");
            var retryIntervalSec = config.GetValue<int>("AppOptions:DbConnRetryIntervalSec");
            var retry = Policy.Handle<Exception>()
                .WaitAndRetry(
                    retryCount: retryCount,
                    sleepDurationProvider: retryAttempt => TimeSpan.FromSeconds(retryIntervalSec),
                    onRetry: (exception, timeSpan, retry, ctx) =>
                    {
                        logger.LogWarning(exception,
                            @"[{Context}] Exception {ExceptionType} detected on attempt {Retry}/{RetryCount}\n with message:\n{Message}",
                            nameof(TContext), exception.GetType().Name, retry, retryCount, exception.Message);
                    });

            // if the sql server container is not created on run docker compose this
            // migration can't fail for network related exception. The retry options for DbContext only 
            // apply to transient exceptionsÏ
            await retry.Execute(async () => await seeder.Invoke(serviceProvider));
            logger.LogInformation("Migrations completed with: {DbContextName}", typeof(TContext).Name);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error while migrating: {DbContextName}", typeof(TContext).Name);
        }
    }
}