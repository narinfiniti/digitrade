using System.Net;
using System.Text.Json.Nodes;
using Ewai.Common.Exceptions;
using Ewai.Common.Extensions;
using Ewai.Common.JsonOptions;
using Ewai.SharedKernel.Models.Logging;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Serilog.Context;

namespace Ewai.SharedKernel.Extensions;

public static class Hubs
{
    public const string Checkout = "checkout";
    public const string MobileHub = "hubs/mobilehub";
}
public static class Product
{
    public const string Base = "api/app/products";
    public const string SendBarcodes = "send-barcodes";
}
public static class LogInfoExtensions
{
    public static (int, string, int) LogError(this LogInfoModel info,
        ILogger logger, IHostEnvironment env, JsonOps jsonOps)
    {
        var statusCode = 0;
        string error = null;
        var customCode = 0;
        if (info.Exception is null)
        {
            if (info.Url.Is($"/{Product.Base}/{Product.SendBarcodes}"))
                return (customCode, null, statusCode);

            if (info.Url.IsNotEmpty() &&
                info.Url.StartsWith($"/{Hubs.MobileHub}", StringComparison.OrdinalIgnoreCase) &&
                !info.HasTarget)
                return (customCode, null, statusCode);

            PushLogModel(info);
            info.Url = info.Url.IsNotEmpty() ? info.Url : "Information";
            logger.LogInformation("Url: {Url}", info.Url);
        }
        else
        {
            customCode = (int)HttpStatusCode.InternalServerError;
            error = env.IsProduction()
                ? "An error occurred. Please try again later."
                : $"{info.Exception.Message}";

            switch (info.Exception)
            {
                case GoneException gone:
                    error = gone.Message;
                    customCode = gone.Status;
                    statusCode = (int)HttpStatusCode.Gone;
                    break;
                case NotAcceptableException suspended:
                    error = suspended.Message;
                    customCode = suspended.Status;
                    statusCode = (int)HttpStatusCode.NotAcceptable;
                    break;
                case UnauthorizedException un:
                    error = un.Message;
                    customCode = un.Status;
                    statusCode = (int)HttpStatusCode.Unauthorized;
                    break;
                case ForbiddenException forbid:
                    error = forbid.Message;
                    customCode = forbid.Status;
                    statusCode = (int)HttpStatusCode.Forbidden;
                    break;
                case SecurityTokenExpiredException expired:
                    error = "The token is expired!";
                    customCode = (int)HttpStatusCode.Unauthorized;
                    statusCode = (int)HttpStatusCode.Unauthorized;
                    break;
                case NotFoundException notFound:
                    error = notFound.Message;
                    customCode = notFound.Status;
                    statusCode = (int)HttpStatusCode.NotFound;
                    break;
                case UnsupportedMediaTypeException unsupported:
                    error = unsupported.Message;
                    customCode = unsupported.Status;
                    statusCode = (int)HttpStatusCode.UnsupportedMediaType;
                    break;
                case ServiceUnavailableException unavailable:
                    error = unavailable.Message;
                    customCode = unavailable.Status;
                    statusCode = (int)HttpStatusCode.ServiceUnavailable;
                    break;
                case ValidationException valid:
                    error = valid.ToResult(jsonOps.Serialize);
                    customCode = valid.Status;
                    statusCode = (int)HttpStatusCode.UnprocessableEntity;
                    break;
                case ConflictException conflict:
                    error = conflict.Message;
                    customCode = conflict.Status;
                    statusCode = (int)HttpStatusCode.Conflict;
                    break;
                case PreconditionFailedException pre:
                    error = pre.Message;
                    customCode = pre.Status;
                    statusCode = (int)HttpStatusCode.PreconditionFailed;
                    break;
                case BadRequestException bad:
                    error = bad.Message;
                    customCode = bad.Status;
                    statusCode = (int)HttpStatusCode.BadRequest;
                    break;
            }

            PushLogModel(info);
            logger.LogError(info.Exception, "Error: {Error}", error);
        }

        return (customCode, error, statusCode);
    }

    private static void PushLogModel(this LogInfoModel info)
    {
        var header = info.RequestHeaders?[..Math.Min(4000, info.RequestHeaders?.Length ?? 0)];
        var body = info.RequestBody?[..Math.Min(4000, info.RequestBody?.Length ?? 0)];
        var username = info.Claims.FirstOrDefault(c => c.Type.Is(nameof(info.UserName)))?.Value;
        var tenantIdValue = info.Claims.FirstOrDefault(c => c.Type.Is("tenant_id"))?.Value;
        if (info.TenantId.IsEmpty() && Guid.TryParse(tenantIdValue, out var tenantId))
        {
            info.TenantId = tenantId;
        }

        //LogContext.PushProperty(nameof(info.Id), info.Id);
        LogContext.PushProperty(nameof(info.StatusCode), info.StatusCode);
        LogContext.PushProperty(nameof(info.ExecutionDuration), info.ExecutionDuration);
        LogContext.PushProperty(nameof(info.HttpMethod), info.HttpMethod);
        LogContext.PushProperty(nameof(info.Method), info.Method);
        LogContext.PushProperty(nameof(info.Url), info.Url?[..Math.Min(256, info.Url?.Length ?? 0)]);
        LogContext.PushProperty(nameof(info.Host), info.Host?[..Math.Min(255, info.Host?.Length ?? 0)]);
        LogContext.PushProperty(nameof(info.UserAgent), info.UserAgent?[..Math.Min(256, info.UserAgent?.Length ?? 0)]);
        LogContext.PushProperty(nameof(info.RequestHeaders), header);
        LogContext.PushProperty(nameof(info.RequestBody), body);
        LogContext.PushProperty(nameof(info.UserName), username);
        LogContext.PushProperty(nameof(info.TenantId), info.TenantId);
    }

    public static (string, bool) GetMethod(this LogInfoModel info,
        string requestPath)
    {
        string method = null;
        var hasTarget = false;
        var body = info.RequestBody;
        try
        {
            if (requestPath.StartsWith($"/{Hubs.MobileHub}", StringComparison.OrdinalIgnoreCase))
            {
                method = Hubs.MobileHub;
                if (body.IsEmpty()) return (null, false);
                body = body.Replace("\u001E", "");

                var document = JsonNode.Parse(body);
                if (document is JsonObject doc)
                {
                    doc.TryGetPropertyValue("target", out var target);
                    if (target != null)
                    {
                        method = $"{Hubs.MobileHub}/{target}";
                        hasTarget = true;
                    }
                }
            }
            else
            {
                var pathSegments = requestPath
                    .Replace("/api/app", "")
                    .Split("/", StringSplitOptions.RemoveEmptyEntries);
                method = pathSegments.Length >= 2
                    ? $"{pathSegments[0]}/{pathSegments[1]}"
                    : pathSegments?[0];
            }
        }
        catch (Exception)
        {
            // ignored
        }

        return (method, hasTarget);
    }
}