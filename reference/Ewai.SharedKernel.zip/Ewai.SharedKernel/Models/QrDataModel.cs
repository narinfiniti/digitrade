namespace Ewai.SharedKernel.Models;

public class QrDataModel
{
    public Guid Id { get; set; }
    public string RoleName { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string PhoneNumber { get; set; }
    public string Email { get; set; }
}

// This is the object that will be serialized into the QR code
public class QrPayloadModel
{
    public QrDataModel Data { get; set; }
    public string Signature { get; set; } // Base64 encoded signature
}