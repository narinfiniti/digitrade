﻿namespace Ewai.SharedKernel.Models;

/// <summary>
/// TwilioSmsOptions.
/// </summary>
public class TwilioSmsOptions
{
    public string AccountSId { get; set; }
    public string FromNumber { get; set; }
    public string AuthToken { get; set; }
}