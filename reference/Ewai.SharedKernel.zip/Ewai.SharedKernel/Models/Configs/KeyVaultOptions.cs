namespace Ewai.SharedKernel.Models.Configs;

/// <summary>
/// Azure KeyVault Options.
/// </summary>
public class KeyVaultOptions
{
    public string EventisRabbitMqHostName { get; set; }
    public string EventisRabbitMqVirtualHost { get; set; }
    public int EventisRabbitMqPort { get; set; }
    public string EventisRabbitMqPassword { get; set; }
    public string EventisRabbitMqUsername { get; set; }
    public string EventisSlackApiKey { get; set; }
}