﻿namespace Ewai.SharedKernel.Models.Configs;

public class BlobStoring
{
    public BlobAzureStoringOptions DefaultAzureStorage { get; set; }
    public BlobAwsS3StoringOptions DefaultAwsS3Storage { get; set; }
}

public class BlobAzureStoringOptions
{
    public string BaseUrl { get; set; }
    public string ConnectionString { get; set; }
    public string DefaultContainerName { get; set; }
    public string BaseLocalUrl { get; set; }
}

public class BlobAwsS3StoringOptions
{
    public string BaseUrl { get; set; }
    public string Region { get; set; }
    public string BucketName { get; set; }
    public string AccessKeyId { get; set; }
    public string SecretAccessKey { get; set; }
}