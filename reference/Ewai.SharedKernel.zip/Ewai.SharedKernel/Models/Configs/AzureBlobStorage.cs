using Azure.Storage.Blobs;

namespace Ewai.SharedKernel.Models.Configs;

public abstract class AzureBlobStorage(BlobAzureStoringOptions options) : BlobServiceClient(options.ConnectionString)
{
    public BlobAzureStoringOptions Options { get; set; } = options;
}

public class DefaultAzureStorage(BlobAzureStoringOptions options) : AzureBlobStorage(options);

public class BackupAzureStorage(BlobAzureStoringOptions options) : AzureBlobStorage(options);