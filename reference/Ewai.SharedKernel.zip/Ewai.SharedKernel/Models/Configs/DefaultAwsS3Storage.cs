using Amazon;
using Amazon.Security;

namespace Ewai.SharedKernel.Models.Configs;

public class DefaultAwsS3Storage(AwsRegion region, AwsCredential credential)
    : Amazon.S3.S3Client(region, credential)
{
    public string BaseUrl { get; set; }
    public string BucketName { get; set; }

    public string GetPreSignedUrl(string objectKey, HttpMethod method = null,
        TimeSpan? expiresIn = null, DateTime? utcNow = null)
    {
        method ??= HttpMethod.Get;
        expiresIn ??= TimeSpan.FromHours(1);
        utcNow ??= DateTime.UtcNow;
        return SignerV4.GetPresignedUrl(
            credential: _credential,
            scope: new CredentialScope(DateOnly.FromDateTime(utcNow.Value), Region, AwsService.S3),
            date: utcNow.Value,
            expires: expiresIn.Value,
            method: method,
            requestUri: new Uri($"https://{Host}/{BucketName}/{objectKey}"),
            payloadHash: "UNSIGNED-PAYLOAD"
        );
    }
}