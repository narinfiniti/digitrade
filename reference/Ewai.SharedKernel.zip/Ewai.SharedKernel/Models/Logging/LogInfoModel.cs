using System.Security.Claims;

namespace Ewai.SharedKernel.Models.Logging;

public class LogInfoModel
{
    // public Guid Id { get; set; }
    public string Host { get; set; }
    public string UserAgent { get; set; }
    public int StatusCode { get; set; }
    public Guid? TenantId { get; set; }
    public string UserName { get; set; }
    public IEnumerable<Claim> Claims { get; set; }
    public double ExecutionDuration { get; set; }
    public string Method { get; set; }
    public bool HasTarget { get; set; }
    public string Url { get; set; }
    public string HttpMethod { get; set; }
    public string RequestHeaders { get; set; }
    public string RequestBody { get; set; }
    public Exception Exception { get; set; }
}