﻿using System.Net;

namespace Ewai.SharedKernel.Models.Response;

/// <summary>
/// Error result for use case.
/// </summary>
public class ErrorResult(string error, int statusCode = (int)HttpStatusCode.BadRequest)
    : StatusResult(statusCode)
{
    public string Error { get; } = error;
}