﻿namespace Ewai.SharedKernel.Models.Response;

public class EnumListResult
{
    public int Id { get; set; }

    public string Name { get; set; }
}