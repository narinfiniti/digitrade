﻿namespace Ewai.SharedKernel.Models;

/// <summary>
/// Twilio SmsMessage.
/// </summary>
public class TwilioSmsMessage(string phoneNumber, string text)
{
    public string PhoneNumber { get; } = phoneNumber ?? throw new ArgumentNullException(nameof(phoneNumber));

    public string Text { get; } = text ?? throw new ArgumentNullException(nameof(text));

    public IDictionary<string, object> Properties { get; } = new Dictionary<string, object>();
}