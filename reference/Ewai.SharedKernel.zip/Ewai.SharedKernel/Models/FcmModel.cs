using System.Text.Json;

namespace Ewai.SharedKernel.Models;

public class FcmModel<TPayload> where TPayload : class
{
    public string ProjectId { get; set; }
    public List<string> Tokens { get; set; } = [];
    public string Title { get; set; }
    public string Body { get; set; }
    public string Action { get; set; }
    public TPayload Payload { get; set; }

    public Dictionary<string, string> PayloadToDictionary => Payload == null
        ? null
        : JsonSerializer.Deserialize<Dictionary<string, string>>(
            JsonSerializer.Serialize(Payload));
}

public record FcmMessage
{
    public string Type { get; set; }
    public string Title { get; set; }
    public string Body { get; set; }
    public string Action { get; set; }
}

public enum FcmNotificationType
{
    ProductsExpired = 1,
    ProductsOutOfStock = 2,
    OrderAssigned = 301,
}