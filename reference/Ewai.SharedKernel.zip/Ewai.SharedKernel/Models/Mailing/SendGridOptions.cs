namespace Ewai.SharedKernel.Models.Mailing;

/// <summary>
///     SendGridOptions.
/// </summary>
public class SendGridOptions
{
    public string ApiKey { get; set; }
    public string FromAddress { get; set; }
    public string FromDisplayName { get; set; }
}