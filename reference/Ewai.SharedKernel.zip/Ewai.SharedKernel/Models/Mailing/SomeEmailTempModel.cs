﻿namespace Ewai.SharedKernel.Models.Mailing;

/// <summary>
///     SomeEmailTempModel.
/// </summary>
public class SomeEmailTempModel
{
    public string Subject { get; set; }
    public string TemplateName { get; set; }
    public string ReceiverEmail { get; set; }
    public string ReceiverFirstName { get; set; }
    public string ReceiverLastName { get; set; }
    public string SenderFirstName { get; set; }
    public string SenderLastName { get; set; }
    public string DocumentsReviewEnglishUri { get; set; }
    public string DocumentsReviewSpanishUri { get; set; }
}