﻿namespace Ewai.SharedKernel.Models.Mailing;

/// <summary>
///     MailingOptions.
/// </summary>
public class MailingOptions
{
    public string CurrentProvider { get; set; }
    public string FromAddress { get; set; }
    public string FromDisplayName { get; set; }

    public SmtpOptions SmtpSender { get; set; }
    public SendGridOptions SendGridSender { get; set; }
}