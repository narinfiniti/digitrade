﻿namespace Ewai.SharedKernel.Enums;

/// <summary>
/// Sequential Guid Type.
/// </summary>
public enum SequentialGuidTypeEnum
{
    SequentialAsString,
    SequentialAsBinary,
    SequentialAtEnd
}