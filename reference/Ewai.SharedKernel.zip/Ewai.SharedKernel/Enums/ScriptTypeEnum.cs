﻿namespace Ewai.SharedKernel.Enums;

public enum ScriptTypeEnum
{
    Insert,
    Update,
    InsertOrUpdate,
    Delete
}