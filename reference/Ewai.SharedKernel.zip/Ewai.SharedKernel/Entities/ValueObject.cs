using System.Reflection;
using Ewai.Common.Attributes;

namespace Ewai.SharedKernel.Entities;

/// <summary>
/// Immutable domain entity type. 
/// </summary>
/// <see cref="https://docs.microsoft.com/en-us/dotnet/standard/microservices-architecture/microservice-ddd-cqrs-patterns/implement-value-objects"/>
public abstract class ValueObject : IEquatable<ValueObject>
{
    private List<PropertyInfo> _properties;
    private List<FieldInfo> _fields;

    public virtual IEnumerable<object> GetAtomicProperties()
    {
        return GetProperties();
    }

    public static bool Equals(ValueObject left, ValueObject right)
    {
        if (left is null || right is null || left.GetType() != right.GetType()) return false;

        return left.GetProperties()
                   .All(p => PropertiesAreEqual(left, right, p)) &&
               left.GetFields()
                   .All(f => FieldsAreEqual(left, right, f));
    }

    public static bool operator ==(ValueObject left, ValueObject right) => left?.Equals(right) ?? right is null;

    public static bool operator !=(ValueObject left, ValueObject right) => !(left == right);

    public virtual bool Equals(ValueObject obj) => Equals(this, obj);

    public override bool Equals(object obj)
    {
        if (obj == null || obj.GetType() != GetType())
        {
            return false;
        }

        var other = (ValueObject)obj;
        var thisValues = GetAtomicProperties().GetEnumerator();
        var otherValues = other.GetAtomicProperties().GetEnumerator();
        using IDisposable thisValues1 = thisValues;
        using IDisposable otherValues1 = otherValues;
        while (thisValues.MoveNext() && otherValues.MoveNext())
        {
            if (thisValues.Current is null ^ otherValues.Current is null)
            {
                return false;
            }

            if (thisValues.Current != null && !thisValues.Current.Equals(otherValues.Current))
            {
                return false;
            }
        }

        return !thisValues.MoveNext() && !otherValues.MoveNext();
    }

    public override int GetHashCode()
    {
        return GetAtomicProperties()
            .Select(x => x != null ? x.GetHashCode() : 0)
            .Aggregate((x, y) => x ^ y);
    }

    public ValueObject GetCopy()
    {
        return MemberwiseClone() as ValueObject;
    }

    protected static bool EqualOperator(ValueObject left, ValueObject right)
    {
        if (left is null ^ right is null)
        {
            return false;
        }

        return left != null && left.Equals(right);
    }

    protected static bool NotEqualOperator(ValueObject left, ValueObject right)
    {
        return !EqualOperator(left, right);
    }

    private static bool PropertiesAreEqual(ValueObject left, ValueObject right, PropertyInfo p)
        => Equals(p.GetValue(left, null), p.GetValue(right, null));

    private static bool FieldsAreEqual(ValueObject left, ValueObject right, FieldInfo f)
        => Equals(f.GetValue(left), f.GetValue(right));

    private IEnumerable<PropertyInfo> GetProperties()
    {
        return _properties ??= _properties = GetType()
            .GetProperties(BindingFlags.Instance | BindingFlags.Public)
            .Where(p => p.GetCustomAttribute<IgnoreMemberAttribute>() == null)
            .ToList();
    }

    private IEnumerable<FieldInfo> GetFields()
    {
        return _fields ??= _fields = GetType()
            .GetFields(BindingFlags.Instance | BindingFlags.Public)
            .Where(p => p.GetCustomAttribute<IgnoreMemberAttribute>() == null)
            .ToList();
    }
}