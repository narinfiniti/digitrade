using Ewai.SharedKernel.Interfaces;
using MediatR;

namespace Ewai.SharedKernel.Entities;

/// <summary>
/// Domain Entity abstract type.
/// </summary>
public abstract class Entity<TKey> : IEntity<TKey>, IEntity where TKey : IEquatable<TKey>
{
    private int? _hashCode;
    public List<INotification> DomainEvents { get; set; } = [];
    public void AddDomainEvent(INotification eventItem) => DomainEvents.Add(eventItem);
    public void RemoveDomainEvent(INotification eventItem) => DomainEvents.Remove(eventItem);
    public void ClearDomainEvents() => DomainEvents?.Clear();
    public bool IsTransient => Id is null || Id.Equals(default(TKey));

    public TKey Id { get; set; }

    public override bool Equals(object obj)
    {
        if (obj is not Entity<TKey> entity)
            return false;

        if (ReferenceEquals(this, obj))
            return true;

        if (GetType() != obj.GetType())
            return false;

        if (entity.IsTransient || IsTransient)
            return false;

        return Id.Equals(entity.Id);
    }

    public override int GetHashCode()
    {
        if (!IsTransient)
        {
            // XOR for random distribution
            _hashCode ??= Id.GetHashCode() ^ 31;

            return _hashCode.Value;
        }

        return base.GetHashCode();
    }

    public static bool operator ==(Entity<TKey> left, Entity<TKey> right)
    {
        return left is not null && left.Equals(right);
    }

    public static bool operator !=(Entity<TKey> left, Entity<TKey> right)
    {
        return !(left == right);
    }

    public byte[] ConcurrencyStamp { get; set; }
}