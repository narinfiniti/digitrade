﻿using System.Security.Cryptography;
using Ewai.SharedKernel.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.SharedKernel.Services;

public class SequentialGuidGenerator(RandomNumberGenerator randomNumberGenerator) : IGuidGenerator
{
    public Guid Create()
    {
        return Create(SequentialGuidTypeEnum.SequentialAtEnd);
    }

    private Guid Create(SequentialGuidTypeEnum guidType)
    {
        var randomBytes = new byte[10];
        randomNumberGenerator.GetBytes(randomBytes);

        var timestamp = DateTime.UtcNow.Ticks / 10000L;

        // Then get the bytes
        var timestampBytes = BitConverter.GetBytes(timestamp);

        // Since we're converting from an Int64, we have to reverse on
        // little-endian systems.
        if (BitConverter.IsLittleEndian)
        {
            Array.Reverse(timestampBytes);
        }

        var guidBytes = new byte[16];

        switch (guidType)
        {
            case SequentialGuidTypeEnum.SequentialAsString:
            case SequentialGuidTypeEnum.SequentialAsBinary:
                Buffer.BlockCopy(timestampBytes, 2, guidBytes, 0, 6);
                Buffer.BlockCopy(randomBytes, 0, guidBytes, 6, 10);
                if (guidType == SequentialGuidTypeEnum.SequentialAsString && BitConverter.IsLittleEndian)
                {
                    Array.Reverse(guidBytes, 0, 4);
                    Array.Reverse(guidBytes, 4, 2);
                }
                break;
            case SequentialGuidTypeEnum.SequentialAtEnd:
                Buffer.BlockCopy(randomBytes, 0, guidBytes, 0, 10);
                Buffer.BlockCopy(timestampBytes, 2, guidBytes, 10, 6);
                break;
        }

        return new Guid(guidBytes);
    }
}