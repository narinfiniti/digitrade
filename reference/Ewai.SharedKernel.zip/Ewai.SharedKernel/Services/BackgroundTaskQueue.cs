using System.Collections.Concurrent;
using Ewai.SharedKernel.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Ewai.SharedKernel.Services;

/// <summary>
/// Email template provider.
/// </summary>
public class BackgroundTaskQueue(ILogger<BackgroundTaskQueue> logger) : IBackgroundTaskQueue, IDisposable
{
    private readonly ConcurrentQueue<Func<CancellationToken, IServiceScope, Task>> _workItems = new();

    private readonly SemaphoreSlim _signal = new(0);

    //private readonly AsyncReaderWriterLock _lock = new AsyncReaderWriterLock();
    public void QueueWorkItem(
        Func<CancellationToken, IServiceScope, Task> workItem)
    {
        if (workItem == null)
        {
            throw new ArgumentNullException(nameof(workItem));
        }

        _workItems.Enqueue(workItem);
        logger.LogWarning($"Task added. Number of tasks {_workItems.Count}");
        _signal.Release();
    }

    public int GetCount()
    {
        return _workItems.Count;
    }

    public async Task<Func<CancellationToken, IServiceScope, Task>> DequeueAsync(
        CancellationToken cancellationToken)
    {
        await _signal.WaitAsync(cancellationToken);
        _workItems.TryDequeue(out var workItem);
        logger.LogWarning($"Task removed. Number of tasks {_workItems.Count}");
        return workItem;
    }

    public void Dispose()
    {
        _workItems?.Clear();
        _signal?.Dispose();
    }
}