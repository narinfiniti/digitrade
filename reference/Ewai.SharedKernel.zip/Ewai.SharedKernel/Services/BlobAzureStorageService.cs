﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Ewai.SharedKernel.Interfaces;
using Ewai.SharedKernel.Models.Configs;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Ewai.SharedKernel.Services;

public class BlobAzureStorageService<T>(
    ILogger<BlobAzureStorageService<T>> logger,
    IServiceProvider serviceProvider
) : IBlobStorageService<T> where T : AzureBlobStorage
{
    private readonly T _blobServiceClient = serviceProvider.GetRequiredService<T>();
    private readonly ILogger _logger = logger;

    public async ValueTask UploadBlobAsync(IFormFile image, string blobName, CancellationToken cancelToken = default)
    {
        await using var stream = image.OpenReadStream();
        var blobClient = (await GetContainerClient()).GetBlobClient(blobName);
        await blobClient.UploadAsync(stream, true, cancelToken);
    }

    public async ValueTask UploadBlobAsync(Stream stream, string blobName, CancellationToken cancelToken = default)
    {
        var blobClient = (await GetContainerClient()).GetBlobClient(blobName);
        await blobClient.UploadAsync(stream, true, cancelToken);
    }

    public async ValueTask<Stream> DownloadBlobAsync(string blobName, CancellationToken cancelToken = default)
    {
        var blobClient = (await GetContainerClient()).GetBlobClient(blobName);
        try
        {
            var info = await blobClient.DownloadAsync(cancelToken);
            return info.HasValue ? info.Value.Content : null;
        }
        catch (Exception e)
        {
            _logger.LogError(e, "{Message}", e.Message);
        }

        return null;
    }

    public async ValueTask RemoveBlobAsync(string blobName, CancellationToken cancelToken = default)
    {
        try
        {
            await (await GetContainerClient()).DeleteBlobIfExistsAsync(blobName, cancellationToken: cancelToken);
        }
        catch (Exception e)
        {
            _logger.LogError(e, "{Message}", e.Message);
        }
    }

    public async ValueTask RemoveBlobsAsync(IEnumerable<string> blobNames, CancellationToken cancelToken = default)
    {
        foreach (var blobName in blobNames)
        {
            await RemoveBlobAsync(blobName, cancelToken);
        }
    }

    public async ValueTask<bool> ExistsBlobAsync(string blobName, CancellationToken cancelToken = default)
    {
        var blobClient = (await GetContainerClient()).GetBlobClient(blobName);
        var res = await blobClient.ExistsAsync(cancelToken);
        return res.HasValue && res.Value;
    }

    public async ValueTask ForEachBlobAsync(Func<string, Task> action, string containerName = null,
        CancellationToken cancel = default)
    {
        var blobs = (await GetContainerClient(containerName)).GetBlobsAsync(cancellationToken: cancel);
        var enumerator = blobs.GetAsyncEnumerator(cancel);
        try
        {
            while (await enumerator.MoveNextAsync())
            {
                var blob = enumerator.Current;
                if (!blob.Deleted) await action(blob.Name);
            }
        }
        finally
        {
            await enumerator.DisposeAsync();
        }
    }

    public async ValueTask CopyBlobsAsync(string[] blobNames,
        string fromContainerName, string toContainerName, CancellationToken cancelToken = default)
    {
        var serviceClient = _blobServiceClient;
        var from = serviceClient.GetBlobContainerClient(fromContainerName);
        var to = serviceClient.GetBlobContainerClient(toContainerName);
        await to.CreateIfNotExistsAsync(cancellationToken: cancelToken);

        foreach (var blobName in blobNames)
        {
            var fromBlob = from.GetBlobClient(blobName);
            var toBlob = to.GetBlobClient(blobName);
            try
            {
                await toBlob.StartCopyFromUriAsync(new Uri(fromBlob.Uri.AbsoluteUri), cancellationToken: cancelToken);
            }
            catch (Exception)
            {
                _logger.LogWarning("No blob found url: {UriAbsoluteUri}", fromBlob.Uri.AbsoluteUri);
            }
        }
    }

    public async ValueTask CopyBlobsInHierarchyAsync(IEnumerable<string> blobNames,
        string containerName, string toFolderPath, CancellationToken cancelToken)
    {
        var serviceClient = _blobServiceClient;
        var from = serviceClient.GetBlobContainerClient(containerName);
        foreach (var blobName in blobNames)
        {
            var fromBlob = from.GetBlobClient(blobName);
            var toBlob = from.GetBlobClient($"{toFolderPath}/{blobName}");
            try
            {
                await toBlob.StartCopyFromUriAsync(fromBlob.Uri, accessTier: AccessTier.Hot,
                    cancellationToken: cancelToken);
            }
            catch (Exception)
            {
                _logger.LogWarning("No blob found url: {UriAbsoluteUri}", fromBlob.Uri.AbsoluteUri);
            }
        }
    }

    public async ValueTask CleanBlobsInHierarchyAsync(
        string fromContainerName,
        string prefix,
        string[] preserveBlobNames = null,
        CancellationToken cancellationToken = default)
    {
        var serviceClient = _blobServiceClient;
        var from = serviceClient.GetBlobContainerClient(fromContainerName);
        var blobs = from.GetBlobsAsync(prefix: prefix, cancellationToken: cancellationToken);
        await foreach (var blob in blobs)
        {
            if (preserveBlobNames?.Contains(blob.Name) != true && !blob.Deleted)
            {
                await from.DeleteBlobIfExistsAsync(blob.Name, cancellationToken: cancellationToken);
            }
        }
    }

    private async ValueTask<BlobContainerClient> GetContainerClient(string containerName = null)
    {
        containerName ??= _blobServiceClient.Options.DefaultContainerName;
        var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
        await CreateContainerIfNotExists(containerClient);
        return containerClient;
    }

    private async ValueTask CreateContainerIfNotExists(BlobContainerClient containerClient)
    {
        try
        {
            await containerClient.CreateIfNotExistsAsync();
            await containerClient.SetAccessPolicyAsync(PublicAccessType.BlobContainer);
        }
        catch (Exception e)
        {
            _logger.LogError(e, "{Message}", e.Message);
        }
    }
}