﻿using Amazon.S3;
using Ewai.SharedKernel.Interfaces;
using Ewai.SharedKernel.Models.Configs;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Ewai.SharedKernel.Services;

public class BlobAwsS3StorageService<T>(
    ILogger<BlobAwsS3StorageService<T>> logger,
    IServiceProvider serviceProvider
) : IBlobStorageService<T> where T : DefaultAwsS3Storage
{
    private const int PageLimit = 10;
    private readonly T _blobServiceClient = serviceProvider.GetRequiredService<T>();
    private readonly ILogger _logger = logger;

    public async ValueTask UploadBlobAsync(IFormFile image, string blobName, CancellationToken cancelToken = default)
    {
        await using var stream = image.OpenReadStream();
        var request = new PutObjectRequest(
            host: _blobServiceClient.Host,
            bucketName: _blobServiceClient.BucketName,
            key: blobName);
        request.SetStream(stream);
        await _blobServiceClient.PutObjectAsync(request, cancelToken);
    }

    public async ValueTask UploadBlobAsync(Stream stream, string blobName, CancellationToken cancelToken = default)
    {
        stream.Position = 0;
        var request = new PutObjectRequest(
            host: _blobServiceClient.Host,
            bucketName: _blobServiceClient.BucketName,
            key: blobName);
        request.SetStream(stream);
        await _blobServiceClient.PutObjectAsync(request, cancelToken);
    }

    public async ValueTask<Stream> DownloadBlobAsync(string blobName, CancellationToken cancelToken = default)
    {
        var request = new GetObjectRequest(
            host: _blobServiceClient.Host,
            bucketName: _blobServiceClient.BucketName,
            key: blobName);
        using var response = await _blobServiceClient.GetObjectAsync(request, cancelToken);
        return await response.OpenAsync();
    }

    public async ValueTask RemoveBlobAsync(string blobName, CancellationToken cancelToken = default)
    {
        try
        {
            var request = new DeleteObjectRequest(
                host: _blobServiceClient.Host,
                bucketName: _blobServiceClient.BucketName,
                key: blobName);
            await _blobServiceClient.DeleteObjectAsync(request, cancelToken);
        }
        catch (Exception e)
        {
            _logger.LogError(e, "{Message}", e.Message);
        }
    }

    public async ValueTask RemoveBlobsAsync(IEnumerable<string> blobNames, CancellationToken cancelToken = default)
    {
        foreach (var blobName in blobNames)
        {
            await RemoveBlobAsync(blobName, cancelToken);
        }
    }

    public async ValueTask<bool> ExistsBlobAsync(string blobName, CancellationToken cancelToken = default)
    {
        try
        {
            var request = new ObjectHeadRequest(
                host: _blobServiceClient.Host,
                bucketName: _blobServiceClient.BucketName,
                key: blobName);
            var result = await _blobServiceClient.GetObjectHeadAsync(request, cancelToken);
            return result.ContentLength > 0;
        }
        catch (Exception e)
        {
            _logger.LogError(e, "{Message}", e.Message);
        }

        return false;
    }

    public async ValueTask ForEachBlobAsync(Func<string, Task> action, string containerName = null,
        CancellationToken cancel = default)
    {
        string continuationToken = null;
        while (true)
        {
            var options = new ListBucketOptions
            {
                MaxKeys = PageLimit,
                ContinuationToken = continuationToken
            };

            var result = await _blobServiceClient.ListBucketAsync(_blobServiceClient.BucketName, options);
            if (result?.Items == null || result.Items.Length == 0) break;

            foreach (var item in result.Items)
            {
                // Optional: filter folders if needed (e.g., by checking if Name ends with '/')
                if (!item.Key.EndsWith("/")) // assuming folders are marked with '/'
                {
                    try
                    {
                        await action(item.Key);
                    }
                    catch (Exception e)
                    {
                        _logger.LogError(e, "{Message}", e.Message);
                    }
                }
            }

            if (!result.IsTruncated) break;
            continuationToken = result.NextContinuationToken;
        }
    }

    public async ValueTask CopyBlobsAsync(string[] blobNames,
        string fromContainerName, string toContainerName, CancellationToken cancelToken = default)
    {
        foreach (var blobName in blobNames)
        {
            if (string.Equals(fromContainerName, toContainerName)) continue;
            try
            {
                var fromBlobName = $"{fromContainerName}/{blobName}";
                var source = new S3ObjectLocation(_blobServiceClient.BucketName, fromBlobName);

                var toBlobName = $"{toContainerName}/{blobName}";
                var destination = new S3ObjectLocation(_blobServiceClient.BucketName, toBlobName);

                var request = new CopyObjectRequest(_blobServiceClient.Host, source, destination);
                var res = await _blobServiceClient.CopyObjectAsync(request);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "{Message}", e.Message);
            }
        }
    }

    public async ValueTask CopyBlobsInHierarchyAsync(IEnumerable<string> blobNames,
        string containerName, string toFolderPath, CancellationToken cancelToken)
    {
        foreach (var blobName in blobNames)
        {
            try
            {
                var fromBlobName = $"{containerName}/{blobName}";
                var source = new S3ObjectLocation(_blobServiceClient.BucketName, fromBlobName);

                var toBlobName = $"{containerName}/{toFolderPath}/{blobName}";
                var destination = new S3ObjectLocation(_blobServiceClient.BucketName, toBlobName);

                var request = new CopyObjectRequest(_blobServiceClient.Host, source, destination);
                var res = await _blobServiceClient.CopyObjectAsync(request);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "{Message}", e.Message);
            }
        }
    }

    public async ValueTask CleanBlobsInHierarchyAsync(
        string fromContainerName,
        string prefix,
        string[] preserveBlobNames = null,
        CancellationToken cancellationToken = default)
    {
        string continuationToken = null;
        while (true)
        {
            var options = new ListBucketOptions
            {
                MaxKeys = PageLimit,
                ContinuationToken = continuationToken,
                Prefix = $"{fromContainerName}/{prefix}"
            };

            var result = await _blobServiceClient.ListBucketAsync(_blobServiceClient.BucketName, options);
            if (result?.Items == null || result.Items.Length == 0) break;

            try
            {
                var keys = result.Items
                    .Where(e => !e.Key.EndsWith("/") && preserveBlobNames?.Contains(e.Key) != true)
                    .Select(e => e.Key)
                    .ToArray();
                var batch = new DeleteBatch(keys, true);
                var request = new DeleteObjectsRequest(
                    _blobServiceClient.Host,
                    _blobServiceClient.BucketName,
                    batch);
                await _blobServiceClient.DeleteObjectsAsync(request);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "{Message}", e.Message);
            }

            if (!result.IsTruncated) break;
            continuationToken = result.NextContinuationToken;
        }
    }
}