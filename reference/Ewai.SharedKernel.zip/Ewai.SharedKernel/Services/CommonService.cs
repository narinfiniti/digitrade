#nullable enable
using System.Globalization;
using System.Net;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using CsvHelper;
using CsvHelper.Configuration;
using Ewai.Common.Models;
using Ewai.SharedKernel.Interfaces;
using Ewai.SharedKernel.Models.Configs;
using FileSignatures;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using PhoneNumbers;

namespace Ewai.SharedKernel.Services;

/// <summary>
/// Shared common service.
/// </summary>
public class CommonService(
    PhoneNumberUtil phoneNumberUtil,
    IFileFormatInspector fileFormatInspector,
    IHostEnvironment env,
    IConfiguration config) : ICommonService
{
    private readonly IHostEnvironment _env = env;
    private readonly IConfiguration _config = config;
    private readonly SHA256 _sha256 = SHA256.Create();
    private readonly Random _random = new();

    public async Task<string> GetCsvAsync<T>(List<T> users, string delimiter = "|")
    {
        await using var ms = new MemoryStream();
        await using (var writer = new StreamWriter(ms))
        await using (var csv = new CsvWriter(writer,
                         new CsvConfiguration(CultureInfo.InvariantCulture) { Delimiter = delimiter }))
        {
            await csv.WriteRecordsAsync(users);
        }

        return Encoding.UTF8.GetString(ms.ToArray());
    }

    public ValueTask<string> GetPhoneNumberCountryAsync(string phoneNumber)
    {
        var parsedPhoneNumber = phoneNumberUtil.Parse(phoneNumber, null);
        var code = phoneNumberUtil.GetRegionCodeForNumber(parsedPhoneNumber);
        return ValueTask.FromResult(code);
    }

    public bool IsValidPhoneNumber(string phoneNumber)
    {
        var parsedPhoneNumber = phoneNumberUtil.Parse(phoneNumber, null);
        return phoneNumberUtil.IsValidNumber(parsedPhoneNumber);
    }

    public bool IsValidEmail(string email)
    {
        const string regex = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
        return Regex.IsMatch(email, regex);
    }

    public bool IsValidIpAddress(string ipAddressString)
    {
        const string ipv4SegmentRegex = "(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)";
        // Check if the string matches the pattern of a valid IPv4 or IPv6 address
        const string ipv4Regex = $"@\"^{ipv4SegmentRegex}.{ipv4SegmentRegex}.{ipv4SegmentRegex}.{ipv4SegmentRegex}$\"";
        if (Regex.IsMatch(ipAddressString, ipv4Regex)
            || IPAddress.TryParse(ipAddressString, out var _))
        {
            return true;
        }

        return false;
    }

    public string GetRandomPassword(int letterSize, int digitLength, bool lowerCase = false)
    {
        var rnd = new Random();
        var builder = new StringBuilder(digitLength + letterSize);
        var offset = lowerCase ? 'a' : 'A';
        const int lettersOffset = 26; // A...Z or a..z: length = 26
        for (var i = 0; i < letterSize; i++)
        {
            var @char = (char)rnd.Next(offset, offset + lettersOffset);
            builder.Append(@char);
        }

        if (digitLength > 0)
        {
            builder.Append(rnd.Next(0, (int)Math.Pow(10, digitLength)).ToString($"D{digitLength}"));
        }

        return lowerCase ? builder.ToString().ToLower() : builder.ToString();
    }

    public string GetFileExtension(Stream stream)
    {
        var fileFormat = fileFormatInspector.DetermineFileFormat(stream);
        if (fileFormat == null) return string.Empty;
        return $".{fileFormat.Extension}";
    }

    public async Task SaveFileToLocal(string path,
        Stream memoryStream, string fileName,
        CancellationToken cancellationToken)
    {
        var filePath = Path.Combine(path, fileName);
        if (File.Exists(filePath))
        {
            return;
        }

        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }

        await using var fileStream = File.Create(filePath);
        await memoryStream.CopyToAsync(fileStream, cancellationToken);
    }

    public async Task<Stream?> GetFileFromLocal(
        string path,
        string fileName, CancellationToken cancel)
    {
        var filePath = Path.Combine(path, fileName);
        if (!File.Exists(filePath))
        {
            return default;
        }

        return new MemoryStream(await File.ReadAllBytesAsync(filePath, cancel));
    }

    public void DeleteFileFromLocal(string path, string fileName)
    {
        var filePath = Path.Combine(path, fileName);
        if (File.Exists(filePath))
        {
            File.Delete(filePath);
        }
    }


    public string GenerateRandomNumberString(int length)
    {
        return string.Concat(Enumerable.Range(0, length).Select(_ => _random.Next(0, 10).ToString()));
    }

    public async Task DownloadToLocal(
        string path,
        IBlobStorageService<DefaultAwsS3Storage> blobService,
        string fileName)
    {
        var filePath = Path.Combine(path, fileName);
        if (File.Exists(filePath))
        {
            return;
        }

        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }

        await using var fileStream = File.Create(filePath);
        await using var stream = await blobService.DownloadBlobAsync(fileName);
        if (stream is not null) await stream.CopyToAsync(fileStream);
    }

    public DateTime ConvertToSpecificTimeZone(DateTime dateTime, string zoneId)
    {
        TimeZoneInfo zone;
        try
        {
            zone = TimeZoneInfo.FindSystemTimeZoneById(zoneId);
        }
        catch (Exception)
        {
            var defaultZoneId = "Arabian Standard Time";
            zone = TimeZoneInfo.FindSystemTimeZoneById(defaultZoneId);
        }

        return TimeZoneInfo.ConvertTimeFromUtc(dateTime, zone);
    }

    public string GenerateDeleteSql(object entity,
        string schema = "app",
        string? tableName = null)
    {
        var entityType = entity.GetType();
        var properties = entityType.GetProperties();

        tableName ??= $"[{schema}].[{entityType.Name}]";
        var idProperty = entityType.GetProperty("Id", BindingFlags.Instance | BindingFlags.Public);
        string condition;
        if (idProperty == null)
        {
            condition = "[" + string.Join(" AND [", properties
                .Where(p => IsPrimitiveType(p.PropertyType))
                .Select(p => p.Name + "] " + $"{GetSqlCondition(p.GetValue(entity))}"));
        }
        else
        {
            condition = $"[Id]={GetSqlValue(idProperty.GetValue(entity))}";
        }

        var sql = new StringBuilder();
        sql.Append($"DELETE FROM {tableName} WHERE {condition}");
        return sql.ToString();
    }

    public IEnumerable<string> GenerateDeleteSql(
        IEnumerable<object> entities, string schema = "app", int length = 4000,
        string? tableName = null)
    {
        return entities.Select(entity => GenerateDeleteSql(entity, schema, tableName));
    }

    public string GenerateUpdateSql(object entity,
        string schema = "app",
        string? tableName = null)
    {
        var entityType = entity.GetType();
        var properties = entityType.GetProperties();

        tableName ??= $"[{schema}].[{entityType.Name}]";
        var idProperty = entityType.GetProperty("Id", BindingFlags.Instance | BindingFlags.Public);
        if (idProperty == null)
        {
            return string.Empty;
        }

        var condition = $"[Id]={GetSqlValue(idProperty.GetValue(entity))}";
        var sql = new StringBuilder();
        GenerateUpdateScript(entity, sql, tableName, properties, condition);
        return sql.ToString();
    }

    public string GenerateInsertOrUpdateSql(object entity,
        string schema = "app",
        string? tableName = null,
        bool needUpdate = true)
    {
        var entityType = entity.GetType();
        var properties = entityType.GetProperties();

        tableName ??= $"[{schema}].[{entityType.Name}]";
        var idProperty = entityType.GetProperty("Id", BindingFlags.Instance | BindingFlags.Public);
        string condition;
        if (idProperty == null)
        {
            condition = "[" + string.Join(" AND [", properties
                .Where(p => IsPrimitiveType(p.PropertyType))
                .Select(p => p.Name + "] " + $"{GetSqlCondition(p.GetValue(entity))}"));
        }
        else
        {
            condition = $"[Id]={GetSqlValue(idProperty.GetValue(entity))}";
        }

        var sql = new StringBuilder();
        var on = $"SET IDENTITY_INSERT {tableName} ON;\r\n";
        var off = $"SET IDENTITY_INSERT {tableName} OFF;";
        if (idProperty is null || idProperty.PropertyType == typeof(Guid))
        {
            on = off = string.Empty;
        }

        sql.Append(on);
        needUpdate = needUpdate && idProperty != null;
        GenerateScript(entity, sql, tableName, properties, condition, needUpdate);
        sql.Append(off);

        return sql.ToString();
    }

    public IEnumerable<string> GenerateInsertOrUpdateSql(IEnumerable<object> entities,
        string schema = "app",
        int length = 4000,
        string? tableName = null,
        bool needUpdate = true)
    {
        var items = entities.ToArray();
        if (!items.Any()) yield break;
        var entityType = items.First().GetType();
        tableName ??= $"[{schema}].[{entityType.Name}]";
        var properties = entityType.GetProperties();
        var idProperty = entityType.GetProperty("Id", BindingFlags.Instance | BindingFlags.Public);
        var on = $"SET IDENTITY_INSERT {tableName} ON;\r\n";
        var off = $"SET IDENTITY_INSERT {tableName} OFF;";

        if (idProperty == null || idProperty.PropertyType == typeof(Guid))
        {
            on = off = string.Empty;
        }

        length -= off.Length;

        var sql = new StringBuilder(on);
        foreach (var entity in items)
        {
            var temp = new StringBuilder();
            string condition;
            if (idProperty == null)
            {
                condition = "[" + string.Join(" AND [", properties
                    .Where(p => IsPrimitiveType(p.PropertyType))
                    .Select(p => p.Name + "] " + $"{GetSqlCondition(p.GetValue(entity))}"));
            }
            else
            {
                condition = $"[Id]={GetSqlValue(idProperty.GetValue(entity))}";
            }

            needUpdate = needUpdate && idProperty != null;
            GenerateScript(entity, temp, tableName, properties, condition, needUpdate);
            if (sql.Length + temp.Length > length)
            {
                sql.Append(off);
                yield return sql.ToString();
                sql = new StringBuilder(on);
            }

            sql.Append(temp);
        }

        sql.Append(off);
        if (sql.Length > on.Length + off.Length)
        {
            yield return sql.ToString();
        }
    }

    public Guid GenerateIdFromBarcode(string barcode)
    {
        var combinedData = "Barcode_" + barcode;
        var hashBytes = _sha256.ComputeHash(Encoding.UTF8.GetBytes(combinedData));
        return new Guid(hashBytes.Take(16).ToArray());
    }

    private void GenerateScript(object entity, StringBuilder sql, string tableName,
        PropertyInfo[] properties, string condition, bool needUpdate = true)
    {
        sql.Append($"IF NOT EXISTS(SELECT 1 FROM {tableName} WHERE {condition})");
        sql.Append($"INSERT INTO {tableName}([");
        sql.Append(string.Join(",[", properties
            .Where(p => IsPrimitiveType(p.PropertyType))
            .Select(p => p.Name + "]")));
        sql.Append(")VALUES(");
        sql.Append(string.Join(",", properties
            .Where(p => IsPrimitiveType(p.PropertyType))
            .Select(p => $"{GetSqlValue(p.GetValue(entity))}")));
        sql.Append(")");
        if (!needUpdate) return;
        {
            sql.Append("ELSE");
            sql.Append($" UPDATE {tableName} SET ");
            sql.Append(string.Join(",",
                properties.Where(p => p.Name != "Id")
                    .Where(p => IsPrimitiveType(p.PropertyType))
                    .Select(p => $"[{p.Name}] = {GetSqlValue(p.GetValue(entity))}")));
            sql.Append($" WHERE {condition}\r\n");
        }
    }

    private void GenerateUpdateScript(object entity, StringBuilder sql, string tableName,
        PropertyInfo[] properties, string condition)
    {
        sql.Append($"UPDATE {tableName} SET ");
        sql.Append(string.Join(",",
            properties.Where(p => p.Name != "Id")
                .Where(p => IsPrimitiveType(p.PropertyType))
                .Select(p => $"[{p.Name}] = {GetSqlValue(p.GetValue(entity))}")));
        sql.Append($" WHERE {condition}\r\n");
    }

    private string? GetSqlValue(object? value)
    {
        return value switch
        {
            null => "NULL",
            string or JsonNode or Guid or Items<string> => $"N'{value.ToString()?.Replace("'", "''")}'",
            DateTime => $"'{Convert.ToDateTime(value):O}'",
            bool b => b ? "1" : "0",
            Enum e => Convert.ToByte(e).ToString(),
            _ => value.ToString()
        };
    }

    private string GetSqlCondition(object? value)
    {
        return GetSqlValue(value) switch
        {
            null => "IS NULL",
            _ => $"={GetSqlValue(value)}"
        };
    }

    private static bool IsPrimitiveType(Type type)
    {
        // Check for commonly used primitive types
        if (type == typeof(JsonNode) ||
            type == typeof(Items<string>) ||
            type.BaseType == typeof(ValueType) ||
            type.BaseType?.BaseType == typeof(ValueType) ||
            type == typeof(string))
        {
            return true;
        }

        // Check for nullable versions of primitive types
        var underlyingType = Nullable.GetUnderlyingType(type);
        return underlyingType != null && IsPrimitiveType(underlyingType);
    }

    public async Task<bool> IsInternetConnected(string host = "google.com", ushort port = 80, int timeout = 200)
    {
        try
        {
            var connectTask = Task.Run(() =>
            {
                using var ping = new Ping();
                var buffer = new byte[32];
                var reply = ping.Send(host, timeout, buffer, new PingOptions());
                return reply is { Status: IPStatus.Success };
            });

            var task = await Task.WhenAny(connectTask, Task.Delay(timeout));
            await task;
            return task == connectTask;
        }
        catch (Exception)
        {
            return false;
        }
    }

    public bool IsDesktopConnected()
    {
        return true;
    }

    public void Dispose()
    {
        _sha256.Dispose();
    }
}