﻿using System.Reflection;
using Ewai.Common.Exceptions;
using Ewai.Common.Extensions;
using Ewai.SharedKernel.Interfaces;
using Ewai.SharedKernel.Models.Mailing;
using FluentEmail.Core;
using FluentEmail.Core.Interfaces;
using FluentEmail.Core.Models;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Ewai.SharedKernel.Services;

/// <summary>
/// MailingService.
/// </summary>
public class MailingService(
    IBackgroundTaskQueue taskQueue
) : IMailingService
{
    public ValueTask SendEmailAsync(
        string toEmail,
        string subject,
        string textOrTemplateName,
        dynamic model,
        string fromEmail = null,
        Attachment[] attachments = null,
        CancellationToken cancellation = default)
    {
        taskQueue.QueueWorkItem((cancel, scope) =>
        {
            var sp = scope.ServiceProvider;

            var logger = sp.GetRequiredService<ILogger<MailingService>>();
            var retryPolicyService = sp.GetRequiredService<PollyRetryPolicyService>();
            var options = sp.GetRequiredService<MailingOptions>();

            var emailClient = sp.GetRequiredService<IFluentEmail>();
            emailClient.Renderer = sp.GetRequiredService<ITemplateRenderer>();
            emailClient.Sender = sp.GetServices<ISender>()
                .First(x => x.GetType().Name == options.CurrentProvider);

            return SendAsync(options,
                emailClient, retryPolicyService, logger,
                toEmail, subject, textOrTemplateName, model, fromEmail, attachments, cancel);
        });
        return ValueTask.CompletedTask;
    }

    private async ValueTask<SendResponse> SendAsync(MailingOptions options,
        IFluentEmail emailClient, PollyRetryPolicyService retryPolicyService, ILogger logger,
        string toEmail,
        string subject,
        string textOrTemplateName,
        dynamic model,
        string fromEmail = null,
        Attachment[] attachments = null,
        CancellationToken cancellation = default)
    {
        emailClient.Data.ToAddresses.Clear();
        emailClient
            .SetFrom(fromEmail ?? options.FromAddress, options.FromDisplayName)
            .To(toEmail)
            .Subject(subject);
        if (textOrTemplateName.IsNotEmpty())
        {
            if (textOrTemplateName.EndsWith(".cshtml") ||
                textOrTemplateName.EndsWith(".html"))
            {
                var templateContent = await GetTemplateContent(logger, textOrTemplateName, model, cancellation);
                emailClient.UsingTemplate(templateContent, model, true);
            }
            else
            {
                emailClient.Body(textOrTemplateName);
            }
        }

        if (attachments?.Length > 0)
        {
            emailClient.Attach(attachments);
        }

        var res = await retryPolicyService.RetryAsync(() => emailClient.SendAsync(cancellation));
        if (!res.Successful)
        {
            throw new ValidationException(res.ErrorMessages.FirstOrDefault());
        }

        return res;
    }

    private async ValueTask<string> GetTemplateContent(ILogger logger,
        string textOrTemplateName, dynamic model, CancellationToken cancellation)
    {
        try
        {
            var assembly = model != null
                ? ((Type)model.GetType()).GetTypeInfo().Assembly
                : Assembly.GetExecutingAssembly();
            var fullName = assembly.GetManifestResourceNames()
                .FirstOrDefault(r => r.Contains($".{textOrTemplateName}", StringComparison.InvariantCultureIgnoreCase));
            if (fullName == null) return null;

            await using var stream = assembly.GetManifestResourceStream(fullName);
            if (stream == null) return null;
            using var reader = new StreamReader(stream);
            return await reader.ReadToEndAsync(cancellation);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, ex.Message);
            return null;
        }
    }
}