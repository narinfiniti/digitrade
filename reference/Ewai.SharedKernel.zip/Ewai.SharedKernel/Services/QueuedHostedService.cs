using Ewai.SharedKernel.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Ewai.SharedKernel.Services;

/// <summary>
/// Queued Hosted Service.
/// </summary>
public class QueuedHostedService(
    IServiceScopeFactory factory,
    ILogger<QueuedHostedService> logger,
    IBackgroundTaskQueue taskQueue)
    : BackgroundService
{
    private readonly ILogger _logger = logger;


    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Background Hosted Service is running.");

        await BackgroundProcessing(stoppingToken);
    }

    private async ValueTask BackgroundProcessing(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            var workItem = await taskQueue.DequeueAsync(stoppingToken);
            var scopeFactory = factory;
            var scope = scopeFactory?.CreateScope();
            try
            {
                if (workItem != null) await workItem.Invoke(stoppingToken, scope);
            }
            catch (Exception ex)
            {
                var logger = scope?.ServiceProvider.GetService<ILogger<QueuedHostedService>>();
                logger?.LogError(
                    $"Exception.Message: {ex.Message}\n{ex.StackTrace}\n{ex.InnerException?.StackTrace}");
            }
            finally
            {
                scope?.Dispose();
            }
        }
    }

    public override async Task StopAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Queued Hosted Service is stopping.");

        await base.StopAsync(stoppingToken);
    }
}