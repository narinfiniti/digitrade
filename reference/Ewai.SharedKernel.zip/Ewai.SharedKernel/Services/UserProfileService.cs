using System.Security.Claims;
using Ewai.SharedKernel.Interfaces;
using Microsoft.AspNetCore.Http;

namespace Ewai.SharedKernel.Services;

/// <summary>
/// User identity or profile representation.
/// </summary>
public class UserProfileService(IHttpContextAccessor context) : IUserProfileService
{
    private readonly IHttpContextAccessor _contextAccessor = context ?? throw new ArgumentNullException(nameof(context));
    private const string TenantAdmin = "TENANT_ADMIN";
    private const string BranchAdmin = "BRANCH_ADMIN";

    private const string SystemAdmin = "SYSTEM_ADMIN";
    private const string SystemManager = "SYSTEM_MANAGER";
    private const string SystemOperator = "SYSTEM_OPERATOR";

    public bool IsAuthenticatedUser() => GetPrincipal()?.Identity?.IsAuthenticated == true;

    public bool IsBranchUser()
    {
        var (userId, _, branchId, _) = GetUserIdRolesBranchIdTenantId();
        if (userId == null) return false;
        return branchId != null;
    }

    public bool IsBranchAdmin()
    {
        var (userId, roles, branchId, _) = GetUserIdRolesBranchIdTenantId();
        if (userId == null) return false;
        return branchId != null && roles?.Contains(BranchAdmin) == true;
    }

    public bool IsTenantUser()
    {
        var (userId, _, branchId, tenantId) = GetUserIdRolesBranchIdTenantId();
        if (userId == null) return false;
        return branchId == null && tenantId != null;
    }

    public bool IsTenantAdmin()
    {
        var (userId, roles, branchId, tenantId) = GetUserIdRolesBranchIdTenantId();
        if (userId == null) return false;
        return branchId == null && tenantId != null && roles?.Contains(TenantAdmin) == true;
    }

    public bool IsSystemUser()
    {
        var (userId, _, branchId, tenantId) = GetUserIdRolesBranchIdTenantId();
        if (userId == null) return false;
        return branchId == null && tenantId == null;
    }

    public bool IsSystemAdmin()
    {
        var (userId, roles, branchId, tenantId) = GetUserIdRolesBranchIdTenantId();
        if (userId == null) return false;
        return branchId == null && tenantId == null && roles?.Contains(SystemAdmin) == true;
    }

    public bool IsSystemManager()
    {
        var (userId, roles, branchId, tenantId) = GetUserIdRolesBranchIdTenantId();
        if (userId == null) return false;
        return branchId == null && tenantId == null && roles?.Contains(SystemManager) == true;
    }

    public bool IsSystemOperator()
    {
        var (userId, roles, branchId, tenantId) = GetUserIdRolesBranchIdTenantId();
        if (userId == null) return false;
        return branchId == null && tenantId == null && roles?.Contains(SystemOperator) == true;
    }

    public string GetUserName() => GetIdentity(type: "username");

    public Guid? GetUserId(ClaimsPrincipal principal = null)
    {
        return Guid.TryParse(GetIdentity(principal, ClaimTypes.NameIdentifier), out var userId)
               && userId != Guid.Empty
            ? userId
            : null;
    }

    public string[] GetUserRoles() => GetIdentity(type: ClaimTypes.Role)?.Split(",", StringSplitOptions.TrimEntries);

    public Guid? GetBranchId(ClaimsPrincipal principal = null)
    {
        return Guid.TryParse(GetIdentity(principal, "branch_id"), out var branchId)
               && branchId != Guid.Empty
            ? branchId
            : null;
    }

    public Guid? GetTenantId(ClaimsPrincipal principal = null)
    {
        return Guid.TryParse(GetIdentity(principal, "tenant_id"), out var tenantId)
               && tenantId != Guid.Empty
            ? tenantId
            : null;
    }

    // In case we need to use user-id, roles, branch-id and tenant-id.
    public (Guid?, string[], Guid?, Guid?) GetUserIdRolesBranchIdTenantId(ClaimsPrincipal principal = null)
    {
        principal = GetPrincipal(principal);
        return (
            GetUserId(principal),
            GetIdentity(principal, ClaimTypes.Role)?.Split(",", StringSplitOptions.TrimEntries),
            GetBranchId(principal),
            GetTenantId(principal)
        );
    }

    #region Private

    private string GetIdentity(ClaimsPrincipal principal = null, string type = null) =>
        GetPrincipal(principal)?.FindFirst(type!)?.Value;

    private ClaimsPrincipal GetPrincipal(ClaimsPrincipal principal = null) =>
        principal ?? _contextAccessor.HttpContext?.User;

    #endregion
}