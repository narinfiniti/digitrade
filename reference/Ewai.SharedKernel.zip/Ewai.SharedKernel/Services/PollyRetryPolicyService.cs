using Polly;
using Polly.Caching;

namespace Ewai.SharedKernel.Services;

/// <summary>
///     PollyPolicyService.
/// </summary>
public class PollyRetryPolicyService
{
    //private IServiceProvider _serviceProvider;

    public readonly Func<double, double, Func<int, TimeSpan>> GetDefaultSleepDurationProvider =
        (periodSec, maxPeriodSec) =>
            retryCount =>
            {
                if (retryCount <= 3)
                    // 3 times with the 3-sec period.
                    periodSec = 3;
                else if (periodSec < maxPeriodSec)
                    // period is increased in accordance with the formula.
                    periodSec += 70 + retryCount * Math.Pow(10, 1.12) - 4;
                else if (periodSec >= maxPeriodSec)
                    // every 4 hrs until the maximum number of attempts is reached.
                    periodSec = maxPeriodSec;
                return TimeSpan.FromSeconds(periodSec);
            };

    public async Task<TResult> ExecuteAsync<TResult>(
        IAsyncPolicy<TResult>[] policyList,
        Func<Context, CancellationToken, Task<TResult>> action,
        Context context,
        CancellationToken cancellationToken = default)
    {
        var n = policyList.Length;
        if (n == 0) return default;
        var policyChain = policyList[0];
        for (var i = 1; i < n; ++i)
        {
            var item = policyList[i];
            policyChain = policyChain.WrapAsync(item);
        }

        return await policyChain
            .ExecuteAsync(action, context, cancellationToken)
            .ConfigureAwait(false);
    }

    public IAsyncPolicy<TResult> GetRetryPolicyOnResult<TException, TResult>(
        int retryCount = 120,
        double minPeriodSec = 10.0,
        double maxPeriodSec = 4 * 60 * 60,
        Func<TResult, bool> retryOnResultPredicate = null,
        Func<int, TimeSpan> sleepDurationProvider = null,
        Action<DelegateResult<TResult>, TimeSpan, int, Context> onRetry = null
    ) where TException : Exception
    {
        sleepDurationProvider ??= GetDefaultSleepDurationProvider(minPeriodSec, maxPeriodSec);
        return Policy
            .Handle<TException>()
            .OrInner<TException>()
            .OrResult(retryOnResultPredicate ?? (res => false))
            .WaitAndRetryAsync(
                retryCount,
                sleepDurationProvider,
                (exception, sleepDuration, attemptNumber, context) =>
                    onRetry?.Invoke(exception, sleepDuration, attemptNumber, context));
    }

    public IAsyncPolicy<TResult> GetCachePolicyForResult<TResult>(
        IAsyncCacheProvider<TResult> cacheProvider,
        TimeSpan ttl,
        Func<Context, string> cacheKeyStrategy,
        Action<Context, string, Exception> onCacheError = null
    )
    {
        return Policy
            .CacheAsync(cacheProvider, ttl, cacheKeyStrategy, onCacheError);
    }

    public IAsyncPolicy<TResult> GetFallbackPolicyForResult<TException, TResult>(
        Func<TResult, bool> resultPredicate = null,
        Func<DelegateResult<TResult>, Context, CancellationToken, Task<TResult>> fallbackAction = null,
        Func<DelegateResult<TResult>, Context, Task> onFallbackAsync = null
    ) where TException : Exception
    {
        fallbackAction ??= (dr, ctx, token) => Task.FromResult(default(TResult));
        onFallbackAsync ??= (dr, ctx) => Task.CompletedTask;
        return Policy
            .Handle<TException>()
            .OrResult(resultPredicate ?? (res => false))
            .FallbackAsync(fallbackAction, onFallbackAsync);
    }

    public IAsyncPolicy GetRetryPolicy<TException>(
        int retryCount,
        double minPeriodSec,
        double maxPeriodSec,
        Func<int, TimeSpan> sleepDurationProvider = null
    ) where TException : Exception
    {
        var periodSec = minPeriodSec;

        if (sleepDurationProvider == null)
            sleepDurationProvider = GetDefaultSleepDurationProvider(minPeriodSec, maxPeriodSec);

        return Policy
            .Handle<TException>()
            .OrInner<TException>()
            .WaitAndRetryAsync(retryCount, sleepDurationProvider);
    }

    public Task<T> RetryAsync<T>(Func<Task<T>> action,
        int retryCount = 3, TimeSpan? timeout = null, Func<int, TimeSpan> sleepDurationProvider = null)
    {
        timeout ??= Timeout.InfiniteTimeSpan;
        sleepDurationProvider ??= i => TimeSpan.FromSeconds(2);
        var timeoutPolicy = Policy.TimeoutAsync(timeout.Value);
        var retryPolicy = Policy
            .Handle<Exception>()
            .OrInner<Exception>()
            .WaitAndRetryAsync(retryCount, sleepDurationProvider);
        var combinedPolicy = timeoutPolicy.WrapAsync(retryPolicy);
        return combinedPolicy.ExecuteAsync(action);
    }
}