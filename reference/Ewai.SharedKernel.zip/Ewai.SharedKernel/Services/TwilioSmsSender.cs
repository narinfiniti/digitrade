﻿using Ewai.Common.Exceptions;
using Ewai.SharedKernel.Interfaces;
using Ewai.SharedKernel.Models;
using Microsoft.Extensions.Options;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace Ewai.SharedKernel.Services;

public sealed class TwilioSmsSender : ISmsSender
{
    private readonly PollyRetryPolicyService _retryPolicyService;
    private readonly ICommonService _commonService;
    private static bool _isTwilioClientInitialized;
    private static readonly object SyncLock = new();

    public TwilioSmsSender(
        PollyRetryPolicyService retryPolicyService,
        ICommonService commonService,
        IOptions<TwilioSmsOptions> options
    )
    {
        _retryPolicyService = retryPolicyService;
        _commonService = commonService;
        Options = options.Value;
        InitTwilioClientIfNeeds();
    }

    private TwilioSmsOptions Options { get; }

    public Task SendAsync(TwilioSmsMessage smsMessage)
    {
        if (!_commonService.IsValidPhoneNumber(smsMessage.PhoneNumber))
        {
            throw new ValidationException($"Invalid phone: {smsMessage.PhoneNumber}");
        }
        var text = smsMessage.Text;
        return _retryPolicyService.RetryAsync(() => MessageResource
            .CreateAsync(new PhoneNumber(smsMessage.PhoneNumber),
                from: new PhoneNumber(Options.FromNumber),
                body: text));
    }

    private void InitTwilioClientIfNeeds()
    {
        if (_isTwilioClientInitialized)
            return;
        lock (SyncLock)
        {
            if (_isTwilioClientInitialized)
                return;
            CheckConfiguration();
            TwilioClient.Init(Options.AccountSId, Options.AuthToken);
            _isTwilioClientInitialized = true;
        }
    }

    private void CheckConfiguration()
    {
        CheckOptionNotNullOrWhiteSpace(Options.FromNumber, "FromNumber");
        CheckOptionNotNullOrWhiteSpace(Options.AccountSId, "AccountSId");
        CheckOptionNotNullOrWhiteSpace(Options.AuthToken, "AuthToken");
    }

    private void CheckOptionNotNullOrWhiteSpace(string option, string optionName)
    {
        if (string.IsNullOrWhiteSpace(option))
            throw new ArgumentNullException(optionName + " option was not configured! Use TwilioSmsOptions.");
    }
}