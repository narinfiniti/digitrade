using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Ewai.SharedKernel.Interfaces;
using Ewai.SharedKernel.Models;
using QRCoder;

namespace Ewai.SharedKernel.Services;

/// <summary>
/// Shared common service.
/// </summary>
public class QrCodeService : IQrCodeService
{
    private readonly RSA _privateKey;
    private readonly RSA _publicKey;
    public byte[] GetQrCodeBytes(string input)
    {
        // Step 4: Generate the QR code from the final payload
        using var qrGenerator = new QRCodeGenerator();
        using var qrCodeData = qrGenerator.CreateQrCode(input, QRCodeGenerator.ECCLevel.Q);
        using var qrCode = new BitmapByteQRCode(qrCodeData);
        return qrCode.GetGraphic(20);
    }

    public string SignData(QrDataModel qrData)
    {
        // Step 1: Serialize the core data
        var options = new JsonSerializerOptions { WriteIndented = false }; // Compact JSON
        var jsonData = JsonSerializer.Serialize(qrData, options);
        var jsonDataBytes = Encoding.UTF8.GetBytes(jsonData);

        // Step 2: Sign the data with the private key
        var signatureBytes =
            _privateKey.SignData(jsonDataBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        var signatureBase64 = Convert.ToBase64String(signatureBytes);

        // Step 3: Create the final payload including data and signature
        var payload = new QrPayloadModel
        {
            Data = qrData,
            Signature = signatureBase64
        };
        var jsonPayload = JsonSerializer.Serialize(payload, options);
        return jsonPayload;
    }

    public (bool, QrDataModel) ValidateSignedQrCode(string jsonPayload, QrDataModel qrData)
    {
        try
        {
            // Step 1: Deserialize the entire payload
            var payload = JsonSerializer.Deserialize<QrPayloadModel>(jsonPayload);
            if (payload?.Data == null || string.IsNullOrEmpty(payload.Signature))
            {
                return (false, qrData);
            }

            // Step 2: Re-serialize the data part to get the original signed content
            // IMPORTANT: Use the same serialization settings to get a byte-for-byte match.
            var options = new JsonSerializerOptions { WriteIndented = false };
            var originalData = JsonSerializer.Serialize(payload.Data, options);
            var originalDataBytes = Encoding.UTF8.GetBytes(originalData);

            // Step 3: Get the signature from the payload
            var signatureBytes = Convert.FromBase64String(payload.Signature);

            // Step 4: Verify the signature with the public key
            var isValid = _publicKey.VerifyData(
                originalDataBytes, signatureBytes,
                HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);

            if (isValid)
            {
                qrData = payload.Data;
            }
            
            return (isValid, qrData);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Validation failed: {ex.Message}");
            return (false, qrData);
        }
    }
}