# .NET Microservices Sample Reference Application

Sample .NET Core microservices architecture.

RabbitMq:

```docker run -d -p 15672:15672 -p 5673:5673 -p 5672:5672  -e RABBITMQ_DEFAULT_USER=admin -e RABBITMQ_DEFAULT_PASS=Pass@word --name local-rabbit -id rabbitmq:3-management```

MsSQLServer:

```docker run -d --network bridge -e 'ACCEPT_EULA=Y' -e 'SA_PASSWORD=Pass@word' -p 1433:1433 --name sqldata mcr.microsoft.com/mssql/server:2019-latest```

Postman collection is required to:

- create new contacts, get contacts' list by use id
- create new address, get address list by contact id
