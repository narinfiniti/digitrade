using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Net;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Hosting;

namespace ApiGateway
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            BuildWebHostBuilder(args).Build().Run();
        }

        private static IHostBuilder BuildWebHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureAppConfiguration((hostBuilderContext, config) =>
                {
                    var envName = hostBuilderContext.HostingEnvironment.EnvironmentName;
                    config.SetBasePath(hostBuilderContext.HostingEnvironment.ContentRootPath)
                        .AddJsonFile("ocelot.json", optional: false)
                        .AddJsonFile($"ocelot.{envName}.json", true)
                        .AddEnvironmentVariables();
                })
                .ConfigureWebHostDefaults(hostBuilder =>
                {
                    hostBuilder
                        .CaptureStartupErrors(true)
                        .UseContentRoot(Directory.GetCurrentDirectory())
                        .UseStartup<Startup>();
                });
    }
}