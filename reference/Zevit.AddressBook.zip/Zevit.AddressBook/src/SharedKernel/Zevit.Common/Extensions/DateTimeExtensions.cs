﻿using System;
using System.Diagnostics;
using System.Globalization;

namespace Zevit.Common.Extensions
{
    /// <summary>
    /// StringCollectionExtensions
    /// </summary>
    public static class DateTimeExtensions
    {
        [DebuggerStepThrough]
        public static string Format(this DateTimeOffset date, string format = "yyyy-MM-dd HH:mm:ss.fffffffZ")
        {
            return date.ToString(format, CultureInfo.InvariantCulture);
        }

    }
}