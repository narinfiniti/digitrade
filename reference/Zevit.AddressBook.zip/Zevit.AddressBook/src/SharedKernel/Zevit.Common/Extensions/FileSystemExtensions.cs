﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.Configuration;

namespace Zevit.Common.Extensions
{
    /// <summary>
    /// Extensions fot system IO types.
    /// </summary>
    public static class FileSystemExtensions
    {
        public static string ReadEmbeddedResource<T>(this string fileName)
        {
            var assembly = typeof(T).GetTypeInfo().Assembly;
            var name = assembly.GetManifestResourceNames()
                .FirstOrDefault(r => r.EndsWith("." + fileName, StringComparison.InvariantCultureIgnoreCase));
            if (name == null)
            {
                return null;
            }

            using var stream = assembly.GetManifestResourceStream(name);
            using var reader = new StreamReader(stream);
            return reader.ReadToEnd();
        }

        /// <summary>
        /// Create a zip file stream from given Directory
        /// </summary>
        /// <param name="directorySelected"></param>
        /// <returns></returns>
        public static byte[] Compress(this DirectoryInfo directorySelected)
        {
            using var zipStream = new MemoryStream();
            using var zip = new ZipArchive(zipStream, ZipArchiveMode.Create, true);
            foreach (var fileToCompress in directorySelected.GetFiles())
            {
                using var fileStream = fileToCompress.OpenRead();
                var entry = zip.CreateEntry(Path.GetFileName(fileStream.Name));
                using var entryStream = entry.Open();
                fileStream.CopyTo(entryStream);
            }

            return zipStream.ToArray();
        }

        /// <summary>
        /// Loads environment variables from .env file.
        /// </summary>
        public static IDictionary<string, string> LoadEnvironmentVariables(
            this IConfigurationBuilder builder,
            string envFilePath)
        {
            var data = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            using (var fileStream = File.OpenRead(envFilePath))
            {
                using (var reader = new StreamReader(fileStream))
                {
                    var sectionPrefix = string.Empty;
                    while (reader.Peek() != -1)
                    {
                        var rawLine = reader.ReadLine();
                        var line = rawLine.Trim();
                        // Ignore blank lines
                        if (string.IsNullOrWhiteSpace(line))
                        {
                            continue;
                        }

                        switch (line[0])
                        {
                            // Ignore comments
                            case ';':
                            case '#':
                            case '/':
                                continue;
                            // [Section:header]
                            case '['
                            when line[line.Length - 1] == ']':
                                // remove the brackets
                                sectionPrefix = line.Substring(1, line.Length - 2) + ConfigurationPath.KeyDelimiter;
                                continue;
                        }

                        // key = value OR "value"
                        var separator = line.IndexOf('=');
                        if (separator < 0)
                        {
                            throw new FormatException($"Unrecognized line format: '{rawLine}'.");
                        }

                        var key = sectionPrefix + line.Substring(0, separator).Trim();
                        var value = line.Substring(separator + 1).Trim();
                        // Remove quotes
                        if (value.Length > 1 && value[0] == '"' && value[value.Length - 1] == '"')
                        {
                            value = value.Substring(1, value.Length - 2);
                        }

                        if (data.ContainsKey(key))
                        {
                            throw new FormatException($"A duplicate key '{key}' was found.");
                        }

                        data[key] = value;
                    }
                }
            }

            return data;
        }
        public static DirectoryInfo AsDirInfo(this string path)
        {
            var dir = new DirectoryInfo(path);
            if (!dir.Exists)
                dir.Create();
            return dir;
        }
    }
}