using System;

namespace Zevit.Common.Extensions
{
    public static class DecimalExtensions
    {
        /// <summary>
        /// Removes integral digits and takes fractional digits.
        /// </summary>
        public static decimal FractDigits(this decimal value)
        {
            return value - decimal.Truncate(value);
        }
        public static bool HasFractDigits(this decimal value, byte MaxDigits)
        {
            var mult = (decimal)Math.Pow(10, MaxDigits);
            return (value.FractDigits() * mult).FractDigits() == 0;
        }
        public static decimal TakeFractDigits(this decimal value, byte digits)
        {
            var mult = (decimal)Math.Pow(10, digits);
            return decimal.Truncate(value) + decimal.Truncate(value.FractDigits() * mult) / mult;
        }
    }
}