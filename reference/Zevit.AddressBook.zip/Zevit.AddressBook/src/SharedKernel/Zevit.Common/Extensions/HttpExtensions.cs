﻿using System;
using System.Diagnostics;
using Microsoft.AspNetCore.Http;

namespace Zevit.Common.Extensions
{
    /// <summary>
    /// HttpExtensions
    /// </summary>
    public static class HttpExtensions
    {
        [DebuggerStepThrough]
        public static bool IsMethod(this HttpRequest value, string method = "")
        {
            return value != null ? value.Method.Equals(method, StringComparison.OrdinalIgnoreCase) : false;
        }

        [DebuggerStepThrough]
        public static bool IsGet(this HttpRequest value)
        {
            return value.IsMethod("GET");
        }

        [DebuggerStepThrough]
        public static bool IsPost(this HttpRequest value)
        {
            return value.IsMethod("POST");
        }
    }
}