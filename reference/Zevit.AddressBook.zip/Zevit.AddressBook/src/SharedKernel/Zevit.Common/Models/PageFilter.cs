namespace Zevit.Common.Models
{
    /// <summary>
    /// PageFilter.
    /// </summary>
    public class PageFilter
    {
        public PageFilter()
        {
            Skip ??= 0;
            Page ??= 1;
            Limit ??= int.MaxValue;
        }

        public int? Skip { get; set; }
        public int? Page { get; set; }
        public int? Limit { get; set; }
    }
}