﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Zevit.Common.Models.Response
{
    /// <summary>
    /// Model for list result. 
    /// </summary>
    [DataContract]
    public class ListResult<T>
    {
        public ListResult() { }

        public ListResult(IEnumerable<T> items)
        {
            Items.AddRange(items);
        }

        [DataMember]
        public List<T> Items { get; set; } = new();

        [DataMember]
        public int? Total { get; set; }
        [DataMember]
        public bool? HasNext { get; set; }
    }
}