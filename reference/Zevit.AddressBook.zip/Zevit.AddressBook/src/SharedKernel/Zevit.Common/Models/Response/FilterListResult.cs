﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Zevit.Common.Models.Response
{
    /// <summary>
    /// Model for list result. 
    /// </summary>
    [DataContract]
    public class FilterListResult<F, T> : ListResult<T>
    {
        public FilterListResult() : base() { }

        public FilterListResult(IEnumerable<T> items) : base(items) { }

        [DataMember]
        public F Filter { get; set; }
    }
}