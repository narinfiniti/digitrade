﻿using System.Net;
using Microsoft.AspNetCore.Mvc;

namespace Zevit.Common.Models.Response
{
    /// <summary>
    /// Error result.
    /// </summary>
    public class ErrorResult : StatusCodeResult
    {
        public ErrorResult(string error, int statusCode = (int)HttpStatusCode.BadRequest) : base(statusCode)
        {
            Error = error;
        }

        private string Error { get; }
    }
}