﻿using System.Net;
using Microsoft.AspNetCore.Mvc;

namespace Zevit.Common.Models.Response
{
    /// <summary>
    /// Use case result with data.
    /// </summary>
    public class DataResult<TData> : StatusCodeResult
    {
        public DataResult(
            TData data,
            int statusCode = (int)HttpStatusCode.OK) : base(statusCode)
        {
            Data = data;
        }
        public TData Data { get; }
    }
}