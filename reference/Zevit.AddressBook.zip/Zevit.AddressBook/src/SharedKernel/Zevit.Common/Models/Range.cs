﻿namespace Zevit.Common.Models
{
    /// <summary>
    /// Range model type.
    /// </summary>
    public class Range<T>
    {
        public Range() { }
        public Range(T start, T end)
        {
            Start = start;
            End = end;
        }
        public T Start { get; set; }
        public T End { get; set; }
    }
}