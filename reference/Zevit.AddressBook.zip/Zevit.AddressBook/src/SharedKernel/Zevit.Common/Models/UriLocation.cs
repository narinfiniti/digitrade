﻿namespace Zevit.Common.Models
{
    /// <summary>
    /// https://developer.mozilla.org/en-US/docs/Web/API/Location
    /// </summary>
    public class UriLocation
    {
        public string Host { get; set; }
        public string Pathname { get; set; }
        public string Scheme { get; set; }
        public string Href { get => $"{Scheme}://{Host}{Pathname}"; }
    }
}