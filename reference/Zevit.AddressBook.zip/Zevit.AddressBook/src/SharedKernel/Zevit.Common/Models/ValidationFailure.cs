﻿namespace Zevit.Common.Models
{
    /// <summary>
    /// Validation failure.
    /// </summary>
    public class ValidationFailure
    {
        public ValidationFailure(string propertyName, string errorMessage)
        {
            PropertyName = propertyName;
            ErrorMessage = errorMessage;
        }

        public string PropertyName { get; set; }
        public string ErrorMessage { get; set; }
    }
}