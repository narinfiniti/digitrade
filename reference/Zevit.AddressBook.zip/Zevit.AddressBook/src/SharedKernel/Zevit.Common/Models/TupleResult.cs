﻿namespace Zevit.Common.Models
{
    public class TupleResult
    {
        public TupleResult(bool isOk, string[] errors)
        {
            Succeeded = isOk;
            Errors = errors;
        }
        public bool Succeeded { get; set; }
        public string[] Errors { get; set; }
    }
}