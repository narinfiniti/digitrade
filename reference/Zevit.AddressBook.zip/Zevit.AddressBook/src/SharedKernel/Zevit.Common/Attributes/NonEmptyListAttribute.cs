using System;
using System.Collections;
using System.ComponentModel.DataAnnotations;

namespace Zevit.Common.Attributes
{
    /// <summary>
    /// Non empty list Attribute.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter)]
    public class NonEmptyListAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value is IEnumerable collection)
            {
                // if empty not valid
                if (!collection.GetEnumerator().MoveNext())
                    return new ValidationResult($"Empty array: {validationContext.MemberName}.");

                return ValidationResult.Success;
            }

            return new ValidationResult("Invalid list!");
        }
    }
}