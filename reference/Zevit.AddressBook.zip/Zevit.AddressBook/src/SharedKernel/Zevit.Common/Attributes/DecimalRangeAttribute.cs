using System.ComponentModel.DataAnnotations;

namespace Zevit.Common.Attributes
{
    /// <summary>
    /// DecimalRangeAttribute.
    /// </summary>
    public class DecimalRangeAttribute : RangeAttribute
    {
        public DecimalRangeAttribute(double minimum = 0, double maximum = 999999999999999.9999)
            : base(minimum, maximum)
        {
            ErrorMessage = "Invalid Target {0}; Max 19 digit non negative number";
        }
    }
}