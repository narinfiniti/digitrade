using System;
using System.ComponentModel.DataAnnotations;
using Zevit.Common.Extensions;

namespace Zevit.Common.Attributes
{
    /// <summary>
    /// DecimalDigitAttribute.
    /// </summary>
    public class DecimalDigitAttribute : ValidationAttribute
    {
        private readonly byte digits;

        public DecimalDigitAttribute(byte digits)
        {
            this.digits = digits;
        }

        public override bool IsValid(object value)
        {
            if (value == null)
            {
                return true;
            }
            else
            {
                if (value.GetType() != typeof(decimal))
                {
                    throw new ArgumentException("Invalid type: the argument is not of type decimal.");
                }

                var val = (decimal)value;
                return val.HasFractDigits(digits);
            }
        }
    }
}