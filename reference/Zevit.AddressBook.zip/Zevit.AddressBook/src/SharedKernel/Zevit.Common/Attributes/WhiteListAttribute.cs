using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Zevit.Common.Attributes
{
    /// <summary>
    /// White list Attribute.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter)]
    public class WhiteListAttribute : ValidationAttribute
    {
        private HashSet<object> WhiteList { get; }

        public WhiteListAttribute(params object[] whiteList) : base()
        {
            WhiteList = new HashSet<object>(whiteList);
        }

        public override bool IsValid(object value)
        {
            return WhiteList.Contains(value);
        }

        public override string FormatErrorMessage(string name)
        {
            return $@"{name} accepts values: {string.Join(",", WhiteList)}";
        }
    }
}