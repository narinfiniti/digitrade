﻿using System.Net;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// The server unable to fulfil the request exception.
    /// </summary>
    public class NotImplementedException : StatusCodeException
    {
        public NotImplementedException(
          string message = "The server unable to fulfill the request."
        ) : base(message, (int)HttpStatusCode.NotImplemented) { }
    }
}