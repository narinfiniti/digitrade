﻿using System.Net;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// Operation could not be processed due to a conflict exception.
    /// </summary>
    public class ConflictException : StatusCodeException
    {
        public ConflictException(
          string message = "Operation could not be processed du to a conflict."
        ) : base(message, (int)HttpStatusCode.Conflict) { }
    }
}