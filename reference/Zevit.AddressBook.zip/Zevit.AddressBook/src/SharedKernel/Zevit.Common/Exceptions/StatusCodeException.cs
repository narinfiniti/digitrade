﻿using System;
using System.Net;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// Exception with StatusCode result.
    /// </summary>
    public class StatusCodeException : Exception
    {
        public int StatusCode { get; private set; }

        public StatusCodeException(
            string message = null,
            int statusCode = (int)HttpStatusCode.BadRequest
        ) : this(message, null, statusCode) { }

        public StatusCodeException(
            string message,
            Exception innerException = null,
            int statusCode = (int)HttpStatusCode.BadRequest) : base(message, innerException)
        {
            StatusCode = statusCode;
        }
    }
}