﻿using System;
using System.Net;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// Request context was not found exception.
    /// </summary>
    public class NotFoundException : StatusCodeException
    {
        public NotFoundException() : this("The requested resource was not found.") { }
        public NotFoundException(Type type) : this($"Entity \"{type}\" was not found.") { }
        public NotFoundException(string name, object key) : this($"Entity \"{name}\" ({key}) was not found.") { }
        public NotFoundException(
            string message = null,
            int statusCode = (int)HttpStatusCode.NotFound
        ) : base(message, statusCode) { }
    }
}