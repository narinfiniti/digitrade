﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Newtonsoft.Json;
using Zevit.Common.Models;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// Request context validation exception.
    /// </summary>
    [DataContract]
    public class ValidationException : StatusCodeException
    {
        [DataMember]
        public IDictionary<string, string[]> Failures { get; }
        public ValidationException(
            string message = "One or more validation failures have occurred.",
            int statusCode = (int)HttpStatusCode.UnprocessableEntity) : base(message, statusCode)
        {
            Failures = new Dictionary<string, string[]>();
        }

        public ValidationException(
            IEnumerable<ValidationFailure> failures = null,
            string message = "One or more validation failures have occurred.") : this(message, (int)HttpStatusCode.UnprocessableEntity)
        {
            if (failures == null) return;

            var failureGroups = failures.GroupBy(e => e.PropertyName, e => e.ErrorMessage);
            foreach (var failureGroup in failureGroups)
            {
                var propertyName = failureGroup.Key;
                var propertyFailures = failureGroup.ToArray();

                Failures.Add(propertyName, propertyFailures);
            }
        }

        public ValidationException(
            IEnumerable<ValidationResult> results = null,
            string message = "One or more validation failures have occurred.") : this(message, (int)HttpStatusCode.UnprocessableEntity)
        {
            if (results == null) return;

            var failures = results.Select(validationResult =>
            {
                var names = string.Join(", ", validationResult.MemberNames);
                return new ValidationFailure(names, validationResult.ErrorMessage);
            });
            var failureGroups = failures.GroupBy(e => e.PropertyName, e => e.ErrorMessage);
            foreach (var failureGroup in failureGroups)
            {
                var propertyName = failureGroup.Key;
                var propertyFailures = failureGroup.ToArray();

                Failures.Add(propertyName, propertyFailures);
            }
        }

        public ValidationException(
            ModelStateDictionary modelState,
            string message = "One or more validation failures have occurred.") : this(message, (int)HttpStatusCode.UnprocessableEntity)
        {
            foreach (var state in modelState)
            {
                var propertyName = state.Key;
                var propertyFailures = state.Value.Errors.Select(err => err.ErrorMessage).ToArray();

                Failures.Add(propertyName, propertyFailures);
            }
        }

        public virtual string ToResult(JsonSerializerSettings serializerSettings)
        {
            return Failures.Any()
                ? JsonConvert.SerializeObject(Failures, serializerSettings)
                : Message;
        }

    }
}