﻿using System.Net;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// The requested content only acceptable according to the Accept headers.
    /// </summary>
    public class NotAcceptableException : StatusCodeException
    {
        public NotAcceptableException(
          string message = "Content type is not acceptable."
        ) : base(message, (int)HttpStatusCode.NotAcceptable) { }
    }
}