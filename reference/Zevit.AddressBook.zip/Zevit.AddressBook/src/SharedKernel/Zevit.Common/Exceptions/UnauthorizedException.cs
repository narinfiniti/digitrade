﻿using System.Net;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// Invalid authentication credentials exception.
    /// </summary>
    public class UnauthorizedException : StatusCodeException
    {
        public UnauthorizedException(
          string message = "Invalid authentication credentials for the target resource."
        ) : base(message, (int)HttpStatusCode.Unauthorized) { }
    }
}