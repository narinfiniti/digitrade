﻿using System.Net;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// The requested Resource is no longer available.
    /// </summary>
    public class GoneException : StatusCodeException
    {
        public GoneException(
          string message = "Resource is no longer available."
        ) : base(message, (int)HttpStatusCode.Gone) { }
    }
}