﻿using System.Net;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// Necessary permissions exception.
    /// </summary>
    public class MethodNotAllowedException : StatusCodeException
    {
        public MethodNotAllowedException(
          string message = "A request method is not supported."
        ) : base(message, (int)HttpStatusCode.MethodNotAllowed) { }
    }
}