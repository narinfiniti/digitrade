﻿using System.Net;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// Necessary permissions exception.
    /// </summary>
    public class BadRequestException : StatusCodeException
    {
        public BadRequestException(
          string message = "The server cannot process the request due to client error/s."
        ) : base(message, (int)HttpStatusCode.BadRequest) { }
    }
}