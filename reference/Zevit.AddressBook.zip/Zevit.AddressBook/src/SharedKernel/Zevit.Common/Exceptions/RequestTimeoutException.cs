﻿using System.Net;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// The server timed out waiting for the request exception. 
    /// </summary>
    public class RequestTimeoutException : StatusCodeException
    {
        public RequestTimeoutException(string message = "The server timed out waiting for the request.")
            : base(message, (int)HttpStatusCode.RequestTimeout) { }
    }
}