﻿using System.Net;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// Request resource media type does not supported.
    /// </summary>
    public class UnsupportedMediaTypeException : StatusCodeException
    {
        public UnsupportedMediaTypeException(
          string message = "Request resource media type does not supported."
        ) : base(message, (int)HttpStatusCode.UnsupportedMediaType) { }
    }
}