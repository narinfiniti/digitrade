﻿using System.Net;

namespace Zevit.Common.Exceptions
{
    /// <summary>
    /// The server cannot handle the request exception.
    /// </summary>
    public class ServiceUnavailableException : StatusCodeException
    {
        public ServiceUnavailableException(
          string message = "Requested resource cannot be served."
        ) : base(message, (int)HttpStatusCode.ServiceUnavailable) { }
    }
}