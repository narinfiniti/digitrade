using System;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.SharedKernel.Services
{
    /// <summary>
    /// User identity or profile representation.
    /// </summary>
    public class UserProfileService : IUserProfileService
    {
        private readonly IHttpContextAccessor _context;

        public UserProfileService(
            IHttpContextAccessor context
            )
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public string[] Roles => _context.HttpContext?.User?
            .FindFirst("role")?.Value?.Split(",");
        public string GetUserIdentity()
        {
            return _context.HttpContext?.User?.FindFirst("sub")?.Value;
        }

        public string GetUserName()
        {
            return _context.HttpContext?.User?.Identity?.Name;
        }

    }
}