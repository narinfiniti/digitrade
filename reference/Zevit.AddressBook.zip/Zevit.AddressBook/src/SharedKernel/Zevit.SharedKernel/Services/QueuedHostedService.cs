using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.SharedKernel.Services
{
    /// <summary>
    /// Queued Hosted Service.
    /// </summary>
    public class QueuedHostedService : BackgroundService
    {
        private readonly IHostEnvironment _env;
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly ILogger<QueuedHostedService> _logger;
        private readonly IBackgroundTaskQueue _taskQueue;

        public QueuedHostedService(
            IHostEnvironment env,
            IServiceScopeFactory scopeFactory,
            ILogger<QueuedHostedService> logger,
            IBackgroundTaskQueue taskQueue
        )
        {
            _env = env;
            _scopeFactory = scopeFactory;
            _logger = logger;
            _taskQueue = taskQueue;
        }


        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation($"Background Hosted Service is running.");

            await BackgroundProcessing(stoppingToken);
        }

        private async Task BackgroundProcessing(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                var workItem = await _taskQueue.DequeueAsync(stoppingToken);
                var scopeFactory = _scopeFactory;
                var scope = scopeFactory?.CreateScope();
                try
                {
                    if (workItem != null) await workItem.Invoke(stoppingToken, scope);
                }
                catch (Exception ex)
                {
                    var logger = scope?.ServiceProvider
                        .GetService<ILogger<QueuedHostedService>>();
                    logger.LogError(
                        new EventId(ex.HResult),
                        $"Exception.Message: {ex.Message ?? ex.InnerException?.Message}\n{ex.StackTrace}\n{ex.InnerException?.StackTrace}");
                }
                finally
                {
                    workItem = null;
                    scope?.Dispose();
                    scope = null;
                    scopeFactory = null;
                }
            }
        }

        public override async Task StopAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Queued Hosted Service is stopping.");

            await base.StopAsync(stoppingToken);
        }
    }
}