using System;
using System.Threading;
using System.Threading.Tasks;
using Polly;
using Polly.Caching;

namespace Zevit.SharedKernel.Services
{
    /// <summary>
    /// PollyPolicyService.
    /// </summary>
    public class PollyRetryPolicyService
    {

        //private IServiceProvider _serviceProvider;

        public PollyRetryPolicyService(
        //IServiceProvider serviceProvider
        )
        {
            //_serviceProvider = serviceProvider;
        }

        public readonly Func<double, double, Func<int, TimeSpan>> GetDefaultSleepDurationProvider = (periodSec, maxPeriodSec) =>
            (retryCount) =>
           {
               if (retryCount <= 6)
               {
                   // 6 times with the 10sec period.
                   periodSec = 10;
               }
               else if (periodSec < maxPeriodSec)
               {
                   // period is increased in accordance with the formula.
                   periodSec += (70 + retryCount * Math.Pow(10, 1.12) - 4);
               }
               else if (periodSec >= maxPeriodSec)
               {
                   // every 4 hrs until the maximum number of attempts is reached.
                   periodSec = maxPeriodSec;
               }
               return TimeSpan.FromSeconds(periodSec);
           };
        public async Task<TResult> ExecuteAsync<TResult>(
             IAsyncPolicy<TResult>[] policyList,
             Func<Context, CancellationToken, Task<TResult>> action,
             Context context,
             CancellationToken cancellationToken = default)
        {
            var n = policyList.Length;
            if (n == 0) return default;
            var policyChain = policyList[0];
            for (var i = 1; i < n; ++i)
            {
                var item = policyList[i];
                policyChain = policyChain.WrapAsync<TResult>(item);
            }
            return await policyChain
                .ExecuteAsync(action, context, cancellationToken)
                .ConfigureAwait(false);
        }

        public IAsyncPolicy<TResult> GetRetryPolicyOnResult<TException, TResult>(
            int retryCount = 120,
            double minPeriodSec = 10.0,
            double maxPeriodSec = 4 * 60 * 60,
            Func<TResult, bool> retryOnResultPredicate = null,
            Func<int, TimeSpan> sleepDurationProvider = null
        ) where TException : Exception
        {
            sleepDurationProvider ??= GetDefaultSleepDurationProvider(minPeriodSec, maxPeriodSec);
            return Policy
                .Handle<TException>()
                .OrInner<TException>()
                .OrResult<TResult>(retryOnResultPredicate ?? ((res) => false))
                .WaitAndRetryAsync<TResult>(retryCount, sleepDurationProvider);
        }

        public IAsyncPolicy<TResult> GetCachePolicyForResult<TResult>(
            IAsyncCacheProvider<TResult> cacheProvider,
            TimeSpan ttl,
            Func<Context, string> cacheKeyStrategy,
            Action<Context, string, Exception> onCacheError = null
        )
        {
            return Policy
                .CacheAsync<TResult>(cacheProvider, ttl, cacheKeyStrategy, onCacheError);
        }

        public IAsyncPolicy<TResult> GetFallbackPolicyForResult<TException, TResult>(
            Func<TResult, bool> resultPredicate = null,
            Func<DelegateResult<TResult>, Context, CancellationToken, Task<TResult>> fallbackAction = null,
            Func<DelegateResult<TResult>, Context, Task> onFallbackAsync = null
        ) where TException : Exception
        {
            fallbackAction ??= (dr, ctx, token) => Task.FromResult(default(TResult));
            onFallbackAsync ??= (dr, ctx) => Task.CompletedTask;
            return Policy
                .Handle<TException>()
                .OrResult<TResult>(resultPredicate ?? ((res) => false))
                .FallbackAsync<TResult>(fallbackAction, onFallbackAsync);
        }

        public IAsyncPolicy GetRetryPolicy<TException>(
            int retryCount,
            double minPeriodSec,
            double maxPeriodSec,
            Func<int, TimeSpan> sleepDurationProvider = null
        ) where TException : Exception
        {
            var periodSec = minPeriodSec;

            if (sleepDurationProvider == null)
            {
                sleepDurationProvider = GetDefaultSleepDurationProvider(minPeriodSec, maxPeriodSec);
            }

            return Policy
                .Handle<TException>()
                .OrInner<TException>()
                .WaitAndRetryAsync(retryCount, sleepDurationProvider);
        }
    }
}