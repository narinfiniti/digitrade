using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.SharedKernel.Services
{
    /// <summary>
    /// Email template provider.
    /// </summary>
    public class BackgroundTaskQueue : IBackgroundTaskQueue, IDisposable
    {
        private readonly ConcurrentQueue<Func<CancellationToken, IServiceScope, Task>> _workItems =
            new ConcurrentQueue<Func<CancellationToken, IServiceScope, Task>>();

        private readonly SemaphoreSlim _signal = new SemaphoreSlim(0);
        //private readonly AsyncReaderWriterLock _lock = new AsyncReaderWriterLock();
        public void QueueWorkItem(
            Func<CancellationToken, IServiceScope, Task> workItem)
        {
            if (workItem == null)
            {
                throw new ArgumentNullException(nameof(workItem));
            }
            _workItems.Enqueue(workItem);
            _signal.Release();
        }

        public async Task<Func<CancellationToken, IServiceScope, Task>> DequeueAsync(
            CancellationToken cancellationToken)
        {
            await _signal.WaitAsync(cancellationToken);
            _workItems.TryDequeue(out var workItem);
            return workItem;
        }

        public void Dispose()
        {
            _workItems?.Clear();
            _signal?.Dispose();
        }
    }
}