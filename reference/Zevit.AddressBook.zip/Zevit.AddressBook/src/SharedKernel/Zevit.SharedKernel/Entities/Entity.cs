using System.Collections.Generic;
using MediatR;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.SharedKernel.Entities
{
    /// <summary>
    /// Domain Entity abstract type.
    /// </summary>
    public abstract class Entity<TKey> : IEntity<TKey>, IEntity
    {
        private int? _hashCode;
        public IList<INotification> Events { get; } = new List<INotification>();
        public void AddDomainEvent(INotification eventItem) => Events.Add(eventItem);
        public void RemoveDomainEvent(INotification eventItem) => Events.Remove(eventItem);
        public void ClearDomainEvents() => Events?.Clear();
        public bool IsTransient => Id is null || Id.Equals(default(TKey));

        public TKey Id { get; set; }


        public override bool Equals(object obj)
        {
            if (obj is not Entity<TKey> entity)
                return false;

            if (ReferenceEquals(this, obj))
                return true;

            if (GetType() != obj.GetType())
                return false;

            if (entity.IsTransient || IsTransient)
                return false;

            return Id.Equals(entity.Id);
        }

        public override int GetHashCode()
        {
            if (!IsTransient)
            {
                // XOR for random distribution
                // http://blogs.msdn.com/b/ericlippert/archive/2011/02/28/guidelines-and-rules-for-gethashcode.aspx
                _hashCode ??= Id.GetHashCode() ^ 31;

                return _hashCode.Value;
            }
            else
                return base.GetHashCode();
        }
        public static bool operator ==(Entity<TKey> left, Entity<TKey> right)
        {
            return !(left is null) && left.Equals(right);
        }

        public static bool operator !=(Entity<TKey> left, Entity<TKey> right)
        {
            return !(left == right);
        }
    }
}