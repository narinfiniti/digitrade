using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Zevit.Common.Attributes;

namespace Zevit.SharedKernel.Entities
{
    /// <summary>
    /// Immutable domain entity type. 
    /// </summary>
    /// <see cref="https://docs.microsoft.com/en-us/dotnet/standard/microservices-architecture/microservice-ddd-cqrs-patterns/implement-value-objects"/>
    public abstract class ValueObject : IEquatable<ValueObject>
    {
        private List<PropertyInfo> properties;
        private List<FieldInfo> fields;

        public virtual IEnumerable<object> GetAtomicProperties()
        {
            foreach (var property in GetProperties())
            {
                yield return property;
            }
        }

        public static bool Equals(ValueObject left, ValueObject right)
        {
            if (left is null || right is null || left.GetType() != right.GetType()) return false;

            return left.GetProperties().All(p => PropertiesAreEqual(left, right, p)) &&
                left.GetFields().All(f => FieldsAreEqual(left, right, f));
        }

        public static bool operator ==(ValueObject left, ValueObject right) => left?.Equals(right) ?? right is null;

        public static bool operator !=(ValueObject left, ValueObject right) => !(left == right);

        public virtual bool Equals(ValueObject obj) => Equals(this, obj);

        public override bool Equals(object obj)
        {
            if (obj == null || obj.GetType() != GetType())
            {
                return false;
            }
            var other = (ValueObject)obj;
            var thisValues = GetAtomicProperties().GetEnumerator();
            var otherValues = other.GetAtomicProperties().GetEnumerator();
            while (thisValues.MoveNext() && otherValues.MoveNext())
            {
                if (thisValues.Current is null ^ otherValues.Current is null)
                {
                    return false;
                }
                if (thisValues.Current != null && !thisValues.Current.Equals(otherValues.Current))
                {
                    return false;
                }
            }
            return !thisValues.MoveNext() && !otherValues.MoveNext();
        }

        public override int GetHashCode()
        {
            return GetAtomicProperties()
                .Select(x => x != null ? x.GetHashCode() : 0)
                .Aggregate((x, y) => x ^ y);
        }

        public ValueObject GetCopy()
        {
            return MemberwiseClone() as ValueObject;
        }

        protected static bool EqualOperator(ValueObject left, ValueObject right)
        {
            if (left is null ^ right is null)
            {
                return false;
            }
            return left.Equals(right);
        }

        protected static bool NotEqualOperator(ValueObject left, ValueObject right)
        {
            return !EqualOperator(left, right);
        }

        private static bool PropertiesAreEqual(ValueObject left, ValueObject right, PropertyInfo p) => Equals(p.GetValue(left, null), p.GetValue(right, null));

        private static bool FieldsAreEqual(ValueObject left, ValueObject right, FieldInfo f) => Equals(f.GetValue(left), f.GetValue(right));

        private IEnumerable<PropertyInfo> GetProperties()
        {
            if (properties == null)
            {
                properties = GetType()
                    .GetProperties(BindingFlags.Instance | BindingFlags.Public)
                    .Where(p => p.GetCustomAttribute(typeof(IgnoreMemberAttribute)) == null)
                    .ToList();
            }

            return properties;
        }

        private IEnumerable<FieldInfo> GetFields()
        {
            if (fields == null)
            {
                fields = GetType().GetFields(BindingFlags.Instance | BindingFlags.Public)
                    .Where(p => p.GetCustomAttribute(typeof(IgnoreMemberAttribute)) == null)
                    .ToList();
            }

            return fields;
        }
    }
}