using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace Zevit.SharedKernel.Interfaces
{
    /// <summary>
    /// Abstraction for BackgroundTaskQueue service.
    /// </summary>
    public interface IBackgroundTaskQueue
    {
        void QueueWorkItem(Func<CancellationToken, IServiceScope, Task> workItem);
        Task<Func<CancellationToken, IServiceScope, Task>> DequeueAsync(CancellationToken cancellationToken);
    }
}