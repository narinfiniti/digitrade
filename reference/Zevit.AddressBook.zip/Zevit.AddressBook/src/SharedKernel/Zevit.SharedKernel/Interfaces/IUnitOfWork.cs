using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Storage;

namespace Zevit.SharedKernel.Interfaces
{
    /// <summary>
    /// IUnitOfWork.
    /// </summary>
    /// <typeparam name="TContext"></typeparam>
    public interface IUnitOfWork<out TContext> : IUnitOfWork
    {
        IRepository<TEntity, TKey> GetRepository<TEntity, TKey>() where TEntity : class, IAggregateRoot<TKey>, new();

        TContext Context { get; }
        new Task<int> SaveAsync(CancellationToken cancellation = default);
    }

    public interface IUnitOfWork : IDisposable
    {
        void ValidateAggregateRootInvariantRules();
        Task<int> SaveAsync(CancellationToken cancellation = default);
        Task<bool> SaveEntitiesAsync(CancellationToken cancellation = default);
        Task MigrateAsync(CancellationToken cancellationToken = default);
        Task<bool> CanConnectAsync(CancellationToken cancellationToken = default);
        
        IDbContextTransaction CurrentTransaction { get; }
        bool HasActiveTransaction { get; }
        Task<IDbContextTransaction> BeginTransactionAsync();
        Task CommitAsync(IDbContextTransaction transaction);
        Task RollbackAsync();
    }
}