﻿namespace Zevit.SharedKernel.Interfaces
{
    /// <summary>
    /// Marker abstraction for trackable entity type.
    /// </summary>
    public interface ITrackableEntity
    {
    }
}
