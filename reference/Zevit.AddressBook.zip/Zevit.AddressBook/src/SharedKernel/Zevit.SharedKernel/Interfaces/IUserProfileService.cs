namespace Zevit.SharedKernel.Interfaces
{
    /// <summary>
    /// Abstraction to retrieve user's identity.
    /// </summary>
    public interface IUserProfileService
    {
        string[] Roles { get; }
        string GetUserIdentity();

        string GetUserName();
    }
}