using System.Collections.Generic;
using AutoMapper;
using Zevit.Common.Models.Response;

namespace Zevit.SharedKernel.Interfaces
{
    /// <summary>
    /// Maps Entity to Data Transfer Object and vice versa.
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    /// <typeparam name="TDto"></typeparam>
    public interface IAutoMap<TEntity, TDto>
        where TEntity : class, new()
        where TDto : class, new()
    {
        void CreateMap(Profile profile)
        {
            profile.CreateMap<TEntity, TDto>().ReverseMap();
            profile.CreateMap<ListResult<TEntity>, ListResult<TDto>>();
            profile.CreateMap<List<TEntity>, ListResult<TDto>>()
                .ForMember(to => to.Items, c => c.MapFrom(from => from));
        }
    }
}