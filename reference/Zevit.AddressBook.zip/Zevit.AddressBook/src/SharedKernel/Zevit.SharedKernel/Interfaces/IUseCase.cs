using MediatR;

namespace Zevit.SharedKernel.Interfaces
{
    /// <summary>
    /// Abstraction for creating a command/query use-case.
    /// </summary>
    public interface IUseCase<out TInputModel, out TOutputModel> : IRequest<TOutputModel>
    {
        TInputModel Model { get; }
    }
}