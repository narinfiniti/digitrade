using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

namespace Zevit.SharedKernel.Interfaces
{
    /// <summary>
    /// Abstaraction for repository.
    /// </summary>
    public interface IRepository<TEntity, in TKey>
        where TEntity : class, IAggregateRoot<TKey>, new()
    {
        IUnitOfWork Uow { get; }
        Task<TEntity> FindAsync(
            Expression<Func<TEntity, bool>> predicate,
            Expression<Func<TEntity, object>>[] includes = null);
        Task<TEntity> AddAsync(TEntity entity);
        void Delete(TEntity entity);
        Task DeleteAsync(TKey id);
        Task<TEntity> UpdateAsync(object id, TEntity entity);
        Task<List<TEntity>> FindRangeAsync(
            Expression<Func<TEntity, bool>> predicate = null,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
            Expression<Func<TEntity, object>>[] includes = null,
            int? skip = null,
            int? limit = null,
            bool tracking = false,
            CancellationToken cancellationToken = default);
    }
}