﻿using System.Collections.Generic;
using MediatR;

namespace Zevit.SharedKernel.Interfaces
{
    /// <summary>
    /// Marker abstraction for Domain entity type.
    /// </summary>
    public interface IEntity
    {
        public IList<INotification> Events { get; }
        public void AddDomainEvent(INotification eventItem);
        public void RemoveDomainEvent(INotification eventItem);
        public void ClearDomainEvents();
    }

    /// <summary>
    /// Identity abstraction of Domain entity.
    /// </summary>
    public interface IEntity<TKey>
    {
        TKey Id { get; set; }
    }
}
