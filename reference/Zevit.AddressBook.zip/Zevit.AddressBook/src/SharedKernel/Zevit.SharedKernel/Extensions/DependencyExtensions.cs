using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Zevit.SharedKernel.Interfaces;
using Zevit.SharedKernel.Services;

namespace Zevit.SharedKernel.Extensions
{
    public static class DependencyExtensions
    {
        public static IServiceCollection AddSharedKernelInfrastructure(this IServiceCollection services,
            IConfiguration config,
            IHostEnvironment env)
        {
            services.AddTransient<IUserProfileService, UserProfileService>();
            services.AddTransient<IEncryptionService, EncryptionService>();

            services.AddScoped<PollyRetryPolicyService>();

            services.AddSingleton<IBackgroundTaskQueue, BackgroundTaskQueue>();
            services.AddHostedService<QueuedHostedService>();
            return services;
        }
    }
}