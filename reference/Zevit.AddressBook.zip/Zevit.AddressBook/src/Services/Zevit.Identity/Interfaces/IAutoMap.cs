﻿using System.Collections.Generic;
using AutoMapper;
using Zevit.Common.Models.Response;

namespace Zevit.Identity.Api.Interfaces
{
    /// <summary>
    /// Maps Entity to Data Transfer Object.
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    /// <typeparam name="TDto"></typeparam>
    public interface IAutoMap<TEntity, TDto> : IAutoMap
        where TEntity : class, new()
        where TDto : class, new()
    {
        new void CreateMap(Profile profile)
        {
            profile.CreateMap<TEntity, TDto>()
                .ReverseMap();
            profile.CreateMap<List<TEntity>, ListResult<TDto>>()
                .ForMember(to => to.Items, c => c.MapFrom(from => from));
        }
    }

    public interface IAutoMap
    {
        void CreateMap(Profile profile) { }
    }
}