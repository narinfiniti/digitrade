﻿namespace Zevit.Identity.Api.Interfaces.Services
{
    public interface IRedirectService
    {
        string ExtractRedirectUriFromReturnUrl(string url);
    }
}
