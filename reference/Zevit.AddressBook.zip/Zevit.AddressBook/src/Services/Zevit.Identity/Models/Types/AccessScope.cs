﻿using System;

namespace Zevit.Identity.Api.Models.Types
{
    /// <summary>
    /// Model for managing permissions for the application.
    /// </summary>
    public class AccessScope
    {
        public AccessScope(string resource, AccessAction action, string resourceGroup = null, string description = null)
        {
            ResourceName = resource;
            Action = action;
            ResourceGroup = resourceGroup;
            Description = description;
        }

        public string ResourceName { get; set; }
        public AccessAction Action { get; set; }
        public string ResourceGroup { get; set; }
        public string Description { get; set; }

        public int ValueAsInt32 => Enum.TryParse<int>(Action.ToString(), out var result) ? result : default;
        public string ValueAsString => Action.ToString();
        public string Value => $"{ResourceName}_{Action.ToString()}";

        public override string ToString() => Value;
        public static implicit operator string(AccessScope access) => access.Value;
    }

    /// <summary>
    /// Operations are actions the user can perform in the system.
    /// </summary>
    /// <remarks>
    /// Use the "|" binary operator to combine operations. 
    /// </remarks>
    [Flags]
    public enum AccessAction : byte
    {
        /// <summary>convenience operation that indicates that nothing is allowed</summary>
        none = 0x00, // 0000

        /// <summary>right to newly create an item</summary>
        create = 0x01, // 0001

        /// <summary>right to access (read) an item.</summary>
        read = 0x02, // 0010

        /// <summary>right modify an existing item.</summary>
        update = 0x04, // 0100

        /// <summary>right to delete create an</summary>
        delete = 0x08, // 1000

        /// <summary>convenience operation that holds all operations</summary>
        all = create | read | update | delete, // 1111 -> 15

        create_read_update = create | read | update, // 0111 -> 7

        create_read = create | read, // 0011 -> 3

        read_update = read | update, // 0110 -> 6
    }
}
