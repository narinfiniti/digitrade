﻿using System.ComponentModel.DataAnnotations;

namespace Zevit.Identity.Api.Models.Account
{
    public class ExternalLoginConfirmationViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
