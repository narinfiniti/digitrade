using System.ComponentModel.DataAnnotations;
using Zevit.Identity.Api.Quickstart.Account;

namespace Zevit.Identity.Api.Models.Account
{
    public class RegisterViewModel : LoginViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        public RegisterViewModel Convert(LoginViewModel data)
        {
            Password = data.Password;
            Username = data.Username;
            ExternalProviders = data.ExternalProviders;
            RememberLogin = data.RememberLogin;
            ReturnUrl = data.ReturnUrl;
            AllowRememberLogin = data.AllowRememberLogin;
            EnableLocalLogin = data.EnableLocalLogin;
            return this;
        }
    }
}