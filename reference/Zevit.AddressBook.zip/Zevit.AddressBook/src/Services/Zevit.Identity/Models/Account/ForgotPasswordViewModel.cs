﻿using System.ComponentModel.DataAnnotations;

namespace Zevit.Identity.Api.Models.Account
{
    public class ForgotPasswordViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
