﻿namespace Zevit.Identity.Api.Models.Manage
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}
