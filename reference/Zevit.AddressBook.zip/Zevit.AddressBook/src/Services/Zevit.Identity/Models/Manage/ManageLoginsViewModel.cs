﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Identity;
using Zevit.Identity.Api.Quickstart.Account;

namespace Zevit.Identity.Api.Models.Manage
{
    public class ManageLoginsViewModel
    {
        public IList<UserLoginInfo> CurrentLogins { get; set; }
        public IList<ExternalProvider> OtherLogins { get; set; }
    }
}
