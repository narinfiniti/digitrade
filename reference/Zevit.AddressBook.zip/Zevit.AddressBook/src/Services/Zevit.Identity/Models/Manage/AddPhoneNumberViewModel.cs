﻿using System.ComponentModel.DataAnnotations;

namespace Zevit.Identity.Api.Models.Manage
{
    public class AddPhoneNumberViewModel
    {
        [Required]
        [Phone]
        [Display(Name = "Phone number")]
        public string PhoneNumber { get; set; }
    }
}
