﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Zevit.Identity.Api.Extensions;
using Zevit.Identity.Api.Infrastructure.Dependency;
using Zevit.Identity.Api.Infrastructure.Middlewares;
using Swashbuckle.AspNetCore.SwaggerUI;

namespace Zevit.Identity.Api
{
    public class Startup
    {
        public Startup(
            IConfiguration configuration,
            IWebHostEnvironment environment)
        {
            Configuration = configuration;
            Environment = environment;
        }

        public IServiceCollection Services { get; private set; }
        public IConfiguration Configuration { get; }
        public IWebHostEnvironment Environment { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCustomConfiguration(Configuration, Environment);
            services.AddCustomDependencies(Configuration, Environment);
            services.AddHttpServices(Environment);

            //services.AddApplicationDependencies(Configuration, Environment);

            services.AddHealthChecks(Configuration, Environment);
            //services.AddApplicationInsights(Configuration, Environment);

            services.AddCustomControllers(Configuration);
            services.AddCustomAuthentication(Configuration, Environment);
            services.AddCustomAuthorization(Configuration);

            services.AddCustomCors(Configuration, Environment);
            //services.AddCustomApiVersioning(Configuration);
            services.AddCustomSwagger(Configuration, Environment);

            Services = services;
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app,
            IWebHostEnvironment env
        //,IApiVersionDescriptionProvider provider
        )
        {
            app.UseMiddleware<ExceptionHandlingMiddleware>();
            if (env.IsDevOrLocal())
            {
                // Make work identity server redirections in Edge and lastest versions of browers.
                // WARN: Not valid in a production environment.
                //if (env.IsDevOrLocal())
                //    app.Use(async (context, next) =>
                //    {
                //        context.Response.Headers.Add(
                //            "Content-Security-Policy", "script-src 'unsafe-inline'");
                //        await next();
                //    });
                app.UseDeveloperExceptionPage();
                // Use DatabaseDeveloperPageExceptionFilter instead.
                // https://aka.ms/DatabaseDeveloperPageExceptionFilter.
                // app.UseDatabaseErrorPage();
                app.UseServicesDisplayPage(Services);
            }
            else if (env.IsProduction())
            {
                //app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days.
                // You may want to change this for production scenarios,
                // see https://aka.ms/aspnetcore-hsts.
                app.UseHsts(); // Browsers only
                app.UseHttpsRedirection();
            }

            app.UseDefaultFiles();
            app.UseStaticFiles();
            //app.UseMyStaticFiles(Environment);

            // Fix a problem with chrome. Chrome enabled a new feature "Cookies without SameSite must be secure", 
            // the coockies shold be expided from https, but internal comunicacion in AKS and docker compose is http.
            // To avoid this problem, the policy of cookies shold be in Lax mode.
            //app.UseCookiePolicy(new CookiePolicyOptions { MinimumSameSitePolicy = SameSiteMode.Lax });

            app.UseRouting();
            app.UseCors("CorsPolicy");
            app.UseForwardedHeaders();
            // Adds IdentityServer
            app.UseIdentityServer();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthCheck();
                endpoints.MapDefaultControllerRoute();
                //endpoints.MapControllers();
            });

            if (env.IsDevOrLocal())
            {
                app.UseHealthChecks("/health");
                app.UseHealthChecks("/health/db");

                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.DocumentTitle = "Identity API";
                    //foreach (var v in provider.ApiVersionDescriptions)
                    //c.SwaggerEndpoint($"/swagger/{v.GroupName}/swagger.json", $"Identity API {v.GroupName}");
                    c.SwaggerEndpoint($"/swagger/v1/swagger.json", $"SwaggerUI Client V1");
                    //c.RoutePrefix = "569ac745-b631-43a9-8afc-4414d1db48c1";
                    c.DefaultModelExpandDepth(2); // model shown in endpoint
                    c.DefaultModelRendering(ModelRendering.Model);
                    c.DefaultModelsExpandDepth(2); // model shown in list at the bottom
                    c.DisplayOperationId();
                    c.DisplayRequestDuration();
                    c.DocExpansion(DocExpansion.List);
                    c.EnableDeepLinking();
                    c.EnableFilter();
                    //c.MaxDisplayedTags(5);
                    c.ShowExtensions();
                    c.EnableValidator();
                    c.SupportedSubmitMethods(SubmitMethod.Post, SubmitMethod.Put);
                    c.OAuthClientId("identity-swagger-ui");
                    //c.OAuthClientSecret("no_password");
                });
            }
        }
    }
}
