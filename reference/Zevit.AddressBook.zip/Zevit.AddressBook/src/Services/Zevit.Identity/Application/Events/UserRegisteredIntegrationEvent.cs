using System;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Logging;
using Zevit.Messaging.Abstractions;
using Zevit.Messaging.Abstractions.Events;

namespace Zevit.Identity.Api.Application.Events
{
    public class UserRegisteredIntegrationEvent : IntegrationEvent
    {
        public Guid UserId { get; }

        public UserRegisteredIntegrationEvent(
            Guid userId
        )
        {
            UserId = userId;
        }
    }
}