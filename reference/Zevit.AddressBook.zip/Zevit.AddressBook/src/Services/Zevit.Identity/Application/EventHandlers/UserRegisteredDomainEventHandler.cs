using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Zevit.Identity.Api.Application.Events;
using Zevit.Identity.Api.Domain.Events;
using Zevit.Messaging.Abstractions;

namespace Zevit.Identity.Api.Application.EventHandlers
{
    public class UserRegisteredDomainEventHandler : INotificationHandler<UserRegisteredDomainEvent>
    {
        private readonly IEventBus _eventBus;

        public UserRegisteredDomainEventHandler(
            IEventBus eventBus
            )
        {
            _eventBus = eventBus;
        }
        public Task Handle(
            UserRegisteredDomainEvent notification,
            CancellationToken cancellationToken)
        {
            var @event = new UserRegisteredIntegrationEvent(notification.User.Id);
            _eventBus.Publish(@event);
            return Task.CompletedTask;
        }
    }
}