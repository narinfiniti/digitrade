using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Zevit.Identity.Api.Application.Events;
using Zevit.Identity.Api.Domain.Events;
using Zevit.Messaging.Abstractions;

namespace Zevit.Identity.Api.Application.EventHandlers
{
    public class UserLoggedInDomainEventHandler : INotificationHandler<UserLoggedInDomainEvent>
    {
        private readonly IEventBus _eventBus;

        public UserLoggedInDomainEventHandler(
            IEventBus eventBus
            )
        {
            _eventBus = eventBus;
        }
        public Task Handle(
            UserLoggedInDomainEvent notification,
            CancellationToken cancellationToken)
        {
            var @event = new UserLoggedInIntegrationEvent(notification.User.Id);
            _eventBus.Publish(@event);
            return Task.CompletedTask;
        }
    }
}