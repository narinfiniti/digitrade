using Zevit.Identity.Api.Domain.Entity;
using Zevit.Identity.Api.Interfaces;

namespace Zevit.Identity.Api.Application.Dto
{
    public class AppUserDto : IAutoMap<User, AppUserDto>
    {
        public string UserName { get; set; }
        public string Email { get; set; }

        // public class Validator : AbstractValidator<AppUserDto>
        // {
        //     public Validator()
        //     {
        //         RuleFor(v => v.UserName)
        //             .MaximumLength(200)
        //             .NotEmpty();
        //     }
        // }
    }
}