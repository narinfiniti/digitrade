﻿using System.Reflection;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Zevit.Identity.Api.Application.Mapping;

namespace Zevit.Identity.Api.Application.Extensions
{
    public static partial class DependencyExtensions
    {
        public static IServiceCollection AddApplicationDependencies(
            this IServiceCollection services,
            IConfiguration configuration, IHostEnvironment env)
        {
            services.AddMediatR(
                c => c.AsTransient(),
                Assembly.GetExecutingAssembly());
            //services.AddScoped(typeof(IPipelineBehavior<,>), typeof(RequestPerformanceBehaviour<,>));
            //services.AddScoped(typeof(IPipelineBehavior<,>), typeof(RequestValidationBehavior<,>));
            services.AddAutoMapper(
                assemblies: new[] {typeof(MappingProfile).GetTypeInfo().Assembly},
                serviceLifetime: ServiceLifetime.Transient
            );

            return services;
        }
    }
}