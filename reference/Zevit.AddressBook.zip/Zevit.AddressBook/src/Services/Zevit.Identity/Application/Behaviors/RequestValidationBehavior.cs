﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using MediatR;

namespace Zevit.Identity.Api.Application.Behaviors
{
    /// <summary>
    /// Request validation pipeline behavior.
    /// </summary>
    /// <typeparam name="TRequest"></typeparam>
    /// <typeparam name="TResponse"></typeparam>
    public class RequestValidationBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
        where TRequest : IRequest<TResponse>
    {
        private readonly IEnumerable<IValidator<TRequest>> _validators;

        public RequestValidationBehavior(IEnumerable<IValidator<TRequest>> validators)
        {
            _validators = validators;
        }

        public Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next)
        {
            var context = new ValidationContext<TRequest>(request);
            var failures = _validators
                .Select(v => v.Validate(context))
                .SelectMany(result => result.Errors)
                .Where(e => e != null)
                .ToList();

            if (failures.Count == 0)
            {
                return next();
            }

            throw new ValidationException("Validation exception", failures);
        }

        public Task<TResponse> Handle(TRequest request, CancellationToken cancellationToken, RequestHandlerDelegate<TResponse> next)
        {
            var context = new ValidationContext<TRequest>(request);
            var failures = _validators
                .Select(async v => await v.ValidateAsync(context, cancellationToken))
                .SelectMany(result => result.Result.Errors)
                .Where(e => e != null)
                .ToList();

            if (failures.Count == 0)
            {
                return next();
            }

            throw new ValidationException("Validation exception", failures);
        }
    }
}
