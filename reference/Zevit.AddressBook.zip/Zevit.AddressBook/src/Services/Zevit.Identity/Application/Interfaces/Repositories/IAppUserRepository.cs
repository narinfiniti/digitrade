using System;
using Zevit.Identity.Api.Domain.Entity;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.Identity.Api.Application.Interfaces.Repositories
{
    public interface IAppUserRepository : IRepository<User, Guid>
    {
    }
}