﻿using System;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using MediatR;
using Zevit.Identity.Api.Application.Dto;
using Zevit.Identity.Api.Application.Interfaces.Repositories;
using Zevit.Identity.Api.Domain.Entity;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.Identity.Api.Application.UseCase
{
    public class UserCreateCommand : IUseCase<AppUserDto, Guid>
    {
        public AppUserDto Model { get; set; }
        public class Handler : IRequestHandler<UserCreateCommand, Guid>
        {
            private readonly IMapper _mapper;
            private readonly IAppUserRepository _userRepo;

            public Handler(
                IMapper mapper,
                IAppUserRepository userRepo
             )
            {
                _mapper = mapper;
                _userRepo = userRepo;
            }

            public async Task<Guid> Handle(
                UserCreateCommand request, CancellationToken cancellationToken)
            {
                var entity = _mapper.Map<User>(request.Model);

                await _userRepo.AddAsync(entity);
                await _userRepo.Uow.SaveAsync(cancellationToken);

                return entity.Id;
            }
        }
    }
}
