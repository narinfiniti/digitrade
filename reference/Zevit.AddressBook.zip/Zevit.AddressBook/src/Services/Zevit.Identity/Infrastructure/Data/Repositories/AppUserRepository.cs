using System;
using Zevit.Identity.Api.Application.Interfaces.Repositories;
using Zevit.Identity.Api.Domain.Entity;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.Identity.Api.Infrastructure.Data.Repositories
{
    public class AppUserRepository
        : RepositoryBase<User, Guid, AppDbContext>, IAppUserRepository
    {
        public AppUserRepository(
            IUnitOfWork context
        ) : base((AppDbContext)context)
        {

        }
    }
}