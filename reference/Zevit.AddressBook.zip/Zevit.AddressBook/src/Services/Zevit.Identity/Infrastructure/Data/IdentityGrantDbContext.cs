﻿using Microsoft.EntityFrameworkCore;
using IdentityServer4.EntityFramework.DbContexts;
using IdentityServer4.EntityFramework.Options;
using Zevit.Identity.Api.Infrastructure.EntityConfigurations;

namespace Zevit.Identity.Api.Infrastructure.Data
{
    /// <summary>
    /// ConfigurationDbContext customization DbContext.
    /// </summary>
    public class IdentityGrantDbContext
        : PersistedGrantDbContext<IdentityGrantDbContext>
    {
        public const string DbScheme = "grant";
        public IdentityGrantDbContext(
            DbContextOptions<IdentityGrantDbContext> options,
            OperationalStoreOptions storeOptions)
            : base(options, storeOptions)
        { }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.HasDefaultSchema(DbScheme);
            this.AddEntityTypeConfigurations(builder);
        }
    }
}
