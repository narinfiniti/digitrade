﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.Identity.Api.Infrastructure.Data.Repositories
{
    /// <summary>
    /// RepositoryBase.
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    /// <typeparam name="TKey"></typeparam>
    /// <typeparam name="TContext"></typeparam>
    public class RepositoryBase<TEntity, TKey, TContext> : IRepository<TEntity, TKey>
         where TEntity : class, IAggregateRoot<TKey>, new()
         where TContext : DbContext, IUnitOfWork
    {
        private System.Data.Common.DbConnection _conn;
        private readonly TContext _context;
        protected async Task<T> WithDbConnection<T>(Func<IDbConnection, Task<T>> action)
        {
            _conn ??= _context.Database.GetDbConnection();
            if (_conn?.State == ConnectionState.Closed)
            {
                await _context.Database.OpenConnectionAsync();
            }
            try
            {
                return await action(_conn);
            }
            finally
            {
                if (_conn?.State == ConnectionState.Open)
                {
                    await _context.Database.CloseConnectionAsync();
                }
            }
        }

        public IUnitOfWork Uow => _context;

        protected RepositoryBase(TContext context)
        {
            _context = context;
        }

        public Task<List<TEntity>> FindRangeAsync(
            Expression<Func<TEntity, bool>> predicate = null,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
            Expression<Func<TEntity, object>>[] includes = null,
            int? skip = null,
            int? limit = null,
            bool tracking = false,
            CancellationToken cancellationToken = default)

        {
            var query = _context.Set<TEntity>().AsQueryable();
            if (includes != null)
                foreach (var include in includes)
                {
                    query = query.Include(include);
                }

            if (predicate != null)
                query = query.Where(predicate);
            if (orderBy != null)
                query = orderBy(query);
            if (skip != null)
                query = query.Skip(skip.Value);
            if (limit != null)
                query = query.Take(limit.Value);

            return tracking
                ? query.ToListAsync(cancellationToken)
                : query.AsNoTracking().ToListAsync(cancellationToken);
        }

        public async Task<TEntity> FindAsync(
            Expression<Func<TEntity, bool>> predicate,
            Expression<Func<TEntity, object>>[] includes = null)
        {
            var query = _context.Set<TEntity>().AsNoTracking().AsQueryable();
            if (includes != null)
                foreach (var include in includes)
                {
                    query = query.Include(include);
                }

            return await query.FirstOrDefaultAsync(predicate);
        }
        public async Task<TEntity> AddAsync(TEntity entity)
        {
            if (entity != null)
            {
                var entry = await _context.Set<TEntity>().AddAsync(entity);
                entity = entry.Entity;
            }
            return entity;
        }
        public async Task<TEntity> UpdateAsync(object id, TEntity entity)
        {
            if (entity != null)
            {
                if (id != null)
                {
                    var entitytoUpdate = await _context.Set<TEntity>().FindAsync(id);
                    if (entitytoUpdate != null)
                        _context.Entry(entitytoUpdate).CurrentValues.SetValues(entity);
                }
                _context.Entry(entity).State = EntityState.Modified;
            }
            return entity;
        }
        public async Task DeleteAsync(TKey id)
        {
            var entity = await _context.Set<TEntity>().FindAsync(id);
            Delete(entity);
        }
        public void Delete(TEntity entity)
        {
            if (entity != null) _context.Set<TEntity>().Remove(entity);
        }
    }
}