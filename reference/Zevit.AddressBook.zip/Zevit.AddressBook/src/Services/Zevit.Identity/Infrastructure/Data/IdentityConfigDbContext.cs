﻿using Microsoft.EntityFrameworkCore;
using Zevit.Identity.Api.Infrastructure.EntityConfigurations;
using IdentityServer4.EntityFramework.DbContexts;
using IdentityServer4.EntityFramework.Options;

namespace Zevit.Identity.Api.Infrastructure.Data
{
    /// <summary>
    /// ConfigurationDbContext customization DbContext.
    /// </summary>
    public class IdentityConfigDbContext : ConfigurationDbContext<IdentityConfigDbContext>
    {
        public const string DbScheme = "config";
        public IdentityConfigDbContext(
            DbContextOptions<IdentityConfigDbContext> options,
            ConfigurationStoreOptions storeOptions)
            : base(options, storeOptions)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.HasDefaultSchema(DbScheme);
            this.AddEntityTypeConfigurations(builder);
        }
    }
}
