﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Zevit.Identity.Api.Application.Interfaces.Repositories;
using Zevit.Identity.Api.Infrastructure.Data.Repositories;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.Identity.Api.Infrastructure.Data.Extensions
{
    public static partial class DependencyExtensions
    {
        public static void AddDataPersistence(
            this IServiceCollection services,
            IConfiguration config, IHostEnvironment env)
        {
            var connectionString = config.GetConnectionString("DefaultConnection");

            if (!env.IsEnvironment("Testing"))
            {
                services.AddDbContext<AppDbContext>(options =>
                    options.UseSqlServer(connectionString, b =>
                    {
                        b.MigrationsAssembly(typeof(AppDbContext).Assembly.FullName);
                        // Connection Resiliency: https://docs.microsoft.com/en-us/ef/core/miscellaneous/connection-resiliency 
                        b.EnableRetryOnFailure(
                                maxRetryCount: 3,
                                maxRetryDelay: TimeSpan.FromSeconds(5),
                                errorNumbersToAdd: null);
                    })
                    .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking),
                    contextLifetime: ServiceLifetime.Transient,
                    optionsLifetime: ServiceLifetime.Transient);
            }
            services.AddScoped<IUnitOfWork, AppDbContext>();
            services.AddScoped<IAppUserRepository, AppUserRepository>();
        }
    }
}
