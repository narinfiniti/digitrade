﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace Zevit.Identity.Api.Infrastructure.Auth
{
    /// <summary>
    /// Authorization handler to customize hub method.
    /// </summary>
    public class DomainRestrictedRequirement :
        AuthorizationHandler<DomainRestrictedRequirement, HubInvocationContext>,
        IAuthorizationRequirement
    {
        protected override Task HandleRequirementAsync(
            AuthorizationHandlerContext context,
            DomainRestrictedRequirement requirement,
            HubInvocationContext resource)
        {
            if (IsUserAllowedTo(resource.HubMethodName, context.User.Identity.Name) &&
                context.User.Identity.Name.EndsWith("@microsoft.com"))
            {
                context.Succeed(requirement);
            }
            return Task.CompletedTask;
        }

        private bool IsUserAllowedTo(string hubMethodName,
            string currentUsername)
        {
            return !(currentUsername.Equals("asdf42@microsoft.com") &&
                hubMethodName.Equals("banUser", StringComparison.OrdinalIgnoreCase));
        }
    }
}