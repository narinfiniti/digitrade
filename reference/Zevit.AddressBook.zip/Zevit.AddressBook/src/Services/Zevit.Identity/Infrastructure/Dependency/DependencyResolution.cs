﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Zevit.Identity.Api.Infrastructure.Data.Extensions;
using Zevit.Messaging.Extensions;

namespace Zevit.Identity.Api.Infrastructure.Dependency
{
    public static class DependencyResolution
    {
        public static IServiceCollection AddCustomDependencies(
            this IServiceCollection services,
            IConfiguration config, IHostEnvironment env)
        {
            services.AddIntegrationEventMessaging(config, env);
            services.AddDataPersistence(config, env);
            
            // services.AddBackgroundWorker(configuration);
            // services.AddDataSeeder();
            // services.AddWebSockets(configuration, env);
            // services.AddSignalrHubs(configuration, env);

            // services.AddUseCases();
            // services.AddCommandUseCases();
            // services.AddQueryUseCases();

            // services.AddCommandApplicationServices(configuration, env);
            // services.AddQueryApplicationServices(configuration, env);

            //services.AddTransient<IUserAccountService<User, Role>, UserAccountService>();
            //services.AddTransient<IRedirectService, RedirectService>();

            // services.AddScoped<IUnitOfWork<IdentityConfigDbContext>, UnitOfWork<IdentityConfigDbContext>>();
            // services.AddScoped<IUnitOfWork<IdentityGrantDbContext>, UnitOfWork<IdentityGrantDbContext>>();

            return services;
        }
    }
}
