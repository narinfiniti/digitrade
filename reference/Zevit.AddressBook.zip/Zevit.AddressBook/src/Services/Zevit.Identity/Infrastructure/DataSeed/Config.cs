﻿using System.Collections.Generic;
using IdentityModel;
using IdentityServer4;
using IdentityServer4.Models;
using Microsoft.Extensions.Configuration;

namespace Zevit.Identity.Api.Infrastructure.DataSeed
{
    public static class Config
    {
        public static IEnumerable<IdentityResource> IdentityResources =>
            new[]
            {
                new IdentityResource(
                    name: "openid",
                    userClaims: new[] { JwtClaimTypes.Subject },
                    displayName: "User's identifier"){Required=true},
                new IdentityResource(
                    name: "profile",
                    userClaims: new[] {
                        JwtClaimTypes.Name,
                        JwtClaimTypes.Email,
                        JwtClaimTypes.WebSite
                    },
                    displayName: "User's profile data"){Required=true}
            };

        public static IEnumerable<ApiScope> ApiScopes =>
            new[]
            {
                // invoice API specific scopes
                //new ApiScope(name: "invoice.read", displayName: "Reads your invoices.", UserClaims){Required=true},
                //new ApiScope(name: "invoice.pay", displayName: "Pays your invoices.", UserClaims){Required=true},
                // shared scope
                //new ApiScope(name: "manage", displayName: "Admin to invoice and customer data.", UserClaims){Required=true},

                // For authorizing Clients - not Users.
                new ApiScope("identityapi", "Read/Write Identity Service", UserClaims){Required=true},
                new ApiScope("contactapi", "Read/Write Contact Service", UserClaims){Required=true},
                new ApiScope("addressapi", "Read/Write Address Service", UserClaims){Required=true},
            };

        private static ICollection<string> UserClaims => new[] { JwtClaimTypes.Audience, JwtClaimTypes.Subject };
        public static IEnumerable<ApiResource> ApiResources =>
            new[]
            {
                new ApiResource("identityapi", "Identity API", UserClaims)
                {
                    Scopes = new[] {"identityapi", /*"invoice.read", "invoice.pay", "manage"*/},
                    // For the introspection endpoint. The API can authenticate
                    // with introspection using the API name and secret.
                    //ApiSecrets = new[] { new Secret("password".Sha256()) }
                },
                new ApiResource("contactapi", "Contact Service API", UserClaims)
                {
                    Scopes = new[] {"contactapi"}
                },
                new ApiResource("addressapi", "Address Service API", UserClaims)
                {
                    Scopes = new[] {"addressapi"}
                }
            };

        public static IEnumerable<Client> Clients(
            bool isProd,
            IConfiguration config) => new[]
            {
                new Client
                {
                    ClientId = "identity-swagger-ui",
                    ClientSecrets =
                    {
                        //new Secret("no_password".Sha256())
                    },
                    ClientName = "Zevit.Identity.Api Swagger UI",
                    AllowedGrantTypes = GrantTypes.Implicit,
                    RequireClientSecret = false,
                    AllowAccessTokensViaBrowser = true,

                    RedirectUris = { $"{config["AppOptions:HostUrl"]}/swagger/oauth2-redirect.html" },
                    PostLogoutRedirectUris = { $"{config["AppOptions:HostUrl"]}/swagger/" },
                    AllowedScopes =
                    {
                       // ApiName
                       "identityapi"
                    }
                },
                new Client
                {
                    ClientName = "Zevit AddressBook Client",
                    ClientId = "reactapp",
                    ClientSecrets =
                    {
                        new Secret("acf2ec6fb01a4b698ba240c2b10a0243".Sha256())
                    },
                    AllowedGrantTypes = GrantTypes.ResourceOwnerPasswordAndClientCredentials,

                    RequireClientSecret = false,
                    RequireConsent = false,
                    RequirePkce = false,

                    AllowAccessTokensViaBrowser = true,
                    AccessTokenLifetime = 60*60*2, // 2 hours
                    IdentityTokenLifetime= 60*60*2, // 2 hours

                    AllowOfflineAccess = true,
                    AbsoluteRefreshTokenLifetime = 60*60*24*30, // 30 days
                    SlidingRefreshTokenLifetime = 60*60*24*15, // 15 days
                    RefreshTokenExpiration = TokenExpiration.Sliding,
                    RefreshTokenUsage = TokenUsage.OneTimeOnly,
                    UpdateAccessTokenClaimsOnRefresh = false,

                    AllowedCorsOrigins = new[]
                    {
                        "http://localhost:4000",
                        "http://localhost:3000"
                    },
                    PostLogoutRedirectUris = new List<string>
                    {
                        "http://localhost:4000/addressbook/callback/logout"
                    },
                    RedirectUris = new List<string>
                    {
                        "http://localhost:4000/addressbook/callback/login",
                        "http://localhost:4000/addressbook/silent.html"
                    },
                    AllowedScopes =
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.StandardScopes.OfflineAccess,
                        "identityapi",
                        "contactapi",
                        "addressapi"
                    },
                }
            };
    }
}