﻿using System;
using System.Linq;
using System.Threading.Tasks;
using IdentityServer4.EntityFramework.Mappers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Zevit.Identity.Api.Domain.Entity;
using Zevit.Identity.Api.Infrastructure.Data;
using Zevit.Identity.Api.Models.Configs;

namespace Zevit.Identity.Api.Infrastructure.DataSeed
{
    /// <summary>
    /// Data seeding for IdentityConfigDbContext.
    /// </summary>
    public class IdentityConfigDbContextSeed
    {
        public async Task SeedAsync(
            IServiceProvider services
        )
        {
            var env = services.GetService<IWebHostEnvironment>();
            var config = services.GetService<IConfiguration>();
            var logger = services.GetService<ILogger<IdentityConfigDbContext>>();
            var appOptions = services.GetService<IOptions<AppOptions>>().Value;
            var context = services.GetService<IdentityConfigDbContext>();
            var userManager = services.GetService<UserManager<User>>();
            await context.Database.MigrateAsync();


            var clients = Config.Clients(env.IsProduction(), config);
            if (!context.Clients.Any())
            {
                context.Clients.AddRange(clients.Select(e => e.ToEntity()));
                await context.SaveChangesAsync();
            }
            else
            {
                var oldRedirectUris = (
                    await context.Clients.Include(c => c.RedirectUris)
                    .ToListAsync())
                    .SelectMany(c => c.RedirectUris)
                    .Where(ru => ru.RedirectUri.EndsWith("/o2c.html"))
                    .ToList();

                if (oldRedirectUris.Any())
                {
                    foreach (var ru in oldRedirectUris)
                    {
                        ru.RedirectUri = ru.RedirectUri.Replace("/o2c.html", "/oauth2-redirect.html");
                        context.Update(ru.Client);
                    }
                    await context.SaveChangesAsync();
                }
            }

            if (!context.IdentityResources.Any())
            {
                context.IdentityResources.AddRange(Config.IdentityResources.Select(e => e.ToEntity()));
                await context.SaveChangesAsync();
            }

            if (!context.ApiScopes.Any())
            {
                context.ApiScopes.AddRange(Config.ApiScopes.Select(e => e.ToEntity()));
                await context.SaveChangesAsync();
            }

            if (!context.ApiResources.Any())
            {
                context.ApiResources.AddRange(Config.ApiResources.Select(e => e.ToEntity()));
                await context.SaveChangesAsync();
            }
        }
    }
}
