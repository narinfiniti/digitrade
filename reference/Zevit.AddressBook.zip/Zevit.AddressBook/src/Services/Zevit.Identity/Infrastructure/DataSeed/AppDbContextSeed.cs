﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using IdentityModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Zevit.Identity.Api.Domain.Entity;
using Zevit.Identity.Api.Infrastructure.Data;
using Zevit.Identity.Api.Models.Configs;

namespace Zevit.Identity.Api.Infrastructure.DataSeed
{
    /// <summary>
    /// Data seeding for 
    /// </summary>
    public class AppDbContextSeed
    {
        private readonly IPasswordHasher<User> _passwordHasher = new PasswordHasher<User>();

        public async Task SeedAsync(
            IServiceProvider services
        )
        {
            var context = services.GetService<AppDbContext>();
            if (context == null) return;
            var env = services.GetService<IWebHostEnvironment>();
            var logger = services.GetService<ILogger<AppDbContextSeed>>();
            var appOptions = services.GetService<IOptions<AppOptions>>()?.Value;
            var userManager = services.GetService<UserManager<User>>();

            await context.Database.MigrateAsync();

            try
            {
                var useCustomizationData = appOptions?.UseCustomizationData;
                var contentRootPath = env?.ContentRootPath;
                var webroot = env?.WebRootPath;

                var rolesMap = new Dictionary<string, Role>
                {
                    {"Admin", new Role("Admin")},
                    {"Operator", new Role("Operator")},
                };
                if (!context.Roles.Any())
                {
                    await context.Roles.AddRangeAsync(rolesMap.Values.ToArray());
                }

                if (!context.Users.Any())
                {
                    var users = GetDefaultUsers(rolesMap);
                    if (userManager?.SupportsUserClaim == true)
                    {
                        foreach (var user in users)
                        {
                            var userClaims = GetUserClaims(user, userManager);
                            user.Claims = userClaims
                                .Select(c => new UserClaim
                                {
                                    UserId = user.Id,
                                    ClaimType = c.Type,
                                    ClaimValue = c.Value
                                })
                                .ToList();
                        }
                    }

                    await context.Users.AddRangeAsync(users);
                    await context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                logger.LogError(
                    ex,
                    "EXCEPTION ERROR while migrating {DbContextName}",
                    nameof(AppDbContext));
            }
        }

        private User[] GetDefaultUsers(IReadOnlyDictionary<string, Role> rolesMap)
        {
            var user1 = new User
            {
                Id = Guid.Parse("41061A7E-BD01-411E-8F06-392EF8C772B5"),
                Email = "admin@website.com",
                PhoneNumber = "1134567890",
                UserName = "admin@website.com",
            };
            user1.PasswordHash = _passwordHasher.HashPassword(user1, "Pass@word");
            user1.Roles = new List<UserRole>
            {
                new UserRole
                {
                    RoleId = rolesMap["Admin"].Id,
                    UserId = user1.Id
                }
            };

            var user2 = new User
            {
                Id = Guid.Parse("F742F87A-7A24-4A97-BDB2-27C8B87241FF"),
                Email = "operator@website.com",
                PhoneNumber = "2234567890",
                UserName = "operator@website.com",
            };
            user2.PasswordHash = _passwordHasher.HashPassword(user2, "Pass@word");
            user2.Roles = new List<UserRole>
            {
                new UserRole
                {
                    RoleId = rolesMap["Operator"].Id,
                    UserId = user2.Id
                }
            };
            return new[] {user1, user2};
        }

        private IEnumerable<Claim> GetUserClaims(
            User user,
            UserManager<User> userManager)
        {
            var claims = new List<Claim>
            {
                new Claim(JwtClaimTypes.Subject, user.Id.ToString()),
                new Claim(ClaimTypes.NameIdentifier, user.UserName),
            };

            if (userManager.SupportsUserRole)
                foreach (var userRole in user.Roles)
                {
                    claims.Add(new Claim(
                        JwtClaimTypes.Role,
                        userRole.RoleId.ToString()
                    ));
                }

            if (userManager.SupportsUserSecurityStamp
                && !string.IsNullOrWhiteSpace(user.SecurityStamp))
                claims.Add(new Claim("security_stamp", user.SecurityStamp));

            if (userManager.SupportsUserEmail && !string.IsNullOrWhiteSpace(user.Email))
            {
                claims.AddRange(new[]
                {
                    new Claim(JwtClaimTypes.Email, user.Email),
                    new Claim(JwtClaimTypes.EmailVerified, user.EmailConfirmed ? "true" : "false")
                });
            }

            if (userManager.SupportsUserPhoneNumber && !string.IsNullOrWhiteSpace(user.PhoneNumber))
            {
                claims.AddRange(new[]
                {
                    new Claim(JwtClaimTypes.PhoneNumber, user.PhoneNumber),
                    new Claim(JwtClaimTypes.PhoneNumberVerified, user.PhoneNumberConfirmed ? "true" : "false")
                });
            }

            return claims;
        }
    }
}