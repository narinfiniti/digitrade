﻿using IdentityServer4.EntityFramework.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Zevit.Identity.Api.Infrastructure.Data;

namespace Zevit.Identity.Api.Infrastructure.Factory
{
    public class IdentityConfigDbContextFactory : IDesignTimeDbContextFactory<IdentityConfigDbContext>
    {
        public IdentityConfigDbContext CreateDbContext(string[] args = null)
        {
            var connectionString = new ConfigurationBuilder()
               .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false)
               .AddUserSecrets("7823b554-417c-4e61-837f-d4157db0ff9d")
               .Build()
               .GetConnectionString("DefaultConnection");

            var optionsBuilder = new DbContextOptionsBuilder<IdentityConfigDbContext>();
            var storeOptions = new ConfigurationStoreOptions
            {
                DefaultSchema = IdentityConfigDbContext.DbScheme
            };

            optionsBuilder.UseSqlServer(
                connectionString,
                b => b.MigrationsAssembly(typeof(IdentityConfigDbContext).Assembly.FullName));

            return new IdentityConfigDbContext(optionsBuilder.Options, storeOptions);
        }
    }
}