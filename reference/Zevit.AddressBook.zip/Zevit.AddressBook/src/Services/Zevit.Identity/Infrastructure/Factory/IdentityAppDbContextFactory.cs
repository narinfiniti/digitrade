﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Zevit.Identity.Api.Infrastructure.Data;

namespace Zevit.Identity.Api.Infrastructure.Factory
{
    public class IdentityAppDbContextFactory : IDesignTimeDbContextFactory<AppDbContext>
    {
        public AppDbContext CreateDbContext(string[] args)
        {
            var connectionString = new ConfigurationBuilder()
               .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false)
               .AddUserSecrets("7823b554-417c-4e61-837f-d4157db0ff9d")
               .Build()
               .GetConnectionString("DefaultConnection");

            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();

            optionsBuilder.UseSqlServer(
                connectionString,
                b => b.MigrationsAssembly(typeof(AppDbContext).Assembly.FullName));

            return new AppDbContext(optionsBuilder.Options);
        }
    }
}