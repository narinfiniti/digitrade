﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;
using IdentityServer4;
using IdentityServer4.Configuration;
using IdentityServer4.Models;
using IdentityServer4.Services;
using Zevit.Identity.Api.Certificates;

namespace Zevit.Identity.Api.Infrastructure.Services
{
    /// <summary>
    /// IdentityServer4 User profile service.
    /// </summary>
    public class JweTokenCreationService : DefaultTokenCreationService
    {
        private readonly IConfiguration _config;
        private readonly IWebHostEnvironment _env;
        private readonly ILogger<JweTokenCreationService> _logger;

        public JweTokenCreationService(
            IConfiguration config,
            IWebHostEnvironment env,
            ISystemClock clock,
            IKeyMaterialService keys,
            IdentityServerOptions options,
            ILogger<JweTokenCreationService> logger) : base(clock, keys, options, logger)
        {
            _config = config;
            _env = env;
            _logger = logger;
        }

        public override async Task<string> CreateTokenAsync(Token token)
        {
            if (token.Type == IdentityServerConstants.TokenTypes.IdentityToken)
            {
                var payload = await base.CreatePayloadAsync(token);

                var handler = new JsonWebTokenHandler();
                var jwe = handler.CreateToken(
                    payload.SerializeToJson(),
                    await Keys.GetSigningCredentialsAsync(),

                    // load public key per client
                    new X509EncryptingCredentials(
                        Certificate.Load(_config, _env)
                        // new X509Certificate2("idsrv3test.cer")
                        )
                    );

                return jwe;
            }

            return await base.CreateTokenAsync(token);
        }
    }
}
