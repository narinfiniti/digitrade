﻿using System.Threading.Tasks;
using IdentityServer4.Validation;

namespace Zevit.Identity.Api.Infrastructure.Services
{
    public class CustomTokenRequestValidator : ICustomTokenRequestValidator
    {
        public Task ValidateAsync(CustomTokenRequestValidationContext context)
        {
            throw new System.NotImplementedException();
        }
    }
}
