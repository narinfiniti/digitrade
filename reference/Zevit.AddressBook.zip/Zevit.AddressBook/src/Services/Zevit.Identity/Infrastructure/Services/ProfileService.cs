﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using IdentityServer4.Extensions;
using IdentityServer4.Models;
using IdentityServer4.Services;
using Microsoft.Extensions.Options;
using Zevit.Identity.Api.Domain.Entity;
using Zevit.Identity.Api.Models.Configs;

namespace Zevit.Identity.Api.Infrastructure.Services
{
    /// <summary>
    /// Default profile service implementation.
    /// This implementation sources all claims from the current subject (e.g. the cookie).
    /// </summary>
    /// <seealso cref="IdentityServer4.Services.IProfileService" />
    public class ProfileService : IProfileService
    {
        private readonly ILogger<ProfileService> _logger;

        //private IUserClaimsPrincipalFactory<User> _claimsFactory;
        private readonly UserManager<User> _userManager;
        private readonly JwtOptions _jwt;

        public ProfileService(
            ILogger<ProfileService> logger,
            //IUserClaimsPrincipalFactory<User> claimsFactory,
            UserManager<User> userManager,
            IOptions<JwtOptions> jwt)
        {
            _logger = logger;
            //_claimsFactory = claimsFactory;
            _userManager = userManager;
            _jwt = jwt.Value;
        }

        public virtual async Task GetProfileDataAsync(ProfileDataRequestContext context)
        {
            var sub = context.Subject.GetSubjectId();
            var user = await _userManager.FindByIdAsync(sub);
            if (user == null)
            {
                throw new ArgumentException("No user in Db.");
            }

            var claims = new List<Claim>(); //(await _claimsFactory.CreateAsync(user)).Claims.ToList();
            if (!string.IsNullOrWhiteSpace(user.UserName))
            {
                claims.Add(new Claim("username", user.NormalizedUserName));
            }

            if (_userManager.SupportsUserEmail && !string.IsNullOrWhiteSpace(user.Email))
            {
                claims.Add(new Claim("email", user.NormalizedEmail));
                claims.Add(new Claim("email_verified", user.EmailConfirmed.ToString(), ClaimValueTypes.Boolean));
            }

            if (_userManager.SupportsUserPhoneNumber && !string.IsNullOrWhiteSpace(user.PhoneNumber))
            {
                claims.Add(new Claim("phone", user.PhoneNumber));
                claims.Add(new Claim("phone_verified", user.PhoneNumberConfirmed.ToString(), ClaimValueTypes.Boolean));
            }

            if (_userManager.SupportsUserSecurityStamp && !string.IsNullOrWhiteSpace(user.SecurityStamp))
            {
                claims.Add(new Claim("security_stamp", user.SecurityStamp));
            }

            var (nameClaimType, roleClaimType) = (
                _jwt.TokenValidationParameters.NameClaimType,
                _jwt.TokenValidationParameters.RoleClaimType
            );
            claims.Add(new Claim(nameClaimType, user.Id.ToString()));
            if (_userManager.SupportsUserRole)
                foreach (var role in await _userManager.GetRolesAsync(user))
                {
                    claims.Add(new Claim(roleClaimType, role));
                }

            context.IssuedClaims = claims;
        }

        public async Task IsActiveAsync(IsActiveContext context)
        {
            var sub = context.Subject.GetSubjectId();
            var user = await _userManager.FindByIdAsync(sub);
            context.IsActive = user?.IsActive == true;
        }
    }
}