﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using IdentityModel;
using IdentityServer4.Models;
using IdentityServer4.Validation;
using Zevit.Identity.Api.Domain.Entity;

namespace Zevit.Identity.Api.Infrastructure.Services
{
    /// <summary>
    /// ResourceOwnerPasswordValidator.
    /// </summary>
    public class ResourceOwnerPasswordValidator : IResourceOwnerPasswordValidator
    {
        private readonly UserManager<User> _userManager;
        //private readonly IEncryptionService _encryptionService;
        private readonly IConfiguration _config;

        public ResourceOwnerPasswordValidator(
            UserManager<User> userManager,
            //IEncryptionService encryptionService,
            IConfiguration config)
        {
            _userManager = userManager;
            //_encryptionService = encryptionService;
            _config = config;
        }
        public async Task ValidateAsync(ResourceOwnerPasswordValidationContext context)
        {
            var user = _userManager.Users.FirstOrDefault(x => x.Id.ToString() == context.Result.Subject.Identity.Name);

            if (user == null)
            {
                context.Result = new GrantValidationResult(
                    TokenRequestErrors.InvalidGrant, 
                    "The username or password are incorrect", null);
            }
            else if (!await _userManager.CheckPasswordAsync(user, context.Password))
            {
                context.Result = new GrantValidationResult(
                    TokenRequestErrors.InvalidGrant, 
                    "The user or password are incorrect", null);
            }
            else if (!user.IsActive)
            {
                context.Result = new GrantValidationResult(
                    TokenRequestErrors.InvalidGrant, 
                    "The user is not active", null);
            }
            else  // then the user is valid
            {
                //this will set the userID that is used to get the claims in the ProfileService.cs
                context.Result = new GrantValidationResult(
                    user.Id.ToString(), 
                    "password", 
                    DateTime.Now, 
                    GetUserClaims(user), 
                    "local", 
                    null);
            }
        }

        //build claims array from user data
        private IEnumerable<Claim> GetUserClaims(User user)
        {
            var claims = new List<Claim>
            {
                new Claim(JwtClaimTypes.Subject, user.Id.ToString()),
                new Claim(ClaimTypes.NameIdentifier, user.UserName),
            };

            //add user roles (authorization)
            foreach (var role in user.Roles)
            {
                claims.Add(new Claim(JwtClaimTypes.Role, role.RoleId.ToString()));
            }

            if (_userManager.SupportsUserSecurityStamp
                && !string.IsNullOrWhiteSpace(user.SecurityStamp))
                claims.Add(new Claim("security_stamp", user.SecurityStamp));

            //if (!string.IsNullOrWhiteSpace(user.FirstName))
            //    claims.Add(new Claim("first_name", user.FirstName));

            //if (!string.IsNullOrWhiteSpace(user.LastName))
            //    claims.Add(new Claim("last_name", user.LastName));

            //if (!string.IsNullOrWhiteSpace(user.CardNumber))
            //    claims.Add(new Claim("card_number", user.CardNumber));

            //if (!string.IsNullOrWhiteSpace(user.CardHolderName))
            //    claims.Add(new Claim("card_holder_name", user.CardHolderName));

            //if (!string.IsNullOrWhiteSpace(user.CardSecurityNumber))
            //    claims.Add(new Claim("card_security_number", user.CardSecurityNumber));

            //if (!string.IsNullOrWhiteSpace(user.CardExpiration))
            //    claims.Add(new Claim("card_expiration", user.CardExpiration));

            //if (!string.IsNullOrWhiteSpace(user.City))
            //    claims.Add(new Claim("city", user.City));

            //if (!string.IsNullOrWhiteSpace(user.Country))
            //    claims.Add(new Claim("country", user.Country));

            //if (!string.IsNullOrWhiteSpace(user.State))
            //    claims.Add(new Claim("state", user.State));

            //if (!string.IsNullOrWhiteSpace(user.Street))
            //    claims.Add(new Claim("street", user.Street));

            //if (!string.IsNullOrWhiteSpace(user.ZipCode))
            //    claims.Add(new Claim("zip_code", user.ZipCode));

            if (_userManager.SupportsUserEmail)
            {
                claims.AddRange(new[]
                {
                    new Claim(JwtClaimTypes.Email, user.Email),
                    new Claim(JwtClaimTypes.EmailVerified, user.EmailConfirmed ? "true" : "false", ClaimValueTypes.Boolean)
                });
            }

            if (_userManager.SupportsUserPhoneNumber && !string.IsNullOrWhiteSpace(user.PhoneNumber))
            {
                claims.AddRange(new[]
                {
                    new Claim(JwtClaimTypes.PhoneNumber, user.PhoneNumber),
                    new Claim(JwtClaimTypes.PhoneNumberVerified, user.PhoneNumberConfirmed ? "true" : "false", ClaimValueTypes.Boolean)
                });
            }
            return claims;
        }
    }
}
