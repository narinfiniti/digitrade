﻿using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Zevit.Common.Models.Response;

namespace Zevit.Identity.Api.Infrastructure.Filters
{
    /// <summary>
    /// Response result as Use-case result Filter.
    /// </summary>
    public class ResponseResultFilter : IAlwaysRunResultFilter
    {
        public void OnResultExecuting(ResultExecutingContext context)
        {
            var result = context.Result;
            if (!(result is JsonResult || result is ObjectResult))
            {
                return;
            }

            var propInfo = result.GetType().GetProperty("Value");
            var value = propInfo?.GetValue(result);
            if (value == null)
            {
                context.Result = new NotFoundResult();
                return;
            }
            else if (result is BadRequestObjectResult bad &&
              bad.Value is ValidationProblemDetails validation)
            {
                var error = validation.Errors.First();
                value = $"{error.Key}: {error.Value?[0]}";
                value = new ErrorResult(value.ToString(), 422);
                bad.StatusCode = 422;
            }
            else if (!(value is StatusCodeResult))
            {
                value = new DataResult<object>(value);
            }
            propInfo?.SetValue(context.Result, value);
        }

        public void OnResultExecuted(ResultExecutedContext context)
        {

        }
    }
}