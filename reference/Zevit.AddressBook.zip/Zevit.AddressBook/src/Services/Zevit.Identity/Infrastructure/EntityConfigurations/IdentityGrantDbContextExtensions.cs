﻿using Zevit.Identity.Api.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Zevit.Identity.Api.Infrastructure.EntityConfigurations
{
    /// <summary>
    /// IdentityGrantDbContext ModelBuilder Extensions.
    /// </summary>
    public static class IdentityGrantDbContextExtensions
    {
        public static void AddEntityTypeConfigurations(this IdentityGrantDbContext _, ModelBuilder builder)
        {
        }
    }
}
