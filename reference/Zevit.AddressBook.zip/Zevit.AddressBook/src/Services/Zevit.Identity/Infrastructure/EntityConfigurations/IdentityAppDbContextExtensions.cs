﻿using Microsoft.EntityFrameworkCore;
using Zevit.Identity.Api.Domain.Entity;
using Zevit.Identity.Api.Infrastructure.Data;

namespace Zevit.Identity.Api.Infrastructure.EntityConfigurations
{
    /// <summary>
    /// IdentityAppDbContext ModelBuilder Extensions.
    /// </summary>
    public static class IdentityAppDbContextExtensions
    {
        public static void AddEntityTypeConfigurations(this AppDbContext _, ModelBuilder builder)
        {
            //ASP.NET Identity
            builder.Entity<RoleClaim>(b =>
            {
                b.ToTable("RoleClaims");
                b.HasKey(e => e.Id);
                b.Property(e => e.ClaimType).HasMaxLength(128).IsUnicode(false).IsRequired();
                b.Property(e => e.ClaimValue).HasMaxLength(128).IsUnicode(false).IsRequired();
            });
            builder.Entity<UserRole>(b =>
            {
                b.ToTable("UserRoles");
                b.HasKey(e => new { e.UserId, e.RoleId });
            });
            builder.Entity<UserLogin>(b =>
            {
                b.ToTable("UserLogins");
                b.HasKey(e => new { e.LoginProvider, e.ProviderKey });
                b.Property(e => e.LoginProvider).HasMaxLength(128).IsUnicode(false).IsRequired();
                b.Property(e => e.ProviderKey).HasMaxLength(4000).IsUnicode(false).IsRequired();
                b.Property(e => e.ProviderDisplayName).HasMaxLength(128).IsUnicode(false).IsRequired(false);
            });
            builder.Entity<UserClaim>(b =>
            {
                b.ToTable("UserClaims");
                b.HasKey(e => e.Id);
                b.Property(e => e.ClaimType).HasMaxLength(128).IsUnicode(false).IsRequired();
                b.Property(e => e.ClaimValue).HasMaxLength(128).IsUnicode(false).IsRequired();
            });
            builder.Entity<UserToken>(b =>
            {
                b.ToTable("UserTokens");
                b.HasKey(e => new { e.UserId, e.LoginProvider, e.Name });
                b.Property(e => e.LoginProvider).HasMaxLength(256).IsUnicode(false).IsRequired();
                b.Property(e => e.Name).HasMaxLength(128).IsUnicode(false).IsRequired();
            });

            builder.Entity<Role>(b =>
            {
                b.ToTable("Roles");
                b.HasKey(e => e.Id);
                b.HasIndex(e => e.NormalizedName).IsUnique();//.HasDatabaseName("RoleNameIndex");

                //b.Property(e => e.Id).HasMaxLength(128).IsUnicode(false).ValueGeneratedOnAdd();
                b.Property(e => e.ConcurrencyStamp).HasMaxLength(36).IsUnicode(false).IsConcurrencyToken();
                b.Property(e => e.Name).HasMaxLength(128).IsUnicode(false).IsRequired();
                b.Property(e => e.NormalizedName).HasMaxLength(128).IsUnicode(false).IsRequired()
                    .UsePropertyAccessMode(PropertyAccessMode.Property)
                    ;
                // b.Property<string>("Discriminator").HasMaxLength(128).IsUnicode(false).IsRequired(false);

                b.HasMany(e => e.RoleUsers).WithOne().HasForeignKey(e => e.RoleId).IsRequired();
                b.HasMany(e => e.RoleClaims).WithOne().HasForeignKey(e => e.RoleId).IsRequired();
            });

            builder.Entity<User>(b =>
            {
                b.Ignore(e => e.IsActive);
                b.ToTable("Users");
                b.HasKey(e => e.Id);
                b.HasIndex(e => e.NormalizedUserName).IsUnique();//.HasDatabaseName("UserNameIndex");
                b.HasIndex(e => e.NormalizedEmail);//.HasDatabaseName("EmailIndex");

                //b.Property(e => e.CardNumber).HasMaxLength(128).IsUnicode(false).IsRequired();
                //b.Property(e => e.CardSecurityNumber).HasMaxLength(128).IsUnicode(false).IsRequired();
                //b.Property(e => e.CardExpiration).HasMaxLength(128).IsUnicode(false).IsRequired();

                //b.Property(e => e.CardHolderName).HasMaxLength(128).IsUnicode(false).IsRequired();
                //b.Property(e => e.CardType).HasColumnType("smallint").IsRequired(false);
                //b.Property(e => e.Street).HasMaxLength(128).IsUnicode(false).IsRequired();
                //b.Property(e => e.City).HasMaxLength(128).IsUnicode(false).IsRequired();
                //b.Property(e => e.State).HasMaxLength(128).IsUnicode(false).IsRequired();
                //b.Property(e => e.Country).HasMaxLength(128).IsUnicode(false).IsRequired();
                //b.Property(e => e.ZipCode).HasMaxLength(128).IsUnicode(false).IsRequired();

                //b.Property(e => e.FirstName).HasMaxLength(100).IsUnicode().IsRequired();
                //b.Property(e => e.LastName).HasMaxLength(100).IsUnicode().IsRequired();

                b.Property(e => e.ConcurrencyStamp).HasMaxLength(36).IsUnicode(false).IsRequired(false);
                b.Property(e => e.UserName).HasMaxLength(50).IsUnicode().IsRequired(false);
                b.Property(e => e.NormalizedUserName).HasMaxLength(50).IsUnicode().IsRequired(false)
                    .UsePropertyAccessMode(PropertyAccessMode.Property)
                    ;
                b.Property(e => e.Email).HasMaxLength(100).IsUnicode(false).IsRequired();
                b.Property(e => e.NormalizedEmail).HasMaxLength(100).IsUnicode(false).IsRequired()
                    .UsePropertyAccessMode(PropertyAccessMode.Property)
                    ;
                b.Property(e => e.PasswordHash).HasMaxLength(4000).IsUnicode(false).IsRequired(false);
                b.Property(e => e.SecurityStamp).HasMaxLength(36).IsUnicode(false).IsRequired();
                b.Property(e => e.PhoneNumber).HasMaxLength(50).IsUnicode(false).IsRequired(false);
            });
            builder.Entity<User>()
                .HasMany(e => e.Claims)
                .WithOne()
                .HasForeignKey(e => e.UserId)
                .IsRequired()
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<User>()
                .HasMany(e => e.Logins)
                .WithOne()
                .HasForeignKey(e => e.UserId)
                .IsRequired()
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<User>()
                .HasMany(e => e.Roles)
                .WithOne()
                .HasForeignKey(e => e.UserId)
                .IsRequired()
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<User>()
                .HasMany(e => e.Tokens)
                .WithOne()
                .HasForeignKey(e => e.UserId)
                .IsRequired()
                .OnDelete(DeleteBehavior.Cascade);
        }

    }
}
