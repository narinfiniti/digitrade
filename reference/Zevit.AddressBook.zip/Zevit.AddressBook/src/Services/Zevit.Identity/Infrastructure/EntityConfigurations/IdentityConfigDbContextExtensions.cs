﻿using Zevit.Identity.Api.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Zevit.Identity.Api.Infrastructure.EntityConfigurations
{
    /// <summary>
    /// IdentityConfigDbContext ModelBuilder Extensions.
    /// </summary>
    public static class IdentityConfigDbContextExtensions
    {
        public static void AddEntityTypeConfigurations(this IdentityConfigDbContext _, ModelBuilder builder)
        {
        }
    }
}
