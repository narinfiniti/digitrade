﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using IdentityServer4.AccessTokenValidation;
using Zevit.Identity.Api.Extensions;
using Zevit.Identity.Api.Models.Configs;

namespace Zevit.Identity.Api.Infrastructure.JsonOptions
{
    /// <summary>
    /// Custom CustomIdentityServerAuthenticationOptions settings for Asp.Net MVC.
    /// </summary>
    public class CustomIdsAuthOptions : IConfigureOptions<IdentityServerAuthenticationOptions>
    {
        private readonly JwtOptions _jwt;
        public CustomIdsAuthOptions(
            IHostEnvironment env,
            IOptions<JwtOptions> jwt
        )
        {
            _jwt = jwt.Value;
            Microsoft.IdentityModel.Logging
                .IdentityModelEventSource.ShowPII = env.IsDevOrLocal();
        }

        public void Configure(IdentityServerAuthenticationOptions options)
        {
            JwtSecurityTokenHandler.DefaultMapInboundClaims = false;
            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();
            // var tokenHandler = new JwtSecurityTokenHandler
            // {
            //     MapInboundClaims = false,
            //     TokenLifetimeInMinutes = _jwt.AccessTokenLifetimeMinutes
            // };
            // options.SecurityTokenValidators.Clear();
            // options.SecurityTokenValidators.Add(tokenHandler);
            var signKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(_jwt.SignKey));
            var encKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(_jwt.EncKey));
            _jwt.TokenValidationParameters.ClockSkew = TimeSpan.FromMinutes(5);
            _jwt.TokenValidationParameters.IssuerSigningKey = signKey;
            _jwt.TokenValidationParameters.TokenDecryptionKey = encKey;


            //ops.MetadataAddress = $"{jwt.Authority}/.well-known/oauth-authorization-server";
            // "/.well-known/oauth-authorization-server"
            // ops.ConfigurationManager = new ConfigurationManager<OpenIdConnectConfiguration>(
            //    $"{_jwt.Authority}/.well-known/oauth-authorization-server",
            //    new OpenIdConnectConfigurationRetriever(),
            //    new HttpDocumentRetriever { RequireHttps = _jwt.RequireHttpsMetadata });

            options.RequireHttpsMetadata = _jwt.RequireHttpsMetadata;
            //options.IncludeErrorDetails = _env.IsDevOrLocal();

            options.ForwardAuthenticate = JwtBearerDefaults.AuthenticationScheme;
            options.ForwardChallenge = JwtBearerDefaults.AuthenticationScheme;
            options.ForwardSignIn = JwtBearerDefaults.AuthenticationScheme;
            //options.TokenValidationParameters = _jwt.TokenValidationParameters.Clone();
            options.ClaimsIssuer = _jwt.TokenValidationParameters.ValidIssuer;
            options.RoleClaimType = _jwt.TokenValidationParameters.RoleClaimType;
            options.NameClaimType = _jwt.TokenValidationParameters.NameClaimType;
            options.SupportedTokens = SupportedTokens.Both;
            options.Authority = _jwt.Authority;
            options.ApiName = _jwt.Audience;
            //options.ApiSecret = "";
            //options.RefreshOnIssuerKeyNotFound = _jwt.RefreshOnIssuerKeyNotFound;
            options.SaveToken = _jwt.SaveToken;
            //options.EventsType = typeof(CustomIdsAuthEvents);
            // options.OAuth2IntrospectionEvents = new OAuth2IntrospectionEvents
            // {
            //     OnAuthenticationFailed = context =>
            //     {
            //         return Task.CompletedTask;
            //     },
            //     OnTokenValidated = context =>
            //     {
            //         return Task.CompletedTask;
            //     },
            // };
        }
    }

    public class CustomIdsAuthEvents : JwtBearerEvents
    {
        public override Task AuthenticationFailed(AuthenticationFailedContext context)
        {
            //context.Fail(new UnauthorizedException());
            return Task.CompletedTask;
        }
        public override Task Challenge(JwtBearerChallengeContext context)
        {
            if (context.Error != null)
            {
                var logger = context.HttpContext
                    .RequestServices
                    .GetService<ILogger<JwtBearerEvents>>();
                logger?.LogError($"OnChallenge: {context.Error}", context.ErrorDescription);
            }
            if (context.AuthenticateFailure != null)
            {
                throw context.AuthenticateFailure;
            }
            return Task.CompletedTask;
        }
        //public override Task Forbidden(ForbiddenContext context) { }
        // public override Task MessageReceived(MessageReceivedContext context)
        // {
        //     var validator = context.HttpContext
        //         .RequestServices
        //         .GetService<ITokenValidatorService>();
        //     return validator.ValidateSignatureAsync(context);
        // }
        public override Task TokenValidated(TokenValidatedContext context)
        {
            var jwt = context.SecurityToken as JwtSecurityToken;
            var type = jwt.Header.Typ;
            if (!string.Equals(type, "at+jwt", StringComparison.Ordinal))
            {
                context.Fail("JWT is not an access token");
            }
            return Task.CompletedTask;
        }
    }
}