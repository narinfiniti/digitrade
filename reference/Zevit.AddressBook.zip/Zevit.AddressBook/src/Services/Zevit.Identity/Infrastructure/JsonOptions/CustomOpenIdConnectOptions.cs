﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using IdentityServer4;
using IdentityModel;
using Zevit.Identity.Api.Extensions;
using Zevit.Identity.Api.Models.Configs;

namespace Zevit.Identity.Api.Infrastructure.JsonOptions
{
    /// <summary>
    /// Custom CustomOpenIdConnectOptions settings for Asp.Net MVC.
    /// </summary>
    public class CustomOpenIdConnectOptions : IConfigureOptions<OpenIdConnectOptions>
    {
        private readonly JwtOptions _jwt;
        public CustomOpenIdConnectOptions(
            IHostEnvironment env,
            IOptions<JwtOptions> jwt
        )
        {
            _jwt = jwt.Value;
            Microsoft.IdentityModel.Logging
                .IdentityModelEventSource.ShowPII = env.IsDevOrLocal();
        }

        public void Configure(OpenIdConnectOptions options)
        {
            JwtSecurityTokenHandler.DefaultMapInboundClaims = false;
            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();
            // var tokenHandler = new JwtSecurityTokenHandler
            // {
            //     MapInboundClaims = false,
            //     TokenLifetimeInMinutes = _jwt.AccessTokenLifetimeMinutes
            // };
            // options.SecurityTokenValidator = tokenHandler;

            var signKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(_jwt.SignKey));
            var encKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(_jwt.EncKey));
            _jwt.TokenValidationParameters.ClockSkew = TimeSpan.FromMinutes(5);
            _jwt.TokenValidationParameters.IssuerSigningKey = signKey;
            _jwt.TokenValidationParameters.TokenDecryptionKey = encKey;

            options.TokenValidationParameters = _jwt.TokenValidationParameters.Clone();
            options.Authority = _jwt.Authority;
            options.Resource = _jwt.Audience;
            options.RefreshOnIssuerKeyNotFound = _jwt.RefreshOnIssuerKeyNotFound;
            options.SaveTokens = _jwt.SaveToken;
            //ops.MetadataAddress = $"{jwt.Authority}/.well-known/openid-configuration";
            // "/.well-known/openid-configuration"
            // ops.ConfigurationManager = new ConfigurationManager<OpenIdConnectConfiguration>(
            //    $"{_jwt.Authority}/.well-known/openid-configuration",
            //    new OpenIdConnectConfigurationRetriever(),
            //    new HttpDocumentRetriever { RequireHttps = _jwt.RequireHttpsMetadata });

            options.RequireHttpsMetadata = _jwt.RequireHttpsMetadata;
            //ops.IncludeErrorDetails = _env.IsDevOrLocal();

            options.ForwardAuthenticate = OpenIdConnectDefaults.AuthenticationScheme;
            options.ForwardChallenge = OpenIdConnectDefaults.AuthenticationScheme;
            options.ForwardSignIn = OpenIdConnectDefaults.AuthenticationScheme;
            options.EventsType = typeof(CustomOpenIdConnectEvents);

            options.ClientId = "reactapp";
            options.ClientSecret = "acf2ec6fb01a4b698ba240c2b10a0243";

            options.SignInScheme = IdentityServerConstants.LocalIdentityProvider;
            options.ResponseType = OidcConstants.ResponseTypes.Code;
            options.ResponseMode = OidcConstants.ResponseModes.Query;
            options.GetClaimsFromUserInfoEndpoint = true;
            options.Scope.Add("openid");
            options.Scope.Add("profile");
            options.Scope.Add("offline_access");
            options.Scope.Add("identityapi");
            options.SkipUnrecognizedRequests = true;
            options.UsePkce = true;
            options.CallbackPath = "/signin-oidc";
            options.GetClaimsFromUserInfoEndpoint = true;
            options.SaveTokens = true;
        }
    }

    public class CustomOpenIdConnectEvents : OpenIdConnectEvents
    {
        public override Task AuthenticationFailed(AuthenticationFailedContext context)
        {
            //context.Fail(new UnauthorizedException());
            return Task.CompletedTask;
        }
        public override Task TokenResponseReceived(TokenResponseReceivedContext context)
        {
            if (context.Result?.Failure != null)
            {
                var logger = context.HttpContext
                    .RequestServices
                    .GetService<ILogger<OpenIdConnectEvents>>();
                logger?.LogError($"OnTokenResponse: {context.Result.Failure}", context.Result.Failure.Message);
                throw context.Result.Failure;
            }
            return Task.CompletedTask;
        }
        //public override Task Forbidden(ForbiddenContext context) { }
        public override Task MessageReceived(MessageReceivedContext context)
        {
            // var validator = context.HttpContext
            //     .RequestServices
            //     .GetService<ITokenValidatorService>();
            return Task.CompletedTask;//validator.ValidateSignatureAsync(context);
        }
        //public override Task TokenValidated(TokenValidatedContext context) { }
    }
}