﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace Zevit.Identity.Api.Infrastructure.JsonOptions
{
    /// <summary>
    /// Provides custom json serialization settings.
    /// </summary>
    public class JsonSerializationSettingsProvider
    {
        public static JsonSerializerSettings GetSerializerSettings()
        {
            var settings = new JsonSerializerSettings
            {
                ObjectCreationHandling = ObjectCreationHandling.Replace,
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                MissingMemberHandling = MissingMemberHandling.Ignore,
                NullValueHandling = NullValueHandling.Ignore,
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                TypeNameHandling = TypeNameHandling.None,
                DateFormatHandling = DateFormatHandling.IsoDateFormat,
                DateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind,
                DateParseHandling = DateParseHandling.DateTime,
            };
            //settings.Converters.Add(new StringEnumConverter());
            return settings;
        }
    }
}