﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
namespace Zevit.Identity.Api.Infrastructure.JsonOptions
{
    /// <summary>
    /// Custom NewtonsoftJsonSerializer settings for Asp.Net MVC.
    /// </summary>
    public class CustomNewtonsoftJsonMvcOptions
        : IConfigureOptions<MvcNewtonsoftJsonOptions>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public CustomNewtonsoftJsonMvcOptions(
            IHttpContextAccessor httpContextAccessor
        )
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public void Configure(MvcNewtonsoftJsonOptions options)
        {
            var defaultSettings = JsonSerializationSettingsProvider.GetSerializerSettings();
            var settings = options.SerializerSettings;
            settings.TypeNameHandling = defaultSettings.TypeNameHandling;
            settings.Formatting = defaultSettings.Formatting;
            settings.ContractResolver = defaultSettings.ContractResolver;
            settings.DateFormatHandling = defaultSettings.DateFormatHandling;
            settings.DateTimeZoneHandling = defaultSettings.DateTimeZoneHandling;
            settings.DateParseHandling = defaultSettings.DateParseHandling;
            settings.ObjectCreationHandling = defaultSettings.ObjectCreationHandling;
            settings.ReferenceLoopHandling = defaultSettings.ReferenceLoopHandling;
            settings.MissingMemberHandling = defaultSettings.MissingMemberHandling;
            settings.NullValueHandling = defaultSettings.NullValueHandling;
            settings.PreserveReferencesHandling = defaultSettings.PreserveReferencesHandling;

            settings.Converters = defaultSettings.Converters;
            // see https://stackoverflow.com/a/50456608/2477619
            //settings.Converters.Add(new UrlJsonConverter(httpContextAccessor));
        }
    }
}