using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace Zevit.Identity.Api.Infrastructure
{
    public class HttpClientAuthzDelegatingHandler : DelegatingHandler
    {
        private readonly IHttpContextAccessor _httpContextAccesor;
        private readonly ILogger<HttpClientAuthzDelegatingHandler> _logger;

        public HttpClientAuthzDelegatingHandler(
            IHttpContextAccessor httpContextAccesor,
            ILogger<HttpClientAuthzDelegatingHandler> logger)
        {
            _httpContextAccesor = httpContextAccesor;
            _logger = logger;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            request.Version = new Version(2, 0);
            request.Method = HttpMethod.Get;

            if (_httpContextAccesor.HttpContext == null)
            {
                return await base.SendAsync(request, cancellationToken);
            }

            var authorizationHeader = _httpContextAccesor.HttpContext.Request.Headers["Authorization"];

            if (!string.IsNullOrEmpty(authorizationHeader))
            {
                request.Headers.Add("Authorization", new List<string>() {authorizationHeader});
            }

            var token = await GetToken();

            if (token != null)
            {
                request.Headers.Authorization = new AuthenticationHeaderValue(
                    JwtBearerDefaults.AuthenticationScheme,
                    token);
            }

            return await base.SendAsync(request, cancellationToken);
        }

        private Task<string> GetToken()
        {
            const string accessToken = "access_token";
            return _httpContextAccesor.HttpContext!.GetTokenAsync(accessToken);
        }
    }
}