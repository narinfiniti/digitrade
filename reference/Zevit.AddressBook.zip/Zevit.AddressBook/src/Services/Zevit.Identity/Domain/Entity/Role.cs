﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.Identity.Api.Domain.Entity
{
    /// <summary>
    /// Role for app users.
    /// </summary>
    public sealed class Role : IdentityRole<Guid>, IEntity<Guid>
    {
        public Role() : base()
        {
            Id = Guid.NewGuid();
        }
        public Role(string roleName) : base(roleName)
        {
        }

        public override string NormalizedName => Name?.ToUpper();
        public IList<UserRole> RoleUsers { get; set; } = new List<UserRole>();
        public IList<RoleClaim> RoleClaims { get; set; } = new List<RoleClaim>();
    }
}
