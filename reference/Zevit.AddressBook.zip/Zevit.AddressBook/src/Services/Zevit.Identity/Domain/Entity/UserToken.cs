﻿using System;
using Microsoft.AspNetCore.Identity;

namespace Zevit.Identity.Api.Domain.Entity
{
    /// <summary>
    /// Role for app users.
    /// </summary>
    public class UserToken : IdentityUserToken<Guid>
    {
    }
}
