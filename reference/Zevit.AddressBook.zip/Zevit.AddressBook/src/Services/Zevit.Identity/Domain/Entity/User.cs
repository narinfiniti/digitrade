﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.Identity.Api.Domain.Entity
{
    // Add profile data for application users by adding properties to the User class
    public sealed class User : IdentityUser<Guid>, IAggregateRoot<Guid>
    {
        public User() : base()
        {
            //Id = Guid.NewGuid();
            SecurityStamp = Guid.NewGuid().ToString("D");
        }
        public User(string userName) : base(userName)
        {
        }

        public bool IsActive => !LockoutEnabled || !LockoutEnd.HasValue || LockoutEnd <= DateTimeOffset.UtcNow;

        //inherited
        public override string PhoneNumber { get; set; }

        public override string UserName { get; set; }
        public override string NormalizedUserName => UserName?.ToUpper();
        public override string Email { get; set; }
        public override string NormalizedEmail => Email?.ToUpper();
        public override string PasswordHash { get; set; }

        public IList<UserRole> Roles { get; set; } = new List<UserRole>();
        public IList<UserClaim> Claims { get; set; } = new List<UserClaim>();
        public IList<UserLogin> Logins { get; set; } = new List<UserLogin>();
        public IList<UserToken> Tokens { get; set; } = new List<UserToken>();
    }
}
