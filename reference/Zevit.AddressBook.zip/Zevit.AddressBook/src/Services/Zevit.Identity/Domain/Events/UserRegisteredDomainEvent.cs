using MediatR;
using Zevit.Identity.Api.Domain.Entity;

namespace Zevit.Identity.Api.Domain.Events
{
    public class UserRegisteredDomainEvent : INotification
    {
        public User User { get; }
        public UserRegisteredDomainEvent(User user)
        {
            User = user;
        }
    }
}