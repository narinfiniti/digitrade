using MediatR;
using Zevit.Identity.Api.Domain.Entity;

namespace Zevit.Identity.Api.Domain.Events
{
    public class UserLoggedInDomainEvent : INotification
    {
        public User User { get; }
        public UserLoggedInDomainEvent(User user)
        {
            User = user;
        }
    }
}