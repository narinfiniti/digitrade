namespace Zevit.Identity.Api.Domain.Enums
{
    /// <summary>
    /// IntegrationEventType.
    /// </summary>
    public enum IntegrationEventType
    {
        UserRegistered = 100,
        UserSignedIn = 101,
    }
}