namespace Zevit.Identity.Api.Constants
{
    /// <summary>
    /// Route options' config.
    /// </summary>
    public class Consts
    {
        public const string ApiPrefix = "/api";

        public class Version
        {
            public const string V1 = "1.0";
        }

        public class Route
        {
            public class ApiDocs
            {
                public const string Base = ApiPrefix + "/docs";
                public const string Postman = ApiPrefix + "/docs/postman-files";
            }
            public class Account
            {
                public const string Base = ApiPrefix + "/account";
                public const string Detail = "id";
            }

        }
    }
}