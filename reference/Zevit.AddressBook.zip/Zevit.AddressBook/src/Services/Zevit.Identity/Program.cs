﻿using System;
using System.IO;
using System.Net;
using System.Security.Authentication;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Zevit.Identity.Api.Extensions;
using Zevit.Identity.Api.Infrastructure.Data;
using Serilog;
using Serilog.Events;
using Serilog.Sinks.MSSqlServer;
using Serilog.Sinks.SystemConsole.Themes;
using Zevit.Identity.Api.Certificates;
using Zevit.Identity.Api.Infrastructure.DataSeed;
using Zevit.Identity.Api.Models.Configs;

namespace Zevit.Identity.Api
{
    public class Program
    {
        public static readonly string Namespace = typeof(Program).Namespace;
        public static readonly string AppName = Namespace;

        public static async Task Main(string[] args)
        {
            var config = GetConfiguration();
            Log.Logger = CreateSerilogLogger(config);
            try
            {
                Log.Information("Configuring web host ({ApplicationContext})...", AppName);
                var host = CreateHostBuilder(args, config).Build();

                Log.Information("Applying migrations ({ApplicationContext})...", AppName);

                await host.Services.MigrateAsync<IdentityGrantDbContext>((services) =>
                {
                    var context = services.GetService<IdentityGrantDbContext>();
                    return context.Database.MigrateAsync();
                });
                await host.Services.MigrateAsync<AppDbContext>((services) =>
                    new AppDbContextSeed().SeedAsync(services));
                await host.Services.MigrateAsync<IdentityConfigDbContext>((services) =>
                    new IdentityConfigDbContextSeed().SeedAsync(services));

                Log.Information("Starting web host ({ApplicationContext})...", AppName);
                await host.RunAsync();
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "Program terminated unexpectedly ({ApplicationContext})!", AppName);
                throw;
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args, IConfiguration config) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureLogging((hostContext, logBuilder) =>
                {
                    //Disabling default integrated logger
                    logBuilder.ClearProviders().AddSerilog();
                })
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder
                        .UseContentRoot(Directory.GetCurrentDirectory())
                        .CaptureStartupErrors(true)
                        .ConfigureKestrel((builderCtx, options) =>
                        {
                            var appOps = new AppOptions();
                            config.GetSection(nameof(AppOptions)).Bind(appOps);
                            options.Listen(IPAddress.Any, appOps.PortSsl, ops =>
                            {
                                ops.Protocols = HttpProtocols.Http1AndHttp2;
                                var x509 = Certificate.Load(builderCtx.Configuration, builderCtx.HostingEnvironment);
                                ops.UseHttps(x509, o => o.SslProtocols = SslProtocols.Tls12);
                            });
                            //options.ConfigureHttpsDefaults(o =>
                            //o.ClientCertificateMode = ClientCertificateMode.RequireCertificate);
                        })
                        .UseStartup<Startup>()
                        .UseConfiguration(config)
                        .UseSerilog(LoggerConfig(config));
                });

        private static IConfiguration GetConfiguration()
        {
            var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false)
                .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: false)
                //.AddUserSecrets("7823b554-417c-4e61-837f-d4157db0ff9d")
                .AddEnvironmentVariables();

            // var config = builder.Build();
            // if (config.GetValue<bool>("UseVault"))
            // {
            //     builder.AddAzureKeyVault(
            //         $"https://{config["Vault:Name"]}.vault.azure.net/",
            //         config["Vault:ClientId"],
            //         config["Vault:ClientSecret"]);
            // }

            return builder.Build();
        }

        private static Serilog.ILogger CreateSerilogLogger(IConfiguration config)
        {
            return new LoggerConfiguration()
                .ReadFrom.Configuration(config)
                .CreateLogger();
        }

        private static Action<WebHostBuilderContext, LoggerConfiguration> LoggerConfig(IConfiguration config) =>
            (hostContext, logConfig) =>
            {
                logConfig
                    .MinimumLevel.Verbose()
                    .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                    .MinimumLevel.Override("System", LogEventLevel.Warning)
                    .MinimumLevel.Override("Microsoft.AspNetCore.Authentication", LogEventLevel.Information)
                    .Enrich.WithProperty("ApplicationContext", AppName)
                    .Enrich.FromLogContext()
                    .Enrich.WithMachineName()
                    .Enrich.WithEnvironmentUserName();

                if (hostContext.HostingEnvironment.IsDevOrLocal())
                {
                    logConfig
                        //.WriteTo.File(
                        //    Path.Combine(@"Infrastructure", "Log", "log.txt"),
                        //    fileSizeLimitBytes: 5_000, rollOnFileSizeLimit: true, shared: true,
                        //    flushToDiskInterval: TimeSpan.FromSeconds(1))
                        .WriteTo.Console(
                            outputTemplate:
                            "[{Timestamp:HH:mm:ss} {Level}] {SourceContext}{NewLine}{Message:lj}{NewLine}{Exception}{NewLine}",
                            theme: AnsiConsoleTheme.Literate);
                }
                else
                {
                    // var seqServerUrl = configuration["Serilog:SeqServerUrl"];
                    // var logstashUrl = configuration["Serilog:LogstashgUrl"];
                    var connStr = config.GetConnectionString("DefaultConnection");
                    logConfig
                        .WriteTo.MSSqlServer(connStr, sinkOptions: new MSSqlServerSinkOptions
                        {
                            TableName = "Log",
                            AutoCreateSqlTable = true
                        })
                        //.WriteTo.Seq(string.IsNullOrWhiteSpace(seqServerUrl) ? "http://seq" : seqServerUrl)
                        //.WriteTo.Http(string.IsNullOrWhiteSpace(logstashUrl) ? "http://logstash:8080" : logstashUrl)
                        ;
                }
            };
    }
}