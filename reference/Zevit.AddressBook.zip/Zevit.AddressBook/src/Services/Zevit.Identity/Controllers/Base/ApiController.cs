﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Zevit.Identity.Api.Infrastructure.Filters;

namespace Zevit.Identity.Api.Controllers
{
    /// <summary>
    /// Base WebAPI controller.
    /// </summary>
    [ApiController]
    [EnableCors("CorsPolicy")]
    [Authorize("JwtBearerPolicy")]
    [TypeFilter(typeof(ValidateModelActionFilter))]
    [TypeFilter(typeof(ResponseResultFilter))]
    public abstract class ApiController : ControllerBase
    {
        private IMediator _mediator;
        protected IMediator Mediator => _mediator ??= HttpContext.RequestServices.GetService<IMediator>();
    }
}
