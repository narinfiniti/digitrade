﻿using System.IO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zevit.Common.Exceptions;
using Zevit.Common.Extensions;
using Zevit.Identity.Api.Constants;
using Zevit.Identity.Api.Models.Configs;

namespace Zevit.Identity.Api.Controllers.Base
{
    [ApiVersion(Consts.Version.V1)]
    [Route(Consts.Route.ApiDocs.Base)]
    public class DocApiController : ApiController
    {
        [AllowAnonymous]
        [HttpGet(Consts.Route.ApiDocs.Postman)]
        public FileContentResult GetPostmanFiles()
        {
            if (Directory.Exists(SwaggerOptions.PostmanDirectoryPath))
            {
                var di = new DirectoryInfo(SwaggerOptions.PostmanDirectoryPath);
                var postmanZipBytes = di.Compress();
                if (postmanZipBytes != null)
                {
                    return File(postmanZipBytes, "application/octet-stream", "postman.zip");
                }
            }
            throw new NotFoundException();
        }
    }
}