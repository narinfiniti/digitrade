﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zevit.Identity.Api.Application.Dto;
using Zevit.Identity.Api.Application.UseCase;
using Zevit.Identity.Api.Constants;

namespace Zevit.Identity.Api.Controllers
{
    [ApiVersion(Consts.Version.V1)]
    [Route(Consts.Route.Account.Base)]
    public class AccountApiController : ApiController
    {
        public AccountApiController()
        {
        }

        [HttpGet]
        [AllowAnonymous]
        public Task<Guid> Register(string returnUrl = null)
        {
            return Mediator.Send<Guid>(new UserCreateCommand
            {
                Model = new AppUserDto()
            });
        }


    }
}