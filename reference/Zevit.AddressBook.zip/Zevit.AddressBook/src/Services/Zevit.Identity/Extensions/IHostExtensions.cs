﻿using System;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Polly;

namespace Zevit.Identity.Api.Extensions
{
    /// <summary>
    /// Extensions for web host.
    /// </summary>
    public static class IHostExtensions
    {
        public static async Task MigrateAsync<TContext>(
            this IServiceProvider services,
            Func<IServiceProvider, Task> seeder) where TContext : DbContext
        {
            var logger = services.GetRequiredService<ILogger<TContext>>();
            try
            {
                logger.LogInformation("Migrations started with: {DbContextName}", typeof(TContext).Name);

                var retries = 3;
                var retry = Policy.Handle<SqlException>()
                    .WaitAndRetry(
                        retryCount: retries,
                        sleepDurationProvider: retryAttempt => TimeSpan.FromSeconds(5),
                        onRetry: (exception, timeSpan, retry, ctx) =>
                        {
                            logger.LogWarning(exception,
                                @"[{prefix}] Exception {ExceptionType}
                                        with message {Message} detected on attempt {retry} of {retries}",
                                nameof(TContext), exception.GetType().Name, exception.Message, retry, retries);
                        });

                // if the sql server container is not created on run docker compose this
                //migration can't fail for network related exception. The retry options for DbContext only 
                //apply to transient exceptions
                // Note that this is NOT applied when running some orchestrators
                //(let the orchestrator to recreate the failing service)
                await retry.Execute(async () => await seeder.Invoke(services));
                logger.LogInformation("Migrations completed with: {DbContextName}", typeof(TContext).Name);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "An error occurred while migrating with: {DbContextName}", typeof(TContext).Name);
            }
        }
    }
}