﻿using Microsoft.Extensions.Hosting;

namespace Zevit.Identity.Api.Extensions
{
    /// <summary>
    /// HttpResponseExtensions.
    /// </summary>
    public static class HostEnvironmentExtensions
    {
        public static bool IsDevOrLocal(this IHostEnvironment env)
        {
            return env.IsLocalhost() || env.IsDevelopment();
        }
        public static bool IsLocalhost(this IHostEnvironment env)
        {
            return env.IsEnvironment("Localhost");
        }
    }
}
