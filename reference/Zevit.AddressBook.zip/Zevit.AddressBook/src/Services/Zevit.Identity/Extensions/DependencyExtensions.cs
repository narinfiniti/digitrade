using System;
using System.IO;
using System.Linq;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using IdentityServer4;
using IdentityServer4.AccessTokenValidation;
using IdentityServer4.Configuration;
using Zevit.Identity.Api.Domain.Entity;
using Zevit.Identity.Api.Infrastructure.Data;
using Zevit.Identity.Api.Infrastructure.JsonOptions;
using Zevit.Identity.Api.Infrastructure.Services;
using Zevit.Identity.Api.Models.Configs;

namespace Zevit.Identity.Api.Extensions
{
    /// <summary>
    /// Extensions for service collection
    /// </summary>
    public static partial class DependencyExtensions
    {
        public static IServiceCollection AddCustomConfiguration(
            this IServiceCollection services,
            IConfiguration config,
            IWebHostEnvironment env)
        {
            var connectionString = config.GetConnectionString("DefaultConnection");

            services.Configure<AppOptions>(config.GetSection(nameof(AppOptions)));
            services.Configure<JwtOptions>(config.GetSection(nameof(JwtOptions)));
            services.Configure<FormOptions>(options =>
            {
                // Set the limit to 256 MB
                options.MultipartBodyLengthLimit = 256 * 1024 * 1024;
            });

            services.Replace(ServiceDescriptor
                .Singleton<IConfigureOptions<JwtBearerOptions>, CustomJwtBearerOptions>());
            services.Replace(ServiceDescriptor
                .Singleton<IConfigureOptions<OpenIdConnectOptions>, CustomOpenIdConnectOptions>());
            services.Replace(ServiceDescriptor
                .Singleton<IConfigureOptions<IdentityServerAuthenticationOptions>, CustomIdsAuthOptions>());

            services.AddSingleton<CustomJwtBearerEvents>();
            services.AddSingleton<CustomOpenIdConnectEvents>();
            services.AddSingleton<CustomIdsAuthEvents>();

            // NewtonsoftJsonMvcOptions
            services.Replace(ServiceDescriptor
                .Singleton<IConfigureOptions<MvcNewtonsoftJsonOptions>, CustomNewtonsoftJsonMvcOptions>());

            return services;
        }

        public static IServiceCollection AddApplicationInsights(
            this IServiceCollection services,
            IConfiguration config, IWebHostEnvironment env)
        {
            services.AddApplicationInsightsTelemetry(config);
            //services.AddApplicationInsightsKubernetesEnricher();

            return services;
        }

        public static IServiceCollection AddCustomControllers(
            this IServiceCollection services, IConfiguration config)
        {
            // Customise default API behaviour to use FluentValidators
            /*
             services.Configure<ApiBehaviorOptions>(options =>
             {
                 options.SuppressModelStateInvalidFilter = true;
                 options.InvalidModelStateResponseFactory = context =>
                 {
                     var problemDetails = new ValidationProblemDetails(context.ModelState)
                     {
                         Instance = context.HttpContext.Request.Path,
                         Status = StatusCodes.Status400BadRequest,
                         Detail = "Please refer to the errors for additional details."
                     };

                     return new BadRequestObjectResult(problemDetails)
                     {
                         ContentTypes = { "application/problem+json", "application/problem+xml" }
                     };
                 };
             });
             */
            //services.AddRazorPages();
            services.AddControllersWithViews(options =>
                {
                    //options.AllowEmptyInputInBodyModelBinding = true;
                    //options.Filters.Add(typeof(HttpGlobalExceptionFilter));
                    options.Filters.Add(new ProducesAttribute("application/json"));
                })
                .AddNewtonsoftJson()
                //.AddFluentValidation(fv => fv.RegisterValidatorsFromAssembly(Assembly.GetExecutingAssembly()))
                //.SetCompatibilityVersion(CompatibilityVersion.Version_3_0)
                ;

            return services;
        }

        public static IServiceCollection AddCustomCors(
            this IServiceCollection services,
            IConfiguration config, IWebHostEnvironment env)
        {
            var origins = config.GetSection("Origins")
                .AsEnumerable()
                .Select(x => x.Value)
                .Where(x => x != null)
                .ToArray();

            // services.AddSingleton<ICorsPolicyService>(container =>
            // {
            //     var logger = container.GetService<ILogger<DefaultCorsPolicyService>>();
            //     return new DefaultCorsPolicyService(logger)
            //     {
            //         AllowedOrigins = origins
            //     };
            // });

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy", builder =>
                {
                    builder
                        .AllowAnyHeader()
                        // .WithExposedHeaders(
                        //     HeaderNames.WWWAuthenticate,
                        //     "Grpc-Status",
                        //     "Grpc-Message",
                        //     "Grpc-Encoding",
                        //     "Grpc-Accept-Encoding"
                        // )
                        // .WithHeaders(
                        //     HeaderNames.Authorization,
                        //     HeaderNames.ContentType,
                        //     HeaderNames.Accept,
                        //     HeaderNames.Origin,
                        //     "x-requested-with"
                        // )
                        .AllowAnyMethod();
                    // .WithMethods(
                    //     HttpMethods.Get,
                    //     HttpMethods.Post,
                    //     HttpMethods.Delete,
                    //     HttpMethods.Options
                    // )
                    //.AllowCredentials() // for browser signalr-clients
                    //.DisallowCredentials()
                    // https://docs.microsoft.com/en-us/aspnet/core/security/cors?view=aspnetcore-3.1#set-the-preflight-expiration-time
                    //.SetPreflightMaxAge(TimeSpan.FromSeconds(2400))
                    if (env.IsDevOrLocal())
                    {
                        builder.AllowAnyOrigin();
                    }
                    else
                    {
                        builder.WithOrigins(origins);
                        //.SetIsOriginAllowedToAllowWildcardSubdomains()
                        //.SetIsOriginAllowed((host) => true)
                    }
                });
            });

            if (!env.IsDevOrLocal())
            {
                services.AddHsts(ops =>
                {
                    ops.Preload = true;
                    ops.IncludeSubDomains = true;
                    ops.MaxAge = TimeSpan.FromDays(60);
                    ops.ExcludedHosts.Add("example.com");
                    ops.ExcludedHosts.Add("www.example.com");
                });
                services.AddHttpsRedirection(ops =>
                {
                    ops.RedirectStatusCode = StatusCodes.Status301MovedPermanently;
                    ops.HttpsPort = config.GetValue<int>("Zevit.Identity.Api:SSL_PORT");
                });
            }

            return services;
        }

        public static IServiceCollection AddCustomAuthorization(
            this IServiceCollection services, IConfiguration config)
        {
            services.AddAuthorization(ops =>
            {
                // options.DefaultPolicy = new AuthorizationPolicyBuilder()
                //     .RequireAuthenticatedUser()
                //     .AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme)
                //     .AddAuthenticationSchemes("oidc")
                //     .Build();
                //o.FallbackPolicy = new AuthorizationPolicyBuilder()
                //  .RequireAuthenticatedUser().Build();

                ops.AddPolicy("JwtBearerPolicy", b =>
                {
                    b.AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme);
                    b.RequireAuthenticatedUser();
                    // custom requirements
                });

                // o.AddPolicy("DomainRestricted", b =>
                // {
                //     b.Requirements.Add(new DomainRestrictedRequirement());
                // });
            });

            return services;
        }

        public static IServiceCollection AddCustomApiVersioning(
            this IServiceCollection services, IConfiguration config)
        {
            services.AddApiVersioning(ops =>
            {
                //o.Conventions.Controller<UserController>().HasApiVersion(1, 0);
                ops.RegisterMiddleware = true;
                ops.ReportApiVersions = true;
                ops.AssumeDefaultVersionWhenUnspecified = true;
                ops.DefaultApiVersion = null;
                ops.ApiVersionSelector = new CurrentImplementationApiVersionSelector(ops);
                //o.ApiVersionReader = new UrlSegmentApiVersionReader();
                ops.ApiVersionReader = new MediaTypeApiVersionReader("v");
            });
            services.AddVersionedApiExplorer(ops =>
            {
                // version as "'v'major[.minor][-status]"
                ops.GroupNameFormat = "'v'VVV";
                // only necessary when versioning by url segment.
                // the SubstitutionFormat can also be used to control the
                // format of the API version in route templates
                ops.SubstituteApiVersionInUrl = false;
            });

            return services;
        }

        public static IServiceCollection AddHealthChecks(
            this IServiceCollection services,
            IConfiguration config, IWebHostEnvironment env)
        {
            var connectionString = config.GetConnectionString("DefaultConnection");
            services.AddHealthChecks()
                .AddCheck("/health", () => HealthCheckResult.Healthy())
                .AddSqlServer(connectionString,
                    name: "/health/db",
                    tags: new[] {"/health/db"});

            return services;
        }

        public static IServiceCollection AddCustomSwagger(
            this IServiceCollection services,
            IConfiguration config, IWebHostEnvironment env)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new SwaggerOptions(env.ContentRootPath) {Version = "v1"});
                options.IncludeXmlComments(
                    Path.Combine(AppContext.BaseDirectory, "Zevit.Identity.Api.xml")
                );
                options.AddSecurityDefinition("ApiKey", new OpenApiSecurityScheme()
                {
                    Type = SecuritySchemeType.ApiKey,
                    In = ParameterLocation.Header,
                    Name = "Authorization",
                    Description = "Authorization Api Key",
                });
                options.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                                {Type = ReferenceType.SecurityScheme, Id = "ApiKey"}
                        },
                        new string[] { }
                    }
                });

                /*
                options.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
                {
                   Type = SecuritySchemeType.OAuth2,
                   Flows = new OpenApiOAuthFlows
                   {
                       Implicit = new OpenApiOAuthFlow
                       {
                           AuthorizationUrl = new Uri($"{config.GetValue<string>("MobileApi:Url")}/connect/authorize"),
                           TokenUrl = new Uri($"{config.GetValue<string>("MobileApi:Url")}/connect/token"),

                           Scopes = new Dictionary<string, string>
                           {
                               { "ff45ec867dcd46da991d042de8cfc113", "Http Aggregator for Mobile Clients" }
                           }
                       }
                   }
                });
                options.OperationFilter<OpenApiAuthorizationFilter>();
                */
            });

            return services;
        }

        public static IServiceCollection AddCustomAuthentication(
            this IServiceCollection services,
            IConfiguration config,
            IWebHostEnvironment env)
        {
            services.AddIdentity<User, Role>(ops =>
            {
                ops.Password.RequiredLength = 6;
                ops.Password.RequireDigit = false;
                ops.Password.RequireNonAlphanumeric = false;
                ops.Password.RequireUppercase = false;
            })
            .AddEntityFrameworkStores<AppDbContext>()
            .AddDefaultTokenProviders();

            var connectionString = config.GetConnectionString("DefaultConnection");
            //services.AddTransient<ITokenCreationService, JweTokenCreationService>();
            // Adds IdentityServer
            var ids = services.AddIdentityServer(options =>
                    {
                        options.IssuerUri = null; //config.GetSection("JwtOptions:Authority").Value;

                        options.Events.RaiseErrorEvents = env.IsDevOrLocal();
                        options.Events.RaiseInformationEvents = env.IsDevOrLocal();
                        options.Events.RaiseFailureEvents = env.IsDevOrLocal();
                        options.Events.RaiseSuccessEvents = env.IsDevOrLocal();
                        options.UserInteraction = new UserInteractionOptions
                        {
                            LogoutUrl = "/Account/Logout",
                            LoginUrl = "/Account/Login",
                            LoginReturnUrlParameter = "returnUrl",
                            LogoutIdParameter = "logoutId"
                        };
                        options.Authentication = new AuthenticationOptions
                        {
                            CookieLifetime = TimeSpan.FromHours(2), // ID server cookie timeout set to 10 hours
                            CookieSlidingExpiration = true,
                            CookieSameSiteMode = SameSiteMode.Lax
                        };
                    })
                    .AddConfigurationStore<IdentityConfigDbContext>(options => options.ConfigureDbContext = builder =>
                        builder.UseSqlServer(connectionString, b =>
                        {
                            b.MigrationsAssembly(typeof(IdentityConfigDbContext).Assembly.FullName);
                            //Configuring Connection Resiliency: https://docs.microsoft.com/en-us/ef/core/miscellaneous/connection-resiliency 
                            b.EnableRetryOnFailure(
                                maxRetryCount: 3,
                                maxRetryDelay: TimeSpan.FromSeconds(5),
                                errorNumbersToAdd: null);
                        }))
                    .AddOperationalStore<IdentityGrantDbContext>(options =>
                    {
                        options.ConfigureDbContext = builder =>
                            builder.UseSqlServer(connectionString, b =>
                            {
                                b.MigrationsAssembly(typeof(IdentityGrantDbContext).Assembly.FullName);
                                //Configuring Connection Resiliency: https://docs.microsoft.com/en-us/ef/core/miscellaneous/connection-resiliency 
                                b.EnableRetryOnFailure(
                                    maxRetryCount: 3,
                                    maxRetryDelay: TimeSpan.FromSeconds(5),
                                    errorNumbersToAdd: null);
                            });
                        // this enables automatic token cleanup. this is optional.
                        options.EnableTokenCleanup = true;
                        options.TokenCleanupInterval = 30;
                    })
                    .AddAspNetIdentity<User>()
                    .AddProfileService<ProfileService>()
                //.AddResourceOwnerValidator<ResourceOwnerPasswordValidator>()
                //.AddCustomTokenRequestValidator<CustomTokenRequestValidator>()
                //.AddJwtBearerClientAuthentication()
                ;

            if (env.IsDevOrLocal())
            {
                ids
                    .AddDeveloperSigningCredential()
                    //.AddTemporarySigningCredential()
                    // .AddSigningKeyManagement(options =>
                    // {
                    //     options.Licensee = "DEMO";
                    //     options.License = "asasdfkabkkjbfkdbfkak";
                    //     options.KeyActivationDelay = TimeSpan.FromSeconds(10);
                    //     options.KeyExpiration = TimeSpan.FromSeconds(20);
                    //     options.KeyRetirement = TimeSpan.FromSeconds(40);
                    // })
                    // .PersistKeysToDatabase(
                    //     new IdentityServer4.KeyManagement.EntityFramework.DatabaseKeyManagementOptions
                    //     {
                    //         ConfigureDbContext = builder => builder.UseSqlServer(connectionString)
                    //     })
                    // .ProtectKeysWithDataProtection()
                    // .EnableInMemoryCaching()
                    ;
            }
            else
            {
                // var keyInfo = new SecurityKeyInfo
                // {
                //     Key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config.GetSection("JwtOptions:SignKey").Value)),
                //     SigningAlgorithm = SecurityAlgorithms.HmacSha256Signature
                // };
                // var signCred = new SigningCredentials(
                //     new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config.GetSection("JwtOptions:SignKey").Value)),
                //     SecurityAlgorithms.HmacSha256Signature);
                //ids
                //.AddSigningCredential(GetRsaKey(config))
                //.AddValidationKey(keyInfo);
            }

            services
                .AddAuthentication(options =>
                {
                    options.DefaultAuthenticateScheme = IdentityServerConstants.LocalIdentityProvider;
                    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddCookie(IdentityServerConstants.LocalIdentityProvider, options =>
                {
                    options.Cookie.MaxAge = TimeSpan.FromHours(2);
                    // ID server cookie timeout set to 2 hours
                    options.SlidingExpiration = true;
                    options.ExpireTimeSpan = TimeSpan.FromHours(2);
                    options.Cookie.SameSite = SameSiteMode.Lax;
                })
                .AddIdentityServerAuthentication(JwtBearerDefaults.AuthenticationScheme, options =>
                {
                    using var serviceProvider = services.BuildServiceProvider();
                    var configOps = serviceProvider
                        .GetRequiredService<IOptions<IdentityServerAuthenticationOptions>>()
                        .Value;
                    options.Authority = configOps.Authority;
                    options.RequireHttpsMetadata = configOps.RequireHttpsMetadata;
                    options.ApiName = configOps.ApiName;
                });
            return services;
        }

        public static IServiceCollection AddHttpServices(
            this IServiceCollection services, IWebHostEnvironment env)
        {
            //register delegating handlers
            //services.AddTransient<HttpClientAuthzDelegatingHandler>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            return services;
        }
    }
}