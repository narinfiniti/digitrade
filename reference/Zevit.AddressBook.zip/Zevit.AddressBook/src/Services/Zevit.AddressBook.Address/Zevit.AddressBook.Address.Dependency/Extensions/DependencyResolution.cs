﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Zevit.AddressBook.Address.Application.Extensions;
using Zevit.AddressBook.Address.Infra.DataSeed.Extensions;
using Zevit.AddressBook.Address.Infrastructure.Extensions;
using Zevit.AddressBook.Address.Persistence.Extensions;

namespace Zevit.AddressBook.Address.Dependency.Extensions
{
    public static class DependencyResolution
    {
        public static IServiceCollection AddDependencies(this IServiceCollection services,
            IConfiguration configuration,
            IHostEnvironment env)
        {
            services.AddPersistence(configuration, env);
            services.AddInfrastructure(configuration, env);
            services.AddUseCaseDependencies(configuration, env);

            //services.AddBackgroundWorker(configuration);
            services.AddDataSeeder();
            //services.AddWebSockets(configuration, env);
            //services.AddSignalrHubs(configuration, env);

            return services;
        }
    }
}
