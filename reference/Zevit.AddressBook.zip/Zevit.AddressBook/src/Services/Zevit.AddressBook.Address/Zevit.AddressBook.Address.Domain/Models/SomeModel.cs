﻿namespace Zevit.AddressBook.Address.Domain.Models
{
    public class SomeModel
    {
        public string Id { get; set; }
        public string EventId { get; set; }
    }
}
