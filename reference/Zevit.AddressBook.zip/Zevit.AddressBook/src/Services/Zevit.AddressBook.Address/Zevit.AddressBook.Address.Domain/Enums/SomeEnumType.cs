namespace Zevit.AddressBook.Address.Domain.Enums
{
    /// <summary>
    /// SomeEnumType.
    /// </summary>
    public enum SomeEnumType
    {
    }
}