namespace Zevit.AddressBook.Address.Domain.Interface
{
    /// <summary>
    /// IDomainLogic.
    /// </summary>
    public interface IDomainLogic
    {
    }
}