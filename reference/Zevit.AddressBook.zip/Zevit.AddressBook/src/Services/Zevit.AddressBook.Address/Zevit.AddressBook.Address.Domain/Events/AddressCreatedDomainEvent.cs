using MediatR;
using Zevit.AddressBook.Address.Domain.Entity;

namespace Zevit.AddressBook.Address.Domain.Events
{
    /// <summary>
    /// Address Created Domain Event.
    /// </summary>
    public class AddressCreatedDomainEvent : INotification
    {
        public ContactAddress Address { get; init; }

        public AddressCreatedDomainEvent(ContactAddress address)
        {
            Address = address;
        }
    }
}