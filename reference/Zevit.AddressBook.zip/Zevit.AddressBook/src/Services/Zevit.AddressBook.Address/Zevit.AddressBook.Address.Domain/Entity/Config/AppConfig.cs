namespace Zevit.AddressBook.Address.Domain.Entity.Config
{
    /// <summary>
    /// AppConfig.
    /// </summary>
    public class AppConfig
    {
        public int BackgroundTaskExecTimeout { get; set; }
    }
}