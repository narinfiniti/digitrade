﻿using System;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Address.Domain.Entity
{
    /// <summary>
    /// ContactAddress.
    /// </summary>
    public class ContactAddress : IAggregateRoot<Guid>
    {
        public Guid Id { get; set; }
        public Guid ContactId { get; set; }

        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }

        public override bool Equals(object obj)
        {
            if (obj is ContactAddress other)
            {
                return other.Id == Id;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }
    }
}
