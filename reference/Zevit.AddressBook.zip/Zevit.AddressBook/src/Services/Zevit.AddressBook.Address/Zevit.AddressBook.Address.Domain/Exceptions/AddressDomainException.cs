using System.Collections.Generic;
using Zevit.Common.Exceptions;
using Zevit.Common.Models;

namespace Zevit.AddressBook.Address.Domain.Exceptions
{
    /// <summary>
    /// Domain Exception for Address service sub-domain.
    /// </summary>
    public class AddressDomainException : ValidationException
    {
        public AddressDomainException(string message, int statusCode = 422)
            : base(message, statusCode)
        {
        }

        public AddressDomainException(IEnumerable<ValidationFailure> failures, string message)
            : base(failures, message)
        {
        }
    }
}