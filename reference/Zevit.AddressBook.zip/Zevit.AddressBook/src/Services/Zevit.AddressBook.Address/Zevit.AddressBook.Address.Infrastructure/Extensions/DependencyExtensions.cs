﻿using Microsoft.Extensions.Caching.SqlServer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Zevit.AddressBook.Address.Application.Interfaces.Services;
using Zevit.AddressBook.Address.Infrastructure.Services;
using Zevit.Messaging.Extensions;
using Zevit.SharedKernel.Extensions;

namespace Zevit.AddressBook.Address.Infrastructure.Extensions
{
    /// <summary>
    /// Extensions for adding dependencies into service collection.
    /// </summary>
    public static class DependencyExtensions
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services,
            IConfiguration config,
            IHostEnvironment env)
        {
            services.AddDistributedSqlServerCache(ops =>
            {
                config.GetSection(nameof(SqlServerCacheOptions)).Bind(ops);
                ops.ConnectionString = config.GetConnectionString("DefaultConnection");
            });


            services.AddSharedKernelInfrastructure(config, env);
            services.AddIntegrationEventMessaging(config, env);
            services.AddTransient<IAddressIntegrationEventService, AddressIntegrationEventService>();

            //services.AddHttpClient();

            return services;
        }
    }
}