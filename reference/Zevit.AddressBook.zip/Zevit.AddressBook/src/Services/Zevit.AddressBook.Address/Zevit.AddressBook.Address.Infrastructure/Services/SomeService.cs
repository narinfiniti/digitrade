using Zevit.AddressBook.Address.Application.Interfaces.Services;

namespace Zevit.AddressBook.Address.Infrastructure.Services
{
    /// <summary>
    /// SomeService.
    /// </summary>
    public class SomeService : ISomeService
    {
    }
}