﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Zevit.AddressBook.Address.Application.Interfaces.Services;
using Zevit.Messaging.Abstractions;
using Zevit.Messaging.Abstractions.Events;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Address.Infrastructure.Services
{
    public class AddressIntegrationEventService : IAddressIntegrationEventService
    {
        private readonly IEventBus _eventBus;
        private readonly IUnitOfWork _dbContext;
        private readonly ILogger<AddressIntegrationEventService> _logger;
        private readonly IEventSnapshotService _eventSnapshotService;

        public AddressIntegrationEventService(IEventBus eventBus,
            IUnitOfWork dbContext,
            IEventSnapshotService eventSnapshotService,
            ILogger<AddressIntegrationEventService> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _eventSnapshotService = eventSnapshotService ??
                                    throw new ArgumentNullException(nameof(eventSnapshotService));
            _eventBus = eventBus ?? throw new ArgumentNullException(nameof(eventBus));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task PublishEventsThroughEventBusAsync(Guid transactionId)
        {
            var conn = ((DbContext) _dbContext).Database.GetDbConnection();
            var pendingEvents = await _eventSnapshotService
                .GetEventsPendingToPublishAsync(transactionId);

            foreach (var ev in pendingEvents)
            {
                _logger.LogInformation($"----- Publishing integration event: {ev.Id} - ({ev.IntegrationEvent})");

                try
                {
                    await _eventSnapshotService.MarkEventAsInProgressAsync(ev.Id);
                    _eventBus.Publish(ev.IntegrationEvent);
                    await _eventSnapshotService.MarkEventAsPublishedAsync(ev.Id);
                }
                catch (Exception ex)
                {
                    var msg = $"ERROR publishing integration event: {ev.Id}";
                    _logger.LogError(ex, msg);
                    await _eventSnapshotService.MarkEventAsFailedAsync(ev.Id);
                }
            }
        }

        public async Task AddAndSaveEventAsync(IntegrationEvent @event)
        {
            _logger
                .LogInformation(
                    "----- Enqueuing integration event {IntegrationEventId} to repository ({@IntegrationEvent})",
                    @event.Id, @event);
            var conn = ((DbContext) _dbContext).Database.GetDbConnection();
            await _eventSnapshotService.SaveEventAsync(@event, _dbContext.CurrentTransaction);
        }
    }
}