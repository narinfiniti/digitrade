﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Zevit.AddressBook.Address.Application.Interfaces.Common;
using Zevit.AddressBook.Address.Domain.Entity;
using Zevit.AddressBook.Address.Domain.Entity.Config;
using Zevit.AddressBook.Address.Infra.DataSeed.DataProviders;
using Zevit.AddressBook.Address.Persistence.Common;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Address.Infra.DataSeed
{
    /// <summary>
    /// Seeds the data for database
    /// </summary>
    public class DataSeeder : IDataSeeder
    {
        private readonly ILogger<DataSeeder> _logger;
        private readonly IHostEnvironment _env;
        private UnitOfWork _context;
        public DataSeeder(
            ILogger<DataSeeder> logger,
            IHostEnvironment env)
        {
            _logger = logger;
            _env = env;
        }

        public async Task SeedAsync(IUnitOfWork context)
        {
            try
            {
                _context = (UnitOfWork)context;
                await _context.Database.OpenConnectionAsync();
                await Seed<AppSetting>(new JsonFileDataProvider<AppSetting>());
                await Seed<ContactAddress>(new JsonFileDataProvider<ContactAddress>());


                //await Seed(new ScriptDataProvider("udtt_createUserDefinedTypes"));

            }
            catch (Exception ex)
            {
                _logger.LogError(new EventId(ex.HResult), ex, ex.Message);
            }
            finally
            {
                await _context.Database.CloseConnectionAsync();
                _context = null;
            }
        }

        private async Task Seed<TEntity>(IDataProvider<TEntity> dataProvider)
            where TEntity : class
        {
            if (await _context.Set<TEntity>().AnyAsync())
            {
                return;
            }
            var data = dataProvider.GetData();
            await _context.AddRangeAsync(data);

            var schema = UnitOfWork.DbScheme;
            var tableName = typeof(TEntity).Name;

            if (_context.Database.IsSqlServer())
            {
                var on = $@"IF OBJECTPROPERTY(OBJECT_ID('[{schema}].[{tableName}]'), 'TableHasIdentity') = 1
	                SET IDENTITY_INSERT [{schema}].[{tableName}] ON;";
                await _context.Database.ExecuteSqlRawAsync(on);
            }
            await _context.SaveChangesAsync();
            if (_context.Database.IsSqlServer())
            {
                var off = $@"IF OBJECTPROPERTY(OBJECT_ID('[{schema}].[{tableName}]'), 'TableHasIdentity') = 1
	                SET IDENTITY_INSERT [{schema}].[{tableName}] OFF;";
                await _context.Database.ExecuteSqlRawAsync(off);
            }
        }
        private async Task Seed(IScriptDataProvider provider)
        {
            var batches = provider.GetScriptSql()
                .Split(new[] { "GO", "GO;" }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var batch in batches)
            {
                await _context.Database.ExecuteSqlRawAsync(batch);
            }
        }
    }
}
