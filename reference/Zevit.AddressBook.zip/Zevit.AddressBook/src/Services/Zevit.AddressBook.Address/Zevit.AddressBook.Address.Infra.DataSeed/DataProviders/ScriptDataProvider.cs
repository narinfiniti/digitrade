﻿using Zevit.Common.Extensions;

namespace Zevit.AddressBook.Address.Infra.DataSeed.DataProviders
{
    /// <summary>
    /// ScriptDataProvider.
    /// </summary>
    internal class ScriptDataProvider : IScriptDataProvider
    {
        private string _fileName;
        public ScriptDataProvider(string fileName)
        {
            _fileName = fileName;
        }
        public string GetScriptSql()
        {
            if (!_fileName.Contains(".sql")) _fileName = $"{_fileName}.sql";
            return _fileName.ReadEmbeddedResource<DataSeeder>();
        }
    }
}