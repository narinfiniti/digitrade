﻿namespace Zevit.AddressBook.Address.Infra.DataSeed
{
    /// <summary>
    /// Abstraction for preparing script data for seeding.
    /// </summary>
    public interface IScriptDataProvider
    {
        string GetScriptSql();
    };
}
