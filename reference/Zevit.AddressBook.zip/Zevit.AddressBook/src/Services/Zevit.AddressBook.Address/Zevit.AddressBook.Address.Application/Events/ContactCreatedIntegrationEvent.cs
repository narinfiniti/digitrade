using System;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Logging;
using Zevit.AddressBook.Address.Application.Dto;
using Zevit.AddressBook.Address.Application.UseCase;
using Zevit.Messaging.Abstractions;
using Zevit.Messaging.Abstractions.Events;

namespace Zevit.AddressBook.Address.Application.Events
{
    /// <summary>
    /// Contact Created Integration Event.
    /// </summary>
    public class ContactCreatedIntegrationEvent : IntegrationEvent
    {
        public Guid ContactId { get; set; }

        public ContactCreatedIntegrationEvent(Guid contactId)
        {
            ContactId = contactId;
        }

        public class Handler : IIntegrationEventHandler<ContactCreatedIntegrationEvent>
        {
            private readonly IMediator _mediator;
            private readonly ILogger<Handler> _logger;

            public Handler(
                IMediator mediator,
                ILogger<Handler> logger)
            {
                _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
                _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            }

            public Task Handle(ContactCreatedIntegrationEvent @event)
            {
                _logger.LogInformation($"----- Handling integration event: {@event.Id} - ({@event})");

                // TODO: Execute any command on contact create.
                // var command = new AddressCreateCommand
                // {
                //     Model = new AddressCreateOrUpdateDto
                //     {
                //         Id = Guid.NewGuid(),
                //         ContactId = @event.ContactId,
                //         City = "Some City",
                //         State = "Some State",
                //         Country = "Some Country"
                //     }
                // };
                // return _mediator.Send(command);
                return Task.CompletedTask;
            }
        }
    }
}