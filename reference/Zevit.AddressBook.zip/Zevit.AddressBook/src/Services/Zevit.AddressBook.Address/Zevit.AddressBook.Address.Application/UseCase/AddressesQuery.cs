using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using MediatR;
using Zevit.AddressBook.Address.Application.Dto;
using Zevit.AddressBook.Address.Application.Interfaces.Repositories;
using Zevit.AddressBook.Address.Application.Models.Filters;
using Zevit.Common.Models.Response;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Address.Application.UseCase
{
    /// <summary>
    /// ContactsQuery.
    /// </summary>
    public class AddressesQuery
        : IUseCase<AddressListFilter, ListResult<AddressDto>>
    {
        public AddressListFilter Model { get; set; }
        public class Handler
            : IRequestHandler<AddressesQuery, ListResult<AddressDto>>
        {
            private readonly IMapper _mapper;
            private readonly IAddressRepository _addressRepo;

            public Handler(
                IMapper mapper,
                IAddressRepository addressRepo
             )
            {
                _mapper = mapper;
                _addressRepo = addressRepo;
            }

            public async Task<ListResult<AddressDto>> Handle(
                AddressesQuery request,
                CancellationToken cancellationToken)
            {
                var filter = request.Model;
                var result = await _addressRepo.FindAddressRangeAsync(filter);
                return _mapper.Map<ListResult<AddressDto>>(result);
            }
        }
    }
}