﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Zevit.AddressBook.Address.Application.Dto;
using Zevit.AddressBook.Address.Application.Interfaces.Repositories;
using Zevit.AddressBook.Address.Domain.Entity;
using MediatR;
using Zevit.Common.Exceptions;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Address.Application.UseCase
{
    /// <summary>
    /// ContactCreateCommand.
    /// </summary>
    public class AddressCreateCommand
        : IUseCase<AddressCreateOrUpdateDto, AddressDto>
    {
        public AddressCreateOrUpdateDto Model { get; set; }
        public class Handler
            : IRequestHandler<AddressCreateCommand, AddressDto>
        {
            private readonly IMapper _mapper;
            private readonly IAddressRepository _addressRepo;
            private readonly IUserProfileService _userProfileService;

            public Handler(
                IMapper mapper,
                IAddressRepository addressRepo,
                IUserProfileService userProfileService
                )
            {
                _mapper = mapper;
                _addressRepo = addressRepo;
                _userProfileService = userProfileService;
            }

            public async Task<AddressDto> Handle(
                AddressCreateCommand request, CancellationToken cancellationToken)
            {
                var model = request.Model;
                var roles = _userProfileService.Roles;
                if (roles == null)
                {
                    throw new UnauthorizedException();
                }
                var address = new ContactAddress
                {
                    Id = Guid.NewGuid(),
                    ContactId = model.ContactId,
                    City = $"{roles.FirstOrDefault()} Contact {model.City}",
                    State = $"{roles.FirstOrDefault()} Contact {model.State}",
                    Country = $"{roles.FirstOrDefault()} Contact {model.Country}"
                };
                await _addressRepo.AddAsync(address);
                await _addressRepo.Uow.SaveAsync(cancellationToken);
                return _mapper.Map<AddressDto>(address);
            }
        }
    }
}