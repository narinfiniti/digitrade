﻿using System;
using System.Threading.Tasks;
using Zevit.Messaging.Abstractions.Events;

namespace Zevit.AddressBook.Address.Application.Interfaces.Services
{
    /// <summary>
    /// Abstraction for Address  service integration event publish.
    /// </summary>
    public interface IAddressIntegrationEventService
    {
        Task PublishEventsThroughEventBusAsync(Guid transactionId);
        Task AddAndSaveEventAsync(IntegrationEvent @event);
    }
}
