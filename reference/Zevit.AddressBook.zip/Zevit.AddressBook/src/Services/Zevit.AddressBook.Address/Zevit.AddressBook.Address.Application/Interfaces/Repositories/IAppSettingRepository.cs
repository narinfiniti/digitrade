using Zevit.AddressBook.Address.Domain.Entity.Config;

namespace Zevit.AddressBook.Address.Application.Interfaces.Repositories
{
    /// <summary>
    /// Abstraction for AppSetting Repository.
    /// </summary>
    public interface IAppSettingRepository
    {
        AppSetting Find(byte id, bool useCache = true);
        AppSetting Save(AppSetting entity);
    }
}