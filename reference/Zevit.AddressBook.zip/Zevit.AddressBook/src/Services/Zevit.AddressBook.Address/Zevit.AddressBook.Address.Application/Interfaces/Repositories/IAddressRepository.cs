using System;
using System.Threading.Tasks;
using Zevit.AddressBook.Address.Application.Models.Filters;
using Zevit.AddressBook.Address.Domain.Entity;
using Zevit.Common.Models.Response;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Address.Application.Interfaces.Repositories
{
    public interface IAddressRepository : IRepository<ContactAddress, Guid>
    {
        Task<ListResult<ContactAddress>> FindAddressRangeAsync(AddressListFilter filter);
    }
}