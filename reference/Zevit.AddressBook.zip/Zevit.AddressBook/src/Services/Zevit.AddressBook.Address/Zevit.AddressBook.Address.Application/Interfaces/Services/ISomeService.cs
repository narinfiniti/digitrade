﻿namespace Zevit.AddressBook.Address.Application.Interfaces.Services
{
    /// <summary>
    /// ISomeService.
    /// </summary>
    public interface ISomeService
    {
    }
}