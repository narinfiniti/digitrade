﻿using System.Reflection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Zevit.AddressBook.Address.Application.Mapping;
using MediatR;
using Zevit.AddressBook.Address.Application.Behaviors;
using Zevit.AddressBook.Address.Application.Events;
using Zevit.Messaging.Abstractions;

namespace Zevit.AddressBook.Address.Application.Extensions
{
    public static partial class DependencyExtensions
    {
        public static IServiceCollection AddUseCaseDependencies(
            this IServiceCollection services,
            IConfiguration configuration,
            IHostEnvironment env)
        {
            services.AddMediatR(c => c.AsTransient(), Assembly.GetExecutingAssembly());
            // services.AddScoped(typeof(IPipelineBehavior<,>), typeof(RequestPerformanceBehaviour<,>));
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestValidationBehavior<,>));
            //services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestTransactionBehaviour<,>));
            services.AddAutoMapper(
                assemblies: new[] { typeof(MappingProfile).GetTypeInfo().Assembly },
                serviceLifetime: ServiceLifetime.Transient
            );

            services.AddTransient<IIntegrationEventHandler<ContactCreatedIntegrationEvent>, ContactCreatedIntegrationEvent.Handler>();
            return services;
        }
    }
}
