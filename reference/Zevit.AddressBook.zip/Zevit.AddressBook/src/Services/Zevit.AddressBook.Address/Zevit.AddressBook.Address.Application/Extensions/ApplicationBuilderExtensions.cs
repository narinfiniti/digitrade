using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Zevit.AddressBook.Address.Application.Events;
using Zevit.Messaging.Abstractions;

namespace Zevit.AddressBook.Address.Application.Extensions
{
    public static class ApplicationBuilderExtensions
    {
        public static void ConfigureEventBus(this IApplicationBuilder app)
        {
            var eventBus = app.ApplicationServices.GetRequiredService<IEventBus>();

            eventBus.Subscribe<ContactCreatedIntegrationEvent, IIntegrationEventHandler<ContactCreatedIntegrationEvent>>();
        }
    }
}