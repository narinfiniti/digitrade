using System;
using Zevit.Common.Models;

namespace Zevit.AddressBook.Address.Application.Models.Filters
{
    /// <summary>
    /// ContactFilter.
    /// </summary>
    public class AddressListFilter : PageFilter
    {
        public Guid? ContactId { get; set; }
    }
}