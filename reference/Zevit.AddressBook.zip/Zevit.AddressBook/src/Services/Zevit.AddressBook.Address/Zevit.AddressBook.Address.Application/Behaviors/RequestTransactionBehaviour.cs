﻿using System;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Zevit.AddressBook.Address.Application.Interfaces.Services;
using Zevit.Common.Extensions;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Address.Application.Behaviors
{
    /// <summary>
    /// Request validation pipeline behavior.
    /// </summary>
    /// <typeparam name="TRequest"></typeparam>
    /// <typeparam name="TResponse"></typeparam>
    public class RequestTransactionBehaviour<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    {
        private readonly ILogger<RequestTransactionBehaviour<TRequest, TResponse>> _logger;
        private readonly IUnitOfWork _dbContext;
        private readonly IAddressIntegrationEventService _integrationEventService;

        public RequestTransactionBehaviour(
            IUnitOfWork dbContext,
            IAddressIntegrationEventService integrationEventService,
            ILogger<RequestTransactionBehaviour<TRequest, TResponse>> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentException(nameof(IUnitOfWork));
            _integrationEventService = integrationEventService ??
                throw new ArgumentException(nameof(integrationEventService));
            _logger = logger ?? throw new ArgumentException(nameof(ILogger));
        }

        public async Task<TResponse> Handle(
            TRequest request,
            CancellationToken cancellationToken,
            RequestHandlerDelegate<TResponse> next)
        {
            var response = default(TResponse);
            var typeName = request.GetGenericTypeName();

            try
            {
                if (_dbContext.HasActiveTransaction)
                {
                    return await next();
                }

                var strategy = ((DbContext)_dbContext).Database.CreateExecutionStrategy();
                await strategy.ExecuteAsync(async () =>
                {
                    await using var transaction = await _dbContext.BeginTransactionAsync();
                    _logger.LogInformation("----- Begin transaction {TransactionId} for {CommandName} ({@Command})",
                        transaction.TransactionId, typeName, request);

                    response = await next();

                    _logger.LogInformation("----- Commit transaction {TransactionId} for {CommandName}",
                        transaction.TransactionId, typeName);

                    await _dbContext.CommitAsync(transaction);

                    var transactionId = transaction.TransactionId;
                    
                    await _integrationEventService.PublishEventsThroughEventBusAsync(transactionId);
                });

                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ERROR Handling transaction for {CommandName} ({@Command})", typeName, request);
                throw;
            }
        }
    }
}