﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace Zevit.AddressBook.Address.Application.Behaviors
{
    /// <summary>
    /// Request Logger.
    /// </summary>
    /// <typeparam name="TRequest"></typeparam>
    public class RequestLoggerPreProcessor<TRequest> //: IRequestPreProcessor<TRequest>
    {
        private readonly ILogger _logger;

        public RequestLoggerPreProcessor(
            ILogger<RequestLoggerPreProcessor<TRequest>> logger)
        {
            _logger = logger;
        }

        public Task Process(TRequest request, CancellationToken cancellationToken)
        {
            var requestName = typeof(TRequest).Name;
            var userId = Guid.Empty;// _userService.GetStringId();
            var userName = "userName";// _userService.GetUserName();

            _logger.LogInformation("Request: {Name} {@UserId} {@UserName} {@Request}",
                requestName, userId, userName, request);

            return Task.CompletedTask;
        }
    }
}
