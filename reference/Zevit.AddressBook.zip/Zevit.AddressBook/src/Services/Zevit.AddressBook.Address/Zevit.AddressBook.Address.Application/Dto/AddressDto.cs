using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Zevit.AddressBook.Address.Domain.Entity;
using Zevit.Common.Models.Response;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Address.Application.Dto
{
    /// <summary>
    /// UserContactDto.
    /// </summary>
    public class AddressDto
        : IAutoMap<ContactAddress, AddressDto>
    {
        public Guid Id { get; set; }
        public Guid ContactId { get; set; }

        [Required, MaxLength(100)] public string City { get; set; }
        [MaxLength(100)] public string State { get; set; }
        [Required, MaxLength(100)] public string Country { get; set; }

        public void CreateMap(Profile profile)
        {
            profile.CreateMap<ContactAddress, AddressDto>()
            .ReverseMap()
            ;

            profile.CreateMap<ListResult<ContactAddress>, ListResult<AddressDto>>();
            profile.CreateMap<List<ContactAddress>, ListResult<AddressDto>>()
                .ForMember(to => to.Items, c => c.MapFrom(from => from));
        }

    }
}