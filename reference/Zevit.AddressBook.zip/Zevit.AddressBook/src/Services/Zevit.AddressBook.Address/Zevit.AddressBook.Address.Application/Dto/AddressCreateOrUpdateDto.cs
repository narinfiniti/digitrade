using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Zevit.AddressBook.Address.Domain.Entity;
using Zevit.Common.Models.Response;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Address.Application.Dto
{
    public class AddressCreateOrUpdateDto
        : IAutoMap<ContactAddress, AddressCreateOrUpdateDto>
    {
        public Guid? Id { get; set; }
        public Guid ContactId { get; set; }

        [Required, MaxLength(100)] public string City { get; set; }
        [MaxLength(100)] public string State { get; set; }
        [Required, MaxLength(100)] public string Country { get; set; }

        public void CreateMap(Profile profile)
        {
            profile.CreateMap<ContactAddress, AddressCreateOrUpdateDto>()
                .ReverseMap()
                ;

            profile.CreateMap<ListResult<ContactAddress>, ListResult<AddressCreateOrUpdateDto>>();
            profile.CreateMap<List<ContactAddress>, ListResult<AddressCreateOrUpdateDto>>()
                .ForMember(to => to.Items, c => c.MapFrom(from => from));
        }

        // public class AddressModelValidator : AbstractValidator<AddressCreateDto>
        // {
        //     public AddressModelValidator(
        //         ILogger<AddressModelValidator> logger
        //     )
        //     {
        //         RuleFor(order => order.City)
        //             .NotEmpty().WithMessage($"{nameof(AddressCreateDto.City)} is required.");
        //         RuleFor(order => order.Country)
        //             .NotEmpty().WithMessage($"{nameof(AddressCreateDto.Country)} is required.");
        //     }
        // }
    }
}