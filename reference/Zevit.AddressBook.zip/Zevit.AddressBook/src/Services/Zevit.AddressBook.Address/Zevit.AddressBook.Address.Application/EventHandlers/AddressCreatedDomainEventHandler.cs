using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Zevit.AddressBook.Address.Application.Events;
using Zevit.AddressBook.Address.Domain.Events;
using Zevit.Messaging.Abstractions;

namespace Zevit.AddressBook.Address.Application.EventHandlers
{
    /// <summary>
    /// Address Created Domain Event Handler.
    /// </summary>
    public class AddressCreatedDomainEventHandler : INotificationHandler<AddressCreatedDomainEvent>
    {
        private readonly IEventBus _eventBus;

        public AddressCreatedDomainEventHandler(
            IEventBus eventBus
        )
        {
            _eventBus = eventBus;
        }

        public Task Handle(
            AddressCreatedDomainEvent notification,
            CancellationToken cancellationToken)
        {
            //var @event = new AddressCreatedIntegrationEvent(notification.Address.Id);
            //_eventBus.Publish(@event);
            return Task.CompletedTask;
        }
    }
}