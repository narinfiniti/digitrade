﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Newtonsoft.Json;
using Zevit.Common.JsonOptions;

namespace Zevit.AddressBook.Address.Persistence.Extensions
{
    /// <summary>
    /// Value convertion extensions.
    /// </summary>
    internal static class ValueConversionExtensions
    {
        public static PropertyBuilder<T> HasJsonConversion<T>(this PropertyBuilder<T> propertyBuilder)
        {
            var jsonSettings = JsonSerializationSettingsProvider.GetSerializerSettings();
            var jsonConverter = new ValueConverter<T, string>(
                    v => JsonConvert.SerializeObject(v, jsonSettings).Replace(" ", ""),
                    v => JsonConvert.DeserializeObject<T>(v, jsonSettings));
            return propertyBuilder.HasConversion(jsonConverter);
        }
    }
}