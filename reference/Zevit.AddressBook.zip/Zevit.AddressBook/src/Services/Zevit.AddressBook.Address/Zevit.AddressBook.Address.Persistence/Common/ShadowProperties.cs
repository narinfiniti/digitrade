﻿using System;
using System.Linq;
using Zevit.SharedKernel.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;


namespace Zevit.AddressBook.Address.Persistence.Common
{
    /// <summary>
    /// Extensions for shadow properties.
    /// </summary>
    internal static class ShadowProperties
    {
        public static readonly Func<object, string> EfPropertyCreatedByBrowserName =
            entity => EF.Property<string>(entity, CreatedByBrowserName);
        public const string CreatedByBrowserName = nameof(CreatedByBrowserName);

        public static readonly Func<object, string> EfPropertyModifiedByBrowserName =
            entity => EF.Property<string>(entity, ModifiedByBrowserName);
        public const string ModifiedByBrowserName = nameof(ModifiedByBrowserName);

        public static readonly Func<object, string> EfPropertyCreatedByIp =
            entity => EF.Property<string>(entity, CreatedByIp);
        public const string CreatedByIp = nameof(CreatedByIp);

        public static readonly Func<object, string> EfPropertyModifiedByIp =
            entity => EF.Property<string>(entity, ModifiedByIp);
        public const string ModifiedByIp = nameof(ModifiedByIp);

        public static readonly Func<object, int?> EfPropertyCreatedByUserId =
            entity => EF.Property<int?>(entity, CreatedByUserId);
        public const string CreatedByUserId = nameof(CreatedByUserId);

        public static readonly Func<object, int?> EfPropertyModifiedByUserId =
            entity => EF.Property<int?>(entity, ModifiedByUserId);
        public const string ModifiedByUserId = nameof(ModifiedByUserId);

        public static readonly Func<object, DateTimeOffset?> EfPropertyCreatedDateTime =
            entity => EF.Property<DateTimeOffset?>(entity, CreatedDateTime);
        public const string CreatedDateTime = nameof(CreatedDateTime);

        public static readonly Func<object, DateTimeOffset?> EfPropertyModifiedDateTime =
            entity => EF.Property<DateTimeOffset?>(entity, ModifiedDateTime);
        public const string ModifiedDateTime = nameof(ModifiedDateTime);

        public static void AddShadowProperties(this ModelBuilder mb)
        {
            var eTypes = mb.Model.GetEntityTypes()
                .Where(e => typeof(ITrackableEntity).IsAssignableFrom(e.ClrType));
            foreach (var et in eTypes)
            {
                mb.Entity(et.ClrType).Property<string>(CreatedByBrowserName).HasMaxLength(200);
                mb.Entity(et.ClrType).Property<string>(ModifiedByBrowserName).HasMaxLength(200);

                mb.Entity(et.ClrType).Property<string>(CreatedByIp).HasMaxLength(100);
                mb.Entity(et.ClrType).Property<string>(ModifiedByIp).HasMaxLength(100);

                mb.Entity(et.ClrType).Property<Guid?>(CreatedByUserId);
                mb.Entity(et.ClrType).Property<Guid?>(ModifiedByUserId);

                mb.Entity(et.ClrType).Property<DateTimeOffset?>(CreatedDateTime);
                mb.Entity(et.ClrType).Property<DateTimeOffset?>(ModifiedDateTime);
            }
        }

        public static void SetTrackableEntityPropertyValues(this ChangeTracker changeTracker)
        {
            var userId = Guid.Empty;// userSession.GetId();
            var httpContext = new HttpContextAccessor().HttpContext;//userSession?.HttpContextAccessor?.HttpContext;
            var userAgent = httpContext?.Request?.Headers["User-Agent"].ToString();
            var userIp = httpContext?.Connection?.RemoteIpAddress?.ToString();
            var now = DateTimeOffset.UtcNow;

            var modifiedEntries = changeTracker
                .Entries<ITrackableEntity>().Where(x => x.State == EntityState.Modified);
            foreach (var modifiedEntry in modifiedEntries)
            {
                modifiedEntry.Property(ModifiedDateTime).CurrentValue = now;
                modifiedEntry.Property(ModifiedByBrowserName).CurrentValue = userAgent.Substring(0, 200);
                modifiedEntry.Property(ModifiedByIp).CurrentValue = userIp.Substring(0, 100);
                modifiedEntry.Property(ModifiedByUserId).CurrentValue = userId;
            }

            var addedEntries = changeTracker
                .Entries<ITrackableEntity>().Where(x => x.State == EntityState.Added);
            foreach (var addedEntry in addedEntries)
            {
                addedEntry.Property(CreatedDateTime).CurrentValue = now;
                addedEntry.Property(CreatedByBrowserName).CurrentValue = userAgent;
                addedEntry.Property(CreatedByIp).CurrentValue = userIp;
                addedEntry.Property(CreatedByUserId).CurrentValue = userId;
            }
        }
    }
}
