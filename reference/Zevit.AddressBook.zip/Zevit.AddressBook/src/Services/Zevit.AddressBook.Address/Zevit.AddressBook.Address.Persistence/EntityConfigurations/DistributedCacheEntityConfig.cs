﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Zevit.AddressBook.Address.Persistence.Common;

namespace Zevit.AddressBook.Address.Persistence.EntityConfigurations
{
    internal class DistributedCacheEntityConfig : IEntityTypeConfiguration<DistributedCache>
    {
        public void Configure(EntityTypeBuilder<DistributedCache> builder)
        {
            builder.ToTable(nameof(DistributedCache));
            builder.HasKey(e => e.Id);

            builder.Property(e => e.Id)
                .HasColumnType("VARCHAR(36)").IsRequired();
            builder.Property(e => e.Value)
                .HasColumnType("VARBINARY(MAX)").IsRequired();
            builder.Property(e => e.ExpiresAtTime).IsRequired();
            builder.Property(e => e.SlidingExpirationInSeconds).IsRequired(false);
            builder.Property(e => e.AbsoluteExpiration).IsRequired(false);
        }
    }
}