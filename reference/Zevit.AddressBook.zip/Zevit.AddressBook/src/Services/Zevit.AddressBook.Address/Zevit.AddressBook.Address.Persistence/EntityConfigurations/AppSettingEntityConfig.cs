﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Zevit.AddressBook.Address.Domain.Entity.Config;
using Zevit.AddressBook.Address.Persistence.Extensions;

namespace Zevit.AddressBook.Address.Persistence.EntityConfigurations
{
    internal class AppSettingEntityConfig : IEntityTypeConfiguration<AppSetting>
    {
        public void Configure(EntityTypeBuilder<AppSetting> builder)
        {
            builder.ToTable(nameof(AppSetting));
            builder.HasKey(e => e.Id);

            builder.Property(e => e.Config)
                .HasJsonConversion()
                .HasColumnType("VARCHAR(8000)").IsRequired();
        }
    }
}