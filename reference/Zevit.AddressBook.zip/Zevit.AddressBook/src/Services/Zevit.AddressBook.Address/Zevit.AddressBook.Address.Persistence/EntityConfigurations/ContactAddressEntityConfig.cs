﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Zevit.AddressBook.Address.Domain.Entity;

namespace Zevit.AddressBook.Address.Persistence.EntityConfigurations
{
    internal class ContactAddressEntityConfig : IEntityTypeConfiguration<ContactAddress>
    {
        public void Configure(EntityTypeBuilder<ContactAddress> builder)
        {
            builder.ToTable(nameof(ContactAddress));
            builder.HasKey(e => e.Id);
            builder.HasIndex(e => e.ContactId);

            builder.Property(e => e.City).HasColumnType("VARCHAR(100)").IsRequired();
            builder.Property(e => e.State).HasColumnType("VARCHAR(100)").IsRequired(false);
            builder.Property(e => e.Country).HasColumnType("VARCHAR(100)").IsRequired();
        }
    }
}