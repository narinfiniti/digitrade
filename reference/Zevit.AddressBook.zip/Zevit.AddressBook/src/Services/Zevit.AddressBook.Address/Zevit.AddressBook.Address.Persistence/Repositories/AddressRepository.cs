using System;
using System.Threading.Tasks;
using Dapper;
using Zevit.AddressBook.Address.Application.Interfaces.Repositories;
using Zevit.AddressBook.Address.Application.Models.Filters;
using Zevit.AddressBook.Address.Domain.Entity;
using Zevit.AddressBook.Address.Persistence.Common;
using Zevit.Common.Models.Response;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Address.Persistence.Repositories
{
    public class AddressRepository
        : RepositoryBase<ContactAddress, Guid, UnitOfWork>, IAddressRepository
    {
        public AddressRepository(
            IUnitOfWork context
        ) : base((UnitOfWork)context)
        { }

        public async Task<ListResult<ContactAddress>> FindAddressRangeAsync(
            AddressListFilter filter)
        {
            var param = new DynamicParameters();
            param.AddDynamicParams(new
            {
                ContactId = filter.ContactId,
                filter.Skip,
                filter.Limit
            });
            var sql = $@"
                SELECT c.*, COUNT(*) OVER() [Count]
                FROM [{UnitOfWork.DbScheme}].[{nameof(ContactAddress)}] c
                WHERE @ContactId is NULL OR c.[ContactId]=@ContactId
                ORDER BY c.[Id] DESC
                OFFSET @Skip ROWS
                FETCH NEXT @Limit ROWS ONLY
            ";
            var total = 0;
            var result = await WithDbConnection(conn => conn
                .QueryAsync<ContactAddress, int, ContactAddress>(
                    sql: sql,
                    map: (contact, count) =>
                    {
                        total = count;
                        return contact;
                    },
                    splitOn: $"Count",
                    param: param));
            return new ListResult<ContactAddress>(result)
            {
                //HasNext = total - filter.Skip > filter.Limit
                Total = total
            };
        }

    }
}