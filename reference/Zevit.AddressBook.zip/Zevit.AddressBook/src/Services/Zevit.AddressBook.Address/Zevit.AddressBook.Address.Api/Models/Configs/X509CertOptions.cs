﻿namespace Zevit.AddressBook.Address.Api.Models.Configs
{
    /// <summary>
    /// HttpsConfig options model.
    /// </summary>
    public class X509CertOptions
    {
        public string Subject { get; set; }
        public bool ValidOnly { get; set; }
        public string Scheme { get; set; }
        public string StoreName { get; set; }
        public string StoreLocation { get; set; }
        public string FileName { get; set; }
        public string Password { get; set; }
    }
}