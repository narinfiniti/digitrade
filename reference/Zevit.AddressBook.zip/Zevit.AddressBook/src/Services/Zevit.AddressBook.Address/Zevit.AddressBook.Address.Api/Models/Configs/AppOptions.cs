﻿namespace Zevit.AddressBook.Address.Api.Models.Configs
{
    /// <summary>
    /// Application settings Model.
    /// </summary>
    public class AppOptions
    {
        public string HostUrl { get; set; }
        public short Port { get; set; }
        public short PortSsl { get; set; }
        public short PortGrpc { get; set; }
        public bool UseCustomizationData { get; set; }
        public string LoginPath { get; set; }
        public string LogoutPath { get; set; }

        public int DbConnectionRetryCount { get; set; }
        public int DbConnectionRetryIntervalMinutes { get; set; }
        /// <summary>
        /// Account activation / password reset token
        /// </summary>
        public int ActivationTokenExpirationDays { get; set; }
    }
}
