﻿using System.Linq;
using System.Net;
using Zevit.Common.Models.Response;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Zevit.AddressBook.Address.Api.Infrastructure.Filters
{
    /// <summary>
    /// Response result as Use-case result Filter.
    /// </summary>
    public class ResponseResultFilter : IAlwaysRunResultFilter
    {
        public void OnResultExecuting(ResultExecutingContext context)
        {
            var result = context.Result;
            if (!(result is JsonResult || result is ObjectResult))
            {
                return;
            }

            var propInfo = result.GetType().GetProperty("Value");
            var value = propInfo?.GetValue(result);
            if (value == null)
            {
                context.Result = new NotFoundResult();
                return;
            }
            else if (result is BadRequestObjectResult { Value: ValidationProblemDetails validation } bad)
            {
                bad.StatusCode = (int)HttpStatusCode.UnprocessableEntity;
                var (key, errors) = validation.Errors.First();
                value = new ErrorResult($"{key}: {string.Join("\n", errors)}", bad.StatusCode.Value);
            }
            else if (!(value is StatusCodeResult))
            {
                value = new DataResult<object>(value);
            }
            propInfo?.SetValue(result, value);
        }

        public void OnResultExecuted(ResultExecutedContext context)
        {
        }
    }
}