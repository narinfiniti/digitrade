﻿using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace Zevit.AddressBook.Address.Api.Infrastructure.Middlewares
{
    /// <summary>
    /// CORS middleware to set Access-Control-Allow-Credentials to false.
    /// </summary>
    public class CorsMiddleware
    {
        private readonly RequestDelegate _next;

        public CorsMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public Task Invoke(HttpContext context)
        {
            if (context.Request.Headers.TryGetValue("Origin", out var origin))
            {
                context.Response.Headers.Add("Access-Control-Allow-Credentials", "true");
                // context.Response.Headers.Add("Access-Control-Allow-Headers", "X-Requested-With");
                // context.Response.Headers.Add("Access-Control-Allow-Methods", "POST,GET,OPTIONS");
                // context.Response.Headers.Add("Access-Control-Allow-Origin", origin);

                if (context.Request.Method == "OPTIONS")
                {
                    context.Response.StatusCode = 204;
                    return context.Response.WriteAsync(string.Empty);
                }
            }
            // context.Response.OnStarting(() =>
            // {
            //     if (context.Request.Method == "OPTIONS")
            //     {
            //         context.Response.Headers.Remove("Access-Control-Allow-Credentials");
            //         context.Response.Headers.Add("Access-Control-Allow-Credentials", "true");
            //     }
            //     return Task.CompletedTask;
            // });

            var watch = new Stopwatch();

            context.Response.OnStarting(() =>
            {
                watch.Stop();

                context.Response.Headers
                    .Add("Server-Timing", $"{watch.ElapsedMilliseconds}ms");

                return Task.CompletedTask;
            });

            watch.Start();

            return _next(context);
        }
    }
}