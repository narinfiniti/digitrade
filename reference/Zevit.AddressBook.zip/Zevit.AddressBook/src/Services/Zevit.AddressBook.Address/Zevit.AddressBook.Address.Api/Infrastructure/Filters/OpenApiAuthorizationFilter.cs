﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace Zevit.AddressBook.Address.Api.Infrastructure.Filters
{
    /// <summary>
    /// OpenApi Authorization Filter.
    /// </summary>
    public class OpenApiAuthorizationFilter : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            // Check for authorize attribute
            var hasAuthorize = context.MethodInfo.DeclaringType
                .GetCustomAttributes(true).OfType<AuthorizeAttribute>().Any() ||
                context.MethodInfo
                .GetCustomAttributes(true).OfType<AuthorizeAttribute>().Any();

            if (!hasAuthorize)
                return;

            operation.Responses.TryAdd("401", new OpenApiResponse { Description = "Unauthorized" });
            operation.Responses.TryAdd("403", new OpenApiResponse { Description = "Forbidden" });

            var oAuthScheme = new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "oauth2"
                }
            };

            operation.Security = new List<OpenApiSecurityRequirement> {
                new OpenApiSecurityRequirement { [oAuthScheme] = { "ff45ec867dcd46da991d042de8cfc113" } }
            };
        }
    }
}