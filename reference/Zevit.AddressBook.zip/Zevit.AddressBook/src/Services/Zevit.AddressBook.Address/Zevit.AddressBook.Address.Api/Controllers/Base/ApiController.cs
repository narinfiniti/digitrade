﻿using MediatR;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Zevit.AddressBook.Address.Api.Infrastructure.Filters;

namespace Zevit.AddressBook.Address.Api.Controllers.Base
{
    /// <summary>
    /// Base WebAPI controller.
    /// </summary>
    [ApiController]
    [EnableCors("CorsPolicy")]
    //[Authorize("JwtBearerPolicy")]
    [TypeFilter(typeof(ValidateModelActionFilter))]
    [TypeFilter(typeof(ResponseResultFilter))]
    public abstract class ApiController : ControllerBase
    {
        private IMediator _mediator;
        protected IMediator Mediator => _mediator ??= HttpContext.RequestServices.GetService<IMediator>();
    }
}
