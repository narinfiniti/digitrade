﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Zevit.AddressBook.Address.Api.Constants;
using Zevit.AddressBook.Address.Api.Controllers.Base;
using Zevit.AddressBook.Address.Application.Dto;
using Zevit.AddressBook.Address.Application.Models.Filters;
using Zevit.AddressBook.Address.Application.UseCase;
using Zevit.Common.Models.Response;

namespace Zevit.AddressBook.Address.Api.Controllers
{
    [ApiVersion(Consts.Version.V1)]
    [Route(Consts.Route.Address.Base)]
    public class AddressApiController : ApiController
    {
        public AddressApiController()
        {
        }

        [HttpGet]
        public Task<ListResult<AddressDto>> GetList(
            [FromQuery] AddressListFilter model)
        {
            return Mediator.Send(new AddressesQuery
            {
                Model = model
            });
        }

        [HttpPost]
        public Task<AddressDto> Create(
            [FromBody] AddressCreateOrUpdateDto model)
        {
            return Mediator.Send(new AddressCreateCommand
            {
                Model = model
            });
        }
    }
}