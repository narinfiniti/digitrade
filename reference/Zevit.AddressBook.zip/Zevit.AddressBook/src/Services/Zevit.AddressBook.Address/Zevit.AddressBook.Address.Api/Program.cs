using System;
using System.IO;
using System.Net;
using System.Security.Authentication;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;
using Serilog.Sinks.SystemConsole.Themes;
using Zevit.AddressBook.Address.Api.Certificates;
using Zevit.AddressBook.Address.Api.Extensions;
using Zevit.AddressBook.Address.Api.Models.Configs;
using Zevit.SharedKernel.Interfaces;
using Zevit.AddressBook.Address.Application.Interfaces.Common;
using Zevit.Messaging.Abstractions;

namespace Zevit.AddressBook.Address.Api
{
    public class Program
    {
        private static readonly string Namespace = typeof(Program).Namespace;
        private static readonly string AppName = Namespace;

        public static async Task Main(string[] args)
        {
            var configuration = GetConfiguration();
            Log.Logger = CreateSerilogLogger(configuration);
            try
            {
                Log.Information("Configuring web host ({ApplicationContext})...", AppName);
                var host = CreateHostBuilder(args, configuration).Build();

                await MigrateDatabaseAsync(host);

                Log.Information("Starting web host ({ApplicationContext})...", AppName);
                await host.RunAsync();
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "Program terminated unexpectedly ({ApplicationContext})!", AppName);
                throw;
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args, IConfiguration config) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureLogging((hostContext, logBuilder) =>
                {
                    //Disabling default integrated logger
                    logBuilder.ClearProviders().AddSerilog();
                })
                .ConfigureWebHostDefaults(hostBuilder =>
                {
                    hostBuilder
                        .CaptureStartupErrors(true)
                        .UseContentRoot(Directory.GetCurrentDirectory())
                        .UseStartup<Startup>()
                        .UseConfiguration(config)
                        .UseSerilog(LoggerConfig(config))
                        .ConfigureKestrel((builderContext, options) =>
                        {
                            var appOps = new AppOptions();
                            config.GetSection(nameof(AppOptions)).Bind(appOps);
                            options.Listen(IPAddress.Any, appOps.PortSsl, ops =>
                            {
                                ops.Protocols = HttpProtocols.Http1AndHttp2;
                                if (!builderContext.HostingEnvironment.IsLocalhost())
                                {
                                    var x509 = Certificate.Load(
                                        builderContext.Configuration, builderContext.HostingEnvironment);
                                    ops.UseHttps(x509, o => o.SslProtocols = SslProtocols.Tls12);
                                }
                            });
                        });
                });

        private static async Task MigrateDatabaseAsync(IHost host)
        {
            Log.Information("Applying migrations ({ApplicationContext})...", AppName);
            using var scope = host.Services.CreateScope();
            using var context = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            var hasDatabase = await context.CanConnectAsync();
            // Note: Migration exceptions cause program to exit.
            // Important for docker to be able to restart container.
            if (!hasDatabase)
            {
                await context.MigrateAsync();
                var seeder = scope.ServiceProvider.GetRequiredService<IDataSeeder>();
                await seeder.SeedAsync(context);
            }

            using var eventDb = scope.ServiceProvider.GetRequiredService<IEventSnapshotUnitOfWork>();
            hasDatabase = await eventDb.CanConnectAsync();
            // Note: Migration exceptions cause program to exit.
            // Important for docker to be able to restart container.
            if (!hasDatabase)
            {
                await eventDb.MigrateAsync();
            }
        }

        private static IConfiguration GetConfiguration()
        {
            var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false)
                .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: false)
                //.AddUserSecrets("7823b554-417c-4e61-837f-d4157db0ff9d")
                .AddEnvironmentVariables();

            // var config = builder.Build();
            // if (config.GetValue<bool>("UseVault"))
            // {
            //     builder.AddAzureKeyVault(
            //         $"https://{config["Vault:Name"]}.vault.azure.net/",
            //         config["Vault:ClientId"],
            //         config["Vault:ClientSecret"]);
            // }

            return builder.Build();
        }

        private static Serilog.ILogger CreateSerilogLogger(IConfiguration config)
        {
            return new LoggerConfiguration()
                .ReadFrom.Configuration(config)
                .CreateLogger();
        }

        private static Action<WebHostBuilderContext, LoggerConfiguration> LoggerConfig(IConfiguration config) =>
            (hostContext, logConfig) =>
            {
                logConfig
                    .MinimumLevel.Verbose()
                    .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                    .MinimumLevel.Override("System", LogEventLevel.Warning)
                    .MinimumLevel.Override("Microsoft.AspNetCore.Authentication", LogEventLevel.Information)
                    .Enrich.WithProperty("ApplicationContext", AppName)
                    .Enrich.FromLogContext()
                    .Enrich.WithMachineName()
                    .Enrich.WithEnvironmentUserName();

                // if (hostContext.HostingEnvironment.IsLocalhost())
                {
                    logConfig
                        //.WriteTo.File(
                        //    Path.Combine(@"Infrastructure", "Log", "log.txt"),
                        //    fileSizeLimitBytes: 5_000, rollOnFileSizeLimit: true, shared: true,
                        //    flushToDiskInterval: TimeSpan.FromSeconds(1))
                        .WriteTo.Console(
                            outputTemplate:
                            "[{Timestamp:HH:mm:ss} {Level}] {SourceContext}{NewLine}{Message:lj}{NewLine}{Exception}{NewLine}",
                            theme: AnsiConsoleTheme.Literate);
                }
            };
    }
}