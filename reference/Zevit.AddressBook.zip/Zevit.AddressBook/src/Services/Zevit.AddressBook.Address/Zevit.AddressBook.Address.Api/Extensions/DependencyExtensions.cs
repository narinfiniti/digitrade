using System;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Microsoft.Net.Http.Headers;
using Microsoft.OpenApi.Models;
using Zevit.AddressBook.Address.Api.Infrastructure.JsonOptions;
using Zevit.AddressBook.Address.Api.Models.Configs;
using Zevit.Common.Bindings;

namespace Zevit.AddressBook.Address.Api.Extensions
{
    /// <summary>
    /// Extensions for service collection
    /// </summary>
    public static partial class DependencyExtensions
    {
        public static IServiceCollection AddCustomConfiguration(
            this IServiceCollection services,
            IConfiguration config, IWebHostEnvironment env)
        {
            services.Configure<AppOptions>(config.GetSection(nameof(AppOptions)));
            services.Configure<JwtOptions>(config.GetSection(nameof(JwtOptions)));
            services.Configure<FormOptions>(options =>
            {
                // Set the limit to 256 MB
                options.MultipartBodyLengthLimit = 256 * 1024 * 1024;
            });

            services.Replace(ServiceDescriptor
                .Singleton<IConfigureOptions<JwtBearerOptions>, CustomJwtBearerOptions>());
            services.AddSingleton<CustomJwtBearerEvents>();

            // NewtonsoftJsonMvcOptions
            services.Replace(ServiceDescriptor
                .Singleton<IConfigureOptions<MvcNewtonsoftJsonOptions>, CustomNewtonsoftJsonMvcOptions>());

            return services;
        }
        public static IServiceCollection AddApplicationInsights(
            this IServiceCollection services,
            IConfiguration config, IWebHostEnvironment env)
        {
            services.AddApplicationInsightsTelemetry(config);

            return services;
        }

        public static IServiceCollection AddCustomControllers(
            this IServiceCollection services, IConfiguration config)
        {
            // Customise default API behaviour to use FluentValidators
            /*
             services.Configure<ApiBehaviorOptions>(options =>
             {
                 options.SuppressModelStateInvalidFilter = true;
                 options.InvalidModelStateResponseFactory = context =>
                 {
                     var problemDetails = new ValidationProblemDetails(context.ModelState)
                     {
                         Instance = context.HttpContext.Request.Path,
                         Status = StatusCodes.Status400BadRequest,
                         Detail = "Please refer to the errors for additional details."
                     };

                     return new BadRequestObjectResult(problemDetails)
                     {
                         ContentTypes = { "application/problem+json", "application/problem+xml" }
                     };
                 };
             });
             */
            //services.AddRazorPages();
            services.AddControllers(options =>
            {
                //options.AllowEmptyInputInBodyModelBinding = true;
                //options.Filters.Add(typeof(HttpGlobalExceptionFilter));
                options.Filters.Add(new ProducesAttribute("application/json"));
                options.Conventions.Add(new SparseQueryParamConvention());
            })
            .AddNewtonsoftJson()
            //.AddFluentValidation(fv => fv.RegisterValidatorsFromAssembly(Assembly.GetExecutingAssembly()))
            //.SetCompatibilityVersion(CompatibilityVersion.Version_3_0)
            ;

            return services;
        }

        public static IServiceCollection AddCustomCors(
            this IServiceCollection services,
            IConfiguration config, IWebHostEnvironment env)
        {
            // var origins = config.GetSection("Origins")
            //     .AsEnumerable()
            //     .Select(x => x.Value)
            //     .Where(x => x != null)
            //     .ToArray();

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy", builder => builder
                    .WithExposedHeaders(
                        HeaderNames.WWWAuthenticate,
                        "Grpc-Status", "Grpc-Message", "Grpc-Encoding", "Grpc-Accept-Encoding"
                    )
                    // .WithHeaders(
                    //     HeaderNames.Authorization,
                    //     HeaderNames.ContentType,
                    //     HeaderNames.Accept,
                    //     HeaderNames.Origin,
                    //     "x-requested-with"
                    // )
                    .AllowAnyHeader()
                    .WithMethods(
                        HttpMethods.Get,
                        HttpMethods.Post,
                        HttpMethods.Put,
                        HttpMethods.Delete,
                        HttpMethods.Options
                    )
                    //.AllowAnyMethod()
                    .AllowAnyOrigin()
                //.WithOrigins(origins)
                //.SetIsOriginAllowedToAllowWildcardSubdomains()
                //.SetIsOriginAllowed((host) => origins.Contains(host))
                //.AllowCredentials() // for browser signalr-clients
                //.DisallowCredentials()
                // https://docs.microsoft.com/en-us/aspnet/core/security/cors?view=aspnetcore-3.1#set-the-preflight-expiration-time
                //.SetPreflightMaxAge(TimeSpan.FromSeconds(2400))
                );
            });

            if (!env.IsDevOrLocal())
            {
                services.AddHsts(options =>
                {
                    options.Preload = true;
                    options.IncludeSubDomains = true;
                    options.MaxAge = TimeSpan.FromDays(60);
                    options.ExcludedHosts.Add("example.com");
                    options.ExcludedHosts.Add("www.example.com");
                });
                services.AddHttpsRedirection(options =>
                {
                    options.RedirectStatusCode = StatusCodes.Status301MovedPermanently;
                    options.HttpsPort = config.GetValue<int>("AppOptions:PORT_SSL");
                });
            }
            return services;
        }

        public static IServiceCollection AddCustomAuthorization(
            this IServiceCollection services, IConfiguration config)
        {
            services.AddAuthorization(options =>
            {
                // options.DefaultPolicy = new AuthorizationPolicyBuilder()
                //     .RequireAuthenticatedUser()
                //     .AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme)
                //     .AddAuthenticationSchemes("oidc")
                //     .Build();
                //o.FallbackPolicy = new AuthorizationPolicyBuilder()
                //  .RequireAuthenticatedUser().Build();

                // options.AddPolicy("JwtBearerPolicy", b =>
                // {
                //     b.AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme);
                //     b.RequireAuthenticatedUser();
                //     // custom requirements
                //     //b.Requirements.Add(new DomainRestrictedRequirement());
                // });
            });

            return services;
        }
        public static IServiceCollection AddCustomApiVersioning(
            this IServiceCollection services, IConfiguration config)
        {
            services.AddApiVersioning(options =>
            {
                //o.Conventions.Controller<UserController>().HasApiVersion(1, 0);
                options.RegisterMiddleware = true;
                options.ReportApiVersions = true;
                options.AssumeDefaultVersionWhenUnspecified = true;
                options.DefaultApiVersion = null;
                options.ApiVersionSelector = new CurrentImplementationApiVersionSelector(options);
                //o.ApiVersionReader = new UrlSegmentApiVersionReader();
                options.ApiVersionReader = new MediaTypeApiVersionReader("v");
            });
            services.AddVersionedApiExplorer(options =>
            {
                // version as "'v'major[.minor][-status]"
                options.GroupNameFormat = "'v'VVV";
                // only necessary when versioning by url segment.
                // the SubstitutionFormat can also be used to control the
                // format of the API version in route templates
                options.SubstituteApiVersionInUrl = false;
            });

            return services;
        }
        public static IServiceCollection AddHealthChecks(
            this IServiceCollection services,
            IConfiguration config, IWebHostEnvironment env)
        {
            var connectionString = config.GetConnectionString("DefaultConnection");
            services.AddHealthChecks()
                .AddCheck("/health", () => HealthCheckResult.Healthy())
                .AddSqlServer(connectionString,
                    name: "/health/db",
                    tags: new[] { "/health/db" });

            return services;
        }

        public static IServiceCollection AddCustomSwagger(
            this IServiceCollection services,
            IConfiguration config, IWebHostEnvironment env)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new SwaggerOptions(env.ContentRootPath) { Version = "v1" });
                options.IncludeXmlComments(
                    Path.Combine(AppContext.BaseDirectory, "Zevit.AddressBook.Address.Api.xml")
                );
                options.AddSecurityDefinition("ApiKey", new OpenApiSecurityScheme()
                {
                    Type = SecuritySchemeType.ApiKey,
                    In = ParameterLocation.Header,
                    Name = "Authorization",
                    Description = "Authorization Api Key",
                });
                options.AddSecurityRequirement(new OpenApiSecurityRequirement {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                                { Type = ReferenceType.SecurityScheme, Id = "ApiKey" }
                        },
                        new string[] {}
                    }
                });
            });

            return services;
        }
        public static IServiceCollection AddCustomAuthentication(this IServiceCollection services,
            IConfiguration config,
            IWebHostEnvironment env)
        {
            services
            .AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                using var serviceProvider = services.BuildServiceProvider();
                var configOps = serviceProvider
                    .GetRequiredService<IOptions<JwtBearerOptions>>()
                    .Value;
                var tokenHandler = new JwtSecurityTokenHandler
                {
                    MapInboundClaims = false
                };
                options.SecurityTokenValidators.Clear();
                options.SecurityTokenValidators.Add(tokenHandler);
                options.Authority = configOps.Authority;
                options.RequireHttpsMetadata = configOps.RequireHttpsMetadata;
                options.Audience = configOps.Audience;
                options.TokenValidationParameters.RoleClaimType = configOps.TokenValidationParameters.RoleClaimType;
                options.TokenValidationParameters.NameClaimType = configOps.TokenValidationParameters.NameClaimType;
            });
            return services;
        }

        public static IServiceCollection AddHttpServices(
            this IServiceCollection services, IWebHostEnvironment env)
        {
            //register delegating handlers
            //services.AddTransient<HttpClientAuthzDelegatingHandler>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            return services;
        }
    }
}