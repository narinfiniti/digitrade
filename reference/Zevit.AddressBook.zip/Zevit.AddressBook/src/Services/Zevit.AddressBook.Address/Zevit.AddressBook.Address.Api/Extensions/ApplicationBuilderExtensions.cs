﻿using System.IO;
using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;

namespace Zevit.AddressBook.Address.Api.Extensions
{
    /// <summary>
    /// Extensions for app builder.
    /// </summary>
    public static class ApplicationBuilderExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="app"></param>
        /// <param name="services"></param>
        public static void UseServicesDisplayPage(this IApplicationBuilder app, IServiceCollection services)
        {
            app.Map("/services", builder => builder.Run(async context =>
            {
                var sb = new System.Text.StringBuilder();
                sb.Append("<h1>Registered Services</h1>");
                sb.Append("<table><thead>");
                sb.Append("<tr><th>Type</th><th>Lifetime</th><th>Instance</th></tr>");
                sb.Append("</thead><tbody>");
                foreach (var svc in services.OrderBy(s => s.Lifetime))
                {
                    sb.Append("<tr>");
                    sb.Append($"<td>{svc.ServiceType.FullName}</td>");
                    sb.Append($"<td>{svc.Lifetime}</td>");
                    sb.Append($"<td>{svc.ImplementationType?.FullName}</td>");
                    sb.Append("</tr>");
                }
                sb.Append("</tbody></table>");
                await context.Response.WriteAsync(sb.ToString());
            }));
        }

        public static IApplicationBuilder UseMyStaticFiles(
            this IApplicationBuilder app, IWebHostEnvironment env)
        {
            var imageMessageContentTypeProvider = new FileExtensionContentTypeProvider();
            foreach (var mimeType in new[] { "image/jpg", "image/jpeg" })
            {
                imageMessageContentTypeProvider.Mappings.Add(mimeType, mimeType);
            }
            app.UseStaticFiles(new StaticFileOptions
            {
                FileProvider = new PhysicalFileProvider(Path.Combine("basePath", "subPath")),
                RequestPath = $"/files",
                ContentTypeProvider = imageMessageContentTypeProvider,
                ServeUnknownFileTypes = true,
                DefaultContentType = "image/jpg",
                OnPrepareResponse = ctx =>
                {
                    if (ctx.Context.User?.FindFirst("sub") == null)
                    {
                        ctx.Context.Abort();
                    }
                }
            });
            return app;
        }

    }
}
