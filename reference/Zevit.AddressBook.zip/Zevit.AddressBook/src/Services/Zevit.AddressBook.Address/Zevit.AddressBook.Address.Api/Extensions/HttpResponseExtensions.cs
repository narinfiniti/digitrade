﻿using Zevit.Common.Models;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace Zevit.AddressBook.Address.Api.Extensions
{
    /// <summary>
    /// HttpResponseExtensions.
    /// </summary>
    public static class HttpResponseExtensions
    {
        public static void AddPagination(this HttpResponse response, PageHeaderModel pageHeader)
        {
            response.Headers.Add("Pagination", JsonConvert.SerializeObject(pageHeader));
            response.Headers.Add("access-control-expose-headers", "Pagination"); // CORS
        }

        public static void AddApplicationError(this HttpResponse response, string message)
        {
            response.Headers.Add("Application-Error", message);
            response.Headers.Add("access-control-expose-headers", "Application-Error");// CORS
        }
    }
}
