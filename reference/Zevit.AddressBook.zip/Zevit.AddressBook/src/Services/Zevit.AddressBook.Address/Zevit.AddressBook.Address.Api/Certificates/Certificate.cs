﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Zevit.AddressBook.Address.Api.Models.Configs;

namespace Zevit.AddressBook.Address.Api.Certificates
{
    internal static class Certificate
    {
        public static X509Certificate2 Load(IConfiguration config, IWebHostEnvironment env)
        {
            var ops = new X509CertOptions();
            config.GetSection(nameof(X509CertOptions)).Bind(ops);

            if (!string.IsNullOrEmpty(ops.FileName) && !string.IsNullOrEmpty(ops.Password))
            {
                var assembly = typeof(Certificate).GetTypeInfo().Assembly;
                var resourceName = assembly
                    .GetManifestResourceNames()
                    .FirstOrDefault(e => e.EndsWith(ops.FileName));
                using var stream = assembly.GetManifestResourceStream(resourceName);
                return new X509Certificate2(ReadStream(stream), ops.Password);
            }
            else if (!string.IsNullOrEmpty(ops.StoreName) && !string.IsNullOrEmpty(ops.StoreLocation))
            {
                using var store = new X509Store(ops.StoreName, Enum.Parse<StoreLocation>(ops.StoreLocation));
                store.Open(OpenFlags.ReadOnly);
                var certificate = store.Certificates.Find(X509FindType.FindBySubjectName,
                    ops.Subject,
                    validOnly: ops.ValidOnly);
                if (certificate.Count == 0)
                {
                    throw new InvalidOperationException("No valid certificate configuration found for the current endpoint.");
                }
                return certificate[0];
            }
            throw new InvalidOperationException("No valid certificate configuration found for the current endpoint.");
        }

        private static byte[] ReadStream(Stream input)
        {
            var buffer = new byte[16 * 1024];
            using var ms = new MemoryStream();
            int read;
            while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                ms.Write(buffer, 0, read);
            }
            return ms.ToArray();
        }
    }
}