using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Zevit.AddressBook.Contact.Domain.Entity;
using Zevit.Common.Models.Response;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Application.Dto
{
    /// <summary>
    /// UserContactDto.
    /// </summary>
    public class UserContactDto
        : IAutoMap<UserContact, UserContactDto>
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }

        [Required, MaxLength(100)]
        public string FirstName { get; set; }

        [MaxLength(100)]
        public string LastName { get; set; }

        public void CreateMap(Profile profile)
        {
            profile.CreateMap<UserContact, UserContactDto>()
            .ReverseMap()
            ;

            profile.CreateMap<ListResult<UserContact>, ListResult<UserContactDto>>();
            profile.CreateMap<List<UserContact>, ListResult<UserContactDto>>()
                .ForMember(to => to.Items, c => c.MapFrom(from => from));
        }
    }
}