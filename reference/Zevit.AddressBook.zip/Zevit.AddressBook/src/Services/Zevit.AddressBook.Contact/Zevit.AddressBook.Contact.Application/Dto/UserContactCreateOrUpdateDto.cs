using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Zevit.AddressBook.Contact.Domain.Entity;
using Zevit.Common.Models.Response;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Application.Dto
{
    public class UserContactCreateOrUpdateDto
        : IAutoMap<UserContact, UserContactCreateOrUpdateDto>
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }

        [Required, MaxLength(100)]
        public string FirstName { get; set; }

        [MaxLength(100)]
        public string LastName { get; set; }

        public void CreateMap(Profile profile)
        {
            profile.CreateMap<UserContact, UserContactCreateOrUpdateDto>()
                .ReverseMap()
                ;

            profile.CreateMap<ListResult<UserContact>, ListResult<UserContactCreateOrUpdateDto>>();
            profile.CreateMap<List<UserContact>, ListResult<UserContactCreateOrUpdateDto>>()
                .ForMember(to => to.Items, c => c.MapFrom(from => from));
        }
        // public class Validator: AbstractValidator<UserContactCreateDto>
        // {
        //     public UserContactModelValidator(
        //         ILogger<UserContactModelValidator> logger
        //     )
        //     {
        //         RuleFor(order => order.FirstName)
        //             .NotEmpty().WithMessage($"{nameof(UserContactCreateDto.FirstName)} is required.");
        //     }
        // }
    }
}