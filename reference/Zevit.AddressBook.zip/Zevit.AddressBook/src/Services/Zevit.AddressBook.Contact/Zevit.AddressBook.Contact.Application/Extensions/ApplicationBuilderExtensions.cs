using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Zevit.AddressBook.Contact.Application.Events;
using Zevit.Messaging.Abstractions;

namespace Zevit.AddressBook.Contact.Application.Extensions
{
    public static class ApplicationBuilderExtensions
    {
        public static void ConfigureEventBus(this IApplicationBuilder app)
        {
            var eventBus = app.ApplicationServices.GetRequiredService<IEventBus>();

            eventBus.Subscribe<UserRegisteredIntegrationEvent, IIntegrationEventHandler<UserRegisteredIntegrationEvent>>();
            eventBus.Subscribe<UserLoggedInIntegrationEvent, IIntegrationEventHandler<UserLoggedInIntegrationEvent>>();
        }
    }
}