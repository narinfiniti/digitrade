﻿using System.Reflection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MediatR;
using Zevit.AddressBook.Contact.Application.Mapping;
using Zevit.AddressBook.Contact.Application.Behaviors;
using Zevit.AddressBook.Contact.Application.Events;
using Zevit.Messaging.Abstractions;

namespace Zevit.AddressBook.Contact.Application.Extensions
{
    public static partial class DependencyExtensions
    {
        public static IServiceCollection AddUseCaseDependencies(
            this IServiceCollection services,
            IConfiguration configuration,
            IHostEnvironment env)
        {
            services.AddMediatR(c => c.AsTransient(), Assembly.GetExecutingAssembly());
            // services.AddScoped(typeof(IPipelineBehavior<,>), typeof(RequestPerformanceBehaviour<,>));
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestValidationBehavior<,>));
            //services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestTransactionBehaviour<,>));
            services.AddAutoMapper(
                assemblies: new[] {typeof(MappingProfile).GetTypeInfo().Assembly},
                serviceLifetime: ServiceLifetime.Transient
            );

            services.AddTransient<IIntegrationEventHandler<UserRegisteredIntegrationEvent>, UserRegisteredIntegrationEvent.Handler>();
            services.AddTransient<IIntegrationEventHandler<UserLoggedInIntegrationEvent>, UserLoggedInIntegrationEvent.Handler>();
            return services;
        }
    }
}