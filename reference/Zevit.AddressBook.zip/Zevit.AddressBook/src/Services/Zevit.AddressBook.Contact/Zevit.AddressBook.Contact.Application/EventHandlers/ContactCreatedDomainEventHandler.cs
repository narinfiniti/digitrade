using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Zevit.AddressBook.Contact.Application.Events;
using Zevit.AddressBook.Contact.Domain.Events;
using Zevit.Messaging.Abstractions;

namespace Zevit.AddressBook.Contact.Application.EventHandlers
{
    /// <summary>
    /// Contact Created Domain Event Handler.
    /// </summary>
    public class ContactCreatedDomainEventHandler : INotificationHandler<ContactCreatedDomainEvent>
    {
        private readonly IEventBus _eventBus;

        public ContactCreatedDomainEventHandler(
            IEventBus eventBus
        )
        {
            _eventBus = eventBus;
        }

        public Task Handle(
            ContactCreatedDomainEvent notification,
            CancellationToken cancellationToken)
        {
            var @event = new ContactCreatedIntegrationEvent(notification.Contact.Id);
            _eventBus.Publish(@event);
            return Task.CompletedTask;
        }
    }
}