using System;
using Zevit.Common.Models;

namespace Zevit.AddressBook.Contact.Application.Models.Filters
{
    /// <summary>
    /// ContactFilter.
    /// </summary>
    public class ContactListFilter : PageFilter
    {
        public Guid? UserId { get; set; }
    }
}