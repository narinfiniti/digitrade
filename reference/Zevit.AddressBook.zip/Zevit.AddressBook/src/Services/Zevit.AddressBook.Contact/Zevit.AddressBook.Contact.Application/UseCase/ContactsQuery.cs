using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Http;
using Zevit.AddressBook.Contact.Application.Dto;
using Zevit.AddressBook.Contact.Application.Interfaces.Repositories;
using Zevit.AddressBook.Contact.Application.Models.Filters;
using Zevit.Common.Exceptions;
using Zevit.Common.Models.Response;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Application.UseCase
{
    /// <summary>
    /// ContactsQuery.
    /// </summary>
    public class ContactsQuery
        : IUseCase<ContactListFilter, ListResult<UserContactDto>>
    {
        public ContactListFilter Model { get; set; }
        public class Handler
            : IRequestHandler<ContactsQuery, ListResult<UserContactDto>>
        {
            private readonly IMapper _mapper;
            private readonly IContactRepository _contactRepo;
            private readonly IUserProfileService _userProfileService;

            public Handler(
                IMapper mapper,
                IContactRepository contactRepo,
                IUserProfileService userProfileService
             )
            {
                _mapper = mapper;
                _contactRepo = contactRepo;
                _userProfileService = userProfileService;
            }

            public async Task<ListResult<UserContactDto>> Handle(
                ContactsQuery request,
                CancellationToken cancellationToken)
            {
                var filter = request.Model;
                var roles = _userProfileService.Roles;
                if (roles == null)
                {
                    throw new UnauthorizedException();
                }
                if (roles.Contains("Admin")) filter.UserId = null;
                var result = await _contactRepo.FindContactRangeAsync(filter);
                return _mapper.Map<ListResult<UserContactDto>>(result);
            }
        }
    }
}