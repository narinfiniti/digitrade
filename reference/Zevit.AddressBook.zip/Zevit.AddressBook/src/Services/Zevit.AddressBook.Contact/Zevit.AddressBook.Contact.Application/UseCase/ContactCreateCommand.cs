﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Zevit.AddressBook.Contact.Application.Dto;
using Zevit.AddressBook.Contact.Application.Interfaces.Repositories;
using Zevit.AddressBook.Contact.Domain.Entity;
using MediatR;
using Zevit.AddressBook.Contact.Domain.Events;
using Zevit.Common.Exceptions;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Application.UseCase
{
    /// <summary>
    /// ContactCreateCommand.
    /// </summary>
    public class ContactCreateCommand
        : IUseCase<UserContactCreateOrUpdateDto, UserContactDto>
    {
        public UserContactCreateOrUpdateDto Model { get; set; }

        public class Handler
            : IRequestHandler<ContactCreateCommand, UserContactDto>
        {
            private readonly IMapper _mapper;
            private readonly IMediator _mediator;
            private readonly IContactRepository _contactRepo;
            private readonly IUserProfileService _userProfileService;

            public Handler(
                IMapper mapper,
                IMediator mediator,
                IContactRepository contactRepo,
                IUserProfileService userProfileService
            )
            {
                _mapper = mapper;
                _mediator = mediator;
                _contactRepo = contactRepo;
                _userProfileService = userProfileService;
            }

            public async Task<UserContactDto> Handle(
                ContactCreateCommand request, CancellationToken cancellationToken)
            {
                var model = request.Model;
                var userId = _userProfileService.GetUserIdentity();
                if (!model.UserId.ToString().Equals(userId, StringComparison.OrdinalIgnoreCase))
                {
                    throw new UnauthorizedException();
                }

                var roles = _userProfileService.Roles;
                var contact = new UserContact
                {
                    Id = Guid.NewGuid(),
                    UserId = model.UserId,
                    FirstName = $"{roles.FirstOrDefault()} Contact FirstName",
                    LastName = $"{roles.FirstOrDefault()} Contact LastName"
                };
                await _contactRepo.AddAsync(contact);
                await _contactRepo.Uow.SaveAsync(cancellationToken);
                await _mediator.Publish(new ContactCreatedDomainEvent(contact), cancellationToken);
                return _mapper.Map<UserContactDto>(contact);
            }
        }
    }
}