using Zevit.AddressBook.Contact.Domain.Entity.Config;

namespace Zevit.AddressBook.Contact.Application.Interfaces.Repositories
{
    /// <summary>
    /// Abstraction for AppSetting Repository.
    /// </summary>
    public interface IAppSettingRepository
    {
        AppSetting Find(byte id, bool useCache = true);
        AppSetting Save(AppSetting entity);
    }
}