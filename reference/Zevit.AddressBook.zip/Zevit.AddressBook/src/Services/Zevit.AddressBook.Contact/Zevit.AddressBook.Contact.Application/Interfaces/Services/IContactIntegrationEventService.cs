using System;
using System.Threading.Tasks;
using Zevit.Messaging.Abstractions.Events;

namespace Zevit.AddressBook.Contact.Application.Interfaces.Services
{
    /// <summary>
    /// Abstraction for publishing Contact service integration event publish.
    /// </summary>
    public interface IContactIntegrationEventService
    {
        Task PublishEventsThroughEventBusAsync(Guid transactionId);
        Task AddAndSaveEventAsync(IntegrationEvent @event);
    }
}