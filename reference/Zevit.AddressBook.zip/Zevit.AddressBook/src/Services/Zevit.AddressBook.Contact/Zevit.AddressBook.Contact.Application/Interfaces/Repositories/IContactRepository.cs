using System;
using System.Threading.Tasks;
using Zevit.AddressBook.Contact.Application.Models.Filters;
using Zevit.AddressBook.Contact.Domain.Entity;
using Zevit.Common.Models.Response;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Application.Interfaces.Repositories
{
    public interface IContactRepository : IRepository<UserContact, Guid>
    {
        Task<ListResult<UserContact>> FindContactRangeAsync(ContactListFilter listFilter);
    }
}