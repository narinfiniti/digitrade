﻿namespace Zevit.AddressBook.Contact.Application.Interfaces.Services
{
    /// <summary>
    /// ISomeService.
    /// </summary>
    public interface ISomeService
    {
    }
}