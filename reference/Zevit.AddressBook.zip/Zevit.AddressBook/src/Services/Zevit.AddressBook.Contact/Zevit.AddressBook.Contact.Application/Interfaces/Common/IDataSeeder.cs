﻿using System.Threading.Tasks;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Application.Interfaces.Common
{
    /// <summary>
    /// Abstraction for data seeding into the database.
    /// </summary>
    public interface IDataSeeder
    {
        Task SeedAsync(IUnitOfWork context);
    }
}
