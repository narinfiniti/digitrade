using System;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Logging;
using Zevit.Messaging.Abstractions;
using Zevit.Messaging.Abstractions.Events;

namespace Zevit.AddressBook.Contact.Application.Events
{
    /// <summary>
    /// Contact Created Integration Event.
    /// </summary>
    public class ContactCreatedIntegrationEvent : IntegrationEvent
    {
        public Guid ContactId { get; set; }

        public ContactCreatedIntegrationEvent(Guid contactId)
        {
            ContactId = contactId;
        }
    }
}