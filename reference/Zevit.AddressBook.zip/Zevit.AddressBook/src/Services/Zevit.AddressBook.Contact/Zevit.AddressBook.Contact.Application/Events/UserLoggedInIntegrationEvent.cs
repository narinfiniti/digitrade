using System;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Logging;
using Zevit.Messaging.Abstractions;
using Zevit.Messaging.Abstractions.Events;

namespace Zevit.AddressBook.Contact.Application.Events
{
    public class UserLoggedInIntegrationEvent : IntegrationEvent
    {
        public Guid UserId { get; }

        public UserLoggedInIntegrationEvent(
            Guid userId
        )
        {
            UserId = userId;
        }

        public class Handler : IIntegrationEventHandler<UserLoggedInIntegrationEvent>
        {
            private readonly IMediator _mediator;
            private readonly ILogger<Handler> _logger;

            public Handler(
                IMediator mediator,
                ILogger<Handler> logger)
            {
                _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
                _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            }

            public Task Handle(UserLoggedInIntegrationEvent @event)
            {
                _logger.LogInformation($"----- Handling integration event: {@event.Id} - UserId: {@event.UserId}");

                var command = new object();

                //await _mediator.Send(command);
                return Task.CompletedTask;
            }
        }
    }
}