using System;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Logging;
using Zevit.AddressBook.Contact.Application.Dto;
using Zevit.AddressBook.Contact.Application.UseCase;
using Zevit.Messaging.Abstractions;
using Zevit.Messaging.Abstractions.Events;

namespace Zevit.AddressBook.Contact.Application.Events
{
    public class UserRegisteredIntegrationEvent : IntegrationEvent
    {
        public Guid UserId { get; }

        public UserRegisteredIntegrationEvent(
            Guid userId
        )
        {
            UserId = userId;
        }

        public class Handler : IIntegrationEventHandler<UserRegisteredIntegrationEvent>
        {
            private readonly IMediator _mediator;
            private readonly ILogger<Handler> _logger;

            public Handler(
                IMediator mediator,
                ILogger<Handler> logger)
            {
                _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
                _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            }

            public async Task Handle(UserRegisteredIntegrationEvent @event)
            {
                _logger.LogInformation($"----- Handling integration event: {@event.Id} - UserId: {@event.UserId}");

                var command = new ContactCreateCommand
                {
                    Model = new UserContactCreateOrUpdateDto
                    {
                        Id = Guid.NewGuid(),
                        UserId = @event.UserId,
                        FirstName = "Some Name",
                        LastName = "Some LastName"
                    }
                };
                await _mediator.Send(command);
            }
        }
    }
}