﻿using Microsoft.Extensions.DependencyInjection;
using Zevit.AddressBook.Contact.Application.Interfaces.Common;

namespace Zevit.AddressBook.Contact.Infra.DataSeed.Extensions
{
    /// <summary>
    /// Extensions for adding dependencies into service collection.
    /// </summary>
    public static class DependencyExtensions
    {
        public static IServiceCollection AddDataSeeder(this IServiceCollection services)
        {
            services.AddScoped<IDataSeeder, DataSeeder>();

            return services;
        }
    }
}
