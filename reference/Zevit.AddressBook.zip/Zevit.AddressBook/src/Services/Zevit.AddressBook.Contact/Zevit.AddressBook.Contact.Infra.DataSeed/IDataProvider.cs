﻿namespace Zevit.AddressBook.Contact.Infra.DataSeed
{
    /// <summary>
    /// Abstraction for preparing data for seeding.
    /// </summary>
    public interface IDataProvider<out TEntity>
    {
        TEntity[] GetData();
    };
}
