﻿using Newtonsoft.Json;
using Zevit.Common.Extensions;

namespace Zevit.AddressBook.Contact.Infra.DataSeed.DataProviders
{
    /// <summary>
    /// JsonFileDataProvider.
    /// </summary>
    public class JsonFileDataProvider<TEntity> : IDataProvider<TEntity>
    {
        private TEntity[] _data;
        public TEntity[] GetData()
        {
            if (_data != null) return _data;

            var filename = $"{typeof(TEntity).Name}.json";
            var content = filename.ReadEmbeddedResource<DataSeeder>();
            return _data = JsonConvert.DeserializeObject<TEntity[]>(content);
        }
    }
}