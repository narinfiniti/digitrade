﻿namespace Zevit.AddressBook.Contact.Infra.DataSeed
{
    /// <summary>
    /// Abstraction for preparing script data for seeding.
    /// </summary>
    public interface IScriptDataProvider
    {
        string GetScriptSql();
    };
}
