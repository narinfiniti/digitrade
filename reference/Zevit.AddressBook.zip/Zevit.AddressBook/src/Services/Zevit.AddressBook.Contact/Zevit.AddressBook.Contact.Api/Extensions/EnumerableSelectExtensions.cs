﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Zevit.AddressBook.Contact.Api.Extensions
{
    /// <summary>
    /// Enumerable select extensions.
    /// </summary>
    public static class EnumerableSelectExtensions
    {
        public static IEnumerable<SelectResult<TSource, TResult>> TrySelect<TSource, TResult>(
            this IEnumerable<TSource> enumerable,
            Func<TSource, TResult> selector)
        {
            foreach (var element in enumerable)
            {
                SelectResult<TSource, TResult> returnedValue;
                try
                {
                    returnedValue = new SelectResult<TSource, TResult>(element, selector(element), null);
                }
                catch (Exception ex)
                {
                    returnedValue = new SelectResult<TSource, TResult>(element, default(TResult), ex);
                }
                yield return returnedValue;
            }
        }

        public static IEnumerable<TResult> Catch<TSource, TResult>(
            this IEnumerable<SelectResult<TSource, TResult>> enumerable,
            Func<Exception, TResult> exceptionHandler)
        {
            return enumerable.Select(x => x.CaughtException == null ? x.Result : exceptionHandler(x.CaughtException));
        }

        public static IEnumerable<TResult> Catch<TSource, TResult>(
            this IEnumerable<SelectResult<TSource, TResult>> enumerable,
            Func<TSource, Exception, TResult> exceptionHandler)
        {
            return enumerable.Select(x => x.CaughtException == null ? x.Result : exceptionHandler(x.Source, x.CaughtException));
        }

        public class SelectResult<TSource, TResult>
        {
            internal SelectResult(TSource source, TResult result, Exception exception)
            {
                Source = source;
                Result = result;
                CaughtException = exception;
            }

            public TSource Source { get; private set; }
            public TResult Result { get; private set; }
            public Exception CaughtException { get; private set; }
        }
    }
}
