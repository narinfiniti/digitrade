﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Routing;
using HealthChecks.UI.Client;

namespace Zevit.AddressBook.Contact.Api.Extensions
{
    /// <summary>
    /// Extensions for adding dependencies into service collection.
    /// </summary>
    public static class EndpointRouteBuilderExtensions
    {
        public static IEndpointRouteBuilder MapGrpcServices(this IEndpointRouteBuilder endpoints)
        {
            // Implements greet.v1.Greeter
            // endpoints.MapGrpcService<NotifyGrpcCommandServiceV1>()
            //     .RequireAuthorization()
            //     .EnableGrpcWeb()
            //     .RequireCors("CorsPolicy");

            // Implements greet.v2.Greeter
            // endpoints.MapGrpcService<GreeterServiceV2>()
            //     .RequireAuthorization().EnableGrpcWeb()
            //     .RequireCors("CorsPolicy");

            return endpoints;
        }

        public static IEndpointRouteBuilder MapHealthCheck(
            this IEndpointRouteBuilder endpoints)
        {
            endpoints.MapHealthChecks("/health", new HealthCheckOptions
            {
                Predicate = r => r.Name.Contains("health")
            });
            //.RequireAuthorization(new AuthorizeAttribute() { Roles = "1", });
            endpoints.MapHealthChecks("/health/db", new HealthCheckOptions
            {
                Predicate = r => r.Name.Contains("db"),
                ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
            });
            return endpoints;
        }
    }
}
