namespace Zevit.AddressBook.Contact.Api.Constants
{
    /// <summary>
    /// Route options' config.
    /// </summary>
    public class Consts
    {
        public const string ApiPrefix = "api/contact";

        public class Version
        {
            public const string V1 = "1.0";
        }

        public class Route
        {
            public class ApiDocs
            {
                public const string Base = ApiPrefix + "/docs";
                public const string Postman = ApiPrefix + "/docs/postman-files";
            }

            public class Contact
            {
                public const string Base = ApiPrefix + "/contacts";
                public const string Detail = "id";
            }

        }
    }
}