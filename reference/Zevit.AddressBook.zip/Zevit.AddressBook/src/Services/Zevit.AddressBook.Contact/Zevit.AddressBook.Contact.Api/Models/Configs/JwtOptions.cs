﻿using Microsoft.IdentityModel.Tokens;

namespace Zevit.AddressBook.Contact.Api.Models.Configs
{
    /// <summary>
    /// JwtOptions
    /// </summary>
    public class JwtOptions
    {
        public string EncKey { get; set; }
        public string SignKey { get; set; }

        public int AccessTokenLifetimeMinutes { get; set; }
        public int RefreshTokenLifetimeDays { get; set; }

        public bool AllowMultipleLoginsForUser { get; set; }
        public bool RequireHttpsMetadata { get; set; }

        public string Authority { get; set; }
        public string Audience { get; set; }
        public bool RefreshOnIssuerKeyNotFound { get; set; } = true;
        public bool SaveToken { get; set; } = false;
        public TokenValidationParameters TokenValidationParameters { get; set; }
        // Using the configured Auth schemes, populate the auth challenge headers.
        // This is for scenarios where Anonymous access is allowed for some resources,
        // but the server later determines that authorization is required for this request.
        //public string Challenge { get; set; }
        //public TimeSpan BackchannelTimeout { get; set; }
    }
}
