﻿using System.IO;
using Microsoft.OpenApi.Models;
using Zevit.AddressBook.Contact.Api.Constants;

namespace Zevit.AddressBook.Contact.Api.Models.Configs
{
    /// <summary>
    /// SwaggerOptions
    /// </summary>
    public class SwaggerOptions : OpenApiInfo
    {
        public static string PostmanDirectoryPath;
        /// <summary>
        /// Initialization of Swagger options, adding url to download postman.zip
        /// </summary>
        public SwaggerOptions(string contentRoot)
        {
            PostmanDirectoryPath = Path.Combine(contentRoot, "Models", "Configs", "postman");
            Title = "Zevit.AddressBook.Contact.Api";
            Description = GetDescription();
        }

        private string GetDescription()
        {
            if (Directory.Exists(PostmanDirectoryPath))
            {
                var lastWriteDate = Directory.GetLastWriteTimeUtc(PostmanDirectoryPath);
                return $"Download <a href='{Consts.Route.ApiDocs.Postman}'>postman.zip</a> " +
                    $"(last updated:{lastWriteDate: ddd, dd MMM yyy HH:mm:ss UTC})";
            }
            return $"Warning: Postman directory \"{PostmanDirectoryPath}\" not found";
        }
    }
}
