﻿using Zevit.Common.Exceptions;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Zevit.AddressBook.Contact.Api.Infrastructure.Filters
{
    /// <summary>
    /// Validates action arguments.
    /// </summary>
    public class ValidateModelActionFilter : IActionFilter
    {
        public void OnActionExecuting(ActionExecutingContext context)
        {
            if (!context.ModelState.IsValid)
            {
                throw new ValidationException(context.ModelState);
            }
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            var result = context.Result;
            // Do something with Result.
            if (context.Canceled == true)
            {
                // Action execution was short-circuited by another filter.
            }

            if (context.Exception != null)
            {
                // Exception thrown by action or action filter.
                // Set to null to handle the exception.
                //context.Exception = null;
            }
        }
    }
}