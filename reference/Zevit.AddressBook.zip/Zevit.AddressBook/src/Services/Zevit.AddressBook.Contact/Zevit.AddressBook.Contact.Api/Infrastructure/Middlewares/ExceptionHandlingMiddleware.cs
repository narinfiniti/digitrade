﻿using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Zevit.Common.Exceptions;
using Zevit.Common.Models.Response;

namespace Zevit.AddressBook.Contact.Api.Infrastructure.Middlewares
{
    /// <summary>
    /// Custom middleware for exception handling.
    /// </summary>
    public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly MvcNewtonsoftJsonOptions _json;
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;

        public ExceptionHandlingMiddleware(
            RequestDelegate next,
            IOptions<MvcNewtonsoftJsonOptions> jsonOptions,
            ILogger<ExceptionHandlingMiddleware> logger)
        {
            _next = next ??
                throw new ArgumentNullException(nameof(RequestDelegate));
            _json = jsonOptions?.Value ??
                throw new ArgumentNullException(nameof(IOptions<MvcNewtonsoftJsonOptions>));
            _logger = logger ??
                throw new ArgumentNullException(nameof(ILogger<ExceptionHandlingMiddleware>));
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                HandleExceptionAsync(context, ex);
            }
        }

        private void HandleExceptionAsync(HttpContext context, Exception exception)
        {
            _logger.LogError(
                new EventId(exception.HResult),
                exception,
                $"{exception?.Message}\n{exception?.InnerException?.Message}");

            var result = "An error occurred. Please try again later.";
            var res = context.Response;
            var code = (int)HttpStatusCode.InternalServerError;
            switch (exception)
            {
                case GoneException gone:
                    result = gone.Message;
                    code = gone.StatusCode;
                    res.StatusCode = (int)HttpStatusCode.Gone;
                    break;
                case NotAcceptableException suspended:
                    result = suspended.Message;
                    code = suspended.StatusCode;
                    res.StatusCode = (int)HttpStatusCode.NotAcceptable;
                    break;
                case UnauthorizedException unauth:
                    result = unauth.Message;
                    code = unauth.StatusCode;
                    res.StatusCode = (int)HttpStatusCode.Unauthorized;
                    break;
                case ForbiddenException forbid:
                    result = forbid.Message;
                    code = forbid.StatusCode;
                    res.StatusCode = (int)HttpStatusCode.Forbidden;
                    break;
                case Microsoft.IdentityModel.Tokens.SecurityTokenExpiredException expired:
                    result = "The token is expired!";
                    code = (int)HttpStatusCode.Unauthorized;
                    res.StatusCode = (int)HttpStatusCode.Unauthorized;
                    break;
                case NotFoundException notFound:
                    result = notFound.Message;
                    code = notFound.StatusCode;
                    res.StatusCode = (int)HttpStatusCode.NotFound;
                    break;
                case UnsupportedMediaTypeException unsupported:
                    result = unsupported.Message;
                    code = unsupported.StatusCode;
                    res.StatusCode = (int)HttpStatusCode.UnsupportedMediaType;
                    break;
                case ServiceUnavailableException unavailable:
                    result = unavailable.Message;
                    code = unavailable.StatusCode;
                    res.StatusCode = (int)HttpStatusCode.ServiceUnavailable;
                    break;
                case ValidationException valid:
                    result = valid.ToResult(_json.SerializerSettings);
                    code = valid.StatusCode;
                    res.StatusCode = (int)HttpStatusCode.UnprocessableEntity;
                    break;
            }

            res.ContentType = "application/json";

            result = JsonConvert.SerializeObject(
                new ErrorResult(result, code), _json.SerializerSettings);

            //return res.WriteAsync(result);
            res.OnStarting(state =>
            {
                var httpContext = (HttpContext)state;
                // httpContext.Response.Headers.Add(
                //     "X-Response-Time-Milliseconds",
                //     new[] { watch.ElapsedMilliseconds.ToString() });
                return httpContext.Response.WriteAsync(result);
            }, context);
        }
    }
}