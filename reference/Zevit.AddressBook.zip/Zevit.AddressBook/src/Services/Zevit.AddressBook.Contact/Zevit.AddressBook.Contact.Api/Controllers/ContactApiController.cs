﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Zevit.AddressBook.Contact.Api.Constants;
using Zevit.AddressBook.Contact.Api.Controllers.Base;
using Zevit.AddressBook.Contact.Application.Dto;
using Zevit.AddressBook.Contact.Application.Models.Filters;
using Zevit.AddressBook.Contact.Application.UseCase;
using Zevit.Common.Models.Response;

namespace Zevit.AddressBook.Contact.Api.Controllers
{
    [ApiVersion(Consts.Version.V1)]
    [Route(Consts.Route.Contact.Base)]
    public class ContactApiController : ApiController
    {
        public ContactApiController()
        {
        }

        [HttpGet]
        public Task<ListResult<UserContactDto>> GetList(
            [FromQuery] ContactListFilter model)
        {
            return Mediator.Send(new ContactsQuery
            {
                Model = model
            });
        }

        [HttpPost]
        public Task<UserContactDto> Create(
            [FromBody] UserContactCreateOrUpdateDto model)
        {
            return Mediator.Send(new ContactCreateCommand
            {
                Model = model
            });
        }
    }
}