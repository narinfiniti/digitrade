﻿using System.IO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Zevit.AddressBook.Contact.Api.Constants;
using Zevit.AddressBook.Contact.Api.Models.Configs;
using Zevit.Common.Exceptions;
using Zevit.Common.Extensions;

namespace Zevit.AddressBook.Contact.Api.Controllers.Base
{
    [ApiVersion(Consts.Version.V1)]
    [Route(Consts.Route.ApiDocs.Base)]
    public class DocApiController : ApiController
    {
        [AllowAnonymous]
        [HttpGet(Consts.Route.ApiDocs.Postman)]
        public FileContentResult GetPostmanFiles()
        {
            if (Directory.Exists(SwaggerOptions.PostmanDirectoryPath))
            {
                var di = new DirectoryInfo(SwaggerOptions.PostmanDirectoryPath);
                var postmanZipBytes = di.Compress();
                if (postmanZipBytes != null)
                {
                    return File(postmanZipBytes, "application/octet-stream", "postman.zip");
                }
            }
            throw new NotFoundException();
        }
    }
}