﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Zevit.AddressBook.Contact.Api.Infrastructure.Filters;

namespace Zevit.AddressBook.Contact.Api.Controllers.Base
{
    /// <summary>
    /// Base WebAPI controller.
    /// </summary>
    [ApiController]
    [EnableCors("CorsPolicy")]
    [TypeFilter(typeof(ValidateModelActionFilter))]
    [TypeFilter(typeof(ResponseResultFilter))]
    public abstract class ApiController : ControllerBase
    {
        private IMediator _mediator;
        protected IMediator Mediator => _mediator ??= HttpContext.RequestServices.GetService<IMediator>();
    }
}
