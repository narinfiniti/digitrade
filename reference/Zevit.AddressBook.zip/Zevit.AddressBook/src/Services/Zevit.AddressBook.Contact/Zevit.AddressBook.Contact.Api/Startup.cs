using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Swashbuckle.AspNetCore.SwaggerUI;
using Zevit.AddressBook.Contact.Api.Extensions;
using Zevit.AddressBook.Contact.Api.Infrastructure.Middlewares;
using Zevit.AddressBook.Contact.Dependency.Extensions;
using Zevit.AddressBook.Contact.Application.Extensions;

namespace Zevit.AddressBook.Contact.Api
{
    public class Startup
    {
        public Startup(
            IConfiguration configuration,
            IWebHostEnvironment environment)
        {
            Configuration = configuration;
            Environment = environment;
        }

        public IConfiguration Configuration { get; }
        public IWebHostEnvironment Environment { get; }
        public IServiceCollection Services { get; private set; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCustomConfiguration(Configuration, Environment);
            services.AddDependencies(Configuration, Environment);
            services.AddHttpServices(Environment);

            services.AddHealthChecks(Configuration, Environment);
            //services.AddApplicationInsights(Configuration, Environment);

            services.AddCustomControllers(Configuration);
            services.AddCustomAuthentication(Configuration, Environment);
            services.AddCustomAuthorization(Configuration);

            services.AddCustomCors(Configuration, Environment);
            services.AddCustomApiVersioning(Configuration);
            services.AddCustomSwagger(Configuration, Environment);

            Services = services;
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseMiddleware<ExceptionHandlingMiddleware>();

            if (env.IsDevOrLocal())
            {
                //app.UseDeveloperExceptionPage();
                app.UseServicesDisplayPage(Services);
            }
            else if (env.IsProduction())
            {
                //app.UseExceptionHandler("/Error");
                app.UseHsts(); // Browsers only
                app.UseHttpsRedirection();
            }

            app.UseRouting();
            app.UseCors("CorsPolicy");
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthCheck();
                //endpoints.MapGrpcServices();
                endpoints.MapControllers()
                    .RequireAuthorization()
                    ;
            });

            app.UseHealthChecks("/health");
            app.UseHealthChecks("/health/db");
            if (env.IsDevOrLocal())
            {

                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.DocumentTitle = "Zevit AddressBook Contact Api";
                    //foreach (var v in provider.ApiVersionDescriptions)
                    c.SwaggerEndpoint($"/swagger/v1/swagger.json", $"Zevit AddressBook Contact API V1");
                    c.RoutePrefix = $"{Constants.Consts.ApiPrefix}/swagger";
                    c.DefaultModelExpandDepth(2); // model shown in endpoint
                    c.DefaultModelRendering(ModelRendering.Model);
                    c.DefaultModelsExpandDepth(2); // model shown in list at the bottom
                    c.DisplayOperationId();
                    c.DisplayRequestDuration();
                    c.DocExpansion(DocExpansion.List);
                    c.EnableDeepLinking();
                    c.EnableFilter();
                    //c.MaxDisplayedTags(5);
                    c.ShowExtensions();
                    c.EnableValidator();
                    c.SupportedSubmitMethods(SubmitMethod.Get, SubmitMethod.Post);
                    //c.OAuthClientId(AppConstants.SwaggerClientID);
                    //c.OAuthClientSecret("no_password");
                });
            }
            app.ConfigureEventBus();
        }
    }
}
