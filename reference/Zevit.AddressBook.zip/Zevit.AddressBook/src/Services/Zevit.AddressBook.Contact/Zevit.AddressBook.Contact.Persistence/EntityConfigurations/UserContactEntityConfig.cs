﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Zevit.AddressBook.Contact.Domain.Entity;

namespace Zevit.AddressBook.Contact.Persistence.EntityConfigurations
{
    internal class UserContactEntityConfig : IEntityTypeConfiguration<UserContact>
    {
        public void Configure(EntityTypeBuilder<UserContact> builder)
        {
            builder.ToTable(nameof(UserContact));
            builder.HasKey(e => e.Id);
            builder.HasIndex(e => e.UserId);

            builder.Property(e => e.FirstName).HasColumnType("NVARCHAR(100)").IsRequired();
            builder.Property(e => e.LastName).HasColumnType("NVARCHAR(100)").IsRequired(false);
        }
    }
}