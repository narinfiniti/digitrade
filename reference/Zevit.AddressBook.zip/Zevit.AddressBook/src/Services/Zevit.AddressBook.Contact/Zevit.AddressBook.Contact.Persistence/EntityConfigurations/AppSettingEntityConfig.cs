﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Zevit.AddressBook.Contact.Domain.Entity.Config;
using Zevit.AddressBook.Contact.Persistence.Extensions;

namespace Zevit.AddressBook.Contact.Persistence.EntityConfigurations
{
    internal class AppSettingEntityConfig : IEntityTypeConfiguration<AppSetting>
    {
        public void Configure(EntityTypeBuilder<AppSetting> builder)
        {
            builder.ToTable(nameof(AppSetting));
            builder.HasKey(e => e.Id);

            builder.Property(e => e.Config)
                .HasJsonConversion()
                .HasColumnType("VARCHAR(8000)").IsRequired();
        }
    }
}