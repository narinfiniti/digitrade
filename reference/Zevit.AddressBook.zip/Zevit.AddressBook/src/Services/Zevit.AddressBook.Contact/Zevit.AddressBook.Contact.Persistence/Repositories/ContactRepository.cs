using System;
using System.Threading.Tasks;
using Dapper;
using Zevit.AddressBook.Contact.Application.Interfaces.Repositories;
using Zevit.AddressBook.Contact.Application.Models.Filters;
using Zevit.AddressBook.Contact.Domain.Entity;
using Zevit.AddressBook.Contact.Persistence.Common;
using Zevit.Common.Models.Response;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Persistence.Repositories
{
    public class ContactRepository
        : RepositoryBase<UserContact, Guid, UnitOfWork>, IContactRepository
    {
        public ContactRepository(
            IUnitOfWork context
        ) : base((UnitOfWork)context)
        { }

        public async Task<ListResult<UserContact>> FindContactRangeAsync(
            ContactListFilter listFilter)
        {
            var param = new DynamicParameters();
            param.AddDynamicParams(new
            {
                listFilter.UserId,
                listFilter.Skip,
                listFilter.Limit
            });
            var sql = $@"
                SELECT c.*, COUNT(*) OVER() [Count]
                FROM [{UnitOfWork.DbScheme}].[{nameof(UserContact)}] c
                WHERE @UserId is NULL OR c.[UserId]=@UserId
                ORDER BY c.[Id] DESC
                OFFSET @Skip ROWS
                FETCH NEXT @Limit ROWS ONLY
            ";
            var total = 0;
            var result = await WithDbConnection(conn => conn
                .QueryAsync<UserContact, int, UserContact>(
                    sql: sql,
                    map: (contact, count) =>
                    {
                        total = count;
                        return contact;
                    },
                    splitOn: $"Count",
                    param: param));
            return new ListResult<UserContact>(result)
            {
                //HasNext = total - filter.Skip > filter.Limit
                Total = total
            };
        }

    }
}