﻿using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Zevit.AddressBook.Contact.Application.Interfaces.Repositories;
using Zevit.AddressBook.Contact.Domain.Entity.Config;
using Zevit.AddressBook.Contact.Persistence.Common;

namespace Zevit.AddressBook.Contact.Persistence.Repositories
{
    /// <summary>
    /// Repository for an AppSetting entity.
    /// </summary>
    public class AppSettingRepository : IAppSettingRepository
    {
        private DbContextOptions<UnitOfWork> _dbOps;
        private AppSetting _setting;
        public AppSettingRepository(
            IConfiguration config,
            DbContextOptions<UnitOfWork> dbOps
            )
        {
            _dbOps = dbOps;
            Find(1);
        }

        public AppSetting Find(byte id, bool useCache = true)
        {
            if (useCache && _setting != null) return _setting;

            using var context = new UnitOfWork(_dbOps);

            return _setting = context
                .Set<AppSetting>()
                .AsNoTracking()
                .FirstOrDefault(e => e.Id == id);
        }

        public AppSetting Save(AppSetting entity)
        {
            using var context = new UnitOfWork(_dbOps);

            var entry = context.ChangeTracker
                .Entries<AppSetting>()
                .FirstOrDefault(e => e.Entity.Id == entity.Id);
            if (entry != null)
            {
                entry.CurrentValues.SetValues(entity);
                _setting = entry.Entity;
            }
            else
            {
                _setting = context.Update(entity)?.Entity;
            }
            context.SaveChanges();
            return _setting;
        }
    }
}
