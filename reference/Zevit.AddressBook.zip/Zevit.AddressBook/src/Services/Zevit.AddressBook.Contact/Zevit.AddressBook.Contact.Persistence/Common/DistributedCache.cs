using System;
namespace Zevit.AddressBook.Contact.Persistence.Common
{
    /// <summary>
    /// DistributedCache.
    /// </summary>
    public class DistributedCache
    {
        public string Id { get; set; }
        public DateTimeOffset ExpiresAtTime { get; set; }
        public byte[] Value { get; set; }
        public DateTimeOffset? AbsoluteExpiration { get; set; }
        public long? SlidingExpirationInSeconds { get; set; }
    }
}