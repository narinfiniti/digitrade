﻿using System.IO;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace Zevit.AddressBook.Contact.Persistence.Common
{
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<UnitOfWork>
    {
        public UnitOfWork CreateDbContext(string[] args)
        {
            var config = new ConfigurationBuilder()
               .SetBasePath(Path.Combine(Directory.GetCurrentDirectory()))
               .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false)
               .AddUserSecrets("b6c6a706-73ce-481f-9b68-3e42612c599c")
               .Build();

            var optionsBuilder = new DbContextOptionsBuilder<UnitOfWork>()
                .UseSqlServer(
                    config.GetConnectionString("DefaultConnection"),
                    b => b.MigrationsAssembly(typeof(UnitOfWork).Assembly.FullName));

            return new UnitOfWork(optionsBuilder.Options);
        }
    }
}
