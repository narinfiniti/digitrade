﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Persistence.Common
{
    internal class EntityTypeConfiguration<TEntity, TKey> where TEntity : class, IEntity<TKey>
    {
        public virtual void Configure(EntityTypeBuilder<TEntity> builder)
        {
            builder.ToTable(typeof(TEntity).Name);
            builder.HasKey(e => e.Id);
        }
    }
}
