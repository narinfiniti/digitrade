﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Zevit.AddressBook.Contact.Persistence.Extensions;
using Zevit.Common.Models;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Persistence.Common
{
    public class UnitOfWork : DbContext, IUnitOfWork
    {
        public const string DbScheme = "app";
        private bool _disposed;
        private readonly IMediator _mediator;
        private readonly ILogger<UnitOfWork> _logger;
        private readonly IServiceScopeFactory _scopeFactory;
        public UnitOfWork(
            DbContextOptions<UnitOfWork> options,
            IMediator mediator = null,
            ILogger<UnitOfWork> logger = null,
            IServiceScopeFactory scopeFactory = null
        ) : base(options)
        {
            _disposed = false;
            _mediator = mediator;
            _logger = logger;
            _scopeFactory = scopeFactory;
            ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }
        public Task MigrateAsync(CancellationToken cancellationToken = default)
        {
            return Database.MigrateAsync(cancellationToken);
        }
        public Task<bool> CanConnectAsync(CancellationToken cancellationToken = default)
        {
            return Database.CanConnectAsync(cancellationToken);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.HasDefaultSchema(DbScheme);
            builder.ApplyConfigurationsFromAssembly(typeof(EntityTypeConfiguration<,>).Assembly);
            //builder.AddShadowProperties();
        }


        public void ValidateAggregateRootInvariantRules()
        {
            using var scope = _scopeFactory?.CreateScope();
            var errors = new List<ValidationFailure>();
            var validationResults = ChangeTracker.Entries<IValidatableObject>()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified)
                .SelectMany(e =>
                    e.Entity.Validate(
                        new ValidationContext(scope?.ServiceProvider)))
                .Where(r => r != ValidationResult.Success);

            foreach (var validationResult in validationResults)
            {
                var names = string.Join(", ", validationResult.MemberNames);
                errors.Add(new ValidationFailure(names, validationResult.ErrorMessage));
            }

            if (errors.Any())
            {
                throw new Zevit.Common.Exceptions.ValidationException(failures: errors);
            }
        }

        public async Task<int> SaveAsync(CancellationToken cancellation = default)
        {
            ValidateAggregateRootInvariantRules();
            return await base.SaveChangesAsync(cancellation);
        }
        public async Task<bool> SaveEntitiesAsync(CancellationToken cancellation = default)
        {
            // Dispatch Domain Events collection. 
            // Choices:
            // A) Right BEFORE committing data (EF SaveChanges) into the DB will make a single transaction including  
            // side effects from the domain event handlers which are using the same DbContext with "InstancePerLifetimeScope" or "scoped" lifetime
            // B) Right AFTER committing data (EF SaveChanges) into the DB will make multiple transactions. 
            // You will need to handle eventual consistency and compensatory actions in case of failures in any of the Handlers. 
            await _mediator.DispatchDomainEventsAsync(this);

            // After executing this line all the changes (from the Command Handler and Domain Event Handlers) 
            // performed through the DbContext will be committed
            var result = await base.SaveChangesAsync(cancellation);
            return true;
        }
        public IDbContextTransaction CurrentTransaction { get; private set; }

        public bool HasActiveTransaction => CurrentTransaction != null;

        public async Task<IDbContextTransaction> BeginTransactionAsync()
        {
            if (CurrentTransaction != null) return null;

            CurrentTransaction = await Database.BeginTransactionAsync(IsolationLevel.ReadCommitted);

            return CurrentTransaction;
        }

        public async Task CommitAsync(IDbContextTransaction transaction)
        {
            if (transaction == null) throw new ArgumentNullException(nameof(transaction));
            if (transaction != CurrentTransaction)
                throw new InvalidOperationException($"Transaction {transaction.TransactionId} is not current");

            try
            {
                await SaveChangesAsync();
                await transaction.CommitAsync();
            }
            catch
            {
                await RollbackAsync();
                throw;
            }
            finally
            {
                CurrentTransaction?.Dispose();
                CurrentTransaction = null;
            }
        }

        public async Task RollbackAsync()
        {
            try
            {
                if (CurrentTransaction != null) await CurrentTransaction.RollbackAsync();
            }
            finally
            {
                CurrentTransaction?.Dispose();
                CurrentTransaction = null;
            }
        }

        public override void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void Dispose(bool isDisposing)
        {
            if (!_disposed)
            {
                if (isDisposing)
                {
                    // Clean up managed resources.
                }
            }
            _disposed = true;
            base.Dispose();
        }
    }
}
