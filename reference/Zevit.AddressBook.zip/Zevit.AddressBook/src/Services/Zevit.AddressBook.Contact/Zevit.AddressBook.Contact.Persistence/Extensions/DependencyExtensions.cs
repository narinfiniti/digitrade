﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Zevit.AddressBook.Contact.Application.Interfaces.Repositories;
using Zevit.AddressBook.Contact.Domain.Entity.Config;
using Zevit.AddressBook.Contact.Persistence.Common;
using Zevit.AddressBook.Contact.Persistence.Repositories;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Persistence.Extensions
{
    public static class DependencyExtensions
    {
        public static void AddPersistence(
            this IServiceCollection services,
            IConfiguration config, IHostEnvironment env)
        {
            var connectionString = config.GetConnectionString("DefaultConnection");

            if (!env.IsEnvironment("Testing"))
            {
                services.AddDbContext<UnitOfWork>(options =>
                    options.UseSqlServer(connectionString, b =>
                    {
                        b.MigrationsAssembly(typeof(UnitOfWork).Assembly.FullName);
                        // Connection Resiliency: https://docs.microsoft.com/en-us/ef/core/miscellaneous/connection-resiliency 
                        b.EnableRetryOnFailure(
                                maxRetryCount: 3,
                                maxRetryDelay: TimeSpan.FromSeconds(5),
                                errorNumbersToAdd: null);
                    })
                    .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking),
                    contextLifetime: ServiceLifetime.Transient,
                    optionsLifetime: ServiceLifetime.Transient);
            }

            services.AddScoped<IUnitOfWork, UnitOfWork>();

            services.AddSingleton<IAppSettingRepository, AppSettingRepository>();
            services.AddTransient<AppSetting>(p => p.GetRequiredService<IAppSettingRepository>().Find(1));

            services.AddScoped<IContactRepository, ContactRepository>();
        }

    }
}
