﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MediatR;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Persistence.Extensions
{
    /// <summary>
    /// MediatorExtensions
    /// </summary>
    internal static class MediatorExtensions
    {
        public static async Task DispatchDomainEventsAsync(this IMediator mediator, DbContext ctx)
        {
            var entries = ctx.ChangeTracker
                .Entries<IEntity>().Where(e => e.Entity.Events.Any());

            var domainEvents = entries.SelectMany(x => x.Entity.Events).ToList();

            foreach (var entity in entries.Select(e => e.Entity))
                entity.ClearDomainEvents();

            foreach (var e in domainEvents)
                await mediator.Publish(e);
        }
    }
}