using Zevit.AddressBook.Contact.Application.Interfaces.Services;

namespace Zevit.AddressBook.Contact.Infrastructure.Services
{
    /// <summary>
    /// SomeService.
    /// </summary>
    public class SomeService : ISomeService
    {
    }
}