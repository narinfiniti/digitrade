namespace Zevit.AddressBook.Contact.Infrastructure.Models
{
    /// <summary>
    /// SomeLocalModel.
    /// </summary>
    public class SomeLocalModel
    {
        public string currency { get; set; }
        public decimal rate { get; set; }
        public long timestamp { get; set; }
    }
}