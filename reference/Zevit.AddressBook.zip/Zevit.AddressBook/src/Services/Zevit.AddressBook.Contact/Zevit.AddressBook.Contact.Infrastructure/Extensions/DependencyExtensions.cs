﻿using Microsoft.Extensions.Caching.SqlServer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Zevit.AddressBook.Contact.Application.Interfaces.Services;
using Zevit.AddressBook.Contact.Infrastructure.Services;
using Zevit.Messaging.Extensions;
using Zevit.SharedKernel.Extensions;

namespace Zevit.AddressBook.Contact.Infrastructure.Extensions
{
    /// <summary>
    /// Extensions for adding dependencies into service collection.
    /// </summary>
    public static class DependencyExtensions
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services,
            IConfiguration config,
            IHostEnvironment env)
        {
            services.AddSharedKernelInfrastructure(config, env);
            services.AddIntegrationEventMessaging(config, env);
            services.AddTransient<IContactIntegrationEventService, ContactIntegrationEventService>();

            services.AddDistributedSqlServerCache(ops =>
            {
                config.GetSection(nameof(SqlServerCacheOptions)).Bind(ops);
                ops.ConnectionString = config.GetConnectionString("DefaultConnection");
            });

            //services.AddHttpClient();

            return services;
        }
    }
}