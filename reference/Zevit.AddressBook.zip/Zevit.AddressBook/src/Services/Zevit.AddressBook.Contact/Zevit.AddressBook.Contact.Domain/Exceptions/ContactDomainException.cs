using System.Collections.Generic;
using Zevit.Common.Exceptions;
using Zevit.Common.Models;

namespace Zevit.AddressBook.Contact.Domain.Exceptions
{
    /// <summary>
    /// Domain Exception for Contact service sub-domain.
    /// </summary>
    public class ContactDomainException : ValidationException
    {
        public ContactDomainException(string message, int statusCode = 422)
            : base(message, statusCode)
        {
        }

        public ContactDomainException(IEnumerable<ValidationFailure> failures, string message)
            : base(failures, message)
        {
        }
    }
}