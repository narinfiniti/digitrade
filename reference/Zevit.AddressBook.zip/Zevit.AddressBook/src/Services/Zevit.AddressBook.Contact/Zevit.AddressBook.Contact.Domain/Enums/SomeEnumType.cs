namespace Zevit.AddressBook.Contact.Domain.Enums
{
    /// <summary>
    /// IntegrationEventType.
    /// </summary>
    public enum SomeEnumType
    {
    }
}