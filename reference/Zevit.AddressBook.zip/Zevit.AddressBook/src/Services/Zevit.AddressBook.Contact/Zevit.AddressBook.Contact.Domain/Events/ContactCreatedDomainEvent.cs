using MediatR;
using Zevit.AddressBook.Contact.Domain.Entity;

namespace Zevit.AddressBook.Contact.Domain.Events
{
    /// <summary>
    /// Contact Created Domain Event.
    /// </summary>
    public class ContactCreatedDomainEvent : INotification
    {
        public UserContact Contact { get; init; }

        public ContactCreatedDomainEvent(UserContact contact)
        {
            Contact = contact;
        }
    }
}