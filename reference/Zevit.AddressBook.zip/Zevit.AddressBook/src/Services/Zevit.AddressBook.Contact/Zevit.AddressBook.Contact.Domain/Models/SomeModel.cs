﻿namespace Zevit.AddressBook.Contact.Domain.Models
{
    public class SomeModel
    {
        public string Id { get; set; }
        public string EventId { get; set; }
    }
}
