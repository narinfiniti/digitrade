﻿using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Domain.Entity.Config
{
    /// <summary>
    /// AppSetting entity.
    /// </summary>
    public class AppSetting : IEntity<byte>
    {
        public byte Id { get; set; }
        public AppConfig Config { get; set; }
    }
}
