﻿using System;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.AddressBook.Contact.Domain.Entity
{
    /// <summary>
    /// UserContact.
    /// </summary>
    public class UserContact : IAggregateRoot<Guid>
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }


        public override bool Equals(object obj)
        {
            if (obj is UserContact other)
            {
                return other.Id == Id;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }
    }
}
