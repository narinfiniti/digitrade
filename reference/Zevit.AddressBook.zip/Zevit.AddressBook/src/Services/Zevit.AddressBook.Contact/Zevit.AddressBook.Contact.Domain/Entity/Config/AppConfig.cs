namespace Zevit.AddressBook.Contact.Domain.Entity.Config
{
    /// <summary>
    /// AppConfig.
    /// </summary>
    public class AppConfig
    {
        public int BackgroundTaskExecTimeout { get; set; }
    }
}