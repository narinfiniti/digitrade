﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Zevit.AddressBook.Contact.Application.Extensions;
using Zevit.AddressBook.Contact.Infra.DataSeed.Extensions;
using Zevit.AddressBook.Contact.Infrastructure.Extensions;
using Zevit.AddressBook.Contact.Persistence.Extensions;

namespace Zevit.AddressBook.Contact.Dependency.Extensions
{
    public static class DependencyResolution
    {
        public static IServiceCollection AddDependencies(this IServiceCollection services,
            IConfiguration configuration,
            IHostEnvironment env)
        {
            services.AddPersistence(configuration, env);
            services.AddInfrastructure(configuration, env);
            services.AddUseCaseDependencies(configuration, env);

            //services.AddBackgroundWorker(configuration);
            services.AddDataSeeder();
            //services.AddWebSockets(configuration, env);
            //services.AddSignalrHubs(configuration, env);

            return services;
        }
    }
}
