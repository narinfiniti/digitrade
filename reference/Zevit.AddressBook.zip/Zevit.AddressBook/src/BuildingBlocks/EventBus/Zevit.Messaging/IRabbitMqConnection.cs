﻿using System;
using RabbitMQ.Client;

namespace Zevit.Messaging
{
    public interface IRabbitMqConnection
        : IDisposable
    {
        bool IsConnected { get; }

        bool TryConnect();

        IModel CreateChannel();
    }
}
