﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using Zevit.Messaging.Abstractions;
using Zevit.Messaging.Persistence.Extensions;

namespace Zevit.Messaging.Extensions
{
    public static partial class DependencyExtensions
    {
        public static IServiceCollection AddIntegrationEventMessaging(this IServiceCollection services,
            IConfiguration config,
            IHostEnvironment env)
        {
            var retryCount = config.GetValue<int>("RabbitMq:RetryCount");
            services.AddSingleton<IRabbitMqConnection>(sp =>
            {
                var logger = sp.GetRequiredService<ILogger<RabbitMqConnection>>();

                ConnectionFactory factory = new()
                {
                    AutomaticRecoveryEnabled = true,
                    DispatchConsumersAsync = true
                };
                config.GetSection("RabbitMq").Bind(factory);

                return new RabbitMqConnection(factory, logger, retryCount);
            });
            services.AddSingleton<ISubscriptionManager, SubscriptionsManagerInMemory>();
            services.AddSingleton<IEventBus, EventBusRabbitMq>(sp =>
            {
                var subscriptionClientName = config.GetValue<string>("RabbitMq:ClientQueueName");
                var rabbitMqConnection = sp.GetRequiredService<IRabbitMqConnection>();
                var serviceScopeFactory = sp.GetRequiredService<IServiceScopeFactory>();
                var logger = sp.GetRequiredService<ILogger<EventBusRabbitMq>>();
                var subscriptionManager = sp.GetRequiredService<ISubscriptionManager>();
                
                return new EventBusRabbitMq(
                    rabbitMqConnection, logger,
                    serviceScopeFactory,
                    subscriptionManager, 
                    subscriptionClientName,
                    retryCount);
            });
            services.AddEventMessagingPersistence(config, env);
            return services;
        }
    }
}
