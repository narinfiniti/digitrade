﻿using System;
using System.Linq;
using Newtonsoft.Json;
using Zevit.Messaging.Abstractions.Enums;
using Zevit.Messaging.Abstractions.Events;
using Zevit.SharedKernel.Interfaces;

namespace Zevit.Messaging.Abstractions.Entity
{
    public class IntegrationEventSnapshot : IAggregateRoot<Guid>
    {
        public IntegrationEventSnapshot()
        {
        }

        public IntegrationEventSnapshot(IntegrationEvent @event, Guid transactionId)
        {
            Id = @event.Id;
            CreateDate = @event.CreateDate;
            EventTypeName = @event.GetType().FullName;
            Content = JsonConvert.SerializeObject(@event);
            State = EventStateEnum.NotPublished;
            SentCount = 0;
            TransactionId = transactionId.ToString();
        }

        public Guid Id { get; set; }
        public string EventTypeName { get; private set; }
        public EventStateEnum State { get; set; }
        public DateTimeOffset CreateDate { get; private set; }
        public string TransactionId { get; private set; }
        public int SentCount { get; set; }
        public string Content { get; private set; }

        public string EventTypeShortName => EventTypeName.Split('.')?.Last();
        public IntegrationEvent IntegrationEvent { get; private set; }

        public IntegrationEventSnapshot DeserializeJsonContent(Type type)
        {
            IntegrationEvent = JsonConvert.DeserializeObject(Content, type) as IntegrationEvent;
            return this;
        }
    }
}