using System;
using System.Threading;
using System.Threading.Tasks;

namespace Zevit.Messaging.Abstractions
{
    public interface IEventSnapshotUnitOfWork : IDisposable
    {
        void ValidateAggregateRootInvariantRules();
        Task<int> SaveAsync(CancellationToken cancellation = default);
        Task MigrateAsync(CancellationToken cancellationToken = default);
        Task<bool> CanConnectAsync(CancellationToken cancellationToken = default);
    }
}