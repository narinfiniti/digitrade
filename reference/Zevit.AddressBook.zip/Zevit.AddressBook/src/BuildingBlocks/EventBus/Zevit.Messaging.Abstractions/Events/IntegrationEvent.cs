using System;

namespace Zevit.Messaging.Abstractions.Events
{
    /// <summary>
    /// Integration Event.
    /// </summary>
    public abstract class IntegrationEvent
    {
        protected IntegrationEvent(Guid? id = null, DateTime? createDate = null)
        {
            Id = id ?? Guid.NewGuid();
            CreateDate = createDate ?? DateTime.UtcNow;
        }

        public Guid Id { get; private init; }
        public DateTime CreateDate { get; private init; }
    }
}