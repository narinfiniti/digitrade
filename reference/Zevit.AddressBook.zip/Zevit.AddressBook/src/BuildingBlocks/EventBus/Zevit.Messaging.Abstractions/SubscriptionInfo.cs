﻿using System;

namespace Zevit.Messaging.Abstractions
{
    public class SubscriptionInfo
    {
        public bool IsDynamic { get; }
        public Type HandlerType { get; }

        private SubscriptionInfo(bool isDynamic, Type handlerType)
        {
            IsDynamic = isDynamic;
            HandlerType = handlerType;
        }

        public static SubscriptionInfo Dynamic(Type handlerType)
        {
            return new(true, handlerType);
        }
        public static SubscriptionInfo Typed(Type handlerType)
        {
            return new(false, handlerType);
        }
    }
}
