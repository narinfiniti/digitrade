﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Zevit.Messaging.Abstractions.Entity;
using Zevit.Messaging.Abstractions.Events;

namespace Zevit.Messaging.Abstractions
{
    public interface IEventSnapshotService
    {
        Task<IEnumerable<IntegrationEventSnapshot>> GetEventsPendingToPublishAsync(Guid transactionId);
        Task SaveEventAsync(IntegrationEvent @event, object transaction);
        Task MarkEventAsPublishedAsync(Guid eventId);
        Task MarkEventAsInProgressAsync(Guid eventId);
        Task MarkEventAsFailedAsync(Guid eventId);
    }
}
