﻿#nullable enable
using System;
using System.Collections.Generic;
using Zevit.Messaging.Abstractions.Events;

namespace Zevit.Messaging.Abstractions
{
    public interface ISubscriptionManager
    {
        bool IsEmpty { get; }
        event EventHandler<string> OnEventRemoved;
        void AddSubscription<THandler>(string eventName)
           where THandler : IDynamicIntegrationEventHandler;

        void AddSubscription<TEvent, THandler>()
           where TEvent : IntegrationEvent
           where THandler : IIntegrationEventHandler<TEvent>;

        void RemoveSubscription<TEvent, THandler>()
            where TEvent : IntegrationEvent
            where THandler : IIntegrationEventHandler<TEvent>;
        void RemoveDynamicSubscription<THandler>(string eventName)
            where THandler : IDynamicIntegrationEventHandler;

        bool HasSubscriptionsForEvent<TEvent>() where TEvent : IntegrationEvent;
        bool HasSubscriptionsForEvent(string eventName);
        Type GetEventTypeByName(string eventName);
        List<Type> GetEventTypes();
        void Clear();
        IEnumerable<SubscriptionInfo> GetHandlersForEvent<TEvent>() where TEvent : IntegrationEvent;
        IEnumerable<SubscriptionInfo> GetHandlersForEvent(string eventName);
        string GetEventKey<TEvent>();
    }
}