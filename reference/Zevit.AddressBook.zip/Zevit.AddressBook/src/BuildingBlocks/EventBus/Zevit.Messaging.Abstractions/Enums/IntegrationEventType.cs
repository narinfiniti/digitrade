namespace Zevit.Messaging.Abstractions.Enums
{
    /// <summary>
    /// IntegrationEventType.
    /// </summary>
    public enum IntegrationEventType
    {
        AddressCreatedIntegrationEvent = 112,
    }
}