using System.Threading.Tasks;
using Zevit.Messaging.Abstractions.Events;

namespace Zevit.Messaging.Abstractions
{
    public interface IIntegrationEventHandler<in TEvent> : IIntegrationEventHandler
        where TEvent : IntegrationEvent
    {
        Task Handle(TEvent @event);
    }
    public interface IDynamicIntegrationEventHandler
    {
        Task Handle(dynamic eventData);
    }
    public interface IIntegrationEventHandler
    {
    }
}