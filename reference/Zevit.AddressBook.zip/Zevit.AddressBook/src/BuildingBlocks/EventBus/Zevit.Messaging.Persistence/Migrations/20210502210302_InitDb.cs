﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Zevit.Messaging.Persistence.Zevit.Messaging.Persistence.Migrations
{
    public partial class InitDb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "app");

            migrationBuilder.CreateTable(
                name: "DistributedCache",
                schema: "app",
                columns: table => new
                {
                    Id = table.Column<string>(type: "VARCHAR(36)", nullable: false),
                    ExpiresAtTime = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    Value = table.Column<byte[]>(type: "VARBINARY(MAX)", nullable: false),
                    AbsoluteExpiration = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    SlidingExpirationInSeconds = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DistributedCache", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "IntegrationEventSnapshot",
                schema: "app",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "UNIQUEIDENTIFIER", nullable: false),
                    EventTypeName = table.Column<string>(type: "VARCHAR(1000)", nullable: false),
                    State = table.Column<byte>(type: "TINYINT", nullable: false),
                    CreateDate = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    TransactionId = table.Column<string>(type: "VARCHAR(1000)", nullable: false),
                    SentCount = table.Column<int>(type: "INT", nullable: false),
                    Content = table.Column<string>(type: "VARCHAR(4000)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IntegrationEventSnapshot", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DistributedCache",
                schema: "app");

            migrationBuilder.DropTable(
                name: "IntegrationEventSnapshot",
                schema: "app");
        }
    }
}
