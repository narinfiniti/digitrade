﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Zevit.Messaging.Abstractions;
using Zevit.Messaging.Persistence.Common;
using Zevit.Messaging.Persistence.Services;

namespace Zevit.Messaging.Persistence.Extensions
{
    public static class DependencyExtensions
    {
        public static void AddEventMessagingPersistence(
            this IServiceCollection services,
            IConfiguration config, IHostEnvironment env)
        {
            var connectionString = config.GetConnectionString("EventSnapshotConnection");
            if (!env.IsEnvironment("Testing"))
            {
                services.AddDbContext<EventSnapshotUnitOfWork>(options =>
                        options.UseSqlServer(connectionString, b =>
                            {
                                b.MigrationsAssembly(typeof(EventSnapshotUnitOfWork).Assembly.FullName);
                                // Connection Resiliency: https://docs.microsoft.com/en-us/ef/core/miscellaneous/connection-resiliency 
                                b.EnableRetryOnFailure(
                                    maxRetryCount: 3,
                                    maxRetryDelay: TimeSpan.FromSeconds(5),
                                    errorNumbersToAdd: null);
                            })
                            .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking),
                    contextLifetime: ServiceLifetime.Transient,
                    optionsLifetime: ServiceLifetime.Transient);
            }

            services.AddTransient<IEventSnapshotUnitOfWork, EventSnapshotUnitOfWork>();
            services.AddTransient<IEventSnapshotService, EventSnapshotService>();

            // services.AddTransient<Func<DbConnection, EventSnapshotService>>(
            //     sp => (DbConnection conn) => new EventSnapshotService(conn));
        }
    }
}
