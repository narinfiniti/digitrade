﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Zevit.Messaging.Persistence.Utilities
{
    public class ResilientTransactionFactory
    {
        private readonly DbContext _context;

        private ResilientTransactionFactory(DbContext context) =>
            _context = context ?? throw new ArgumentNullException(nameof(context));

        public static ResilientTransactionFactory Create(DbContext context) =>
            new ResilientTransactionFactory(context);

        public async Task ExecuteAsync(Func<Task> action)
        {
            //Use of an EF Core resiliency strategy when using multiple DbContexts within an explicit BeginTransaction():
            //See: https://docs.microsoft.com/en-us/ef/core/miscellaneous/connection-resiliency
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                await using var transaction = await _context.Database.BeginTransactionAsync();
                await action();
                await transaction.CommitAsync();
            });
        }
    }
}