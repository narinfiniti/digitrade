﻿using System.IO;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace Zevit.Messaging.Persistence.Common
{
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<EventSnapshotUnitOfWork>
    {
        public EventSnapshotUnitOfWork CreateDbContext(string[] args)
        {
            var config = new ConfigurationBuilder()
                .SetBasePath(Path.Combine(Directory.GetCurrentDirectory()))
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false)
                .Build();

            var optionsBuilder = new DbContextOptionsBuilder<EventSnapshotUnitOfWork>()
                .UseSqlServer(
                    config.GetConnectionString("EventSnapshotConnection"),
                    b => b.MigrationsAssembly(typeof(EventSnapshotUnitOfWork).Assembly.FullName));

            return new EventSnapshotUnitOfWork(optionsBuilder.Options);
        }
    }
}