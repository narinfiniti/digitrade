﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Zevit.Common.Models;
using Zevit.Messaging.Abstractions;
using Zevit.Messaging.Persistence.EntityConfigurations;
using ValidationException = Zevit.Common.Exceptions.ValidationException;

namespace Zevit.Messaging.Persistence.Common
{
    public sealed class EventSnapshotUnitOfWork : DbContext, IEventSnapshotUnitOfWork
    {
        private const string DbScheme = "app";
        private bool _disposed;
        private readonly ILogger<EventSnapshotUnitOfWork> _logger;
        private readonly IServiceScopeFactory _scopeFactory;
        public EventSnapshotUnitOfWork(
            DbContextOptions<EventSnapshotUnitOfWork> options,
            ILogger<EventSnapshotUnitOfWork> logger = null,
            IServiceScopeFactory scopeFactory = null
        ) : base(options)
        {
            _disposed = false;
            _logger = logger;
            _scopeFactory = scopeFactory;
            ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }
        public Task MigrateAsync(CancellationToken cancellationToken = default)
        {
            return Database.MigrateAsync(cancellationToken);
        }
        public Task<bool> CanConnectAsync(CancellationToken cancellationToken = default)
        {
            return Database.CanConnectAsync(cancellationToken);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.HasDefaultSchema(DbScheme);
            builder.ApplyConfigurationsFromAssembly(typeof(IntegrationEventSnapshotEntityConfig).Assembly);
            //builder.AddShadowProperties();
        }


        public void ValidateAggregateRootInvariantRules()
        {
            using var scope = _scopeFactory?.CreateScope();
            var errors = new List<ValidationFailure>();
            var validationResults = ChangeTracker.Entries<IValidatableObject>()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified)
                .SelectMany(e =>
                    e.Entity.Validate(
                        new ValidationContext(scope?.ServiceProvider)))
                .Where(r => r != ValidationResult.Success);

            foreach (var validationResult in validationResults)
            {
                var names = string.Join(", ", validationResult.MemberNames);
                errors.Add(new ValidationFailure(names, validationResult.ErrorMessage));
            }

            if (errors.Any())
            {
                throw new ValidationException(failures: errors);
            }
        }

        public async Task<int> SaveAsync(CancellationToken cancellation = default)
        {
            ValidateAggregateRootInvariantRules();
            return await base.SaveChangesAsync(cancellation);
        }

        public override void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void Dispose(bool isDisposing)
        {
            if (!_disposed)
            {
                if (isDisposing)
                {
                    // Clean up managed resources.
                }
            }
            _disposed = true;
            base.Dispose();
        }
    }
}
