﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Zevit.Messaging.Abstractions.Entity;

namespace Zevit.Messaging.Persistence.EntityConfigurations
{
    internal class IntegrationEventSnapshotEntityConfig : IEntityTypeConfiguration<IntegrationEventSnapshot>
    {
        public void Configure(EntityTypeBuilder<IntegrationEventSnapshot> builder)
        {
            builder.Ignore(e => e.IntegrationEvent);
            builder.Ignore(e => e.EventTypeShortName);
            builder.ToTable(nameof(IntegrationEventSnapshot));
            builder.HasKey(e => e.Id);
            
            builder.Property(e => e.Id).HasColumnType("UNIQUEIDENTIFIER").IsRequired();
            builder.Property(e => e.EventTypeName).HasColumnType("VARCHAR(1000)").IsRequired();
            builder.Property(e => e.State).HasColumnType("TINYINT").IsRequired();
            builder.Property(e => e.CreateDate).IsRequired();
            builder.Property(e => e.TransactionId).HasColumnType("VARCHAR(1000)").IsRequired();
            builder.Property(e => e.SentCount).HasColumnType("INT").IsRequired();
            builder.Property(e => e.Content).HasColumnType("VARCHAR(4000)").IsRequired();
        }
    }
}