﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Zevit.Messaging.Abstractions;
using Zevit.Messaging.Abstractions.Entity;
using Zevit.Messaging.Abstractions.Enums;
using Zevit.Messaging.Abstractions.Events;
using Zevit.Messaging.Persistence.Common;

namespace Zevit.Messaging.Persistence.Services
{
    public sealed class EventSnapshotService : IEventSnapshotService, IDisposable
    {
        private readonly ISubscriptionManager _subscriptionManager;
        private readonly EventSnapshotUnitOfWork _db;
        private volatile bool _disposedValue;
        private List<Type> EventTypes => _subscriptionManager.GetEventTypes();

        public EventSnapshotService(
            IEventSnapshotUnitOfWork eventDb,
            ISubscriptionManager subscriptionManager
        )
        {
            _subscriptionManager = subscriptionManager;
            _db = (EventSnapshotUnitOfWork) eventDb;
        }

        public async Task<IEnumerable<IntegrationEventSnapshot>> GetEventsPendingToPublishAsync(Guid transactionId)
        {
            var tid = transactionId.ToString();

            var result = await _db
                .Set<IntegrationEventSnapshot>()
                .Where(e => e.TransactionId == tid && e.State == EventStateEnum.NotPublished)
                .ToListAsync();

            if (result != null && result.Any())
            {
                return result
                    .OrderBy(o => o.CreateDate)
                    .Select(e => e.DeserializeJsonContent(
                        EventTypes.Find(t => t.Name == e.EventTypeShortName)));
            }

            return new List<IntegrationEventSnapshot>();
        }

        public Task SaveEventAsync(IntegrationEvent @event, object tran)
        {
            if (!(tran is IDbContextTransaction transaction)) throw new ArgumentNullException(nameof(transaction));

            var eventSnapshot = new IntegrationEventSnapshot(@event, transaction.TransactionId);

            _db.Database.UseTransaction(transaction.GetDbTransaction());
            _db.Set<IntegrationEventSnapshot>().Add(eventSnapshot);

            return _db.SaveChangesAsync();
        }

        public Task MarkEventAsPublishedAsync(Guid eventId)
        {
            return UpdateEventStatus(eventId, EventStateEnum.Published);
        }

        public Task MarkEventAsInProgressAsync(Guid eventId)
        {
            return UpdateEventStatus(eventId, EventStateEnum.InProgress);
        }

        public Task MarkEventAsFailedAsync(Guid eventId)
        {
            return UpdateEventStatus(eventId, EventStateEnum.PublishedFailed);
        }

        private Task UpdateEventStatus(Guid eventId, EventStateEnum status)
        {
            var eventHistory = _db
                .Set<IntegrationEventSnapshot>()
                .Single(ie => ie.Id == eventId);
            eventHistory.State = status;

            if (status == EventStateEnum.InProgress)
                eventHistory.SentCount++;

            _db
                .Set<IntegrationEventSnapshot>()
                .Update(eventHistory);

            return _db.SaveChangesAsync();
        }

        private void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    _db?.Dispose();
                }


                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}
