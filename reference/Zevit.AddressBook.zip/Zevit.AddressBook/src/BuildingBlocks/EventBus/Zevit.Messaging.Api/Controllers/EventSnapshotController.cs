﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Zevit.Messaging.Abstractions.Entity;

namespace Zevit.Messaging.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EventSnapshotController : ControllerBase
    {
        private readonly ILogger<EventSnapshotController> _logger;

        public EventSnapshotController(
            ILogger<EventSnapshotController> logger
        )
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<IntegrationEventSnapshot> Get()
        {
            return new []
            {
                new IntegrationEventSnapshot()
            };
        }
    }
}