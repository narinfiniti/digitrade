# App Migrations

#### In Source Project or Solution (in src folder)

Init or Add

```bash
  dotnet-ef migrations add -v AddPermissionView --startup-project ./Ewai.Eventis.Api --project ./Ewai.Eventis.Persistence --context UnitOfWork --output-dir Migrations
```

Update Database

```bash
dotnet-ef database update --startup-project ./Ewai.Eventis.Api --project ./Ewai.Eventis.Persistence --context UnitOfWork
```

If want to remove the last migration that was not ef-Updated to DB

```bash
-- dotnet-ef migrations remove --startup-project ./Ewai.Eventis.Api --project ./Ewai.Eventis.Persistence --context UnitOfWork
```

---

# `dotnet-ef` Installation

### 1. **Ensure .NET SDK is Installed**

Check if .NET SDK is installed by running:

```sh
dotnet --version
```

If .NET SDK is not installed, download and install it from the [official .NET website](https://dotnet.microsoft.com/download/dotnet).

---

### 2. **Install `dotnet-ef` Tool**

If `dotnet-ef` is missing, install it globally:

```sh
dotnet tool install --global dotnet-ef
```

---

### 3. **Verify the Installation**

After installation, check if the tool is accessible:

```sh
dotnet ef --version
```

If the command is not recognized, restart your terminal and try again.

---

### 4. **Ensure Global Tools Are in Your PATH**

Run the following command to check your PATH:

```sh
echo $PATH
```

Ensure that it includes:

```
~/.dotnet/tools
```

If it is missing, manually add it:

```sh
export PATH="$HOME/.dotnet/tools:$PATH"
```

To make this change permanent, add it to `~/.zshrc`:

```sh
echo 'export PATH="$HOME/.dotnet/tools:$PATH"' >> ~/.zshrc
source ~/.zshrc
```

---

Here’s a README.md file you can use for your SQL Server Edge Docker setup on Mac:

⸻

# SQL Server Edge in Docker on macOS

This project sets up Microsoft SQL Server Edge in a Docker container on macOS.

## 🐳 Prerequisites

- [Docker Desktop for Mac](https://www.docker.com/products/docker-desktop) installed and running
- Terminal access
- Optional: [Azure Data Studio](https://learn.microsoft.com/en-us/sql/azure-data-studio/download) or any SQL client

---

## 🚀 Getting Started

### 1. Pull the SQL Server Edge Image

```bash
docker pull mcr.microsoft.com/azure-sql-edge



⸻

2. Run the SQL Server Edge Container

docker run -e "ACCEPT_EULA=1" \
           -e "MSSQL_SA_PASSWORD=YourStrongPassword123" \
           -p 1433:1433 \
           --name sql-edge \
           -d mcr.microsoft.com/azure-sql-edge

Environment Variables:
	•	ACCEPT_EULA=1: Accepts the Microsoft EULA
	•	MSSQL_SA_PASSWORD: Strong password for the sa user (min 8 chars, 1 uppercase, 1 number, 1 special character)

⸻

2.0 Download Postgres image

docker pull postgres

2.1 Run the postgres Container

docker rm psql -v -f;docker run -d -p 5432:5432 -itd --restart always -e POSTGRES_USER=sa -e POSTGRES_PASSWORD=DQtTFas6B7i2kp5Rv6hF -e POSTGRES_DB=ewai.eventis.dev --name psql -id postgres

2.2 Verify the Container is Running

docker ps

2.3 Mac Client
Download Azure data Studio then download postgres extension to connect the database
⸻

🔗 Connect to SQL Server

Use your preferred SQL client (e.g., Azure Data Studio) with the following settings:
	•	Server: localhost
	•	Port: 1433
	•	Username: sa
	•	Password: YourStrongPassword123

⸻

📦 Container Management

Stop the Container

docker stop sql-edge

Start the Container

docker start sql-edge



⸻

🗂️ (Optional) Use Docker Volume for Data Persistence

To avoid data loss when restarting or removing the container:

docker volume create sqlvolume

docker run -e "ACCEPT_EULA=1" \
           -e "MSSQL_SA_PASSWORD=YourStrongPassword123" \
           -p 1433:1433 \
           --name sql-edge \
           -v sqlvolume:/var/opt/mssql \
           -d mcr.microsoft.com/azure-sql-edge



⸻

📜 License

This setup uses the official Microsoft Azure SQL Edge Docker image, subject to Microsoft’s licensing terms.

---


# Messaging Events Migrations

dotnet-ef migrations add -v InitIntegrationEventDb --startup-project ./Ewai.Eventis.Api --project ./AeventBus/Ewai.Eventis.Messaging.Persistence --context EventSnapshotUnitOfWork --output-dir Migrations

dotnet-ef migrations remove --startup-project ./Ewai.Eventis.Api --project ./AeventBus/Ewai.Eventis.Messaging.Persistence --context EventSnapshotUnitOfWork

dotnet-ef database update --startup-project ./Ewai.Eventis.Api --project ./AeventBus/Ewai.Eventis.Messaging.Persistence --context EventSnapshotUnitOfWork

## Identity Migrations

dotnet-ef migrations add -v InitIdentityDb --startup-project ./Ewai.Eventis.Api --project ./Ewai.Eventis.Identity --context IdeDbContext --output-dir Infrastructure/Data/Migrations/Identity

dotnet-ef migrations remove --startup-project ./Ewai.Eventis.Api --project ./Ewai.Eventis.Identity --context IdeDbContext

dotnet-ef database update --startup-project ./Ewai.Eventis.Api --project ./Ewai.Eventis.Identity --context IdeDbContext

dotnet-ef migrations add -v InitIdentityConfigDb --startup-project ./Ewai.Eventis.Api --project ./Ewai.Eventis.Identity --context IdsConfigDbContext --output-dir Infrastructure/Data/Migrations/Config

dotnet-ef migrations remove --startup-project ./Ewai.Eventis.Api --project ./Ewai.Eventis.Identity --context IdsConfigDbContext

dotnet-ef database update --startup-project ./Ewai.Eventis.Api --project ./Ewai.Eventis.Identity --context IdsConfigDbContext

dotnet-ef migrations add -v InitIdentityGrantDb --startup-project ./Ewai.Eventis.Api --project ./Ewai.Eventis.Identity --context IdsGrantDbContext --output-dir Infrastructure/Data/Migrations/Grant

dotnet-ef migrations remove --startup-project ./Ewai.Eventis.Api --project ./Ewai.Eventis.Identity --context IdsGrantDbContext

dotnet-ef database update --startup-project ./Ewai.Eventis.Api --project ./Ewai.Eventis.Identity --context IdsGrantDbContext

## Building and Deploying Bventis-Backend image into azure registry

docker build --pull --rm -f Dockerfile -t ewai-eventis-backend:1.0 "."
docker login account.azurecr.io
username:
password:

docker tag ewai-eventis-backend:1.0 account.azurecr.io/something/desktop/ewai-eventis-backend:1.217
docker push account.azurecr.io/something/desktop/ewai-eventis-backend:1.217

## Building and Deploying Bventis-Job image into azure registry

docker build --pull --rm -f DockerfileJob -t ewai-eventis-job:1.0 "."
docker login account.azurecr.io
username:
password:

docker tag ewai-eventis-job:1.0 account.azurecr.io/something/desktop/ewai-eventis-job:latest
docker push account.azurecr.io/something/desktop/ewai-eventis-job:latest

********************************************************

docker run -d --network bridge -v /Users/narek/Documents/mssql:/var/opt/mssql -e 'ACCEPT_EULA=Y' -e 'MSSQL_SA_PASSWORD=DQtTFas6B7i2kp5Rv6hF' -p 1433:1433 --name mssql mcr.microsoft.com/mssql/server:2022-latest

********************************************************

dotnet tool install --global dotnet-ef --version 8

cat << \EOF >> ~/.zprofile
# Add .NET Core SDK tools
export PATH="$PATH:/Users/narek/.dotnet/tools"
EOF

**********************************************************************

docker run -d --name rabbitmq-eventis -p 23517:23517 -p 15672:15672 -e RABBITMQ_DEFAULT_VHOST=ewai-eventis-rabbitmq-dev -e RABBITMQ_DEFAULT_USER=guest -e RABBITMQ_DEFAULT_PASS=guest rabbitmq:3-management


**********************************************************************

## Run as desktop

docker run --name bventis-backend -p 5001:5001 -v images:/app/wwwroot --env-file dev-desktop.env -id ewai-eventis-backend-local:latest

## Run as Master

docker run --name bventis-backend -p 5001:5001 -v images:/app/wwwroot --env-file dev-master.env -id ewai-eventis-backend-local:latest

## Note: To use the production settings for RabbitMQ use --env-file prod.env

## Troubleshooting

## Check docker logs and identify the issues.

## Run as desktop-azure

ssh bventis-desktop-PS5ja@20.203.6.172
pass:

sudo rm -rf Ewai.Eventis.Api
git clone https://ewai-eventis@dev.azure.com/ewai-eventis/Ewai.Eventis.Api/\_git/Ewai.Eventis.Api

sudo docker ps -a
sudo docker rm -f 639d8a65e956

sudo docker images -a
sudo docker system prune -a

## Create Cloud Desktop container image in azure

cd Ewai.Eventis.Api

## Run Bventis-Backend

sudo docker build -f Dockerfile.local -t ewai-eventis .
sudo docker run --name bventis-backend -p 443:443 -v images:/app/wwwroot --env-file dev-desktop-azure.env -id ewai-eventis

## Run Bventis-Job

sudo docker build -f DockerfileJob.local -t ewai-eventis-job .
sudo docker run --name bventis-backend -p 32014:32014 -v images:/app/wwwroot --env-file dev-desktop-azure.env -id ewai-eventis-job

## Check container logs

sudo docker ps -a
sudo docker logs --tail 500 e1eaeca57f4d
```
