﻿using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.BlobFiles.Extensions;
using Ewai.Eventis.Domain.Entity.Products;
using Ewai.SharedKernel.Interfaces;
using Ewai.SharedKernel.Models.Configs;

namespace Ewai.Eventis.App.Contracts.Models.Products.Dto;

/// <summary>
/// ProductListDto.
/// </summary>
public class ProductListDto : IAutoMap<TenantProduct, ProductListDto>
{
    public Guid Id { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? CategoryId { get; set; }
    public Guid? SubCategoryId { get; set; }
    public Guid? MasterProductId { get; set; }
    public string Name { get; set; }
    public string Barcode { get; set; }
    public string InternalBarcode { get; set; }
    public string ImageUrl { get; set; }
    public string Unit { get; set; }
    public bool IsWeightBased { get; set; }
    public bool? IsProhibited { get; set; }
    public bool? IsShoppingBag { get; set; }
    public decimal? UnitPrice { get; set; }
    public decimal? Vat { get; set; }
    public decimal? UnitCost { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? QtySold { get; set; }
    public decimal? QtyMissing { get; set; }
    public decimal? QtyDamaged { get; set; }
    public decimal? QtyRevoked { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantProduct, ProductListDto>()
            .ForMember(to => to.ImageUrl, c => c.MapFrom<ValueResolver>());
    }

    public class ValueResolver(
        DefaultAwsS3Storage s3Storage,
        IUserProfileService userProfileService)
        : IValueResolver<TenantProduct, ProductListDto, string>
    {
        public string Resolve(
            TenantProduct source, ProductListDto destination,
            string destMember, ResolutionContext context)
        {
            if (source.Image is null) return string.Empty;
            var tenantId = userProfileService.GetTenantId();
            return s3Storage.GetPreSignedUrl(source.Image.ToTenantFileName(tenantId));
        }
    }
}