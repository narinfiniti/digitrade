﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Products;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Products.Dto;

public class ProductGroupDto
    : IAutoMap<TenantProduct, ProductGroupDto>
{
    public Guid Id { get; set; }

    public string Barcode { get; set; }
    public string Name { get; set; }
    public decimal? DiOrig { get; set; }
    public decimal? OriginalSize { get; set; }
    public string Group { get; set; }
    public string Size { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantProduct, ProductGroupDto>();
    }
}