﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Products.Dto;

/// <summary>
/// ProductShopListDto.
/// </summary>
public class ProductBranchListDto : IAutoMap<TenantBranch, ProductBranchListDto>
{
    public Guid Id { get; set; }
    public string Name { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantBranch, ProductBranchListDto>();
    }
}