namespace Ewai.Eventis.App.Contracts.Models.Products.Enums;

public enum ScanProductNextStepEnum
{
    CreateTrainingProduct = 1,
    AddNewImages = 2,
    WaitForTrainingProcess = 3
}