﻿namespace Ewai.Eventis.App.Contracts.Models.Products.Inputs;

public class ProductMakeProhibitedInput
{
    public Guid[] ProductIds { get; set; }
    public bool IsProhibited { get; set; }
}