﻿using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.Products.Inputs;

public class ProductExportFileInput
{
    [Required] public Guid? TenantId { get; set; }
}