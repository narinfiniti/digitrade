﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Attributes;
using Ewai.Eventis.Domain.Entity.Products;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Products.Inputs;

public class ProductShoppingBagCreateOrUpdateInput
    : IAutoMap<TenantProduct, ProductShoppingBagCreateOrUpdateInput>
{
    [Required] public Guid? BranchId { get; set; }
    [MaxLength(200)] public string Name { get; set; }
    [Required, MaxLength(500)] public string Barcode { get; set; }
    [DecimalRange] public decimal UnitPrice { get; set; }
    [DecimalRange] public decimal Quantity { get; set; }
    public Guid? ImageId { get; set; }
}