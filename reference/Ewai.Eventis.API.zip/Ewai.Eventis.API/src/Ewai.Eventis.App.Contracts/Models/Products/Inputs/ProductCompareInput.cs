﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace Ewai.Eventis.App.Contracts.Models.Products.Inputs;

public class ProductCompareInput
{
    [Required] public IFormFile File { get; set; }
}