using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.Products;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Products.Inputs;

public class ProductAddToBranchInput
    : IAutoMap<TenantProduct, ProductAddToBranchInput>
{
    public Guid? BranchId { get; set; }
    [Required, MaxLength(500)] public string Barcode { get; set; }
    public string Name { get; set; }
    public string BoxCode { get; set; }
    public string Unit { get; set; }
    public decimal UnitCost { get; set; }
    public decimal UnitPrice { get; set; }
    public bool IsWeightBased { get; set; }
    public bool IsShoppingBag { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<ProductAddToBranchInput, TenantProduct>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }
}