﻿namespace Ewai.Eventis.App.Contracts.Models.Products.Inputs;

/// <summary>
/// ProductImportFileInput.
/// </summary>
public class ProductImagesImportInput
{
    public Guid? BranchId { get; set; }
}