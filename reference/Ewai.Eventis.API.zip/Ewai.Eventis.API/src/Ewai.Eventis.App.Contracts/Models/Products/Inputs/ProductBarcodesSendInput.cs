using System.Text.Json.Serialization;

namespace Ewai.Eventis.App.Contracts.Models.Products.Inputs;

/// <summary>
/// Product stock-level question.
/// </summary>
public class ProductBarcodesSendInput
{
    public ProductBarcodesSendItem[] Data { get; set; }
    public string SerialNumber { get; set; }
}

/// <summary>
/// ProductBarcodesSendItem.
/// </summary>
public class ProductBarcodesSendItem
{
    public string Sku { get; set; }
    [JsonPropertyName("item_area")]
    public decimal Area { get; set; }
}