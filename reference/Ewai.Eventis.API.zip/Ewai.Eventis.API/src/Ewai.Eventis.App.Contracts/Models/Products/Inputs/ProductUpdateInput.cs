using System.ComponentModel.DataAnnotations;
using Ewai.Common.Attributes;
using Ewai.Eventis.Domain.Entity.Products;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Products.Inputs;

public class ProductUpdateInput
    : IAutoMap<TenantProduct, ProductUpdateInput>
{
    public Guid? TenantId { get; set; }
    public Guid? CategoryId { get; set; }
    public Guid? SubCategoryId { get; set; }
    [MaxLength(200)] public string Name { get; set; }
    [Required, MaxLength(500)] public string Barcode { get; set; }
    [Required, MaxLength(500)] public string InternalBarcode { get; set; }
    public Guid? ImageId { get; set; }
    [MaxLength(10)] public string Unit { get; set; }
    public bool? IsWeightBased { get; set; }
    public bool? IsProhibited { get; set; }
    public bool? IsShoppingBag { get; set; }
    [Required, DecimalRange] public decimal? UnitCost { get; set; }
    [Required, DecimalRange] public decimal? UnitPrice { get; set; }
    [Required][DecimalRange] public decimal? Quantity { get; set; }
    [DecimalRange] public decimal? Vat { get; set; }
    [DecimalRange] public decimal? QtySold { get; set; }
    [DecimalRange] public decimal? QtyMissing { get; set; }
    [DecimalRange] public decimal? QtyDamaged { get; set; }
    [DecimalRange] public decimal? QtyRevoked { get; set; }
}