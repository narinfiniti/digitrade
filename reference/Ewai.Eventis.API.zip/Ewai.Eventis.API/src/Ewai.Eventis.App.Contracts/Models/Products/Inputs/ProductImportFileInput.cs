﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace Ewai.Eventis.App.Contracts.Models.Products.Inputs;

/// <summary>
/// ProductImportFileInput.
/// </summary>
public class ProductImportFileInput
{
    //[Required] public Guid? BranchId { get; set; }
    [Required] public IFormFile File { get; set; }
}