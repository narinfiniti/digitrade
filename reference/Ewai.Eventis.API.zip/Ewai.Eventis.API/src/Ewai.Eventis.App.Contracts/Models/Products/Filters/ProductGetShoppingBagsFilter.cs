﻿using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.Products.Filters;

/// <summary>
/// ProductGetShoppingBagsFilter.
/// </summary>
public class ProductGetShoppingBagsFilter : PageFilter
{
    public string MobileSerialNumber { get; set; }
}