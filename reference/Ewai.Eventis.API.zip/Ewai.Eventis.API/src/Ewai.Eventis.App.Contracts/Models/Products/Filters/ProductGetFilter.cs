﻿namespace Ewai.Eventis.App.Contracts.Models.Products.Filters;

public class ProductGetFilter
{
    public string Sku { get; set; }
    public Guid TenantId { get; set; }
}