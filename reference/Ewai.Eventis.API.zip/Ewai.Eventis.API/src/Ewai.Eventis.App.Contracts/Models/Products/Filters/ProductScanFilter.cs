﻿namespace Ewai.Eventis.App.Contracts.Models.Products.Filters;

public class ProductScanFilter
{
    public string Sku { get; set; }
}