﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.Products.Filters;

public class ProductQueryGetListFilter : PageFilter
{
    [Required] public Guid? TenantId { get; set; }
    public Guid? CategoryId { get; set; }
    public Guid? SubCategoryId { get; set; }
    [MaxLength(500)] public string Filter { get; set; }
    [MaxLength(200)] public string Name { get; set; }
    [MaxLength(500)] public string Barcode { get; set; }
    [MaxLength(500)] public string InternalBarcode { get; set; }

    public bool? IsProhibited { get; set; }
    public bool? IsShoppingBag { get; set; }
    public bool? IsWeightBased { get; set; }
}