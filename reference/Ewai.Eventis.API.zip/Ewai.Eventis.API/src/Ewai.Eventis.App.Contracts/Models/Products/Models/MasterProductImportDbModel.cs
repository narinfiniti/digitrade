﻿using AutoMapper;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Products.Models;

/// <summary>
/// MasterProductImportDbModel.
/// </summary>
public class MasterProductImportDbModel
    : IAutoMap<MasterProductImportDbModel, ProductForTenantImportDbModel>
        , IAutoMap<MasterProductImportDbModel, ProductForBranchImportDbModel>
{
    public Guid? Id { get; set; }
    public string CategoryName { get; set; }
    public string SubCategoryName { get; set; }
    public Guid? CategoryId { get; set; }
    public Guid? SubCategoryId { get; set; }
    public string Name { get; set; }
    public string Barcode { get; set; }
    public string InternalBarcode { get; set; }
    public string Unit { get; set; }
    public bool IsWeightBased { get; set; }
    public bool IsProhibited { get; set; }
    public bool IsShoppingBag { get; set; }
    public decimal? UnitCost { get; set; }
    public decimal? UnitPrice { get; set; }
    public decimal? Vat { get; set; }
    public Guid? ImageId { get; set; }
    public string Group { get; set; }
    public string Size { get; set; }
    public decimal? AverageArea { get; set; }
    public void CreateMap(Profile profile)
    {
        profile.CreateMap<MasterProductImportDbModel, ProductForTenantImportDbModel>();
    }
}