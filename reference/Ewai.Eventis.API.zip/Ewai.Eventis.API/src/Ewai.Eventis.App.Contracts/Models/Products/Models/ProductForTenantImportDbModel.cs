﻿using AutoMapper;

namespace Ewai.Eventis.App.Contracts.Models.Products.Models;

/// <summary>
/// TenantProductImportDbModel.
/// </summary>
public class ProductForTenantImportDbModel
{
    public Guid? Id { get; set; }
    public Guid TenantId { get; set; }
    public string CategoryName { get; set; }
    public string SubCategoryName { get; set; }
    public Guid? CategoryId { get; set; }
    public Guid? SubCategoryId { get; set; }
    public string Name { get; set; }
    public string Barcode { get; set; }
    public string InternalBarcode { get; set; }
    public string Unit { get; set; }
    public bool IsWeightBased { get; set; }
    public bool IsProhibited { get; set; }
    public bool IsShoppingBag { get; set; }
    public decimal? UnitCost { get; set; }
    public decimal? UnitPrice { get; set; }
    public decimal? Vat { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? QtySold { get; set; }
    public decimal? QtyMissing { get; set; }
    public decimal? QtyDamaged { get; set; }
    public decimal? QtyRevoked { get; set; }
    public Guid? ImageId { get; set; }
    public string Group { get; set; }
    public string Size { get; set; }
    public decimal? AverageArea { get; set; }


    public void CreateMap(Profile profile)
    {
    }
}