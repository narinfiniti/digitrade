﻿using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Common.Attributes;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Products.Models;

/// <summary>
/// ProductImportXlsxModel.
/// </summary>
public class ProductImportXlsxModel
    : IAutoMap<ProductForBranchImportDbModel, ProductImportXlsxModel>
        , IAutoMap<MasterProductImportDbModel, ProductImportXlsxModel>
{
    public Guid? Id { get; set; }
    public Guid? BranchId { get; set; }
    [MaxLength(200)] public string Name { get; set; }
    [MaxLength(500)] public string Barcode { get; set; }
    [DecimalRange] public decimal? UnitPrice { get; set; }
    [DecimalRange] public decimal? UnitCost { get; set; }
    [MaxLength(200)] public string CategoryName { get; set; }
    [MaxLength(200)] public string SubCategoryName { get; set; }
    //[Range(1, int.MaxValue)] public int? CategoryId { get; set; }
    //[Range(1, int.MaxValue)] public int? SubCategoryId { get; set; }
    public bool? IsWeightBased { get; set; }
    [MaxLength(10)] public string Unit { get; set; }
    [MaxLength(500)] public string InternalBarcode { get; set; }
    [DecimalRange] public decimal? Quantity { get; set; }
    public Guid? ImageId { get; set; }
    public string Group { get; set; }
    public string Size { get; set; }
    public decimal AverageArea { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<ProductImportXlsxModel, ProductForBranchImportDbModel>();
        profile.CreateMap<ProductImportXlsxModel, MasterProductImportDbModel>();
    }
}