﻿namespace Ewai.Eventis.App.Contracts.Models.Products.Models;

public class ProductsToExportModel
{
    public string Barcode { get; set; }
}