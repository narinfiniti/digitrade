namespace Ewai.Eventis.App.Contracts.Models.Products.Models;

public class WeightedProductModel
{
    public decimal Weight { get; init; }
    public decimal TotalPrice { get; init; }

    public void Deconstruct(out decimal quantity, out decimal total)
    {
        quantity = Weight;
        total = TotalPrice;
    }
}