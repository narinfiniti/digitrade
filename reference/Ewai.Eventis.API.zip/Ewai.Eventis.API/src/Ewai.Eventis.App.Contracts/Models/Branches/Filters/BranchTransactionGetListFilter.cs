﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.Branches.Filters;

/// <summary>
/// BranchTransactionGetListFilter.
/// </summary>
public class BranchTransactionGetListFilter : PageFilter
{
    [MaxLength(200)] public string Filter { get; set; }
    [Required] public Guid BranchId { get; set; }
    public DateTime? FromCreationTime { get; set; }
    public DateTime? ToCreationTime { get; set; }
}