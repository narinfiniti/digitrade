﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.Branches.Filters;

/// <summary>
/// BranchProductGetListFilter.
/// </summary>
public class BranchProductGetListFilter : PageFilter
{
    [MaxLength(200)] public string Filter { get; set; }
    [Required] public Guid BranchId { get; set; }
}