﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.Branches.Filters;

/// <summary>
/// BranchUserGetListFilter.
/// </summary>
public class BranchUserGetListFilter : PageFilter
{
    [MaxLength(200)] public string Filter { get; set; }
    [Required] public Guid BranchId { get; set; }
}