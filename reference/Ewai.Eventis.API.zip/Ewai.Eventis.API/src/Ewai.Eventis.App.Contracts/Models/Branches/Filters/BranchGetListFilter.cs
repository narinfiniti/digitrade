﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.Branches.Filters;

/// <summary>
/// BranchGetListFilter.
/// </summary>
public class BranchGetListFilter : PageFilter
{
    [MaxLength(200)] public string Name { get; set; }
    [MaxLength(1000)] public string Address { get; set; }
    [MaxLength(100)] public string Trn { get; set; }
    [MaxLength(200)] public string TenantName { get; set; }
    [MaxLength(100)] public string IntegrationSystemName { get; set; }
    public Guid? TenantId { get; set; }
    public Guid? IntegrationSystemId { get; set; }
}