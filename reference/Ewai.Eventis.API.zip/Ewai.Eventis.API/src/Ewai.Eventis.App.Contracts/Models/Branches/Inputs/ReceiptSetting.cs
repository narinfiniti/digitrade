﻿namespace Ewai.Eventis.App.Contracts.Models.Branches.Inputs;

public class ReceiptSetting
{
    public string HeaderLogo { get; set; }
    public string HeaderContentShopName { get; set; }
    public string HeaderContentAddress { get; set; }
    public string HeaderContentTrn { get; set; }
    public string BodyContentHeader { get; set; }
    public string BodyContent { get; set; }
    public string BodySummary { get; set; }
    public string BodySummarySubTotal { get; set; }
    public string BodySummaryVat { get; set; }
    public string BodySummaryDiscount { get; set; }
    public string BodySummaryTotal { get; set; }
    public string FooterContent { get; set; }
    public string FooterContentReceiptNumber { get; set; }
    public string FooterContentInvoiceNumber { get; set; }
    public string FooterContentVatMsg { get; set; }
    public string FooterContentShopRewards { get; set; }
    public string FooterContentQrTransaction { get; set; }
    public string FooterContentCashier { get; set; }
    public string FooterContentDate { get; set; }
}