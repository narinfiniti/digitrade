﻿using Ewai.Eventis.App.Contracts.Models.Branches.Models;

namespace Ewai.Eventis.App.Contracts.Models.Branches.Inputs;

public class BranchSettingInput
{
    public bool? IsPaymoneyEnabled { get; set; }
    public bool? IsWheelEnabled { get; set; }
    public string Currency { get; set; }
    public ReceiptSetting ReceiptSetting { get; set; }
    public BranchSettingWeightSystemModel WeightSystem { get; set; }
}