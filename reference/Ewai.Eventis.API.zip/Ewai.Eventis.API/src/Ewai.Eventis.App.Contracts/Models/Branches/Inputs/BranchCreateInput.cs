using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.App.Contracts._ValueResolvers;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Branches.Inputs;

/// <summary>
/// ShopCreateOrUpdateInput.
/// </summary>
public class BranchCreateInput : IAutoMap<TenantBranch, BranchCreateInput>
{
    [Required, MaxLength(50)] public string Name { get; set; }
    [Required, MaxLength(100), EmailAddress]
    [RegularExpression(@"^[a-zA-Z0-9][-a-zA-Z0-9._]+@([-a-zA-Z0-9]+\.)+[a-zA-Z]{2,5}$", ErrorMessage = "Invalid Email.")]
    public string Email { get; set; }
    [Required, MaxLength(1000)] public string Address { get; set; }
    [Required, MaxLength(100)] public string Trn { get; set; }
    [Required, MaxLength(200)] public string CompanyId { get; set; }
    [Required] public Guid? TenantId { get; set; }
    public BranchSettingInput BranchSetting { get; set; }
    public Guid? LogoFileId { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<BranchCreateInput, TenantBranch>()
            .ForMember(to => to.LogoId, c => c.MapFrom(from => from.LogoFileId))
            .ForMember(to => to.Setting, c => c.MapFrom<ShopSettingValueResolver>());
    }
}