﻿namespace Ewai.Eventis.App.Contracts.Models.Branches.Models;

public class BranchSettingModel
{
    public string Currency { get; set; }
    public BranchSettingWeightSystemModel WeightSystem { get; set; }
}