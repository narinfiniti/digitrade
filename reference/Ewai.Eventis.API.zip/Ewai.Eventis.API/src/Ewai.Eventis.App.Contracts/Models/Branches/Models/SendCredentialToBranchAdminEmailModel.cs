﻿namespace Ewai.Eventis.App.Contracts.Models.Branches.Models;

public class SendCredentialToBranchAdminEmailModel
{
    public string BranchName { get; set; }
    public string Message { get; set; }
    public Stream Data { get; set; }
    public string EmailReceivers { get; set; }
}