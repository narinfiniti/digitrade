﻿using Ewai.Eventis.Domain.Entity.Tenants;

namespace Ewai.Eventis.App.Contracts.Models.Branches.Models;

public class SendCredentialToBranchAdminModel
{
    public TenantBranch Branch { get; set; }
    public string BranchAdminEmail { get; set; }
    public string TenantAdminEmail { get; set; }
    public string UserName { get; set; }
    public string Message { get; set; }
    public string LogoImgUrl { get; set; }
    public string Password { get; set; }
}