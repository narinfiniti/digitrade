﻿using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.Eventis.Domain.Entity.Users;

namespace Ewai.Eventis.App.Contracts.Models.Branches.Models;

public class BranchWithUsersModel : TenantBranch
{
    public List<User> Users { get; set; } = [];
}