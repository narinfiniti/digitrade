﻿namespace Ewai.Eventis.App.Contracts.Models.Branches.Models;

public class BranchSettingWeightSystemModel
{
    public bool? IsEnabled { get; set; }
    public string ServiceName { get; set; }
}