using System.Text.Json.Nodes;
using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.BlobFiles.Extensions;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;
using Ewai.SharedKernel.Models.Configs;

namespace Ewai.Eventis.App.Contracts.Models.Branches.Dto;

/// <summary>
/// BranchDto.
/// </summary>
public class BranchDto : IAutoMap<TenantBranch, BranchDto>
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string Address { get; set; }
    public string Trn { get; set; }
    public string CompanyId { get; set; }
    public bool IsActive { get; set; }
    public Guid TenantId { get; set; }
    public JsonNode BranchSetting { get; set; }
    public string Email { get; set; }
    public string LogoUrl { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantBranch, BranchDto>()
            .ForMember(dest => dest.LogoUrl, opt => opt.MapFrom<ValueResolver>());
    }

    public class ValueResolver(
        DefaultAwsS3Storage s3Storage,
        IUserProfileService userProfileService)
        : IValueResolver<TenantBranch, BranchDto, string>
    {
        public string Resolve(
            TenantBranch source, BranchDto destination,
            string destMember, ResolutionContext context)
        {
            if (source.Logo is null) return string.Empty;
            var tenantId = userProfileService.GetTenantId();
            return s3Storage.GetPreSignedUrl(source.Logo.ToTenantFileName(tenantId));
        }
    }
}