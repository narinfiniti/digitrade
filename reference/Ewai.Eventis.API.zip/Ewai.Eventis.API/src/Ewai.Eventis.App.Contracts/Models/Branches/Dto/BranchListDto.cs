﻿using System.Text.Json.Nodes;
using AutoMapper;
using Ewai.Common.Extensions;
using Ewai.Eventis.App.Contracts.Models.Branches.Models;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Branches.Dto;

/// <summary>
/// BranchListDto.
/// </summary>
public class BranchListDto
    : IAutoMap<TenantBranch, BranchListDto>
        , IAutoMap<BranchWithUsersModel, BranchListDto>
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string Address { get; set; }
    public string Trn { get; set; }
    public string CompanyId { get; set; }
    public bool IsActive { get; set; }
    public double? Longitude { get; set; }
    public double? Latitude { get; set; }
    public Guid IntegrationSystemId { get; set; }
    public string IntegrationSystemName { get; set; }
    public Guid TenantId { get; set; }
    public string TenantName { get; set; }
    public JsonNode IntegrationConfig { get; set; }
    public JsonNode ShopSetting { get; set; }
    public string Email { get; set; }
    public string LogoUrl { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantBranch, BranchListDto>()
            .ForMember(dest => dest.TenantName, opt => opt.MapFrom(src => src.Tenant.Name))
            //.ForMember(dest => dest.LogoUrl, opt => opt.MapFrom<UrlValueResolver>())
            ;

        profile.CreateMap<BranchWithUsersModel, BranchListDto>()
            .ForMember(dest => dest.TenantName, opt => opt.MapFrom(src => src.Tenant.Name))
            .ForMember(dest => dest.Email, opt =>
                opt.MapFrom(src => src.Users.FirstOrDefault(e => e.UserName.IsUnderscored(src.Name)).Email))
            //.ForMember(dest => dest.LogoUrl, opt => opt.MapFrom<UrlValueResolver>())
            ;
    }
}