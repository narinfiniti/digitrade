﻿using AutoMapper;
using Ewai.Common.Extensions;
using Ewai.Eventis.App.Contracts.Models.Branches.Models;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Branches.Dto;

public class BranchGetDto : IAutoMap<TenantBranch, BranchGetDto>
{
    public Guid? Id { get; set; }
    public string LogoUrl { get; set; }
    public string Segmentation { get; set; }
    public string Currency { get; set; }
    public bool? IsWheelEnabled { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantBranch, BranchGetDto>()
            .ForMember(dest => dest.Segmentation, opt => opt.MapFrom(src => src.Tenant.Segmentation))

            .ForMember(dest => dest.Currency, opt =>
                opt.MapFrom(src => src.Setting.As<BranchSettingModel>().Currency));
    }
}