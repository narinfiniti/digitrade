﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Products;
using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Branches.Dto;

/// <summary>
/// BranchUserListDto.
/// </summary>
public class BranchUserListDto : IAutoMap<TenantProduct, BranchUserListDto>
{
    public Guid Id { get; set; }
    public string UserName { get; set; }
    public string Email { get; set; }
    public string PhoneNumber { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public Guid? TenantId { get; set; }
    //public List<RoleListDto> Roles { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<User, BranchUserListDto>();
        //.ForMember(to => to.Roles, c => c.MapFrom(from => from.UserRoles.Select(e => e.Role)));
    }
}