using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TextMessages.Inputs;

public class TextMessageUpdateInput : IAutoMap<TextMessage, TextMessageUpdateInput>
{
    [Range(100, 198), EnumDataType(typeof(LanguageCodeEnum))]
    public LanguageCodeEnum Language { get; set; }

    [Required, MaxLength(100)] public string Key { get; set; }
    [Required, MaxLength(4000)] public string Value { get; set; }
}