﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Enums;

namespace Ewai.Eventis.App.Contracts.Models.TextMessages.Filters;

/// <summary>
/// TextMessageGetListFilter.
/// </summary>
public class TextMessageGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    [Required, Range(100, 198), EnumDataType(typeof(LanguageCodeEnum))]
    public LanguageCodeEnum? Language { get; set; }

    [MaxLength(100)] public string Key { get; set; }
    [MaxLength(4000)] public string Value { get; set; }
}