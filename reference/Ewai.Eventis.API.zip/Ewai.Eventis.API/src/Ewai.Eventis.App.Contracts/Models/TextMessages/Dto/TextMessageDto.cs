using AutoMapper;
using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TextMessages.Dto;

/// <summary>
/// TextMessageDto.
/// </summary>
public class TextMessageDto : IAutoMap<TextMessage, TextMessageDto>
{
    public Guid Id { get; set; }
    public LanguageCodeEnum Language { get; set; }
    public string LanguageName { get; set; }
    public string Key { get; set; }
    public string Value { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TextMessage, TextMessageDto>()
            .ForMember(dest => dest.Language, opt => opt.MapFrom(src => src.Language))
            .ForMember(dest => dest.LanguageName, opt => opt.MapFrom(src => src.Language));
    }
}