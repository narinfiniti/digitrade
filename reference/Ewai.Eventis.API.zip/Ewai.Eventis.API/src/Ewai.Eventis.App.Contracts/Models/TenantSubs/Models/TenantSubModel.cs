namespace Ewai.Eventis.App.Contracts.Models.TenantSubs.Models;

public class TenantSubModel
{
    public decimal Vat { get; set; }
}