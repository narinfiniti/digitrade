using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.TenantSubs.Inputs
{
    public class TenantSubAddCreditsInput
    {
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "AddedCredits must be a strictly positive integer.")]
        public int AddedCredits { get; set; }
    }
}