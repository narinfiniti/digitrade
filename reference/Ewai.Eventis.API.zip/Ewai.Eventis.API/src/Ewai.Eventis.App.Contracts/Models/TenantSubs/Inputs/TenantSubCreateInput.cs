using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.Platform;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenantSubs.Inputs;

/// <summary>
/// TenantSubCreateInput.
/// </summary>
public class TenantSubCreateInput
    : IAutoMap<TenantSubscription, TenantSubCreateInput>
{
    [Required] public Guid? TenantId { get; set; }
    [Required] public Guid? SubscriptionId { get; set; }
    [Required, EnumDataType(typeof(PaymentFrequencyEnum))]
    public PaymentFrequencyEnum? PaymentFrequency { get; set; }
}