using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.Invoices;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenantSubs.Inputs;

public class TenantSubPaymentInput
    : IAutoMap<Invoice, TenantSubPaymentInput>
{
    public Guid? TenantId { get; set; }
    //[Required] public Guid? ClientId { get; set; }

    [EnumDataType(typeof(PaymentTypeEnum))] public PaymentTypeEnum PaymentTypeId { get; set; }
    //[EnumDataType(typeof(PaymentFrequencyEnum))] public PaymentFrequencyEnum PaymentFrequency { get; set; }

    //[Range(0, 10_000_000.0)] public decimal? ServiceFees { get; set; }
    //[Required,Range(0, 10_000_000.0)] public  decimal? ReceivedAmount { get; set; }
    //[Range(0, 10_000_000)]public int? AuthorizationCode { get; set; }
    //[MaxLength(50)] public string ReceiptNumber { get; set; }

    //public Guid? RefInvoiceId { get; set; }
    // For Subscription Invoice no Line-Items.
    //public List<InvoiceItemCreateInput> InvoiceItems { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantSubPaymentInput, Invoice>()
            .ForMember(to => to.PaymentTypeId, c => c.MapFrom(from => from.PaymentTypeId))
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }
}