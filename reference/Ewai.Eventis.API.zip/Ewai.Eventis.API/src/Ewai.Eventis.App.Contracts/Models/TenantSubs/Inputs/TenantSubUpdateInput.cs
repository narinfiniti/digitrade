using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.Platform;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenantSubs.Inputs;

/// <summary>
/// TenantSubUpdateInput.
/// </summary>
public class TenantSubUpdateInput
    : IAutoMap<TenantSubscription, TenantSubUpdateInput>
{
    [Required] public Guid? TenantId { get; set; }
    public Guid? SubscriptionId { get; set; }
    [EnumDataType(typeof(PaymentFrequencyEnum))]
    public PaymentFrequencyEnum? PaymentFrequency { get; set; }
    
    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantSubUpdateInput, TenantSubscription>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
        profile.CreateMap<PaymentFrequencyEnum?, PaymentFrequencyEnum>().ConvertUsing((src, dest) => src ?? dest);
    }
}