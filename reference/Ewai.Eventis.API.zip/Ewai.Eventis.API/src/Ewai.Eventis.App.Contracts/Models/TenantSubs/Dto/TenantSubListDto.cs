﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Platform;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenantSubs.Dto
{
    public class TenantSubListDto
        : IAutoMap<TenantSubscription, TenantSubListDto>
    {
        public Guid Id { get; set; }
        public Guid TenantId { get; set; }
        public Guid SubscriptionId { get; set; }
        public bool IsPaid { get; set; }
        public bool IsActive { get; set; }
        public PaymentFrequencyEnum PaymentFrequency { get; set; }
        public string PaymentFrequencyName { get; set; }
        public PlatformSubscriptionTypeEnum Type { get; set; }
        public string TypeName { get; set; }
        public DateTime DateStarted { get; set; }
        public DateTime? DateEnded { get; set; }
        public DateTime? DateLastPayment { get; set; }
        public DateTime? DatePaymentDue { get; set; }
        public decimal? TotalPaymentDue { get; set; }

        // Keep the two counts + the remaining
        public long InProgressVenueCount { get; set; }
        public long FinishedVenueCount { get; set; }
        public int RemainingParties { get; set; }
        public decimal AddedCredits { get; set; }

        public void CreateMap(Profile profile)
        {
            profile.CreateMap<TenantSubscription, TenantSubListDto>()
                .ForMember(dto => dto.IsPaid, opt => opt.MapFrom(src => src.DateLastPayment != null &&
                                                                        src.DatePaymentDue == null &&
                                                                        src.TotalPaymentDue == null))
                .ForMember(dto => dto.Type, opt => opt.MapFrom(src => src.Subscription.Type))
                .ForMember(dto => dto.TypeName, opt => opt.MapFrom(src => src.Subscription.Type))
                .ForMember(dto => dto.InProgressVenueCount, opt => opt.Ignore())
                .ForMember(dto => dto.FinishedVenueCount, opt => opt.Ignore())
                .ForMember(dto => dto.RemainingParties, opt => opt.Ignore())
                .ForMember(to => to.PaymentFrequencyName, c => c.MapFrom(from => from.PaymentFrequency));
        }
    }
}