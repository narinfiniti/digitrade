﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Invoices;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenantSubs.Dto;

/// <summary>
/// TenantSubPaymentDto.
/// </summary>
public class TenantSubPaymentDto : IAutoMap<Invoice, TenantSubPaymentDto>
{
    public Guid Id { get; set; }
    // public Guid BranchId { get; set; }
    // public List<TenantSubPaymentImageDto> FeedImageUrls { get; set; }
    public string TenantName { get; set; }
    public PaymentTypeEnum PaymentTypeId { get; set; } //ok
    public string PaymentType { get; set; }
    public string Number { get; set; }
    public string Status { get; set; }
    public DateTime Date { get; set; }
    public decimal Discount { get; set; } //ok
    public decimal SubTotal { get; set; } //ok
    public decimal Vat { get; set; } //ok
    public decimal Total { get; set; } //ok
    public string ReceiptNumber { get; set; }
    public string ApprovalCode { get; set; }
    public Guid? PaymentTerminalId { get; set; }
    //public List<TenantSubPaymentItemDto> Items { get; set; }
    public decimal AddedCredits { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<Invoice, TenantSubPaymentDto>()
            // .ForMember(to => to.FeedImageUrls, c => c.MapFrom(from => from.TenantSubPaymentImages))
            .ForMember(to => to.TenantName, c => c.MapFrom(from => from.Tenant.Name))
            .ForMember(to => to.Date, c => c.MapFrom(from => from.DatePaid))
            .ForMember(to => to.Status, c => c.MapFrom(from => from.StatusId.ToString()))
            .ForMember(to => to.Number, c => c.MapFrom(from => from.Number))
            .ForMember(to => to.PaymentType, c => c.MapFrom(from => from.PaymentTypeId.ToString()))
            //.ForMember(to => to.Items, c => c.MapFrom(from => from.TenantSubPaymentItems))
            ;
    }
}