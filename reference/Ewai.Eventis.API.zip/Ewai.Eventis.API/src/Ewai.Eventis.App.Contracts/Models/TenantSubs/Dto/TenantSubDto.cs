using AutoMapper;
using Ewai.Eventis.Domain.Entity.Platform;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenantSubs.Dto;

/// <summary>
/// TenantSubDto.
/// </summary>
public class TenantSubDto
    : IAutoMap<TenantSubscription, TenantSubDto>
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid SubscriptionId { get; set; }
    public bool IsPaid { get; set; }
    public bool IsActive { get; set; }
    public PaymentFrequencyEnum PaymentFrequency { get; set; }
    public string PaymentFrequencyName { get; set; }
    public PlatformSubscriptionTypeEnum Type { get; set; }
    public string TypeName { get; set; }
    public DateTime DateStarted { get; set; }
    public DateTime? DateEnded { get; set; }
    public DateTime? DateLastPayment { get; set; }
    public DateTime? DatePaymentDue { get; set; }
    public decimal? TotalPaymentDue { get; set; }
    public decimal AddedCredits { get; set; }
    
    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantSubscription, TenantSubDto>()
            .ForMember(to => to.IsPaid, c => c.MapFrom(from => from.DateLastPayment != null &&
                                                               from.DatePaymentDue == null &&
                                                               from.TotalPaymentDue == null))
            .ForMember(to => to.Type, c => c.MapFrom(from => from.Subscription.Type))
            .ForMember(to => to.TypeName, c => c.MapFrom(from => from.Subscription.Type))
            .ForMember(to => to.PaymentFrequencyName, c => c.MapFrom(from => from.PaymentFrequency));
    }
}