﻿using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.VenueMapPositions.Dto;
using Ewai.Eventis.App.Contracts.Models.Venues.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueZones.Dto;
using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.VenueDesks.Dto;

/// <summary>
/// VenueDeskListDto.
/// </summary>
public class VenueDeskListDto : IAutoMap<VenueDesk, VenueDeskListDto>
{
    public Guid Id { get; set; }

    public Guid VenueId { get; set; }
    public string No { get; set; }
    public short CapacityOfPeople { get; set; }
    public short SizeDiameter { get; set; }
    public decimal MinSpend { get; set; }
    public string ColorCode { get; set; }
    public Guid? ZoneId { get; set; }
    public Guid? EventUserId { get; set; }
    public string QrCode { get; set; }
    public VenueDeskTypeEnum Type { get; set; }
    public VenueMapPositionDto Position { get; set; }
    public VenueZoneDto Zone { get; set; }
    public VenueDto Venue { get; set; }
    //public HashSet<ClientBookingDto> Bookings { get; set; }
    //public HashSet<EventUserDto> Users { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<VenueDesk, VenueDeskListDto>()
            .ForMember(dest => dest.QrCode, opt => opt.MapFrom(src => Convert.FromBase64String(src.QrCode)))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Zone, opt => opt.MapFrom(src => src.Zone))
            .ForMember(dest => dest.Venue, opt => opt.MapFrom(src => src.Venue));
        // .ForMember(dest => dest.Bookings, opt => opt.MapFrom(src => src.Bookings))
        // .ForMember(dest => dest.Users, opt => opt.MapFrom(src => src.Users));
    }
}