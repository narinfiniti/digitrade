namespace Ewai.Eventis.App.Contracts.Models.VenueDesks.Models;

public class VenueDeskModel
{
    
}