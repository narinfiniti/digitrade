using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;
using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.VenueDesks.Inputs;

/// <summary>
/// VenueDeskCreateInput.
/// </summary>
public class VenueDeskCreateInput : IAutoMap<VenueDesk, VenueDeskCreateInput>
{
    public Guid VenueId { get; set; }
    [Required] public Guid MapId { get; set; }
    public string No { get; set; }
    public VenueDeskStatusEnum Status { get; set; }
    public VenueDeskTypeEnum Type { get; set; }
    [Required, MaxLength(20)] public string ColorCode { get; set; }
    public short CapacityOfPeople { get; set; }
    public short SizeDiameter { get; set; }
    public decimal MinSpend { get; set; }
    public Guid? ZoneId { get; set; }
    public string QrCode { get; set; }
    public Guid? PositionId { get; set; }
}