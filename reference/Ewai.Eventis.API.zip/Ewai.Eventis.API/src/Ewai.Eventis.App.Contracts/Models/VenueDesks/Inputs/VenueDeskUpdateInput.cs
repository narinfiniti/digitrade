using AutoMapper;
using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.VenueDesks.Inputs;

/// <summary>
/// VenueDeskUpdateInput.
/// </summary>
public class VenueDeskUpdateInput : IAutoMap<VenueDesk, VenueDeskUpdateInput>
{
    public string No { get; set; }
    public VenueDeskStatusEnum? Status { get; set; }
    public VenueDeskTypeEnum? Type { get; set; }
    public short? CapacityOfPeople { get; set; }
    public short? SizeDiameter { get; set; }
    public decimal? MinSpend { get; set; }
    public string ColorCode { get; set; }
    public Guid? ZoneId { get; set; }
    public string QrCode { get; set; }
    public Guid? PositionId { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<VenueDeskUpdateInput, VenueDesk>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
        profile.CreateMap<VenueDeskStatusEnum?, VenueDeskStatusEnum>().ConvertUsing((src, dest) => src ?? dest);
        profile.CreateMap<VenueDeskTypeEnum?, VenueDeskTypeEnum>().ConvertUsing((src, dest) => src ?? dest);
    }
}