using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;
using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.VenueDesks.Inputs;

/// <summary>
/// VenueDeskAssignWorkerInput.
/// </summary>
public class VenueDeskAssignWorkerInput : IAutoMap<VenueDesk, VenueDeskAssignWorkerInput>
{
    [Required] public Guid? EventUser { get; set; }
    [Required] public Guid? DeskId { get; set; }

    // public void CreateMap(Profile profile)
    // {
    //     profile.CreateMap<VenueDeskAssignWorkerInput, VenueDesk>()
    //         .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    // }
}