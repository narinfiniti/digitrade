﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Enums;

namespace Ewai.Eventis.App.Contracts.Models.VenueDesks.Filters;

/// <summary>
/// VenueDeskGetListFilter.
/// </summary>
public class VenueDeskGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    [EnumDataType(typeof(VenueDeskStatusEnum))]
    public VenueDeskStatusEnum? Status { get; set; }
    [EnumDataType(typeof(VenueDeskTypeEnum))]
    public VenueDeskTypeEnum? Type { get; set; }
    public Guid? VenueId { get; set; }
    public Guid? ZoneId { get; set; }
}