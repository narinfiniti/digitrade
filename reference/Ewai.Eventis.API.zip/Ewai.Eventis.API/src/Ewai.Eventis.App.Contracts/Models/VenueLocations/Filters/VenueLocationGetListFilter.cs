﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.VenueLocations.Filters;

/// <summary>
/// VenueLocationGetListFilter.
/// </summary>
public class VenueLocationGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    public Guid? TenantId { get; set; }
}