using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;
using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Enums;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Entity.BlobFiles;

namespace Ewai.Eventis.App.Contracts.Models.VenueLocations.Inputs;

/// <summary>
/// VenueLocationCreateInput.
/// </summary>
public class VenueLocationCreateInput : IAutoMap<VenueLocation, VenueLocationCreateInput>
{
    // public Guid VenueId { get; set; }
    public Guid? TenantId { get; set; }
    public string Name { get; set; }
    public VenueLocationTypeEnum Type { get; set; }
    public string Address { get; set; }
    public short CapacityOfPeople { get; set; }
    public short CapacityOfDesks { get; set; }
    public float SizeSquareMeters { get; set; }
    public RangeOf<TimeSpan> TimeRange { get; set; }
    [Range(-180, 180)] public double? Longitude { get; set; }
    [Range(-90, 90)] public double? Latitude { get; set; }
    public Guid? ImageId { get; set; }

    public BlobFile Image { get; set; }
    // public HashSet<Venue> Venues { get; set; } = [];
}