using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;
using Ewai.Eventis.Domain.Enums;
using Ewai.Common.Models;


namespace Ewai.Eventis.App.Contracts.Models.VenueLocations.Dto;

/// <summary>
/// VenueLocationDto.
/// </summary>
public class VenueLocationDto : IAutoMap<VenueLocation, VenueLocationDto>
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Name { get; set; }
    public VenueLocationTypeEnum Type { get; set; }
    public string Address { get; set; }
    public short CapacityOfPeople { get; set; }
    public short CapacityOfDesks { get; set; }
    public float SizeSquareMeters { get; set; }
    public RangeOf<TimeSpan> TimeRange { get; set; }
    public double? Longitude { get; set; }
    public double? Latitude { get; set; }

}