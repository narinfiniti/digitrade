namespace Ewai.Eventis.App.Contracts.Models.VenueLocations.Models;

public class VenueLocationModel
{
    
}