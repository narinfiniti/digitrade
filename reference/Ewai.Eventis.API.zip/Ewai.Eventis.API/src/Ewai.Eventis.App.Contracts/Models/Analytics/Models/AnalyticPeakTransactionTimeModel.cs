﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticPeakTransactionTimeModel
{
    public long MaxTransactionCount { get; set; }
    public DateTime PeakTime { get; set; }
    public Guid? ShopId { get; set; }
    public string ShopName { get; set; }
}