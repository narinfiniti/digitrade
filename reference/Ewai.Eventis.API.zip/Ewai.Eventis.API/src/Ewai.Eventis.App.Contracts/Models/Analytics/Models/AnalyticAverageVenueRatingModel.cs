﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticAverageVenueRatingModel
{
    public double GoodRating { get; set; }
    public double BadRating { get; set; }
    public double NormalRating { get; set; }
    public Guid ShopId { get; set; }
    public string ShopName { get; set; }
}