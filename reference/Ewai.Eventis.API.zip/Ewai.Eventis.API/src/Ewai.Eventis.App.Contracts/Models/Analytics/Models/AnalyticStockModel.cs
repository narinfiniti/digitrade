namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticStockModel
{
    public Guid MenuSubSectionProductId { get; set; }
    public Guid ProductId { get; set; }
    public string ProductName { get; set; }
    public string ProductBarcode { get; set; }
    public decimal StockInitial { get; set; }
    public decimal StockUsed { get; set; }
    public decimal StockLeft { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal UnitCost { get; set; }
    public Guid? VenueId { get; set; }
    public string VenueName { get; set; }
    public Guid? SubSectionId { get; set; }
    public string SubSectionName { get; set; }
}