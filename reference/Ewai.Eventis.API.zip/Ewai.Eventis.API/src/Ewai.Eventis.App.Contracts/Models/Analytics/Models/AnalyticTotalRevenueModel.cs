﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticTotalRevenueModel
{
    public decimal TotalRevenue { get; set; }
    public decimal TotalPrePayment { get; set; }
    public decimal TotalCash { get; set; }
    public decimal TotalCreditCard { get; set; }
    public decimal TotalTips { get; set; }
    public decimal TotalOverpaid { get; set; }
    public decimal TotalDiscount { get; set; }
}