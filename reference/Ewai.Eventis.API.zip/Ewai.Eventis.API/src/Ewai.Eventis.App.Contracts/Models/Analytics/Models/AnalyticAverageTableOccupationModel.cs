namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticAverageTableOccupationModel
{
    public string Duration { get; set; }
}