namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticProductsSoldModel
{
    public string ProductName { get; set; }
    public string ProductBarcode { get; set; }
    public decimal UnitPrice { get; set; }
    public int QuantitySold { get; set; }
    public decimal Total { get; set; }
    public Guid? VenueId { get; set; }
    public string VenueName { get; set; }
}