﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticAverageClientSpendModel
{
    public long NumberOfItems { get; set; }
    public decimal AverageBasketSize { get; set; }
    public decimal AverageBasketValue { get; set; }
    public Guid? ShopId { get; set; }
    public string ShopName { get; set; }
}