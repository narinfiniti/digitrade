﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticAverageRevenueModel
{
    public decimal AverageRevenue { get; set; }
    // public decimal AverageRevenue { get; set; }
    // public Guid? VenueId { get; set; }
    // public string VenueName { get; set; }
    // public string EventName { get; set; }
}