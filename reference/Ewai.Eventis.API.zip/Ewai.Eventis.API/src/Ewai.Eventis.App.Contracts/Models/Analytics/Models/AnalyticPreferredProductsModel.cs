﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticPreferredProductsModel
{
    public Guid? VenueId { get; set; }
    public string VenueName { get; set; }
    public string ProductName { get; set; }
    public string Barcode { get; set; }
    public decimal UnitPrice { get; set; }
    public long Quantity { get; set; }
}