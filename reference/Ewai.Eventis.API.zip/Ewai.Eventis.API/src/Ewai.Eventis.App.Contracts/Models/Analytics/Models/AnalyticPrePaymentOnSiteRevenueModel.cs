﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticPrePaymentOnSiteRevenueModel
{
    public decimal PrePaymentRevenue { get; set; }
    public decimal OnSiteRevenue { get; set; }
}