﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticAbandonedTransactionModel
{
    public long TotalCount { get; set; }
    public Guid? ShopId { get; set; }
    public string ShopName { get; set; }
}