namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticRevenuePerDeskModel
{
    public Guid DeskId { get; set; }
    public string DeskNo { get; set; }
    public decimal TotalSpend { get; set; }
    public decimal PrePayment { get; set; }
    public decimal Tips { get; set; }
    public decimal Discount { get; set; }
    public decimal Total { get; set; }
    public int InvoiceCount { get; set; }
    public Guid? VenueId { get; set; }
    public string VenueName { get; set; }
}