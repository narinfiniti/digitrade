﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticCustomerFeedbackModel
{
    public double GoodRating { get; set; }
    public double BadRating { get; set; }
    public double NormalRating { get; set; }
}