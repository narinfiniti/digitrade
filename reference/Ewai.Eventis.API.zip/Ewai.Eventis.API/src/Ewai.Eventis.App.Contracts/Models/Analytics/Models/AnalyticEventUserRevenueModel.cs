namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticEventUserRevenueModel
{
    public Guid EventUserId { get; set; }
    public Guid UserId { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Email { get; set; }
    public decimal TotalRevenue { get; set; }
    public int InvoiceCount { get; set; }
    public string TablesServed { get; set; } // Comma-separated list of desk numbers
    public Guid? EventId { get; set; }
    public string EventName { get; set; }
    public Guid? VenueId { get; set; }
    public string VenueName { get; set; }
}