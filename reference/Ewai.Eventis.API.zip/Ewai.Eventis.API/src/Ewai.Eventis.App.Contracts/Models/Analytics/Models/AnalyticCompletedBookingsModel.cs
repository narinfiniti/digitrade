﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Models;

public class AnalyticCompletedBookingsModel
{
    public long Count { get; set; }
}