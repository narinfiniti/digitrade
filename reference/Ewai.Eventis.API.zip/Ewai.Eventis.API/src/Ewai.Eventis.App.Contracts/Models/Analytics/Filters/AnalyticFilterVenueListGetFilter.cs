﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Enums;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Filters;

/// <summary>
/// AnalyticFilterVenueListGetFilter
/// </summary>
public class AnalyticFilterVenueListGetFilter : PageFilter
{
    public Guid? TenantId { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
    [MaxLength(100)] public string TenantName { get; set; }
    [MaxLength(100)] public string Filter { get; set; }
    [MaxLength(200)] public string Name { get; set; }
    [EnumDataType(typeof(VenueStatusEnum))] public VenueStatusEnum? Status { get; set; }
    [MaxLength(100)] public string EventName { get; set; }
    [MaxLength(100)] public string LocationName { get; set; }

    public Guid? EventId { get; set; }
    public Guid? LocationId { get; set; }
    public bool? IsExternal { get; set; }
}