﻿using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Filters;

public class AnalyticPreferredProductsGetFilter : PageFilter
{
    public string Filter { get; set; }
    public Guid[] EventIds { get; set; }
    public Guid[] VenueIds { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
}