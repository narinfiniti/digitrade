﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Enums;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Filters;

public class AnalyticExportGetFilter: PageFilter
{
    public Guid[] ShopIds { get; set; }
    [Required] public DateTime FromDate { get; set; }
    [Required] public DateTime ToDate { get; set; }
    [EnumDataType(typeof(ExportTypeEnum))] public ExportTypeEnum ExportType { get; set; }
    [EnumDataType(typeof(AnalyticReportTypeEnum))] public AnalyticReportTypeEnum ReportType { get; set; }
}