﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Filters;

public class AnalyticFilterEventListGetFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    public Guid? TenantId { get; set; }
}