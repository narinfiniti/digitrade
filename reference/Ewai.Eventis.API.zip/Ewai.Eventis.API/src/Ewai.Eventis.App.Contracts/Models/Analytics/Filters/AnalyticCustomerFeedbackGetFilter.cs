﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Filters;

public class AnalyticCustomerFeedbackGetFilter
{
    public Guid[] ShopIds { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
}