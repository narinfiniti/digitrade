﻿using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Filters;

public class AnalyticAverageVenueRatingGetFilter: PageFilter
{
    public Guid[] ShopIds { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
}