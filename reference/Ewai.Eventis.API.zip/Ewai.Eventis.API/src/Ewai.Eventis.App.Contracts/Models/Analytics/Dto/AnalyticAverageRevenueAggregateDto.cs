﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticAverageRevenueAggregateDto //: ListResult<AnalyticAverageRevenueDto>
{
    public decimal AverageRevenue { get; set; }
}