﻿using Ewai.SharedKernel.Models.Response;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticPreferredProductAggregateDto : ListResult<AnalyticPreferredProductDto>
{
    public long Quantity { get; set; }
}