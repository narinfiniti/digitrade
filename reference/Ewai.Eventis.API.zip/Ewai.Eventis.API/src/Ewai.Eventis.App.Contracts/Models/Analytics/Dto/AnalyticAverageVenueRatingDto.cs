﻿using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.Analytics.Models;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticAverageVenueRatingDto: IAutoMap<AnalyticAverageVenueRatingModel,AnalyticAverageVenueRatingDto>
{
    public double GoodRating { get; set; }
    public double BadRating { get; set; }
    public double NormalRating { get; set; }
    public Guid ShopId { get; set; }
    public string ShopName { get; set; }
    public void CreateMap(Profile profile)
    {
        profile.CreateMap<AnalyticAverageVenueRatingModel, AnalyticAverageVenueRatingDto>();
    }
}
