﻿using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.Analytics.Models;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticCustomerFeedbackDto : IAutoMap<AnalyticCustomerFeedbackModel, AnalyticCustomerFeedbackDto>
{
    public double GoodRating { get; set; }
    public double BadRating { get; set; }
    public double NormalRating { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<AnalyticCustomerFeedbackModel, AnalyticCustomerFeedbackDto>();
    }
}