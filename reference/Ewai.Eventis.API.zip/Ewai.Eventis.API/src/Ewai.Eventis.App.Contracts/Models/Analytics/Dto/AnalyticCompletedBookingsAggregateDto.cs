﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticCompletedBookingsAggregateDto //: ListResult<AnalyticCompletedBookingsDto>
{
    public long Count { get; set; }
}