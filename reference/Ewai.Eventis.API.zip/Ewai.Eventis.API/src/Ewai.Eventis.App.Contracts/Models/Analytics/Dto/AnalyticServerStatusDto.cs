﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticServerStatusDto
{
    public string ServerStatus { get; set; }
    public DateTime TimeStamp { get; set; }
}