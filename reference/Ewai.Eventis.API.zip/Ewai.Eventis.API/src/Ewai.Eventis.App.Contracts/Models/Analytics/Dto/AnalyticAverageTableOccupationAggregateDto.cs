namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticAverageTableOccupationAggregateDto //: ListResult<AnalyticAverageTableOccupationDto>
{
    public string Duration { get; set; }
}