﻿using Ewai.SharedKernel.Models.Response;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticSoldProductAggregateDto : ListResult<AnalyticSoldProductDto>
{
    public long Quantity { get; set; }
}