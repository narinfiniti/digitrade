﻿using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.Analytics.Models;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticAverageClientSpendDto : IAutoMap<AnalyticAverageClientSpendModel, AnalyticAverageClientSpendDto>
{
    public long NumberOfItems { get; set; }
    public decimal AverageBasketSize { get; set; }
    public decimal AverageBasketValue { get; set; }
    public Guid? ShopId { get; set; }
    public string ShopName { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<AnalyticAverageClientSpendModel, AnalyticAverageClientSpendDto>()
            .ForMember(dest => dest.AverageBasketSize, opt => opt.MapFrom(src => Math.Floor(src.AverageBasketSize)));
    }
}