﻿using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.Analytics.Models;
using Ewai.SharedKernel.Interfaces;
using Ewai.SharedKernel.Models.Response;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticAverageVenueRatingAggregateDto : ListResult<AnalyticAverageVenueRatingDto>,
    IAutoMap<AnalyticAverageVenueRatingModel, AnalyticAverageVenueRatingDto>
{
    public void CreateMap(Profile profile)
    {
        profile.CreateMap<AnalyticAverageVenueRatingModel, AnalyticAverageVenueRatingDto>();
    }
}