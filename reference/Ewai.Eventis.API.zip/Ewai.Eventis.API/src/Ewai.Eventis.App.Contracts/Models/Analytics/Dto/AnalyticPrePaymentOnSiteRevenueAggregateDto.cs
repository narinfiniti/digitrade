﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticPrePaymentOnSiteRevenueAggregateDto //: ListResult<AnalyticFailedTransactionDto>
{
    public decimal PrePaymentRevenue { get; set; }
    public decimal OnSiteRevenue { get; set; }
}