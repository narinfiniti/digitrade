﻿using Ewai.Eventis.App.Contracts.Models.Analytics.Models;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticSoldProductDto : IAutoMap<AnalyticProductsSoldModel, AnalyticSoldProductDto>
{
    public Guid? VenueId { get; set; }
    public string VenueName { get; set; }
    public string ProductName { get; set; }
    public string ProductBarcode { get; set; }
    public decimal UnitPrice { get; set; }
    public int QuantitySold { get; set; }
    public decimal Total { get; set; }
}