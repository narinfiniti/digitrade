﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

/// <summary>
/// AnalyticFilterVenueListDto.
/// </summary>
public class AnalyticFilterVenueListDto : IAutoMap<Venue, AnalyticFilterVenueListDto>
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string LineupDescription { get; set; }

    public VenueStatusEnum Status { get; set; }
    public string StatusName { get; set; }
    public DateTime Date { get; set; }
    public Guid TenantId { get; set; }
    public string TenantName { get; set; }

    public Guid EventId { get; set; }
    public string EventName { get; set; }

    public Guid? LocationId { get; set; }
    public string LocationName { get; set; }

    public bool IsExternal { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<Venue, AnalyticFilterVenueListDto>()
            .ForMember(to => to.StatusName, c => c.MapFrom(from => from.Status))
            .ForMember(to => to.Date, c => c.MapFrom(from => from.DateStarting))
            .ForMember(to => to.TenantName, c => c.MapFrom(from => from.Tenant.Name))
            .ForMember(to => to.EventName, c => c.MapFrom(from => from.Event.Name))
            .ForMember(to => to.LocationName, c => c.MapFrom(from => from.Location.Name));
    }
}