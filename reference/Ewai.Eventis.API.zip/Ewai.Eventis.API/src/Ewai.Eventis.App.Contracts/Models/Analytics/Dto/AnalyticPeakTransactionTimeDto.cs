﻿using Ewai.Eventis.App.Contracts.Models.Analytics.Models;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticPeakTransactionTimeDto : IAutoMap<AnalyticPeakTransactionTimeModel, AnalyticPeakTransactionTimeDto>
{
    public long MaxTransactionCount { get; set; }
    public DateTime PeakTime { get; set; }
    public Guid? ShopId { get; set; }
    public string ShopName { get; set; }
}