﻿using Ewai.SharedKernel.Models.Response;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticAverageClientSpendAggregateDto : ListResult<AnalyticAverageClientSpendDto>
{
    public decimal TotalAverageBasketSize { get; set; }
    public decimal TotalAverageBasketValue { get; set; }
    public long TotalNumberOfItems { get; set; }
}