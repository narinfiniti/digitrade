﻿using Ewai.SharedKernel.Models.Response;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticAbandonedTransactionAggregateDto : ListResult<AnalyticAbandonedTransactionDto>
{
    public long AbandonedTransactions { get; set; }
}