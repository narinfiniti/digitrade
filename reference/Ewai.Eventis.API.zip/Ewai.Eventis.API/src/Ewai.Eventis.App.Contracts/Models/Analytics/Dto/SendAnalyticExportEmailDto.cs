﻿namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class SendAnalyticExportEmailDto
{
    public Stream ExcelStream { get; set; }
    public Stream PdfStream { get; set; }
    public string Email { get; set; }
    public string AnalyticType { get; set; }
}