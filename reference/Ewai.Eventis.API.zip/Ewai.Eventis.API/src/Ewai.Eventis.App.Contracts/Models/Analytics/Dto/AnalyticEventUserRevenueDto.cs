using Ewai.Eventis.App.Contracts.Models.Analytics.Models;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticEventUserRevenueDto : IAutoMap<AnalyticEventUserRevenueModel, AnalyticEventUserRevenueDto>
{
    public Guid EventUserId { get; set; }
    public Guid UserId { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Email { get; set; }
    public decimal TotalRevenue { get; set; }
    public int InvoiceCount { get; set; }
    public string TablesServed { get; set; }
    public Guid? EventId { get; set; }
    public string EventName { get; set; }
    public Guid? VenueId { get; set; }
    public string VenueName { get; set; }
}