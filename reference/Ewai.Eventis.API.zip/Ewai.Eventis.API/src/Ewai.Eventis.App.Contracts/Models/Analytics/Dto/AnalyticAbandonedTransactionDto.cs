﻿using Ewai.Eventis.App.Contracts.Models.Analytics.Models;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticAbandonedTransactionDto : IAutoMap<AnalyticAbandonedTransactionModel, AnalyticAbandonedTransactionDto>
{
    public long TotalCount { get; set; }
    public Guid? ShopId { get; set; }
    public string ShopName { get; set; }
}