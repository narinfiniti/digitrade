﻿using Ewai.Eventis.App.Contracts.Models.Analytics.Models;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticPreferredProductDto : IAutoMap<AnalyticPreferredProductsModel, AnalyticPreferredProductDto>
{
    public Guid? VenueId { get; set; }
    public string VenueName { get; set; }
    public string ProductName { get; set; }
    public string Barcode { get; set; }
    public decimal UnitPrice { get; set; }
    public long Quantity { get; set; }

    public string ImageUrl { get; set; }
}