﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.TenantEvents;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticFilterEventListDto : IAutoMap<TheEvent, AnalyticFilterEventListDto>
{
    public Guid Id { get; set; }
    public string Name { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TheEvent, AnalyticFilterEventListDto>();
    }
}