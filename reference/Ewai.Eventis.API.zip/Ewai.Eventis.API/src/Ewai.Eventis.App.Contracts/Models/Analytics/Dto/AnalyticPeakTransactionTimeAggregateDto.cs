﻿using Ewai.SharedKernel.Models.Response;

namespace Ewai.Eventis.App.Contracts.Models.Analytics.Dto;

public class AnalyticPeakTransactionTimeAggregateDto : ListResult<AnalyticPeakTransactionTimeDto>
{
    public long TotalMaxTransactions { get; set; }
}