using Ewai.Common.Models;
using Ewai.Eventis.App.Contracts.Models.TenantClients.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueDesks.Dto;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.ClientBookings.Dto;

/// <summary>
/// ClientBookingDto.
/// </summary>
public class ClientBookingAssignTableDto
    : IAutoMap<ClientBooking, ClientBookingAssignTableDto>
{
    public Guid Id { get; set; }
    public Guid ClientId { get; set; }
    public short NumberOfPeople { get; set; }
    public ClientBookingStatusEnum ClientStatus { get; set; }
    public short WillSpend { get; set; }
    public DateTime DateBooked { get; set; }
    public RangeOf<TimeSpan> TimeRange { get; set; }
    public Guid? DeskId { get; set; }
    public Guid? LastDeskId { get; set; }
    public DateTime? LeftDeskAt { get; set; }
    public Guid? PublicRelationId { get; set; }
    public string Notes { get; set; }
    public TenantClientDto Client { get; set; }
    public VenueDeskDto Desk { get; set; }
}