namespace Ewai.Eventis.App.Contracts.Models.ClientBookings.Models;

public class ClientBookingModel
{
    
}