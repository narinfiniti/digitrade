﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.ClientBookings.Filters;

/// <summary>
/// ClientBookingGetListFilter.
/// </summary>
public class ClientBookingGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    
    public Guid? VenueId { get; set; }
    [MaxLength(200)] public string ZoneName { get; set; }
    [MaxLength(200)] public string TenantName { get; set; }
    [MaxLength(100)] public string Email { get; set; }
    public Guid? TenantId { get; set; }
}