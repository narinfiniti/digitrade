using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.ClientBookings.Inputs;

/// <summary>
/// ClientBookingAssignTableInput.
/// </summary>
public class ClientBookingAssignTableInput : IAutoMap<ClientBooking, ClientBookingAssignTableInput>
{
    [Required] public Guid? BookingId { get; set; }
    [Required] public Guid? DeskId { get; set; }
    // [Range(1,1000)] public short? NumberOfPeople { get; set; }
    // public ClientBookingStatusEnum ClientStatus { get; set; }
    // [Range(1,1000)] public short? WillSpend { get; set; }
    // public DateTime? DateBooked { get; set; }
    // public Guid? PublicRelationId { get; set; }
    // [MaxLength(1000)] public string Notes { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<ClientBookingAssignTableInput, ClientBooking>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }
}