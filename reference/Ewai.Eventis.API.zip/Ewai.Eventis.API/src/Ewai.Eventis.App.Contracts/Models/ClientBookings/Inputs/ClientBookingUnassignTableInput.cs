using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.ClientBookings.Inputs;

public class ClientBookingUnassignTableInput : IAutoMap<ClientBooking, ClientBookingUnassignTableInput>
{
    [Required] public Guid BookingId { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<ClientBookingUnassignTableInput, ClientBooking>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }
}
