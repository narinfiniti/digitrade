using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.ClientBookings.Inputs;

/// <summary>
/// ClientBookingUpdateArrivedPeopleInput.
/// </summary>
public class ClientBookingUpdateArrivedPeopleInput : IAutoMap<ClientBooking, ClientBookingUpdateArrivedPeopleInput>
{
    [Required] public Guid? BookingId { get; set; }
    [Required] public short ArrivedPeople { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<ClientBookingUpdateArrivedPeopleInput, ClientBooking>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }
}