using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;
using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.ClientBookings.Inputs;

/// <summary>
/// TenantClientBookingInput.
/// </summary>
public class TenantClientBookingInput
    : IAutoMap<TenantClient, TenantClientBookingInput>
{
    [MaxLength(30)] public string PhoneNumber { get; set; }
    [MaxLength(200)] public string Email { get; set; }
    [MaxLength(200)] public string FirstName { get; set; }
    [MaxLength(200)] public string LastName { get; set; }
}