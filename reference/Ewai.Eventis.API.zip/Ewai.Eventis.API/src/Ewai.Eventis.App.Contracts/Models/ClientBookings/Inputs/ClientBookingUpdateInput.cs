using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.ClientBookings.Inputs;

/// <summary>
/// ClientBookingUpdateInput.
/// </summary>
public class ClientBookingUpdateInput : IAutoMap<ClientBooking, ClientBookingUpdateInput>
{
    [Range(1, 1000)] public short? NumberOfPeople { get; set; }
    [EnumDataType(typeof(ClientBookingStatusEnum))]
    public ClientBookingStatusEnum? ClientStatus { get; set; }
    public decimal? WillSpend { get; set; }
    public decimal? PrePayment { get; set; }
    public decimal? BalancePrePayment { get; set; }
    public DateTime? DateBooked { get; set; }
    public Guid? DeskId { get; set; }
    public Guid? PublicRelationId { get; set; }
    [MaxLength(1000)] public string Notes { get; set; }
    public RangeOf<TimeSpan> TimeRange { get; set; }

    public TenantClientBookingInput Client { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<ClientBookingUpdateInput, ClientBooking>()
            // Force mapping for PublicRelationId (even if null)
            .ForMember(dest => dest.PublicRelationId, opt =>
                opt.MapFrom(src => src.PublicRelationId)
            )
            // Only map DeskId if it’s not null
            .ForMember(dest => dest.DeskId, opt =>
                opt.Condition((src, dest, val) => val != null)
            )
            // Default: skip null values
            .ForAllMembers(opt =>
                opt.Condition((src, dest, srcMember) => srcMember != null)
            );

        profile.CreateMap<ClientBookingStatusEnum?, ClientBookingStatusEnum>()
            .ConvertUsing((src, dest) => src ?? dest);
    }
}