using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.ClientBookings.Inputs;

/// <summary>
/// ClientBookingCreateInput.
/// </summary>
public class ClientBookingCreateInput : IAutoMap<ClientBooking, ClientBookingCreateInput>
{
    [EnumDataType(typeof(ClientBookingStatusEnum))]
    public ClientBookingStatusEnum ClientStatus { get; set; }
    public Guid? TenantId { get; set; }
    [Required] public Guid? VenueId { get; set; }
    [MaxLength(50), Phone] public string PhoneNumber { get; set; }
    [Required, MaxLength(100)] public string FirstName { get; set; }
    [Required, MaxLength(100)] public string LastName { get; set; }
    [MaxLength(256), EmailAddress] public string Email { get; set; }

    [Range(1, 1000)] public short? NumberOfPeople { get; set; }
    public int? WillSpend { get; set; }
    public decimal? PrePayment { get; set; }
    public decimal? BalancePrePayment { get; set; }
    public DateTime? DateBooked { get; set; }
    public RangeOf<TimeSpan> TimeRange { get; set; }
    public Guid? DeskId { get; set; }
    public Guid? PublicRelationId { get; set; }
    [MaxLength(1000)] public string Notes { get; set; }
    public Guid? CreatorId { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<ClientBookingCreateInput, ClientBooking>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
        profile.CreateMap<ClientBookingCreateInput, TenantClient>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));


        profile.CreateMap<ClientBookingCreateInput, ClientBooking>()
            // If the incoming DateCreated is not null, remove its Kind:
            .ForMember(dest => dest.DateBooked, opt => opt.MapFrom(src =>
                src.DateBooked.HasValue
                    ? DateTime.SpecifyKind(src.DateBooked.Value, DateTimeKind.Unspecified)
                    : DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Unspecified)
            ))

            // For everything else, only map non-null values:
            .ForAllMembers(opt => opt.Condition((src, dest, srcMember) => srcMember != null));
    }
    
}