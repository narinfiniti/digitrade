﻿using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Roles.Inputs;

/// <summary>
/// RoleCreateOrUpdateInput.
/// </summary>
public class RoleCreateOrUpdateInput : IAutoMap<Role, RoleCreateOrUpdateInput>
{
    [Required, MaxLength(200)] public string Name { get; set; }

    [Range(1, 10), EnumDataType(typeof(RoleTypeEnum))]
    public RoleTypeEnum? Type { get; set; }

    public Guid? BranchId { get; set; }
    public Guid? TenantId { get; set; }
}