﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Permissions;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Roles.Dto;

public class PermissionDto : IAutoMap<Permission, PermissionDto>
{
    public string Name { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<Permission, PermissionDto>()
            .ForMember(dest => dest.Name, opt => opt.MapFrom(src => $"{src.Group}.{src.Name}.{src.Type}".ToLower()));
    }
}