﻿namespace Ewai.Eventis.App.Contracts.Models.Roles.Dto;

/// <summary>
/// RoleNameDto.
/// </summary>
public class RoleNameDto
{
    public string Name { get; set; }
    public string DisplayName { get; set; }
}