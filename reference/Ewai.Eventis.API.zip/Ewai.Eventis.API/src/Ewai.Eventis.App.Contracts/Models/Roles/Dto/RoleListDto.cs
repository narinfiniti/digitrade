﻿using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Roles.Dto;

/// <summary>
/// RoleListDto.
/// </summary>
public class RoleListDto : IAutoMap<Role, RoleListDto>
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public RoleTypeEnum? Type { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? TenantId { get; set; }
}