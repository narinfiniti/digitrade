﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Entity.Users;

namespace Ewai.Eventis.App.Contracts.Models.Roles.Filters;

/// <summary>
/// RoleGetListFilter.
/// </summary>
public class RoleGetListFilter : PageFilter
{
    [MaxLength(200)] public string Name { get; set; }
    [Range(1, 10), EnumDataType(typeof(RoleTypeEnum))]
    public RoleTypeEnum? Type { get; set; }
    public Guid? RoleId { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? TenantId { get; set; }
    public string IgnoreName { get; set; }
}