﻿using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.Roles.Filters;

/// <summary>
/// RoleGetNamesFilter.
/// </summary>
public class RoleGetNamesFilter : PageFilter
{
    public bool? IsInternal { get; set; }
}