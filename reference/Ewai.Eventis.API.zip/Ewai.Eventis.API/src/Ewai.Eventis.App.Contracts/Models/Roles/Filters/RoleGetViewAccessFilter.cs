﻿namespace Ewai.Eventis.App.Contracts.Models.Roles.Filters;

/// <summary>
/// RoleGetViewAccessFilter.
/// </summary>
public class RoleGetViewAccessFilter
{
    public Guid? RoleId { get; set; }
}