﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Attributes;
using Ewai.Eventis.App.Contracts.Models.PaymentSystem.Enums;

namespace Ewai.Eventis.App.Contracts.Models.PaymentSystem.Models;

public class TryPayModel
{
    [DecimalRange(0.0000001d, double.MaxValue)]
    public decimal Amount { get; set; }

    [StringLength(3)] public string Currency { get; set; } = CurrencyEnum.Eur;
    [StringLength(100)] public string Description { get; set; }
    [StringLength(100)] public string PaymentMethod { get; set; } = PaymentMethodEnum.Ideal;
}