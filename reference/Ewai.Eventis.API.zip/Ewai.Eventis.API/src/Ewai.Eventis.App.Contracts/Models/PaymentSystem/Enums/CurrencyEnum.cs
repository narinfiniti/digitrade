﻿namespace Ewai.Eventis.App.Contracts.Models.PaymentSystem.Enums;

public static class CurrencyEnum
{
    public const string Aud = "AUD";
    public const string Bgn = "BGN";
    public const string Cad = "CAD";
    public const string Hrk = "HRK";
    public const string Czk = "CZK";
    public const string Dkk = "DKK";
    public const string Hkd = "HKD";
    public const string Huf = "HUF";
    public const string Isk = "ISK";
    public const string Ils = "ILS";
    public const string Jpy = "JPY";
    public const string Nok = "NOK";
    public const string Pln = "PLN";
    public const string Gbp = "GBP";
    public const string Ron = "RON";
    public const string Sek = "SEK";
    public const string Chf = "CHF";
    public const string Usd = "USD";
    public const string Eur = "EUR";
}