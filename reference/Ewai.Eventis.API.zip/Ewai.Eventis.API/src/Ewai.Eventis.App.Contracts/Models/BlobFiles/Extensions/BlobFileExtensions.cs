﻿using Ewai.Common.Extensions;
using Ewai.Eventis.Domain.Entity.BlobFiles;

namespace Ewai.Eventis.App.Contracts.Models.BlobFiles.Extensions;

public static class BlobFileExtensions
{
    public static string ToTenantFileName(this BlobFile fileName, Guid? tenantId)
    {
        var containerName = tenantId.IsEmpty() ? "system" : $"{tenantId}";
        return $"{containerName}/{fileName.GetFileName()}";
    }

    public static (string folderName, string fileName) ToAwsS3FolderAndFileNames(this string blobName)
    {
        if (blobName.IsEmpty()) return (string.Empty, blobName);

        var pathParts = blobName.Split('/');
        if (pathParts.Length < 2) return (string.Empty, blobName);

        var folderName = pathParts.FirstOrDefault();
        if (folderName.IsEmpty()) return (string.Empty, blobName);

        return (folderName, blobName.Replace($"{folderName}/", string.Empty));
    }
}