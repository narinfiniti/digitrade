﻿using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.BlobFiles.Inputs;

public class BlobImageCopyInput
{
    [Required] public Guid? TenantId { get; set; }
}