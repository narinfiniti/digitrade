﻿namespace Ewai.Eventis.App.Contracts.Models.BlobFiles.Inputs;

public class BlobFileSyncInput
{
    public Guid? TenantId { get; set; }
}