﻿using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.BlobFiles;
using Ewai.SharedKernel.Interfaces;
using Microsoft.AspNetCore.Http;

namespace Ewai.Eventis.App.Contracts.Models.BlobFiles.Inputs;

public class BlobFileUploadInput : IAutoMap<BlobFileUploadInput, BlobFile>
{
    [Required] public IFormFile File { get; set; }
    [Required, MaxLength(100)] public string Target { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<BlobFileUploadInput, BlobFile>();
    }
}