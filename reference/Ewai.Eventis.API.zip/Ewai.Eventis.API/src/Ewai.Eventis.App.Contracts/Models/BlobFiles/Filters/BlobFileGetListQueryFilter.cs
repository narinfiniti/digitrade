﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.BlobFiles.Filters;

public class BlobFileGetListQueryFilter : PageFilter
{
    public Guid? Id { get; set; }
    [MaxLength(10)] public string Extension { get; set; }
    [MaxLength(100)] public string Target { get; set; }
}