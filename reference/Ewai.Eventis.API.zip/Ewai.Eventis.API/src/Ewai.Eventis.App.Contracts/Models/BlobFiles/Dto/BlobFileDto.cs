﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.BlobFiles;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.BlobFiles.Dto;

public class BlobFileDto : IAutoMap<BlobFile, BlobFileDto>
{
    public Guid Id { get; set; }
    public string BlobExtension { get; set; }
    public string Target { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<BlobFile, BlobFileDto>();
    }
}