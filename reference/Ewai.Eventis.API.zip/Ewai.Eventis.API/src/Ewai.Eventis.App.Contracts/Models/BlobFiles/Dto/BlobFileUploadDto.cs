using AutoMapper;
using Ewai.Eventis.Domain.Entity.BlobFiles;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.BlobFiles.Dto;

public class BlobFileUploadDto : IAutoMap<BlobFile, BlobFileUploadDto>
{
    public Guid Id { get; init; }
    public string Target { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<BlobFile, BlobFileUploadDto>();
    }
}