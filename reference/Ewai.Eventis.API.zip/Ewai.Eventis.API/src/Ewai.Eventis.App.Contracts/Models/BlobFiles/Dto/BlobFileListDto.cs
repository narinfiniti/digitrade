﻿using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.BlobFiles.Extensions;
using Ewai.Eventis.Domain.Entity.BlobFiles;
using Ewai.SharedKernel.Interfaces;
using Ewai.SharedKernel.Models.Configs;

namespace Ewai.Eventis.App.Contracts.Models.BlobFiles.Dto;

public class BlobFileListDto : IAutoMap<BlobFile, BlobFileListDto>
{
    public Guid Id { get; set; }
    public string BlobExtension { get; set; }
    public string Target { get; set; }
    public string SourceUrl { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<BlobFile, BlobFileListDto>()
            .ForMember(dest => dest.SourceUrl, opt => opt.MapFrom<ValueResolver>());
    }

    public class ValueResolver(
        DefaultAwsS3Storage s3Storage,
        IUserProfileService userProfileService)
        : IValueResolver<BlobFile, BlobFileListDto, string>
    {
        public string Resolve(BlobFile source, BlobFileListDto destination,
            string destMember, ResolutionContext context)
        {
            if (source is null) return string.Empty;
            var tenantId = userProfileService.GetTenantId();
            return s3Storage.GetPreSignedUrl(source.ToTenantFileName(tenantId));
        }
    }
}