﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.TenantEvents.Filters;

public class TheEventGetListFilter : PageFilter
{
    public Guid? TenantId { get; set; }
    [MaxLength(100)] public string Filter { get; set; }
    [MaxLength(200)] public string TenantName { get; set; }
    [MaxLength(200)] public string Name { get; set; }
    public Guid? EventId { get; set; }
}