﻿using System.Text.Json.Nodes;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.TenantEvents;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenantEvents.Dto;

public class TheEventListDto : IAutoMap<TheEvent, TheEventListDto>
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public Guid? ImageId { get; set; }
    public Guid TenantId { get; set; }
    public string TenantName { get; set; }
    public JsonNode Config { get; set; }
    public Guid? TemplateId { get; set; }
    
    public int TotalParties { get; set; }
    public int TotalPartiesDone { get; set; }
    public int TotalPartiesRemaining { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TheEvent, TheEventListDto>()
            .ForMember(dest => dest.TotalParties, opt => opt.MapFrom(src =>
                src.Venues != null ? src.Venues.Count : 0))
            .ForMember(dest => dest.TotalPartiesDone, opt => opt.MapFrom(src => 
                src.Venues != null 
                    ? src.Venues.Count(venue => (venue.DateStarting + venue.TimeRange.End) < DateTime.UtcNow) 
                    : 0))
            .ForMember(dest => dest.TotalPartiesRemaining, opt => opt.MapFrom(src => 
                src.Venues != null 
                    ? src.Venues.Count(venue => (venue.DateStarting + venue.TimeRange.End) >= DateTime.UtcNow) 
                    : 0));
    }
}