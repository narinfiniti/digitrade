using System.Text.Json.Nodes;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.TenantEvents;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenantEvents.Dto;

/// <summary>
/// TenantEventDto.
/// </summary>
public class TheEventDto : IAutoMap<TheEvent, TheEventDto>
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public Guid TenantId { get; set; }
    public string TenantName { get; set; }
    public JsonNode Config { get; set; }
    public Guid? TemplateId { get; set; }
    
    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TheEvent, TheEventDto>();
    }
}