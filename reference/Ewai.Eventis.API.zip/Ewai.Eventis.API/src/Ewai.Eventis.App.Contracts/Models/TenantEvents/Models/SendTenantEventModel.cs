﻿namespace Ewai.Eventis.App.Contracts.Models.TenantEvents.Models;

public class SendTenantEventModel
{
    public string TenantAdminEmail { get; set; }
    public string TenantName { get; set; }
    public string Message { get; set; }
    public string LogoImgUrl { get; set; }
    public string Password { get; set; }
    public string EmailReceivers { get; set; }
    public Stream Data { get; set; }
}