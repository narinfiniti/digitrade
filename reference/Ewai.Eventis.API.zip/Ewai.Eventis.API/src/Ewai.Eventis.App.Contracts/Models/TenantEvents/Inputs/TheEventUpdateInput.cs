using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.TenantEvents;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenantEvents.Inputs;

public class TheEventUpdateInput : IAutoMap<TheEvent, TheEventUpdateInput>
{
    [Required, MaxLength(100)] public string Name { get; set; }
    // [MaxLength(100)] public string Email { get; set; }
    [MaxLength(500)] public string Description { get; set; }
    [MaxLength(100)] public string FirstName { get; set; }
    [MaxLength(100)] public string LastName { get; set; }
}