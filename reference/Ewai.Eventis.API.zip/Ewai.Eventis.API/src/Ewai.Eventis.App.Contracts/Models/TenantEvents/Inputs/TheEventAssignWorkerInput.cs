using Ewai.Common.Attributes;

namespace Ewai.Eventis.App.Contracts.Models.TenantEvents.Inputs;

/// <summary>
/// TheEventAssignWorkerInput.
/// </summary>
public class TheEventAssignWorkerInput
{
    [NonEmptyList] public Guid[] UserIds { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }
    public Guid? RoleId { get; set; }
}