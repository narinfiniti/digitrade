using System.ComponentModel.DataAnnotations;
using System.Text.Json.Nodes;
using Ewai.Eventis.Domain.Entity.TenantEvents;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenantEvents.Inputs;

public class TheEventCreateInput : IAutoMap<TheEvent, TheEventCreateInput>
{
    [Required, MaxLength(100)] public string Name { get; set; }
    [MaxLength(500)] public string Description { get; set; }
    [MaxLength(4000)] public JsonNode Config { get; set; }
    [Required] public Guid? TenantId { get; set; }
    public Guid? TemplateId { get; set; }
    public Guid? ImageId { get; set; }
}