using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.TenantEvents.Inputs;

/// <summary>
/// Assigns one or more VenueDesks to an EventUser.
/// </summary>
public class TheEventUserAssignDeskInput
{
        [Required] public Guid DeskId { get; set; }

        /// <summary>
        /// List of EventUser IDs to assign to the desk.
        /// </summary>
        [Required, MinLength(1)]
        public List<Guid> EventUserIds { get; set; } = [];

        /// <summary>
        /// If true, replaces existing assignments. If false, adds to existing ones.
        /// </summary>
        public bool ReplaceExisting { get; set; }
}