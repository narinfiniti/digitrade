﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.VenueGusts.Dto;

/// <summary>
/// VenueGuestDto.
/// </summary>
public class VenueGuestDto : IAutoMap<VenueGuest, VenueGuestDto>
{
    public Guid Id { get; set; }
    public Guid VenueId { get; set; }
    public bool IsCheckedIn { get; set; }

    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string QrCode { get; set; }
    public string Notes { get; set; }
    public string PhoneNumber { get; set; }
    public string Email { get; set; }

    public DateTime? DateCheckedIn { get; set; }
    public DateTime DateCreated { get; set; }

    //public string TenantName { get; set; }
    //public string VenueName { get; set; }
    //public VenueDto Venue { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<VenueGuest, VenueGuestDto>()
            //.ForMember(to => to.TenantName, c => c.MapFrom(from => from.Venue.Tenant.Name))
            //.ForMember(to => to.VenueName, c => c.MapFrom(from => from.Venue.Name))
            //.ForMember(to => to.ImageUrl, c => c.MapFrom<ValueResolver>())
            ;
    }

    public class ValueResolver(
        //IUserProfileService userProfileService
        ) : IValueResolver<VenueGuest, VenueGuestDto, string>
    {
        public string Resolve(VenueGuest source, VenueGuestDto destination,
            string destMember, ResolutionContext context)
        {
            if (source.QrCode is null) return string.Empty;
            //var tenantId = userProfileService.GetTenantId();
            return source.QrCode;
        }
    }
}