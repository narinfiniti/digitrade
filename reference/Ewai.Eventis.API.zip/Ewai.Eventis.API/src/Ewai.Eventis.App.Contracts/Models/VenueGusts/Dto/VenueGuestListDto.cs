﻿using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.VenueGusts.Dto;

/// <summary>
/// VenueGuestListDto.
/// </summary>
public class VenueGuestListDto : IAutoMap<VenueGuest, VenueGuestListDto>
{
    public Guid Id { get; set; }
    [Required] public Guid VenueId { get; set; }
    public bool IsCheckedIn { get; set; }

    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string QrCode { get; set; }
    public string Notes { get; set; }
    public string PhoneNumber { get; set; }
    public string Email { get; set; }

    public DateTime? DateCheckedIn { get; set; }
    public DateTime DateCreated { get; set; }

    //public string TenantName { get; set; }
    //public string VenueName { get; set; }
    // public VenueDto Venue { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<VenueGuest, VenueGuestListDto>()
            //.ForMember(to => to.TenantName, c => c.MapFrom(from => from.Venue.Tenant.Name))
            //.ForMember(to => to.VenueName, c => c.MapFrom(from => from.Venue.Name))
            //.ForMember(to => to.ImageUrl, c => c.MapFrom<ValueResolver>())
            ;
    }

    public class ValueResolver(
        //IUserProfileService userProfileService
        ) : IValueResolver<VenueGuest, VenueGuestListDto, string>
    {
        public string Resolve(VenueGuest source, VenueGuestListDto destination,
            string destMember, ResolutionContext context)
        {
            if (source.QrCode is null) return string.Empty;
            //var tenantId = userProfileService.GetTenantId();
            return source.QrCode;
        }
    }
}