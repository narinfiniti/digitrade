using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.VenueGusts.Inputs;

/// <summary>
/// VenueGuestCreateInput.
/// </summary>
public class VenueGuestCreateInput : IAutoMap<VenueGuest, VenueGuestCreateInput>
{
    [Required] public Guid VenueId { get; set; }
    public bool? IsCheckedIn { get; set; }
    [Required, MaxLength(100)] public string FirstName { get; set; }
    [MaxLength(100)] public string LastName { get; set; }
    [MaxLength(1000)] public string Notes { get; set; }

    [MaxLength(1000)] public string QrCode { get; set; }
    [MaxLength(20)] public string PhoneNumber { get; set; }
    [MaxLength(200)] public string Email { get; set; }
}