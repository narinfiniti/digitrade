﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.VenueGusts.Filters;

/// <summary>
/// VenueGuestGetListFilter.
/// </summary>
public class VenueGuestGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    public Guid? VenueId { get; set; }
    public bool? IsCheckedIn { get; set; }
    [MaxLength(100)] public string FirstName { get; set; }
    [MaxLength(100)] public string LastName { get; set; }
    [MaxLength(1000)] public string QrCode { get; set; }
    [MaxLength(1000)] public string Notes { get; set; }
    [MaxLength(20)]public string PhoneNumber { get; set; }
    [MaxLength(200)] public string Email { get; set; }
    public DateTime? DateCreatedFrom { get; set; }
    public DateTime? DateCreatedTo { get; set; }
    public DateTime? DateCheckedInFrom { get; set; }
    public DateTime? DateCheckedInTo { get; set; }

}