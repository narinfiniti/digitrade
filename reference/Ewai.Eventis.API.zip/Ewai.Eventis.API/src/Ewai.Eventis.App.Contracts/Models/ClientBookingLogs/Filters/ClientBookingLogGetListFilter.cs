﻿using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.ClientBookingLogs.Filters;

/// <summary>
/// ClientBookingLogGetListFilter.
/// </summary>
public class ClientBookingLogGetListFilter : PageFilter
{
    public Guid? BookingId { get; set; }
    public Guid? InvoiceId { get; set; }
    public Guid? DeskId { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
}