using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.ClientBookingLogs.Dto;

/// <summary>
/// BookingLogDeskDto.
/// </summary>
public class ClientBookingLogDeskDto : IAutoMap<VenueDesk, ClientBookingLogDeskDto>
{
    public Guid Id { get; set; }

    public string No { get; set; }
    public short CapacityOfPeople { get; set; }
    public short SizeDiameter { get; set; }
    public string ColorCode { get; set; }
    public decimal MinSpend { get; set; }
    public Guid? ZoneId { get; set; }
    public Guid? EventUserId { get; set; }
    public string QrCode { get; set; }
}