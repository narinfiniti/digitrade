using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.ClientBookingLogs.Dto;

/// <summary>
/// ClientBookingLogListDto.
/// </summary>
public class ClientBookingLogListDto
    : IAutoMap<ClientBookingLog, ClientBookingLogListDto>
{
    public Guid Id { get; set; }
    public Guid ClientBookingId { get; set; }
    public Guid InvoiceId { get; set; }
    public Guid? DeskId { get; set; }
    public DateTime DateCreated { get; set; }

    public ClientBookingLogDeskDto Desk { get; set; }
}