using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.Devices;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Devices.Inputs;

/// <summary>
/// UserDeviceRegisterInput.
/// </summary>
public class UserDeviceRegisterInput : IAutoMap<UserDevice, UserDeviceRegisterInput>
{
    [Required, MaxLength(100)] public string RoleName { get; set; }
    [Required, StringLength(1000, MinimumLength = 8)] public string DeviceId { get; set; }
    [Required, EnumDataType(typeof(UserDeviceTypeEnum))] public UserDeviceTypeEnum? DeviceType { get; set; }
}