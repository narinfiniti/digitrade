using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Entity.Devices;

namespace Ewai.Eventis.App.Contracts.Models.Devices.Filters;

public class UserDeviceGetListFilter : PageFilter
{
    public Guid? UserId { get; set; }
    [StringLength(1000, MinimumLength = 8)] public string DeviceId { get; set; }
    [EnumDataType(typeof(UserDeviceTypeEnum))] public UserDeviceTypeEnum DeviceType { get; set; }
    [MaxLength(1000)] public string ConnectionId { get; set; }
}