using Ewai.Eventis.Domain.Entity.Devices;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Devices.Dto;

/// <summary>
/// UserDeviceRegisterDto.
/// </summary>
public class UserDeviceRegisterDto : IAutoMap<UserDevice, UserDeviceRegisterDto>
{
    public Guid Id { get; set; }
    public string DeviceId { get; set; }
    public UserDeviceTypeEnum DeviceType { get; set; }
    public string ConnectionId { get; set; }
}