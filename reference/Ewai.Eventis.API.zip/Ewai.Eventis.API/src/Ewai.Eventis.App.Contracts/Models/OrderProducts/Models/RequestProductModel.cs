namespace Ewai.Eventis.App.Contracts.Models.OrderProducts.Models;

public class RequestProductModel
{
    
}