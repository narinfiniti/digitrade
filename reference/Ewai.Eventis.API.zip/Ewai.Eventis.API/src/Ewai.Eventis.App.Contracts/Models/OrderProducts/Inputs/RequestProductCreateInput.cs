using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.OrderProducts.Inputs;

/// <summary>
/// RequestProductCreateInput.
/// </summary>
public class RequestProductCreateInput
    : IAutoMap<RequestProduct, RequestProductCreateInput>
{
    // public Guid? RequestId { get; set; }
    // public Guid? ProductId { get; set; }

    public Guid MenuProductId { get; set; }

    [MaxLength(100)] public string ProductBarcode { get; set; }
    [Required, Range(0.000_001, 10_000_000.0)] public decimal? Quantity { get; set; }

    [MaxLength(200)] public string ProductName { get; set; }
    [Range(0, 10_000_000.0)] public decimal? UnitPrice { get; set; }
    [Range(0, 10_000_000.0)] public decimal? Vat { get; set; }
    [Range(0, 10_000_000.0)] public decimal? Discount { get; set; }
}