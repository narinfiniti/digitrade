using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.OrderProducts.Inputs;

/// <summary>
/// RequestProductUpdateInput.
/// </summary>
public class RequestProductUpdateInput : IAutoMap<RequestProduct, RequestProductUpdateInput>
{
    public Guid RequestId { get; set; }

    public bool IsWeightBased { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal Quantity { get; set; }
    public decimal Vat { get; set; }
    public decimal Discount { get; set; }
    public decimal Total { get; set; }

    public string ProductBarcode { get; set; }
    public string ProductName { get; set; }
    public string Unit { get; set; }

    public Guid? ProductId { get; set; }
}