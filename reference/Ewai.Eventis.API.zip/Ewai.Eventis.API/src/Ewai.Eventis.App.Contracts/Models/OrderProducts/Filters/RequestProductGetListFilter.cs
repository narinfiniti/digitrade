﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.OrderProducts.Filters;

/// <summary>
/// RequestProductGetListFilter.
/// </summary>
public class RequestProductGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    public Guid? TenantId { get; set; }
}