﻿using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.OrderProducts.Dto;

/// <summary>
/// RequestProductListDto.
/// </summary>
public class RequestProductListDto
    : IAutoMap<RequestProduct, RequestProductListDto>
{
    public Guid Id { get; set; }
    public Guid RequestId { get; set; }

    public bool IsWeightBased { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal Quantity { get; set; }
    public decimal Vat { get; set; }
    public decimal Discount { get; set; }
    public decimal Total { get; set; }

    public string ProductBarcode { get; set; }
    public string ProductName { get; set; }
    public string Unit { get; set; }

    public Guid? ProductId { get; set; }
    public DateTime? DateModified { get; set; }
    public Guid? LastModifierId { get; set; }
}