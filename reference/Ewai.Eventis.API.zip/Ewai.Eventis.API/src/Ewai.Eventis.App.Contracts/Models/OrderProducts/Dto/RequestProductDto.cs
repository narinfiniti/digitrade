using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.OrderProducts.Dto;

/// <summary>
/// RequestProductDto.
/// </summary>
public class RequestProductDto : IAutoMap<RequestProduct, RequestProductDto>
{
    public Guid Id { get; set; }
    public Guid RequestId { get; set; }

    public string ProductName { get; set; }
    public string ProductBarcode { get; set; }

    public decimal UnitPrice { get; set; }
    public decimal Quantity { get; set; }
    public decimal Vat { get; set; }
    public decimal Discount { get; set; }
    public decimal Total { get; set; }

    public bool IsWeightBased { get; set; }
    public string Unit { get; set; }

    public Guid? ProductId { get; set; }
    public DateTime? DateModified { get; set; }
    public Guid? LastModifierId { get; set; }
}