using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Enums;

namespace Ewai.Eventis.App.Contracts.Models.Permissions.Filters;

public class PermissionViewCategoryGetListFilter: PageFilter
{
    [EnumDataType(typeof(PermissionGroupEnum)), Range(1, 3)]
    public PermissionGroupEnum? Group { get; set; }
}