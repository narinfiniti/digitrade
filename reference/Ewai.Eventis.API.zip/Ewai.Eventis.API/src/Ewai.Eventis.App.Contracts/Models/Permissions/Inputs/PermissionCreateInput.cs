﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Attributes;
using Ewai.Eventis.Domain.Enums;

namespace Ewai.Eventis.App.Contracts.Models.Permissions.Inputs;

public class PermissionCreateInput
{
    [EnumDataType(typeof(PermissionTypeEnum)), Range(0, 4)]
    public PermissionTypeEnum? Type { get; set; }
    [EnumDataType(typeof(PermissionGroupEnum)), Range(1, 3)]
    public PermissionGroupEnum? Group { get; set; }
    [Required, EnumDataType(typeof(PermissionTargetEnum)), Range(1, 3)]
    public PermissionTargetEnum? Target { get; set; }
    [Required] public Guid? TargetId { get; set; }
    [NonEmptyList] public List<string> Views { get; set; }
}