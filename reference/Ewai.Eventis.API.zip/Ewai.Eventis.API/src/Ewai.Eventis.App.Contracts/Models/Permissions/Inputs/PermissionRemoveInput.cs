﻿using Ewai.Common.Attributes;
using Ewai.Eventis.Domain.Enums;

namespace Ewai.Eventis.App.Contracts.Models.Permissions.Inputs;

public class PermissionRemoveInput
{
    public Guid[] Ids { get; set; }
    [MaxCountList(5)] public PermissionTypeEnum[] Types { get; set; }
    [MaxCountList(3)] public PermissionGroupEnum[] Groups { get; set; }
    [MaxCountList(3)] public PermissionTargetEnum[] Targets { get; set; }
    public Guid[] TargetIds { get; set; }
}