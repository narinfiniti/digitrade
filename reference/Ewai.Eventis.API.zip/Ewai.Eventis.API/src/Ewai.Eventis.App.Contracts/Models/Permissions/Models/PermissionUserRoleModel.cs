using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Permissions.Models;

public class PermissionUserRoleModel : IAutoMap<UserRole, PermissionUserRoleModel>
{
    public Guid UserId { get; set; }
    public Guid RoleId { get; set; }
}