using AutoMapper;
using Ewai.Eventis.Domain.Entity.PermissionViews;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Permissions.Dto;

public class PermissionViewDto
    : IAutoMap<PermissionView, PermissionViewDto>
{
    public Guid Id { get; set; }
    public Guid CategoryId { get; set; }
    public string Group { get; set; }
    public string Name { get; set; }
    public void CreateMap(Profile profile)
    {
        profile.CreateMap<PermissionView, PermissionViewDto>()
            .ForMember(to => to.Group, c => c.MapFrom(from => from.Group.ToString()))
            .ForMember(to => to.Name, c => c.MapFrom(from => from.Name));
    }
}