﻿using Ewai.Eventis.Domain.Entity.PermissionViews;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Permissions.Dto;

public class PermissionViewCategoryDto
    : IAutoMap<PermissionViewCategory, PermissionViewCategoryDto>
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public List<PermissionViewDto> Views { get; set; }
}