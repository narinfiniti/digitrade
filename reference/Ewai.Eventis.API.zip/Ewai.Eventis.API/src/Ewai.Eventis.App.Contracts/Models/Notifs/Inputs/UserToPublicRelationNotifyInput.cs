using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using System.Text.Json.Nodes;
using AutoMapper;
using Ewai.Common.JsonOptions;
using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Notifs.Inputs;

/// <summary>
/// UserToPublicRelationNotifyInput.
/// </summary>
public class UserToPublicRelationNotifyInput : IAutoMap<UserNotif, UserToPublicRelationNotifyInput>
{
    public UserToPublicRelationNotifyBodyInput Body { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }
    public Guid[] EventUserIds { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<UserToPublicRelationNotifyInput, UserNotif>()
            .ForMember(dest => dest.Body, opt => opt.MapFrom<ValueResolver>())
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }

    public class ValueResolver(
        JsonOps jsonOps)
        : IValueResolver<UserToPublicRelationNotifyInput, UserNotif, JsonNode>
    {
        public JsonNode Resolve(UserToPublicRelationNotifyInput source, UserNotif destination,
            JsonNode destMember, ResolutionContext context)
        {
            return JsonNode.Parse(
                JsonSerializer.Serialize(source.Body, jsonOps.Serialize),
                jsonOps.JsonNodeOps);
        }
    }
}

public class UserToPublicRelationNotifyBodyInput
{
    [MaxLength(20)]public string Title { get; set; }
    [MaxLength(2000)]public string Message { get; set; }
}