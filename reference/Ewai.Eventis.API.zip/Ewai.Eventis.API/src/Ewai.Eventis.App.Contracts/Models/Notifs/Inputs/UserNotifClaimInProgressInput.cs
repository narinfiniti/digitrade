namespace Ewai.Eventis.App.Contracts.Models.Notifs.Inputs
{
    /// <summary>
    /// Request body for claiming a notification (moving it to InProgress).
    /// </summary>
    public class UserNotifClaimInProgressInput
    {
        /// <summary>
        /// The EventUser-ID of the user who is claiming this notification.
        /// </summary>
        public Guid ClaimingUserId { get; set; }
    }
}