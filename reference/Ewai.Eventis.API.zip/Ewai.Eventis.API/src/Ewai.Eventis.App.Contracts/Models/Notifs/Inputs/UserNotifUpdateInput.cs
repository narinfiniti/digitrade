using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using System.Text.Json.Nodes;
using AutoMapper;
using Ewai.Common.JsonOptions;
using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Notifs.Inputs;

/// <summary>
/// UserNotifUpdateInput.
/// </summary>
public class UserNotifUpdateInput : IAutoMap<UserNotif, UserNotifUpdateInput>
{
    public UserNotifUpdateBodyInput Body { get; set; }
    public Guid? SenderUserId { get; set; }
    public Guid[] ReceiverUserIds { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }

    [EnumDataType(typeof(UserNotifStatusEnum))]
    public UserNotifStatusEnum? Status { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<UserNotifUpdateInput, UserNotif>()
            .ForMember(dest => dest.Body, opt => opt.MapFrom<ValueResolver>())
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }

    public class ValueResolver(
        JsonOps jsonOps)
        : IValueResolver<UserNotifUpdateInput, UserNotif, JsonNode>
    {
        public JsonNode Resolve(UserNotifUpdateInput source, UserNotif destination,
            JsonNode destMember, ResolutionContext context)
        {
            return JsonNode.Parse(
                JsonSerializer.Serialize(source.Body, jsonOps.Serialize),
                jsonOps.JsonNodeOps);
        }
    }
}

public class UserNotifUpdateBodyInput
{
    [MaxLength(20)]public string Title { get; set; }
    [MaxLength(2000)]public string Message { get; set; }
}