﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Entity.AppSettings;

namespace Ewai.Eventis.App.Contracts.Models.Notifs.Filters;

public class UserNotifGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    [EnumDataType(typeof(UserNotifStatusEnum))]
    public UserNotifStatusEnum? Status { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }
    public Guid? SenderUserId { get; set; }
    public Guid? ReceiverUserId { get; set; }
}