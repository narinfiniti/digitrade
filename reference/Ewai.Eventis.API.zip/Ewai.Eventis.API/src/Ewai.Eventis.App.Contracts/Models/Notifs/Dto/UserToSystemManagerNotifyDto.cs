using AutoMapper;
using Ewai.Common.Extensions;
using Ewai.Eventis.App.Contracts.Models.TenantEvents.Dto;
using Ewai.Eventis.App.Contracts.Models.Venues.Dto;
using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Notifs.Dto;

/// <summary>
/// UserToSystemManagerNotifyDto.
/// </summary>
public class UserToSystemManagerNotifyDto
    : IAutoMap<UserNotif, UserToSystemManagerNotifyDto>
{
    public Guid Id { get; set; }
    public DateTime DateCreated { get; set; }
    public UserNotifStatusEnum Status { get; set; }
    public string StatusName { get; set; }
    public UserToSystemManagerNotifyBodyDto Body { get; set; }
    public Guid? SenderUserId { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }
    //public DateTime? DateStarted { get; set; }
    //public DateTime? DateCompleted { get; set; }

    public TheEventDto Event { get; set; }
    public VenueDto Venue { get; set; }
    public HashSet<UserNotifReceiverDto> Receivers { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<UserNotif, UserToSystemManagerNotifyDto>()
            .ForMember(dest => dest.Body, opt => opt.MapFrom<ValueResolver>())
            .ForMember(to => to.StatusName, c => c.MapFrom(from => from.Status))
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }

    public class ValueResolver()
        : IValueResolver<UserNotif, UserToSystemManagerNotifyDto, UserToSystemManagerNotifyBodyDto>
    {
        public UserToSystemManagerNotifyBodyDto Resolve(
            UserNotif source, UserToSystemManagerNotifyDto destination,
            UserToSystemManagerNotifyBodyDto destMember, ResolutionContext context)
        {
            return source.Body.As<UserToSystemManagerNotifyBodyDto>();
        }
    }
}

public class UserToSystemManagerNotifyBodyDto
{
    public string Title { get; set; }
    public string Message { get; set; }
}