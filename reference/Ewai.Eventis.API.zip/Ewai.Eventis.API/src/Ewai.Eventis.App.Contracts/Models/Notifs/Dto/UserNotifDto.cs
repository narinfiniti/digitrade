﻿using AutoMapper;
using Ewai.Common.Extensions;
using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Notifs.Dto;

public class UserNotifDto : IAutoMap<UserNotif, UserNotifDto>
{
    public Guid Id { get; set; }
    public DateTime DateCreated { get; set; }
    public UserNotifStatusEnum Status { get; set; }
    public UserNotifBodyDto Body { get; set; }
    public Guid? SenderUserId { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }
    public DateTime? DateStarted { get; set; }
    public DateTime? DateCompleted { get; set; }

    // public TheEventDto Event { get; set; }
    // public VenueDto Venue { get; set; }
    // public HashSet<UserNotifReceiverDto> Receivers { get; set; }
    public void CreateMap(Profile profile)
    {
        profile.CreateMap<UserNotif, UserNotifDto>()
            .ForMember(dest => dest.Body, opt => opt.MapFrom<ValueResolver>())
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }

    public class ValueResolver()
        : IValueResolver<UserNotif, UserNotifDto, UserNotifBodyDto>
    {
        public UserNotifBodyDto Resolve(UserNotif source, UserNotifDto destination,
            UserNotifBodyDto destMember, ResolutionContext context)
        {
            return source.Body.As<UserNotifBodyDto>();
        }
    }
}