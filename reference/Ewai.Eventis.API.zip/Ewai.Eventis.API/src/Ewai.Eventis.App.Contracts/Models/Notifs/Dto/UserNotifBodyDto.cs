namespace Ewai.Eventis.App.Contracts.Models.Notifs.Dto;

public class UserNotifBodyDto
{
    public string Title { get; set; }
    public string Message { get; set; }
}