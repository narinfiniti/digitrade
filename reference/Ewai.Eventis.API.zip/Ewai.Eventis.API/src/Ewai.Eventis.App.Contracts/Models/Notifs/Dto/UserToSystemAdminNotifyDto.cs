using AutoMapper;
using Ewai.Common.Extensions;
using Ewai.Eventis.App.Contracts.Models.TenantEvents.Dto;
using Ewai.Eventis.App.Contracts.Models.Venues.Dto;
using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Notifs.Dto;

/// <summary>
/// UserToSystemAdminNotifyDto.
/// </summary>
public class UserToSystemAdminNotifyDto
    : IAutoMap<UserNotif, UserToSystemAdminNotifyDto>
{
    public Guid Id { get; set; }
    public DateTime DateCreated { get; set; }
    public UserNotifStatusEnum Status { get; set; }
    public string StatusName { get; set; }
    public UserToSystemAdminNotifyBodyDto Body { get; set; }
    public Guid? SenderUserId { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }
    //public DateTime? DateStarted { get; set; }
    //public DateTime? DateCompleted { get; set; }

    public TheEventDto Event { get; set; }
    public VenueDto Venue { get; set; }
    public HashSet<UserNotifReceiverDto> Receivers { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<UserNotif, UserToSystemAdminNotifyDto>()
            .ForMember(dest => dest.Body, opt => opt.MapFrom<ValueResolver>())
            .ForMember(to => to.StatusName, c => c.MapFrom(from => from.Status))
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }

    public class ValueResolver()
        : IValueResolver<UserNotif, UserToSystemAdminNotifyDto, UserToSystemAdminNotifyBodyDto>
    {
        public UserToSystemAdminNotifyBodyDto Resolve(
            UserNotif source, UserToSystemAdminNotifyDto destination,
            UserToSystemAdminNotifyBodyDto destMember, ResolutionContext context)
        {
            return source.Body.As<UserToSystemAdminNotifyBodyDto>();
        }
    }
}

public class UserToSystemAdminNotifyBodyDto
{
    public string Title { get; set; }
    public string Message { get; set; }
}