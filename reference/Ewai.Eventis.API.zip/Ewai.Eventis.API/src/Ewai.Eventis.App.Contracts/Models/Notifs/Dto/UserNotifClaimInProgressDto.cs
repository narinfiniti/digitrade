using AutoMapper;
using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Notifs.Dto
{
    /// <summary>
    /// Response after a successful claimInProgress.
    /// </summary>
    public class UserNotifClaimInProgressDto : IAutoMap<UserNotif, UserNotifClaimInProgressDto>
    {
        public Guid Id { get; set; }
        public UserNotifStatusEnum Status { get; set; }
        public DateTime DateStarted { get; set; }

        public void CreateMap(Profile profile)
        {
            profile.CreateMap<UserNotif, UserNotifClaimInProgressDto>()
                // Map the nullable DateStarted to non-nullable DTO property
                .ForMember(dest => dest.DateStarted,
                    opt => opt.MapFrom(src => src.DateStarted));
        }
    }
}