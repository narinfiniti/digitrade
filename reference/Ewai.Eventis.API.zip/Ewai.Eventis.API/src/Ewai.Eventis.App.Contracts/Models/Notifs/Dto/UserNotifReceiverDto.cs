using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Notifs.Dto;

public class UserNotifReceiverDto : IAutoMap<UserNotifReceiver, UserNotifReceiverDto>
{
    public Guid Id { get; set; }
    public Guid ReceiverUserId { get; set; }
}