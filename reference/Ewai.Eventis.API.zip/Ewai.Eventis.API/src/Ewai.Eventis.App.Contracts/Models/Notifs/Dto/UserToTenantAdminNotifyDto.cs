using AutoMapper;
using Ewai.Common.Extensions;
using Ewai.Eventis.App.Contracts.Models.TenantEvents.Dto;
using Ewai.Eventis.App.Contracts.Models.Venues.Dto;
using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Notifs.Dto;

/// <summary>
/// UserToTenantAdminNotifyDto.
/// </summary>
public class UserToTenantAdminNotifyDto
    : IAutoMap<UserNotif, UserToTenantAdminNotifyDto>
{
    public Guid Id { get; set; }
    public DateTime DateCreated { get; set; }
    public UserNotifStatusEnum Status { get; set; }
    public string StatusName { get; set; }
    public UserToTenantAdminNotifyBodyDto Body { get; set; }
    public Guid? SenderUserId { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }
    //public DateTime? DateStarted { get; set; }
    //public DateTime? DateCompleted { get; set; }

    public TheEventDto Event { get; set; }
    public VenueDto Venue { get; set; }
    public HashSet<UserNotifReceiverDto> Receivers { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<UserNotif, UserToTenantAdminNotifyDto>()
            .ForMember(dest => dest.Body, opt => opt.MapFrom<ValueResolver>())
            .ForMember(to => to.StatusName, c => c.MapFrom(from => from.Status))
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }

    public class ValueResolver()
        : IValueResolver<UserNotif, UserToTenantAdminNotifyDto, UserToTenantAdminNotifyBodyDto>
    {
        public UserToTenantAdminNotifyBodyDto Resolve(
            UserNotif source, UserToTenantAdminNotifyDto destination,
            UserToTenantAdminNotifyBodyDto destMember, ResolutionContext context)
        {
            return source.Body.As<UserToTenantAdminNotifyBodyDto>();
        }
    }
}

public class UserToTenantAdminNotifyBodyDto
{
    public string Title { get; set; }
    public string Message { get; set; }
}