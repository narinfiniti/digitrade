namespace Ewai.Eventis.App.Contracts.Models.VenueMapPositions.Models;

public class VenueMapPositionModel
{
    
}