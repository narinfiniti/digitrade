using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.VenueMapPositions.Dto;

/// <summary>
/// VenueMapPositionDto.
/// </summary>
public class VenueMapPositionDto : IAutoMap<VenueMapPosition, VenueMapPositionDto>
{
    public Guid Id { get; set; }
    
    public short X { get; set; }
    public short Y { get; set; }
    public short Width { get; set; }
    public short Height { get; set; }
}