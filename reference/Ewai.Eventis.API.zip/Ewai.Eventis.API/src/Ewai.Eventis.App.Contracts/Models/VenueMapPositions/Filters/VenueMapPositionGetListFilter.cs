﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.VenueMapPositions.Filters;

/// <summary>
/// VenueMapPositionGetListFilter.
/// </summary>
public class VenueMapPositionGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    
    public Guid? DeskId { get; set; }
    public Guid? ZoneId { get; set; }
    public Guid? TenantId { get; set; }
}