using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.VenueMapPositions.Inputs;

/// <summary>
/// VenueMapPositionUpdateInput.
/// </summary>
public class VenueMapPositionUpdateInput : IAutoMap<VenueMapPosition, VenueMapPositionUpdateInput>
{
    public short X { get; set; }
    public short Y { get; set; }
    public short Width { get; set; }
    public short Height { get; set; }
}