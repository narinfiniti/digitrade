using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.VenueMapPositions.Inputs;

/// <summary>
/// VenueMapPositionCreateInput.
/// </summary>
public class VenueMapPositionCreateInput : IAutoMap<VenueMapPosition, VenueMapPositionCreateInput>
{
    public Guid Id { get; set; }
    
    public short X { get; set; }
    public short Y { get; set; }
    public short Width { get; set; }
    public short Height { get; set; }
}