﻿namespace Ewai.Eventis.App.Contracts.Models.EventUsers.Models;

//TODO:Remove