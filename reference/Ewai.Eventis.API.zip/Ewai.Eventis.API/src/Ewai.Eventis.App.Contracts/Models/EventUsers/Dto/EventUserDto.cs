using AutoMapper;
using Ewai.Eventis.Domain.Entity.TenantEvents;
using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.EventUsers.Dto;

public class EventUserDto : IAutoMap<EventUser, EventUserDto>
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public Guid EventId { get; set; }
    public Guid? VenueId { get; set; }
    public Guid? RoleId { get; set; }
    // public Guid? DeskId { get; set; }
    public Guid? ImageId { get; set; }
    public List<EventUserAvailabilityDto> Availabilities { get; set; }
    public string EventName { get; set; }
    public string VenueName { get; set; }
    public List<VenueDesk> Desks { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<EventUser, EventUserDto>()
            .ForMember(to => to.EventName, c => c.MapFrom(from => from.Event.Name))
            .ForMember(to => to.VenueName, c => c.MapFrom(from => from.Venue.Name))
            ;
    }
}