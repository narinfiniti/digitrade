using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.Roles.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueDesks.Dto;
using Ewai.Eventis.Domain.Entity.TenantEvents;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.EventUsers.Dto;

public class EventUserListDto : IAutoMap<EventUser, EventUserListDto>
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public Guid EventId { get; set; }
    public string EventName { get; set; }
    public Guid? VenueId { get; set; }
    public string VenueName { get; set; }

    public Guid? RoleId { get; set; }
    // public Guid? DeskId { get; set; }
    public Guid? ImageId { get; set; }

    public List<EventUserAvailabilityDto> Availabilities { get; set; }
    public List<VenueDeskDto> Desks { get; set; }
    public List<PermissionDto> Permissions { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<EventUser, EventUserListDto>()
            .ForMember(to => to.EventName, c => c.MapFrom(from => from.Event.Name))
            .ForMember(to => to.VenueName, c => c.MapFrom(from => from.Venue.Name))
            .ForMember(to => to.Desks, c => c.MapFrom(from =>
            from.EventUserVenueDesks.Select(j => j.VenueDesk)));
    }
}