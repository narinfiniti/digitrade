using Ewai.Common.Models;
using Ewai.Eventis.Domain.Entity.TenantEvents;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.EventUsers.Dto;

public class EventUserAvailabilityDto
    : IAutoMap<EventUserAvailability, EventUserAvailabilityDto>
{
    public Guid Id { get; set; }
    public Guid EventUserId { get; set; }

    public DateTime Date { get; set; }
    public RangeOf<TimeSpan> TimeRange { get; set; }
}