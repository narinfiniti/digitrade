using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.TenantEvents;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.EventUsers.Inputs;

/// <summary>
/// EventUserUpdateInput.
/// </summary>
public class EventUserUpdateInput : IAutoMap<EventUser, EventUserUpdateInput>
{
    [Required] public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }

    public Guid? UserRoleId { get; set; }
    // public Guid? DeskId { get; set; }
    public Guid? ImageId { get; set; }
}