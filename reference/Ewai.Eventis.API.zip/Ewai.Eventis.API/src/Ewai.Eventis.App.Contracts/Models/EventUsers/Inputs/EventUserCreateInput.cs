using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.TenantEvents;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.EventUsers.Inputs;

/// <summary>
/// EventUserCreateInput.
/// </summary>
public class EventUserCreateInput : IAutoMap<EventUser, EventUserCreateInput>
{
    [Required] public Guid? UserId { get; set; }
    [Required] public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }

    public Guid? UserRoleId { get; set; }
    // public Guid? DeskId { get; set; }
    public Guid? ImageId { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<EventUserCreateInput, EventUser>()
            .ForMember(to => to.Id, c => c.MapFrom(from => from.UserId))
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }
}