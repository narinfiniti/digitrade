﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Entity.Users;

namespace Ewai.Eventis.App.Contracts.Models.EventUsers.Filters;

/// <summary>
/// EventUserGetListFilter
/// </summary>
public class EventUserGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    [MaxLength(200)] public string UserName { get; set; }
    [MaxLength(200)] public string RoleName { get; set; }
    [MaxLength(100)] public string EventName { get; set; }
    [MaxLength(200)] public string VenueName { get; set; }
    [MaxLength(100)] public string BranchName { get; set; }
    [MaxLength(100)] public string TenantName { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }
    public Guid? RoleId { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? TenantId { get; set; }
    [Range(1, 10), EnumDataType(typeof(RoleTypeEnum))]
    public RoleTypeEnum? RoleType { get; set; }
}