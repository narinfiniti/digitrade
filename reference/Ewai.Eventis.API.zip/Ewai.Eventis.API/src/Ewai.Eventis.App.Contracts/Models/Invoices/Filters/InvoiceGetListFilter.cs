﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Enums;

namespace Ewai.Eventis.App.Contracts.Models.Invoices.Filters;

/// <summary>
/// InvoiceGetListFilter.
/// </summary>
public class InvoiceGetListFilter : PageFilter
{
    [MaxLength(200)] public string Filter { get; set; }
    public Guid? BranchId { get; set; }
    public string InvoiceNumber { get; set; }
    public InvoiceStatusEnum? InvoiceStatusId { get; set; }
    public InvoiceTypeEnum? InvoiceTypeId { get; set; }
    public PaymentTypeEnum? PaymentTypeId { get; set; } 
    public bool? IsDeleted { get; set; }
    public DateTime? CreationTime { get; set; }
    public DateTime? FromCreationTime { get; set; }
    public DateTime? ToCreationTime { get; set; }
    public Guid? RefInvoiceId { get; set; }
    public int? AuthorizationCode { get; set; }
    public decimal? ServiceFees { get; set; }
    public decimal? PrePayment { get; set; }
    public DateTime? PaidDate { get; set; }
    public Guid? ClientId { get; set; }
    public Guid? VenueId { get; set; }
    public Guid? CreatorId { get; set; }
}