namespace Ewai.Eventis.App.Contracts.Models.Invoices.Models;

/// <summary>
/// Pay System Model.
/// </summary>
public class PaySystemModel
{
    public bool IsEnabled { get; set; }
    public string ServiceName { get; set; }
}