﻿using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.Orders.Dto;
using Ewai.Eventis.App.Contracts.Models.TenantClients.Dto;
using Ewai.Eventis.Domain.Entity.Invoices;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Invoices.Dto;

/// <summary>
/// InvoiceListDto.
/// </summary>
public class InvoiceListDto : IAutoMap<Invoice, InvoiceListDto>
{
    public Guid Id { get; set; }
    // public Guid BranchId { get; set; }
    // public List<InvoiceImageDto> FeedImageUrls { get; set; }
    public string TenantName { get; set; }
    public PaymentTypeEnum PaymentTypeId { get; set; } //ok
    public string PaymentType { get; set; }
    public string Number { get; set; }
    public string Status { get; set; }
    public DateTime DateCreated { get; set; }
    public DateTime DatePaid { get; set; }
    public decimal Discount { get; set; } //ok
    public decimal ServiceFees { get; set; }
    public decimal PrePayment { get; set; }
    public decimal SubTotal { get; set; } //ok
    public decimal Vat { get; set; } //ok
    public decimal Total { get; set; } //ok
    public decimal AmountPaid { get; set; } //ok
    public string ReceiptNumber { get; set; }
    public string ApprovalCode { get; set; }
    public Guid? PaymentTerminalId { get; set; }
    public List<InvoiceItemDto> Items { get; set; }
    public List<InvoicePaymentLogDto> InvoicePaymentLogs { get; set; }

    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }
    public Guid? ClientId { get; set; }
    public TenantClientDto Client { get; set; }
    public InvoiceVenueDeskDto Desk { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<Invoice, InvoiceListDto>()
            // .ForMember(to => to.FeedImageUrls, c => c.MapFrom(from => from.InvoiceImages))
            .ForMember(to => to.TenantName, c => c.MapFrom(from => from.Tenant.Name))
            .ForMember(to => to.Status, c => c.MapFrom(from => from.StatusId.ToString()))
            .ForMember(to => to.PaymentType, c => c.MapFrom(from => from.PaymentTypeId.ToString()))
            .ForMember(to => to.Items, c => c.MapFrom(from => from.InvoiceItems));
            // .ForMember(to => to.EventId, c => c.MapFrom(from => from.EventId))
            // .ForMember(to => to.VenueId, c => c.MapFrom(from => from.VenueId))
            // .ForMember(to => to.ClientId, c => c.MapFrom(from => from.ClientId));
    }
}