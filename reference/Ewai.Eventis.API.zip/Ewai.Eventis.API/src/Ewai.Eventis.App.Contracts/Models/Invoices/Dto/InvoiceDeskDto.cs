namespace Ewai.Eventis.App.Contracts.Models.Invoices.Dto;

public class InvoiceDeskDto
{
    public string DeskNo { get; set; }
    public Guid DeskId { get; set; }
}