using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Invoices.Dto;

/// <summary>
/// InvoiceVenueDeskDto.
/// </summary>
public class InvoiceVenueDeskDto : IAutoMap<VenueDesk, InvoiceVenueDeskDto>
{
    public Guid Id { get; set; }

    public string No { get; set; }
    public short CapacityOfPeople { get; set; }
    public short SizeDiameter { get; set; }
    public string ColorCode { get; set; }
    public decimal MinSpend { get; set; }
    public Guid? ZoneId { get; set; }
    public string QrCode { get; set; }

    // public VenueMapPositionDto Position { get; set; }
    // public VenueZoneDto Zone { get; set; }
    // public VenueDto Venue { get; set; }
    //public HashSet<ClientBookingDto> Bookings { get; set; }
    //public HashSet<EventUserDto> Users { get; set; }
}