﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Invoices;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Invoices.Dto;

public class InvoiceImageDto
    : IAutoMap<InvoiceImage, InvoiceImageDto>
{
    public string ImageUrl { get; set; }
    public void CreateMap(Profile profile)
    {
        // profile.CreateMap<InvoiceImage, InvoiceImageDto>()
        //     .ForMember(to => to.ImageUrl, c => c.MapFrom<UrlValueResolver>());
    }
}