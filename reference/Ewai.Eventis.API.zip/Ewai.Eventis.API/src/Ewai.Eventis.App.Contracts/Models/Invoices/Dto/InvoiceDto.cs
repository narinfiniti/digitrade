﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Invoices;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Invoices.Dto;

/// <summary>
/// InvoiceDto.
/// </summary>
public class InvoiceDto : IAutoMap<Invoice, InvoiceDto>
{
    public Guid Id { get; set; }
    // public Guid BranchId { get; set; }
    // public List<InvoiceImageDto> FeedImageUrls { get; set; }
    public string TenantName { get; set; }
    public PaymentTypeEnum PaymentTypeId { get; set; } //ok
    public string PaymentType { get; set; }
    public string Number { get; set; }
    public string Status { get; set; }
    public DateTime Date { get; set; }
    public decimal Discount { get; set; } //ok
    public decimal SubTotal { get; set; } //ok
    public decimal Vat { get; set; } //ok
    public decimal Total { get; set; } //ok
    public string ReceiptNumber { get; set; }
    public string ApprovalCode { get; set; }
    public Guid? PaymentTerminalId { get; set; }
    public List<InvoiceItemDto> Items { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<Invoice, InvoiceDto>()
            // .ForMember(to => to.FeedImageUrls, c => c.MapFrom(from => from.InvoiceImages))
            .ForMember(to => to.TenantName, c => c.MapFrom(from => from.Tenant.Name))
            .ForMember(to => to.Date, c => c.MapFrom(from => from.DatePaid))
            .ForMember(to => to.Status, c => c.MapFrom(from => from.StatusId.ToString()))
            .ForMember(to => to.Number, c => c.MapFrom(from => from.Number))
            .ForMember(to => to.PaymentType, c => c.MapFrom(from => from.PaymentTypeId.ToString()))
            .ForMember(to => to.Items, c => c.MapFrom(from => from.InvoiceItems));
    }
}