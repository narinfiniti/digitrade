﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Invoices;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Invoices.Dto;

public class InvoiceItemDto
    : IAutoMap<InvoiceItem, InvoiceItemDto>
{
    public Guid Id { get; set; }
    public string Barcode { get; set; }
    public string InternalBarcode { get; set; }
    public string Name { get; set; }
    public string ImageUrl { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal Quantity { get; set; }

    public decimal Discount { get; set; }
    public decimal Vat { get; set; }
    public decimal SubTotal { get; set; }
    public decimal Total { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<InvoiceItem, InvoiceItemDto>()
            .ForMember(to => to.Name, c => c.MapFrom(from => from.ProductName))
            .ForMember(to => to.Barcode, c => c.MapFrom(from => from.ProductBarcode));
        // .ForMember(to => to.ImageUrl, c => c.MapFrom<UrlValueResolver>());
    }
}