﻿namespace Ewai.Eventis.App.Contracts.Models.Invoices.Dto;

public class SendInvoiceViaEmailDto
{
    public Stream ExcelStream { get; set; }
    public Stream PdfStream { get; set; }
    public string Email { get; set; }
    public string InvoiceNumber { get; set; }
}