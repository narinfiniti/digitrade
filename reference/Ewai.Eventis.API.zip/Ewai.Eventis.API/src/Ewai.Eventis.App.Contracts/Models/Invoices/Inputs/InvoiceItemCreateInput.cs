﻿using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.Invoices;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Invoices.Inputs;

public class InvoiceItemCreateInput
    : IAutoMap<InvoiceItem, InvoiceItemCreateInput>
{
    public Guid? InvoiceId { get; set; }
    public Guid? ProductId { get; set; }

    [Required, MaxLength(200)]public string ProductBarcode { get; set; }
    [Required, Range(0, 10_000_000.0)] public decimal? Quantity { get; set; }

    [MaxLength(200)]public string ProductName { get; set; }
    [Range(0, 10_000_000.0)] public decimal UnitPrice { get; set; }
    [Range(0, 10_000_000.0)] public decimal Vat { get; set; }
    [Range(0, 10_000_000.0)] public decimal Discount { get; set; }
}