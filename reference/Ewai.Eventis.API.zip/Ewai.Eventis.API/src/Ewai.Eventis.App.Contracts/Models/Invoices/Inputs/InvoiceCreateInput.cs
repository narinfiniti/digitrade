using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.Orders.Inputs;
using Ewai.Eventis.Domain.Entity.Invoices;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Invoices.Inputs;

public class InvoiceCreateInput
    : IAutoMap<Invoice, InvoiceCreateInput>
        , IAutoMap<OrderCashierCreateInput, InvoiceCreateInput>
{
    public Guid? TenantId { get; set; }
    public Guid? RequestId { get; set; }
    [Required] public Guid? ClientId { get; set; }
    [EnumDataType(typeof(InvoiceStatusEnum))] public InvoiceStatusEnum StatusId { get; set; }
    [EnumDataType(typeof(InvoiceTypeEnum))] public InvoiceTypeEnum TypeId { get; set; }
    [EnumDataType(typeof(PaymentTypeEnum))] public PaymentTypeEnum PaymentTypeId { get; set; }
    [Range(0, 10_000_000.0)] public decimal? ServiceFees { get; set; }
    [Range(0, 10_000_000.0)] public decimal? PrePayment { get; set; }
    [Range(0, 10_000_000.0)] public decimal? Discount { get; set; }
    [Range(0, 10_000_000)]public int? AuthorizationCode { get; set; }
    [MaxLength(50)] public string ReceiptNumber { get; set; }
    public Guid? RefInvoiceId { get; set; }

    public List<InvoiceItemCreateInput> InvoiceItems { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<InvoiceCreateInput, Invoice>()
            .ForMember(to => to.PaymentTypeId, c => c.MapFrom(from => from.PaymentTypeId))
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));

        profile.CreateMap<OrderCashierCreateInput, InvoiceCreateInput>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }
}