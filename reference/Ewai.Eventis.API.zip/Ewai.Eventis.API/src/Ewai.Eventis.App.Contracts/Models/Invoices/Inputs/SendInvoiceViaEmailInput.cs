﻿using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.Invoices.Inputs;

public class SendInvoiceViaEmailInput
{
    [Required, MaxLength(6)] public string InvoiceNumber { get; set; }

    [Required, RegularExpression(pattern: "^\\S+@\\S+\\.\\S+$", ErrorMessage = "Email address is not valid"),
     MaxLength(256)]
    public string Email { get; set; }
}