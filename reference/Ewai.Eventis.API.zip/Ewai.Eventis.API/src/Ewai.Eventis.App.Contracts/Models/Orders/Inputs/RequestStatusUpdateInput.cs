using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Inputs;

/// <summary>
/// RequestUpdateInput.
/// </summary>
public class RequestStatusUpdateInput : IAutoMap<Request, RequestStatusUpdateInput>
{
    public Guid Id { get; set; }
    public RequestStageEnum? StageId { get; set; }
    public RequestStatusEnum StatusId { get; set; }
    public PaymentTypeEnum? PaymentTypeId { get; set; }
    

    // public void CreateMap(Profile profile)
    // {
    //     profile.CreateMap<RequestStatusUpdatedNotifyInput, Request>()
    //         .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    //     profile.CreateMap<RequestStageEnum?, RequestStageEnum>().ConvertUsing((src, dest) => src ?? dest);
    //     profile.CreateMap<RequestTypeEnum?, RequestTypeEnum>().ConvertUsing((src, dest) => src ?? dest);
    //     profile.CreateMap<RequestStatusEnum?, RequestStatusEnum>().ConvertUsing((src, dest) => src ?? dest);
    // }
    
}