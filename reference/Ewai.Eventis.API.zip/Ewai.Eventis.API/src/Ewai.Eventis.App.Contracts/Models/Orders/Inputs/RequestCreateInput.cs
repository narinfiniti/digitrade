using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Inputs;

/// <summary>
/// RequestCreateInput.
/// </summary>
public class RequestCreateInput : IAutoMap<Request, RequestCreateInput>
{
    public Guid? TenantId { get; set; }
    public Guid? ClientId { get; set; }
    public Guid? BookingId { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }

    [MaxLength(10)] public string Number { get; set; }
    [EnumDataType(typeof(RequestTypeEnum))] public RequestTypeEnum TypeId { get; set; }
    [EnumDataType(typeof(RequestStageEnum))] public RequestStageEnum StageId { get; set; }
    [EnumDataType(typeof(RequestStatusEnum))] public RequestStatusEnum StatusId { get; set; }
    [EnumDataType(typeof(PaymentTypeEnum))] public PaymentTypeEnum? PaymentTypeId { get; set; }

    [Range(0.000_001, double.MaxValue)] public decimal SubTotal { get; set; }
    [Range(0.000_001, double.MaxValue)] public decimal Vat { get; set; }
    [Range(0.000_001, double.MaxValue)] public decimal Discount { get; set; }
    [Range(0.000_001, double.MaxValue)] public decimal ServiceFees { get; set; }
    [Range(0.000_001, double.MaxValue)] public decimal Total { get; set; }

    [MaxLength(200)] public string Address { get; set; }
    [MaxLength(1000)] public string Details { get; set; }
}