using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Inputs;

/// <summary>
/// RequestUpdateInput.
/// </summary>
public class RequestUpdateInput : IAutoMap<Request, RequestUpdateInput>
{
    public Guid? TenantId { get; set; }
    public Guid? ClientId { get; set; }
    public Guid? BookingId { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }

    [MaxLength(10)] public string Number { get; set; }
    [EnumDataType(typeof(RequestTypeEnum))] public RequestTypeEnum TypeId { get; set; }
    [EnumDataType(typeof(RequestStageEnum))] public RequestStageEnum StageId { get; set; }
    [EnumDataType(typeof(RequestStatusEnum))] public RequestStatusEnum StatusId { get; set; }
    [EnumDataType(typeof(PaymentTypeEnum))] public PaymentTypeEnum? PaymentTypeId { get; set; }
    
    [Range(0.000_001, double.MaxValue)] public decimal SubTotal { get; set; }
    [Range(0.000_001, double.MaxValue)] public decimal Vat { get; set; }
    [Range(0.000_001, double.MaxValue)] public decimal Discount { get; set; }
    [Range(0.000_001, double.MaxValue)] public decimal ServiceFees { get; set; }
    [Range(0.000_001, double.MaxValue)] public decimal Total { get; set; }

    [MaxLength(200)] public string Address { get; set; }
    [MaxLength(1000)] public string Details { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<RequestUpdateInput, Request>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
        profile.CreateMap<RequestTypeEnum?, RequestTypeEnum>().ConvertUsing((src, dest) => src ?? dest);
        profile.CreateMap<RequestStageEnum?, RequestStageEnum>().ConvertUsing((src, dest) => src ?? dest);
        profile.CreateMap<RequestStatusEnum?, RequestStatusEnum>().ConvertUsing((src, dest) => src ?? dest);
        profile.CreateMap<PaymentTypeEnum?, PaymentTypeEnum>().ConvertUsing((src, dest) => src ?? dest);
    }
}