using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.OrderProducts.Inputs;
using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Inputs;

/// <summary>
/// RequestDto.
/// </summary>
public class OrderCashierCreateInput
    : IAutoMap<Request, OrderCashierCreateInput>
{
    public Guid? TenantId { get; set; }
    [Required] public Guid? ClientId { get; set; }
    [Required] public Guid? BookingId { get; set; }
    [Required]  public Guid? VenueId { get; set;}
    [EnumDataType(typeof(RequestTypeEnum))] public RequestTypeEnum? TypeId { get; set; }
    [EnumDataType(typeof(RequestStageEnum))] public RequestStageEnum? StageId { get; set; }
    [EnumDataType(typeof(RequestStatusEnum))] public RequestStatusEnum? StatusId { get; set; }
    [EnumDataType(typeof(PaymentTypeEnum))] public PaymentTypeEnum? PaymentTypeId { get; set; }
    [Range(0, 10_000_000.0)] public decimal? ServiceFees { get; set; }
    [Range(0, 10_000_000.0)] public decimal? PrePayment { get; set; }
    [Range(0, 10_000_000.0)] public decimal? Discount { get; set; }
    [MaxLength(500)] public string Details { get; set; }
    // [MaxLength(50)] public string ReceiptNumber { get; set; }
    [Range(0, 10_000_000)] public int? AuthorizationCode { get; set; }

    public List<RequestProductCreateInput> RequestProducts { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<OrderCashierCreateInput, Request>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }
}