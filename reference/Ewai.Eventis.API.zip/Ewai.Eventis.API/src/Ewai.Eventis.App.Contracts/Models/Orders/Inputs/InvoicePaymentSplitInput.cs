﻿using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Enums;
using Ewai.Eventis.Domain.Models;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Inputs;

public sealed class InvoicePaymentSplitInput
    : IAutoMap<InvoicePaymentSplitModel, InvoicePaymentSplitInput>
{
    [EnumDataType(typeof(PaymentTypeEnum))]
    public PaymentTypeEnum PaymentTypeId { get; set; }

    [Range(0.000_001, double.MaxValue)]
    public decimal Amount { get; set; }
}