using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Inputs;

public class OrderPreCheckoutInput
{
    // public Guid? TenantId { get; set; }
    [Required] public Guid? BookingId { get; set; }
    [Range(0, double.MaxValue)] public decimal? ServiceFees { get; set; }
    [Range(0, double.MaxValue)] public decimal? Discount { get; set; }
}