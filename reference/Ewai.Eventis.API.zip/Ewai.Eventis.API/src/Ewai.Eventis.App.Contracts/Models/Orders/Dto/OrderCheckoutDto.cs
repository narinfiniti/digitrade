﻿using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.Invoices.Dto;
using Ewai.Eventis.Domain.Entity.Invoices;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Dto;

/// <summary>
/// OrderCheckoutDto.
/// </summary>
public class OrderCheckoutDto : IAutoMap<Invoice, OrderCheckoutDto>
{
    public Guid Id { get; set; }
    // public Guid BranchId { get; set; }
    public string TenantName { get; set; }
    public PaymentTypeEnum PaymentTypeId { get; set; }
    public string PaymentType { get; set; }
    public string Number { get; set; }
    public string Status { get; set; }
    public DateTime Date { get; set; }
    public decimal Discount { get; set; }
    public decimal ServiceFees { get; set; }
    public decimal PrePayment { get; set; }
    public decimal SubTotal { get; set; }
    public decimal Vat { get; set; }
    public decimal Total { get; set; }
    public string ReceiptNumber { get; set; }
    public string ApprovalCode { get; set; }
    public Guid? PaymentTerminalId { get; set; }
    public List<InvoiceItemDto> Items { get; set; }
    public List<InvoicePaymentLogDto> InvoicePaymentLogs { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<Invoice, OrderCheckoutDto>()
            // .ForMember(to => to.FeedImageUrls, c => c.MapFrom(from => from.InvoiceImages))
            .ForMember(to => to.TenantName, c => c.MapFrom(from => from.Tenant.Name))
            .ForMember(to => to.Date, c => c.MapFrom(from => from.DateCreated))
            .ForMember(to => to.Status, c => c.MapFrom(from => from.StatusId))
            .ForMember(to => to.Number, c => c.MapFrom(from => from.Number))
            .ForMember(to => to.PaymentType, c => c.MapFrom(from => from.PaymentTypeId))
            .ForMember(to => to.Items, c => c.MapFrom(from => from.InvoiceItems));
    }
}