using AutoMapper;
using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Dto;

/// <summary>
/// RequestStatusUpdatedNotifyDto.
/// </summary>
public class RequestStatusUpdateDto : IAutoMap<Request, RequestStatusUpdateDto>
{
    public Guid Id { get; set; }
    public RequestStageEnum StageId { get; set; }
    public RequestStatusEnum StatusId { get; set; }
    public PaymentTypeEnum? PaymentTypeId { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<Request, RequestStatusUpdateDto>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
        profile.CreateMap<RequestStageEnum?, RequestStageEnum>().ConvertUsing((src, dest) => src ?? dest);
        profile.CreateMap<RequestTypeEnum?, RequestTypeEnum>().ConvertUsing((src, dest) => src ?? dest);
        profile.CreateMap<RequestStatusEnum?, RequestStatusEnum>().ConvertUsing((src, dest) => src ?? dest);
    }
}