using Ewai.Eventis.App.Contracts.Models.OrderProducts.Dto;
using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Dto;

/// <summary>
/// RequestDto.
/// </summary>
public class OrderCashierCreateDto : IAutoMap<Request, OrderCashierCreateDto>
{
    public Guid Id { get; set; }

    public Guid TenantId { get; set; }
    //public Guid? BranchId { get; set; }
    public DateTime DateCreated { get; set; }
    public string Number { get; set; }
    public RequestTypeEnum TypeId { get; set; }
    public RequestStageEnum StageId { get; set; }
    public RequestStatusEnum StatusId { get; set; }

    public decimal SubTotal { get; set; }
    public decimal Vat { get; set; }
    public decimal Discount { get; set; }
    public decimal ServiceFees { get; set; }
    public decimal PrePayment { get; set; }
    public decimal Total { get; set; }

    public PaymentTypeEnum? PaymentTypeId { get; set; }

    public Guid? ClientId { get; set; }
    public Guid? VenueId { get; set; }
    public Guid? CreatorId { get; set; }
    public Guid? LastModifierId { get; set; }
    public DateTime? DateModified { get; set; }
    public DateTime? DateDelivered { get; set; }

    public string Address { get; set; }
    public string Details { get; set; }

    public List<RequestProductDto> RequestProducts { get; set; }
}