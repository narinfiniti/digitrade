﻿using Ewai.Eventis.Domain.Entity.Invoices;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Dto;

public sealed class InvoicePaymentLogDto : IAutoMap<InvoicePaymentLog, InvoicePaymentLogDto>
{
    public Guid InvoiceId { get; set; }
    public PaymentTypeEnum PaymentTypeId { get; set; }
    public decimal Total { get; set; }
    public DateTime DateCreated { get; set; }
}