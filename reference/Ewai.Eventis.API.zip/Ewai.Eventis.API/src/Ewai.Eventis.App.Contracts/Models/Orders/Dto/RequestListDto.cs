﻿using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.OrderProducts.Dto;
using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Dto;

/// <summary>
/// RequestListDto.
/// </summary>
public class RequestListDto : IAutoMap<Request, RequestListDto>
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public object TenantName { get; set; }
    public DateTime DateCreated { get; set; }
    public string Number { get; set; }
    public RequestTypeEnum TypeId { get; set; }
    public RequestStageEnum StageId { get; set; }
    public RequestStatusEnum StatusId { get; set; }

    public decimal SubTotal { get; set; }
    public decimal Vat { get; set; }
    public decimal Discount { get; set; }
    public decimal ServiceFees { get; set; }
    public decimal Total { get; set; }
    public PaymentTypeEnum? PaymentTypeId { get; set; }
    //public Guid? BranchId { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }
    public Guid? ClientId { get; set; }
    public Guid? BookingId { get; set; }
    public Guid? InvoiceId { get; set; }
    public Guid? CreatorId { get; set; }
    public Guid? LastModifierId { get; set; }
    public DateTime? DateModified { get; set; }
    public DateTime? DateDelivered { get; set; }

    public string Address { get; set; }
    public string Details { get; set; }
    public HashSet<RequestProductDto> RequestProducts { get; set; }
    public RequestVenueDeskDto Desk { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<Request, RequestListDto>()
            .ForMember(to => to.TenantName, c => c.MapFrom(from => from.Tenant.Name))
            .ForMember(to => to.Desk, c => c.MapFrom(from => from.Booking.Desk));
    }
}