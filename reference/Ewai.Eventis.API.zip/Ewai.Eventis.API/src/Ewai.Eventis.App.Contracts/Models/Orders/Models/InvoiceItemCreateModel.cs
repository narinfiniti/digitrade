﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.Eventis.Domain.Entity.Products;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Models;

public class InvoiceItemCreateModel
    : IAutoMap<TenantProduct, InvoiceItemCreateModel>
        ,IAutoMap<RequestProduct, InvoiceItemCreateModel>
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    //public Guid? BranchId { get; set; }
    public string Name { get; set; }
    public string Barcode { get; set; }
    public string InternalBarcode { get; set; }
    public string Unit { get; set; }
    public bool IsWeightBased { get; set; }
    public bool IsProhibited { get; set; }
    public bool IsShoppingBag { get; set; }

    public decimal UnitCost { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal Vat { get; set; }
    public decimal Discount { get; set; }
    public decimal Quantity { get; set; }
    public decimal? QtySold { get; set; }
    public decimal? QtyMissing { get; set; }
    public decimal? QtyDamaged { get; set; }
    public decimal? QtyRevoked { get; set; }

    public Guid? CategoryId { get; set; }
    public Guid? SubCategoryId { get; set; }
    public Guid? ImageId { get; set; }
    public string ProductName { get; set; }
    public string ProductBarcode { get; set; }
    public decimal Total { get; set; }
    public Guid? ProductId { get; set; }
    public DateTime? DateModified { get; set; }
    public Guid? LastModifierId { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantProduct, InvoiceItemCreateModel>();
        profile.CreateMap<RequestProduct, InvoiceItemCreateModel>()
            .ForMember(to => to.Name, c => c.MapFrom(from => from.ProductName))
            .ForMember(to => to.Barcode, c => c.MapFrom(from => from.ProductBarcode))
            .ForMember(to => to.Id, c => c.MapFrom(from => from.ProductId));
    }
}