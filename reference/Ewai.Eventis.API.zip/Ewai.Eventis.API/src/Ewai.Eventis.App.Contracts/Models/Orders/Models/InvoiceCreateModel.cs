using AutoMapper;
using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Models;

public class InvoiceCreateModel: IAutoMap<Request, InvoiceCreateModel>
{
    public Guid TenantId { get; set; }
    public Guid Id { get; set; }

    public DateTime DateCreated { get; set; }
    public string Number { get; set; }
    public RequestTypeEnum TypeId { get; set; }
    public RequestStageEnum StageId { get; set; }
    public RequestStatusEnum StatusId { get; set; }

    public decimal Discount { get; set; }
    public decimal Vat { get; set; }
    public decimal SubTotal { get; set; }
    public decimal Total { get; set; }

    public decimal ServiceFees { get; set; }
    public decimal PrePayment { get; set; }
    public string Address { get; set; }
    public string Details { get; set; }

    public PaymentTypeEnum? PaymentTypeId { get; set; }
    //public Guid? BranchId { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }
    public Guid? ClientId { get; set; }
    public Guid? BookingId { get; set; }
    public Guid? InvoiceId { get; set; }
    public Guid? CreatorId { get; set; }
    public Guid? LastModifierId { get; set; }
    public DateTime? DateModified { get; set; }
    public DateTime? DateDelivered { get; set; }

    public List<InvoiceItemCreateModel> InvoiceItems { get; set; } = [];
    public void CreateMap(Profile profile)
    {
        profile.CreateMap<Request, InvoiceCreateModel>()
            .ForMember(to => to.InvoiceItems, c => c.MapFrom(from => from.RequestProducts))
            // .ForMember(to => to.Barcode, c => c.MapFrom(from => from.ProductBarcode))
            // .ForMember(to => to.Id, c => c.MapFrom(from => from.ProductId))
            ;
    }
}