﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Enums;

namespace Ewai.Eventis.App.Contracts.Models.Orders.Filters;

/// <summary>
/// RequestGetListFilter.
/// </summary>
public class RequestGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    public Guid? TenantId { get; set; }
    public Guid? BookingId { get; set; }
    public string Number { get; set; }
    public RequestStatusEnum? Status { get; set; }
    public List<RequestStatusEnum> StatusList { get; set; } 
    public bool? HaveInvoice { get; set; }
}