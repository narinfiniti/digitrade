﻿using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.AppSettings.Filters;

public class AppSettingGetListFilter : PageFilter
{
    public List<string> Keys { get; set; }
    public bool? IsPredefined { get; set; }
}