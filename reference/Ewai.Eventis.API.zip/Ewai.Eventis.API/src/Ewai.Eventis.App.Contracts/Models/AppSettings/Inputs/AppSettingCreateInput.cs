﻿using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.AppSettings.Inputs;

public class AppSettingCreateInput : IAutoMap<AppSettingCreateInput, AppSetting>
{
    [Required, MaxLength(1000)] public string Key { get; set; }
    [Required, MaxLength(4000)] public string Value { get; set; }
}