﻿using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.AppSettings.Inputs;

public class AppSettingUpdateInput : IAutoMap<AppSettingUpdateInput, AppSetting>
{
    [MaxLength(1000)] public string Key { get; set; }
    [MaxLength(4000)] public string Value { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<AppSettingUpdateInput, AppSetting>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
    }
}