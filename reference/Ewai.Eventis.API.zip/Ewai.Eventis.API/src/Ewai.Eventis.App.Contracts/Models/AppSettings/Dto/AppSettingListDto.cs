﻿using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.AppSettings.Dto;

public class AppSettingListDto : IAutoMap<AppSetting, AppSettingListDto>
{
    public Guid Id { get; set; }
    public string Key { get; set; }
    public string Value { get; set; }
    public bool IsPredefined { get; set; }
}