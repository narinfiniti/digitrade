using Ewai.Eventis.Domain.Entity.Devices;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.DevicesFcm.Dto;

public class UserDeviceFcmDto : IAutoMap<UserDeviceFcm, UserDeviceFcmDto>
{
    public Guid Id { get; set; }
    public string DeviceId { get; set; }
    public string FirebaseProjectId { get; set; }
    public DateTime? DateModified { get; set; }
    public string FirebaseToken { get; set; }
}