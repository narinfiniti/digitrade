using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.Devices;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.DevicesFcm.Inputs;

/// <summary>
/// UserDeviceFcmRegisterInput.
/// </summary>
public class UserDeviceFcmRegisterInput : IAutoMap<UserDeviceFcm, UserDeviceFcmRegisterInput>
{
    [Required, MaxLength(100)] public string RoleName { get; set; }
    [Required, StringLength(1000, MinimumLength = 8)] public string DeviceId { get; set; }
    [Required, MaxLength(100)] public string FirebaseProjectId { get; set; }
    [Required, MaxLength(500)] public string FirebaseToken { get; set; }
}