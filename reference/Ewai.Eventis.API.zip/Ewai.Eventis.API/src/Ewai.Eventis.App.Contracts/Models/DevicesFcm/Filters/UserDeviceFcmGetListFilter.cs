using System.ComponentModel.DataAnnotations;
using Ewai.Common.Attributes;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.DevicesFcm.Filters;

public class UserDeviceFcmGetListFilter : PageFilter
{
    public Guid[] UserIds { get; set; }
    [MaxLengthValuesList(1000)] public string[] DeviceIds { get; set; }

    [MaxLength(500)] public string FirebaseProjectId { get; set; }
}