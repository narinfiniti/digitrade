﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Enums;

namespace Ewai.Eventis.App.Contracts.Models.TenAppSubs.Filters;

/// <summary>
/// AppSubGetListFilter.
/// </summary>
public class AppSubGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    [Range(1, 10),EnumDataType(typeof(PlatformSubscriptionTypeEnum))]
    public PlatformSubscriptionTypeEnum? Type { get; set; }
}