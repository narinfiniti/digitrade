using AutoMapper;
using Ewai.Eventis.Domain.Entity.Platform;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenAppSubs.Dto;

/// <summary>
/// AppSubDto.
/// </summary>
public class AppSubDto
    : IAutoMap<PlatformSubscription, AppSubDto>
{
    public Guid Id { get; set; }
    public PlatformSubscriptionTypeEnum Type { get; set; }
    public string TypeName { get; set; }
    public decimal FeeMonthly { get; set; }
    public decimal FeeMonthlyAdditional { get; set; }
    public decimal DiscountPrepaid { get; set; }
    public decimal FeeAnnualLicense { get; set; }
    public decimal FeePerVenue { get; set; }
    public string Description { get; set; }
    public short? VenuesLimit { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<PlatformSubscription, AppSubDto>()
            .ForMember(to => to.TypeName, c => c.MapFrom(from => from.Type));
    }
}