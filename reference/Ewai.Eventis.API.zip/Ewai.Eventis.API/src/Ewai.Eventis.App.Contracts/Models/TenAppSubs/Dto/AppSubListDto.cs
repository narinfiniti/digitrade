﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Platform;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenAppSubs.Dto;

/// <summary>
/// AppSubListDto.
/// </summary>
public class AppSubListDto
    : IAutoMap<PlatformSubscription, AppSubListDto>
{
    public Guid Id { get; set; }
    public PlatformSubscriptionTypeEnum Type { get; set; }
    public string TypeName { get; set; }
    public decimal FeeMonthly { get; set; }
    public decimal FeeMonthlyAdditional { get; set; }
    public decimal DiscountPrepaid { get; set; }
    public decimal FeeAnnualLicense { get; set; }
    public decimal FeePerVenue { get; set; }
    public string Description { get; set; }
    public decimal? VenuesLimitAnnual { get; set; }
    public decimal? VenuesLimitMonthly { get; set; }
    public decimal? FeePerVenueAdditional { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<PlatformSubscription, AppSubListDto>()
            .ForMember(to => to.TypeName, c => c.MapFrom(from => from.Type));
    }
}