namespace Ewai.Eventis.App.Contracts.Models.TenAppSubs.Models;

public class AppSubModel
{
    
}