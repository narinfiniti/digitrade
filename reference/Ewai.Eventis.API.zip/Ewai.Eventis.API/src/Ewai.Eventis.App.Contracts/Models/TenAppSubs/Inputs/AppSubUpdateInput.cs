using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.Platform;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenAppSubs.Inputs;

/// <summary>
/// AppSubUpdateInput.
/// </summary>
public class AppSubUpdateInput
    : IAutoMap<PlatformSubscription, AppSubUpdateInput>
{
    [EnumDataType(typeof(PlatformSubscriptionTypeEnum))]
    public PlatformSubscriptionTypeEnum? Type { get; set; }

    public decimal? FeeMonthly { get; set; }
    public decimal? FeeMonthlyAdditional { get; set; }
    public decimal? DiscountPrepaid { get; set; }
    public decimal? FeeAnnualLicense { get; set; }
    public decimal? FeePerVenue { get; set; }
    [MaxLength(500)] public string Description { get; set; }
    public short? VenuesLimit { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<AppSubUpdateInput, PlatformSubscription>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
        profile.CreateMap<PlatformSubscriptionTypeEnum?, PlatformSubscriptionTypeEnum>()
            .ConvertUsing((src, dest) => src ?? dest);
        profile.CreateMap<decimal?, decimal>().ConvertUsing((src, dest) => src ?? dest);
        profile.CreateMap<short?, short>().ConvertUsing((src, dest) => src ?? dest);
    }
}