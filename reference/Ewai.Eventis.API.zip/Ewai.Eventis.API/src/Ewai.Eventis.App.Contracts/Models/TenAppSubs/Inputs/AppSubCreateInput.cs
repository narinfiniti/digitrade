using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.Platform;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenAppSubs.Inputs;

/// <summary>
/// AppSubCreateInput.
/// </summary>
public class AppSubCreateInput
    : IAutoMap<PlatformSubscription, AppSubCreateInput>
{
    [Required, EnumDataType(typeof(PlatformSubscriptionTypeEnum))]
    public PlatformSubscriptionTypeEnum? Type { get; set; }

    [Required] public decimal? FeeMonthly { get; set; }
    [Required] public decimal? FeeMonthlyAdditional { get; set; }
    [Required] public decimal? DiscountPrepaid { get; set; }
    [Required] public decimal? FeeAnnualLicense { get; set; }
    [Required] public decimal? FeePerVenue { get; set; }
    [Required, MaxLength(500)] public string Description { get; set; }
    public short? VenuesLimit { get; set; }
    public decimal? VenuesLimitAnnual { get; set; }
    public decimal? VenuesLimitMonthly { get; set; }
    public decimal? FeePerVenueAdditional { get; set; }
}