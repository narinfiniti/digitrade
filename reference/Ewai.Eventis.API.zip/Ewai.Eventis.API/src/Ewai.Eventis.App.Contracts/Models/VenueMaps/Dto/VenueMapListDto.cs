﻿using AutoMapper;
using Ewai.Eventis.App.Contracts.Models.BlobFiles.Extensions;
using Ewai.Eventis.App.Contracts.Models.VenueZones.Dto;
using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;
using Ewai.SharedKernel.Models.Configs;

namespace Ewai.Eventis.App.Contracts.Models.VenueMaps.Dto;

/// <summary>
/// VenueMapListDto.
/// </summary>
public class VenueMapListDto : IAutoMap<VenueMap, VenueMapListDto>
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Name { get; set; }
    public string TenantName { get; set; }
    public string ImageUrl { get; set; }
    public HashSet<VenueZoneDto> Zones { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<VenueMap, VenueMapListDto>()
            .ForMember(to => to.TenantName, c => c.MapFrom(from => from.Tenant.Name))
            .ForMember(to => to.ImageUrl, c => c.MapFrom<ValueResolver>());
    }

    public class ValueResolver(
        DefaultAwsS3Storage s3Storage,
        IUserProfileService userProfileService)
        : IValueResolver<VenueMap, VenueMapListDto, string>
    {
        public string Resolve(VenueMap source, VenueMapListDto destination,
            string destMember, ResolutionContext context)
        {
            if (source.Image is null) return string.Empty;
            var tenantId = userProfileService.GetTenantId();
            return s3Storage.GetPreSignedUrl(source.Image.ToTenantFileName(tenantId));
        }
    }
}