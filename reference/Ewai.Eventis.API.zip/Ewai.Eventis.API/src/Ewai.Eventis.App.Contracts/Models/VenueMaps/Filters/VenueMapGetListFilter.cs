﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.VenueMaps.Filters;

/// <summary>
/// VenueMapGetListFilter.
/// </summary>
public class VenueMapGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    public Guid? TenantId { get; set; }
    public Guid? VenueId { get; set; }

    public bool? IsTemplate { get; set; }
    
    public Guid? MapId { get; set; }
}