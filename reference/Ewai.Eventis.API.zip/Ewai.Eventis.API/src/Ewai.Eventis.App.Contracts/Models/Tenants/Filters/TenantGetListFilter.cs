﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;

namespace Ewai.Eventis.App.Contracts.Models.Tenants.Filters;

public class TenantGetListFilter : PageFilter
{
    [MaxLength(100)] public string Filter { get; set; }
    [MaxLength(200)] public string BranchName { get; set; }
    [MaxLength(200)] public string TenantName { get; set; }
    [MaxLength(100)] public string Email { get; set; }
    public Guid? TenantId { get; set; }
}