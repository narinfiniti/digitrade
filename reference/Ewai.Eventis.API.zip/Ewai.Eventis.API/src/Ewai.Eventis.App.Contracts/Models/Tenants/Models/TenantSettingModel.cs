using Ewai.Eventis.App.Contracts.Models.TenantSubs.Models;

namespace Ewai.Eventis.App.Contracts.Models.Tenants.Models;

/// <summary>
/// Tenant Setting Model.
/// </summary>
public class TenantSettingModel
{
    public string Language { get; set; }
    public string Currency { get; set; }
    public string Country { get; set; }
    public TenantSubModel Subscription { get; set; }
    public decimal GetSubVatPercentage() => Subscription is { Vat: > 0 } ? Subscription.Vat : 0;

    //public PaySystemModel PaySystem { get; set; }
    //public bool IsPaySystemEnabled() => PaySystem is { IsEnabled: true } && PaySystem.ServiceName.IsNotEmpty();
}