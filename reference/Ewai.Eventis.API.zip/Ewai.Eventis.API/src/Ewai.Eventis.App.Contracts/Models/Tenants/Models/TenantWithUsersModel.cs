﻿using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.Eventis.Domain.Entity.Users;

namespace Ewai.Eventis.App.Contracts.Models.Tenants.Models;

public class TenantWithUsersModel : Tenant
{
    public HashSet<User> Users { get; set; } = [];
}