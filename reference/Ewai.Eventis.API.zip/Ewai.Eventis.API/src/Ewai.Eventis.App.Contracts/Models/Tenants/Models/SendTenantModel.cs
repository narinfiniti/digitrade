﻿namespace Ewai.Eventis.App.Contracts.Models.Tenants.Models;

public class SendTenantModel
{
    public string TenantAdminEmail { get; set; }
    public string TenantName { get; set; }
    public string Message { get; set; }
    public string LogoImgUrl { get; set; }
    public string Password { get; set; }
}