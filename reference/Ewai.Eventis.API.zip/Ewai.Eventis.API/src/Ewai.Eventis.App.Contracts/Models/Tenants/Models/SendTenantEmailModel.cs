﻿namespace Ewai.Eventis.App.Contracts.Models.Tenants.Models;

public class SendTenantEmailModel
{
    public string EmailReceivers { get; set; }
    public string TenantName { get; set; }
    public string Message { get; set; }
    public Stream Data { get; set; }
}