﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Tenants.Dto;

public class TenantBranchListDto : IAutoMap<TenantBranch, TenantBranchListDto>
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string Address { get; set; }
    public string Trn { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantBranch, TenantBranchListDto>();
    }
}