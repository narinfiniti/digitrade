﻿using System.Text.Json.Nodes;
using AutoMapper;
using Ewai.Common.Extensions;
using Ewai.Eventis.App.Contracts.Models.Tenants.Models;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Tenants.Dto;

public class TenantListDto
    : IAutoMap<Tenant, TenantListDto>
        , IAutoMap<TenantWithUsersModel, TenantListDto>
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string Address { get; set; }
    public string Trn { get; set; }
    public Guid? LogoId { get; set; }
    public string CompanyId { get; set; }
    public string Email { get; set; }
    public SegmentationTypeEnum Segmentation { get; set; }
    public DateTime DateCreated { get; set; }
    public bool IsActive { get; set; }
    public JsonNode Setting { get; set; } 

    // public List<TenantBranchListDto> Branches { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<Tenant, TenantListDto>();
        profile.CreateMap<TenantWithUsersModel, TenantListDto>()
            .ForMember(dest => dest.Email, opt =>
                opt.MapFrom(src => src.Users.FirstOrDefault(e => e.UserName.Includes(src.Name)).Email));
    }
}