using System.Text.Json.Nodes;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Tenants.Dto;

/// <summary>
/// TenantDto.
/// </summary>
public class TenantDto : IAutoMap<Tenant, TenantDto>
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string Address { get; set; }
    public string Trn { get; set; }
    public string CompanyId { get; set; }
    public string Email { get; set; }
    public DateTime DateCreated { get; set; }
    public bool IsActive { get; set; }
    public JsonNode Setting { get; set; }
}