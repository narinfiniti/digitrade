using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;
using System.Text.Json.Nodes;

namespace Ewai.Eventis.App.Contracts.Models.Tenants.Inputs;

public class TenantUpdateSettingInput : IAutoMap<Tenant, TenantUpdateSettingInput>
{
    public JsonNode Setting { get; set; }
}