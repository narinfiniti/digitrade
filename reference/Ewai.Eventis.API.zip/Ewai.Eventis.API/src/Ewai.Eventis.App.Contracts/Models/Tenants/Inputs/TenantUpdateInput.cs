using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Tenants.Inputs;

public class TenantUpdateInput : IAutoMap<Tenant, TenantUpdateInput>
{
    [Required, MaxLength(100)] public string Name { get; set; }
    [MaxLength(500)] public string Address { get; set; }
    [MaxLength(50)] public string Trn { get; set; }
    [MaxLength(50)] public string CompanyId { get; set; }

    [Range(1, 4), EnumDataType(typeof(SegmentationTypeEnum))]
    public SegmentationTypeEnum? Segmentation { get; set; }

    [Required, MaxLength(256), EmailAddress]
    public string Email { get; set; }

    [MaxLength(100)] public string FirstName { get; set; }
    [MaxLength(100)] public string LastName { get; set; }
    public Guid? LogoId { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantUpdateInput, Tenant>()
            .ForAllMembers(opt => opt.Condition((src, dest, mbr) => mbr != null));
        profile.CreateMap<SegmentationTypeEnum?, SegmentationTypeEnum>().ConvertUsing((src, dest) => src ?? dest);
    }
}