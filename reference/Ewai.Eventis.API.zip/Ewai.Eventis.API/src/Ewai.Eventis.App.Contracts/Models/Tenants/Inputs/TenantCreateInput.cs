using System.ComponentModel.DataAnnotations;
using System.Text.Json.Nodes;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;
using AutoMapper;

namespace Ewai.Eventis.App.Contracts.Models.Tenants.Inputs;

public class TenantCreateInput : IAutoMap<Tenant, TenantCreateInput>
{
    [Required, MaxLength(100)] public string Name { get; set; }
    [MaxLength(500)] public string Address { get; set; }
    [MaxLength(50)] public string Trn { get; set; }
    [MaxLength(50)] public string CompanyId { get; set; }
    public JsonNode Setting { get; set; }
    [Range(1, 4), EnumDataType(typeof(SegmentationTypeEnum))]
    public SegmentationTypeEnum? Segmentation { get; set; }

    [Required, MaxLength(256), EmailAddress]
    public string Email { get; set; }

    [MaxLength(100)] public string FirstName { get; set; }
    [MaxLength(100)] public string LastName { get; set; }
    [MaxLength(50), Phone] public string PhoneNumber { get; set; }
    public Guid? LogoId { get; set; }

    public DateTime? DateCreated { get; set; }

        public void CreateMap(Profile profile)
    {
        profile.CreateMap<TenantCreateInput, Tenant>()
            // If the incoming DateCreated is not null, remove its Kind:
            .ForMember(dest => dest.DateCreated, opt => opt.MapFrom(src =>
                src.DateCreated.HasValue
                    ? DateTime.SpecifyKind(src.DateCreated.Value, DateTimeKind.Unspecified)
                    : DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Unspecified)
            ))

            // For everything else, only map non-null values:
            .ForAllMembers(opt => opt.Condition((src, dest, srcMember) => srcMember != null));
    }
}