﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Users.Models;

public class UserForgetPasswordEmailModel
    : IAutoMap<User, UserForgetPasswordEmailModel>
{
    public string Email { get; set; }
    public string UserName { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string CallbackUrl { get; set; }
    public string LogoImgUrl { get; set; }
    public string Environment { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<User, UserForgetPasswordEmailModel>();
    }
}