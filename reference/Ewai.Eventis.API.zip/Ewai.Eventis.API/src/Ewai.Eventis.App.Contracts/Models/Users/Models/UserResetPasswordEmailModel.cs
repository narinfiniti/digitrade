﻿using AutoMapper;
using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Users.Models;

public class UserResetPasswordEmailModel
    : IAutoMap<User, UserResetPasswordEmailModel>
{
    public string Email { get; set; }
    public string UserName { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Password { get; set; }
    public string Message { get; set; }
    public string LogoImgUrl { get; set; }
    //public string WebsiteUrl { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<User, UserResetPasswordEmailModel>();
    }
}