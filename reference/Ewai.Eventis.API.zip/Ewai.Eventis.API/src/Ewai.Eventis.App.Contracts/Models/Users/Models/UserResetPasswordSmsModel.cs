﻿namespace Ewai.Eventis.App.Contracts.Models.Users.Models;

public class UserResetPasswordSmsModel
{
    public string PhoneNumber { get; set; }
    public string Message { get; set; }
}