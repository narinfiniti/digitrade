﻿namespace Ewai.Eventis.App.Contracts.Models.Users.Models;

public class UserCreatedEmailUserModel
{
    public string Email { get; set; }
    public string UserName { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public byte[] QrCode { get; set; }
    public string Password { get; set; }
    public string Message { get; set; }
    public string LogoImgUrl { get; set; }
    //public string WebsiteUrl { get; set; }
}
public class UserCreatedEmailCreatorModel
{
    public string CreatorUserEmail { get; set; }
    public string UserEmail { get; set; }
    public string UserName { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Password { get; set; }
    public string Message { get; set; }
    public string LogoImgUrl { get; set; }
    //public string WebsiteUrl { get; set; }
}