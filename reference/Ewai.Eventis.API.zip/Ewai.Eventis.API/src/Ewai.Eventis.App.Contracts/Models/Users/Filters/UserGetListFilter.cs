﻿using System.ComponentModel.DataAnnotations;
using Ewai.Common.Models;
using Ewai.Eventis.Domain.Entity.Users;

namespace Ewai.Eventis.App.Contracts.Models.Users.Filters;

/// <summary>
/// UserGetListFilter.
/// </summary>
public class UserGetListFilter : PageFilter
{
    [MaxLength(200)] public string Filter { get; set; }
    [MaxLength(200)] public string Name { get; set; }
    [MaxLength(200)] public string RoleName { get; set; }
    public Guid? RoleId { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? TenantId { get; set; }
    public bool? IsInternal { get; set; }
    [Range(1, 10), EnumDataType(typeof(RoleTypeEnum))]
    public RoleTypeEnum? RoleType { get; set; }
}