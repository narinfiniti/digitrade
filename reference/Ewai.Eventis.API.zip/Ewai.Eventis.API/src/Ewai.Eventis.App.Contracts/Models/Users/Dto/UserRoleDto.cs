using Ewai.Eventis.App.Contracts.Models.Roles.Dto;
using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Users.Dto;

public class UserRoleDto : IAutoMap<UserRole, UserRoleDto>
{
    public Guid UserId { get; set; }
    public RoleDto Role { get; set; }
}