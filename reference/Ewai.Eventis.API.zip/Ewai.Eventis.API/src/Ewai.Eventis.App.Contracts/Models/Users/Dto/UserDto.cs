using AutoMapper;
using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Users.Dto;

/// <summary>
/// UserDto.
/// </summary>
public class UserDto : IAutoMap<User, UserDto>
{
    public Guid Id { get; set; }
    public string UserName { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string PhoneNumber { get; set; }
    public string Email { get; set; }

    public Guid? BranchId { get; set; }
    public string BranchName { get; set; }
    public Guid? TenantId { get; set; }
    public string TenantName { get; set; }
    public List<UserRoleDto> UserRoles { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<User, UserDto>()
            //.ForMember(to => to.BranchName, c => c.MapFrom(from => from.Branch.Name))
            //.ForMember(to => to.TenantName, c => c.MapFrom(from => from.Tenant.Name))
            .ForMember(to => to.UserRoles, c => c.MapFrom(from => from.UserRoles));
    }
}