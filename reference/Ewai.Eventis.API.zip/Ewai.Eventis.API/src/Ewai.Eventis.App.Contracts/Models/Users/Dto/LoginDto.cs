using Ewai.Common.Models;
using Ewai.Eventis.App.Contracts.Models.Branches.Models;
using Ewai.Eventis.App.Contracts.Models.Roles.Dto;

namespace Ewai.Eventis.App.Contracts.Models.Users.Dto;

public class LoginDto
{
    public Items<string> CameraUris { get; set; }
    public bool PasswordChangeForced { get; set; }
    public BranchSettingModel BranchSetting { get; set; }
    public List<PermissionDto> ViewAccess { get; set; }
}