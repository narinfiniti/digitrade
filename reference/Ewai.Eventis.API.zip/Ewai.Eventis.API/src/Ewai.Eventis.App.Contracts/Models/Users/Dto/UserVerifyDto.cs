﻿using Ewai.Eventis.App.Contracts.Models.Roles.Dto;

namespace Ewai.Eventis.App.Contracts.Models.Users.Dto;

public class UserVerifyDto
{
    public List<PermissionDto> ViewAccess { get; set; }
}