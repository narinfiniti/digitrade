using System.Text.Json.Nodes;
using Ewai.Eventis.App.Contracts.Models.Roles.Dto;
using Ewai.Eventis.App.Contracts.Models.TenantSubs.Dto;
using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Users.Dto;

public class UserMyProfileDto : IAutoMap<User, UserMyProfileDto>
{
    public Guid? Id { get; set; }
    public string Username { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? TenantId { get; set; }
    public string BranchName { get; set; }
    public string TenantName { get; set; }
    public string RoleName { get; set; }
    public RoleTypeEnum? RoleType { get; set; }
    public string RoleTypeName { get; set; }
    public string CompanyId { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Email { get; set; }
    public string PhoneNumber { get; set; }
    public string LogoImageUrl { get; set; }
    public bool PasswordChangeForced { get; set; }
    public JsonNode Setting { get; set; }
    public List<PermissionDto> Permissions { get; set; } = [];
    public TenantSubDto Subscription { get; set; }
}