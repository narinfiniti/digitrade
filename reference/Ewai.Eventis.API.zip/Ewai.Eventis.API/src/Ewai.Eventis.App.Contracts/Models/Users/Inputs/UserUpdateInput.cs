﻿using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Users.Inputs;

/// <summary>
/// UserCreateOrUpdateInput.
/// </summary>
public class UserUpdateInput : IAutoMap<UserUpdateInput, User>
{
    [MaxLength(50)] public string UserName { get; set; }
    [MaxLength(100), EmailAddress] public string Email { get; set; }
    [MaxLength(50)] public string PhoneNumber { get; set; }
    [MaxLength(100)] public string FirstName { get; set; }
    [MaxLength(100)] public string LastName { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? TenantId { get; set; }
    [MaxLength(200)] public string RoleName { get; set; }

    public void CreateMap(Profile profile)
    {
        profile.CreateMap<UserUpdateInput, User>()
            .ForAllMembers(opt => opt.Condition((src, dest, srcMember) => srcMember != null));
    }
}