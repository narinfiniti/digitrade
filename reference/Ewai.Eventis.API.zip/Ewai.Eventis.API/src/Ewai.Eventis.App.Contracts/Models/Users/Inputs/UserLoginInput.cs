﻿using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.Users.Inputs;

/// <summary>
/// UserLoginInput.
/// </summary>
public class UserLoginInput
{
    [Required, MaxLength(200)] public string MobileSerialNumber { get; set; }
}