﻿using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.Users.Inputs;

/// <summary>
/// UserCreateInput.
/// </summary>
public class UserCreateInput : IAutoMap<User, UserCreateInput>
{
    [Required, MaxLength(100), EmailAddress]
    public string Email { get; set; }
    [Required, MaxLength(50)] public string UserName { get; set; }

    [MaxLength(500), DataType(DataType.Password)]
    public string Password { get; set; }

    [Required, MaxLength(50)] public string PhoneNumber { get; set; }
    [MaxLength(100)] public string FirstName { get; set; }
    [MaxLength(100)] public string LastName { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? TenantId { get; set; }
    [Required, MaxLength(200)] public string RoleName { get; set; }
    public Guid? EventId { get; set; }
    public Guid? VenueId { get; set; }
}