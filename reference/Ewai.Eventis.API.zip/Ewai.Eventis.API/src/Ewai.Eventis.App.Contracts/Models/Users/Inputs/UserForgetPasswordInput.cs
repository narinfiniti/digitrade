﻿using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.Users.Inputs;

/// <summary>
/// UserCreateOrUpdateInput.
/// </summary>
public class UserForgetPasswordInput
{
    [Required] public string Username { get; set; }
}