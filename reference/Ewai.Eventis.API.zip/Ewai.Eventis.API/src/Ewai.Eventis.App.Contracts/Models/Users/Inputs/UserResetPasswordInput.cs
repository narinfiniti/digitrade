﻿using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.Users.Inputs;

/// <summary>
/// UserCreateOrUpdateInput.
/// </summary>
public class UserResetPasswordInput
{
    [Required] public Guid UserId { get; set; }
    public bool SendByEmail { get; set; }
    public bool SendBySms { get; set; }
}