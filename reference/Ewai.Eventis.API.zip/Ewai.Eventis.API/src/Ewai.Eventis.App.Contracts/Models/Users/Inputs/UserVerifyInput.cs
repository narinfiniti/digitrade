﻿using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.Users.Inputs;

public class UserVerifyInput
{
    [Required, MaxLength(128)] public string RoleName { get; set; }
    [MaxLength(50)] public string UserName { get; set; }
    [MaxLength(100)] public string Password { get; set; }
    [MaxLength(500)] public string QrCode { get; set; }
}