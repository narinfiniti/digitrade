﻿using System.ComponentModel.DataAnnotations;

namespace Ewai.Eventis.App.Contracts.Models.Users.Inputs;

/// <summary>
/// UserCreateOrUpdateInput.
/// </summary>
public class UserVerifyForgetPasswordInput
{
    [Required] public string Token { get; set; }
    [Required] public string Email { get; set; }
    [Required] public string Password { get; set; }
}