namespace Ewai.Eventis.App.Contracts.Models.TenantClients.Models;

public class TenantClientModel
{
    
}