using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenantClients.Inputs;

/// <summary>
/// TenantClientUpdateInput.
/// </summary>
public class TenantClientUpdateInput : IAutoMap<TenantClient, TenantClientUpdateInput>
{
    [Required, MaxLength(50), Phone] public string PhoneNumber { get; set; }
    [MaxLength(256), EmailAddress] public string Email { get; set; }
    [Required, MaxLength(100)] public string FirstName { get; set; }
    [MaxLength(100)] public string LastName { get; set; }
}