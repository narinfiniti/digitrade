using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Models.TenantClients.Dto;

/// <summary>
/// TenantClientDto.
/// </summary>
public class TenantClientDto
    : IAutoMap<TenantClient, TenantClientDto>
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }

    public string PhoneNumber { get; set; }
    public string Email { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
}