﻿using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IUserRoleRepository : IRepository<Role, Guid>
{
    Task<(long totalCount, List<Role> users)> GetListAsync(string name, string ignoreName,
        RoleTypeEnum? roleType, Guid? branchId, Guid? tenantId,
        int skip, int limit);
    void DeleteUserRole(UserRole userRole);

    Task<List<Role>> GetRolesAsync(
        Guid branchId, Guid tenantId);

    Task<List<Role>> GetRolesAsync();
}