using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IBranchRepository : IRepository<TenantBranch, Guid>
{
    Task<TenantBranch> GetBranchWithDetail(Guid id);
    Task<(long, List<TenantBranch>)> GetListAsync(
        string branchName = null,
        string branchAddress = null,
        string tenantName = null,
        Guid? tenantId = null,
        string trn = null,
        Guid? id = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");

    Task<List<Guid>> GetBranchIds(Guid tenantId,
        CancellationToken cancellationToken = default);

    Task<Dictionary<Guid, string>> GetBranches(
        Guid[] ids = null, 
        Guid? tenantId = null, CancellationToken cancellationToken = default);
}