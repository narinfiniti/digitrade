using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IClientBookingRepository : IRepository<ClientBooking, Guid>
{
    Task<(long, List<ClientBooking>)> GetListAsync(
        string filter = null,
        Guid? venueId = null,
        string zoneName = null,
        string email = null,
        Guid? tenantId = null,
        string tenantName = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");

    Task<ClientBooking> GetByIdAsync(Guid clientId);

    Task<ClientBooking> GetByClientAndVenueAsync(Guid? clientId, Guid? venueId);

    Task<TResult> QueryDbContext<TResult>(Func<DbContext, Task<TResult>> query);
}