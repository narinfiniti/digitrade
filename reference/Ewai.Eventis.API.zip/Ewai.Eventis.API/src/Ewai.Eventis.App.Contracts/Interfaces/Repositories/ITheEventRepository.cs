using Ewai.Eventis.Domain.Entity.TenantEvents;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface ITheEventRepository : IRepository<TheEvent, Guid>
{
    Task<(long, List<TheEvent>)> GetListAsync(
        string filter = null,
        string tenantName = null,
        string name = null,
        Guid? eventId = null,
        Guid? tenantId = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}