using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IVenueMapPositionRepository : IRepository<VenueMapPosition, Guid>
{
    Task<(long, List<VenueMapPosition>)> GetListAsync(
        string filter = null,
        Guid? deskId = null,
        Guid? zoneId = null,
        int skip = 0, int limit = 10);
}