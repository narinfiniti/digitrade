using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IRequestProductRepository : IRepository<RequestProduct, Guid>
{
    Task<(long, List<RequestProduct>)> GetListAsync(
        string filter = null,
        VenueStatusEnum? status = null,
        string name = null,
        Guid? eventId = null,
        string eventName = null,
        Guid? locationId = null,
        string locationName = null,
        Guid? tenantId = null,
        string tenantName = null,
        int skip = 0, int limit = 10);
}