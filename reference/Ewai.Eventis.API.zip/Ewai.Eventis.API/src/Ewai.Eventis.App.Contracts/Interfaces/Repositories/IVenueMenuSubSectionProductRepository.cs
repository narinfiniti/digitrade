using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IVenueMenuSubSectionProductRepository : IRepository<VenueMenuSubSectionProduct, Guid>
{
    Task<(long, List<VenueMenuSubSectionProduct>)> GetListAsync(
        string filter = null,
        Guid? subSectionId = null,
        Guid? productId = null,
        string size = null,
        decimal? minPrice = null,
        decimal? maxPrice = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}