using Ewai.Eventis.Domain.Entity.Orders;
using Ewai.SharedKernel.Interfaces;
using Ewai.Eventis.Domain.Enums;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IRequestRepository : IRepository<Request, Guid>
{
    Task<(long, List<Request>)> GetListAsync(
        string filter = null,
        string tenantName = null,
        string number = null,
        Guid? tenantId = null,
        Guid? bookingId = null,
        RequestStatusEnum? status = null,
        List<RequestStatusEnum> statusList = null,
        bool? haveInvoice = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}