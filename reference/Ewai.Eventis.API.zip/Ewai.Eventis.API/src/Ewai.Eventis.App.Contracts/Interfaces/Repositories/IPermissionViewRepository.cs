using Ewai.Eventis.Domain.Entity.PermissionViews;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IPermissionViewRepository : IRepository<PermissionView, Guid>
{
    ValueTask<(long, List<PermissionView>)> GetListAsync(
        PermissionGroupEnum? group = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id asc");
}