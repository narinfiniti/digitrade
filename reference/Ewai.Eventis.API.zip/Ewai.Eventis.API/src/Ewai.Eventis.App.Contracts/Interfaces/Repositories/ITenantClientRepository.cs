using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface ITenantClientRepository : IRepository<TenantClient, Guid>
{
    Task<(long, List<TenantClient>)> GetListAsync(
        string filter = null,
        string firstName = null,
        string lastName = null,
        Guid? tenantId = null,
        string tenantName = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}