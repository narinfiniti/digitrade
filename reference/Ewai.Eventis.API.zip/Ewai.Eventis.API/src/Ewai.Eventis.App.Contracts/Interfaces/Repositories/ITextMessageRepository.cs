using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface ITextMessageRepository : IRepository<TextMessage, Guid>
{
    Task<(long, List<TextMessage>)> GetListAsync(
        string filter = null,
        LanguageCodeEnum? language = null,
        string key = null,
        string value = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}