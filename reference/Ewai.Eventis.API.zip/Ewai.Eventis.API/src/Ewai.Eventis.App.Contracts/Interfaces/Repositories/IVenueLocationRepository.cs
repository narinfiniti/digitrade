using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IVenueLocationRepository : IRepository<VenueLocation, Guid>
{
    Task<(long, List<VenueLocation>)> GetListAsync(
        string filter = null,
        Guid? tenantId = null,
        int skip = 0, int limit = 10);
}