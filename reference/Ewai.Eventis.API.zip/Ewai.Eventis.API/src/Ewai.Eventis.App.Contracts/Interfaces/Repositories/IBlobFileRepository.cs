﻿using Ewai.Eventis.Domain.Entity.BlobFiles;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IBlobFileRepository : IRepository<BlobFile, Guid>
{
    Task<(long, List<BlobFile>)> GetListAsync(
        Guid? id = null,
        string target = null,
        string extension = null,
        int skip = 0, int limit = 10);

    Task<BlobFile> GetAsync(
        bool tracking,
        Guid? id = null,
        Guid? targetId = null,
        string target = null);
}