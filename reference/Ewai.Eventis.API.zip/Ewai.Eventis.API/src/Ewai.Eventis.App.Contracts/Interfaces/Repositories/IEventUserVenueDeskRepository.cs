using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

/// <summary>
/// Repository for managing many-to-many assignments between EventUsers and VenueDesks.
/// </summary>
public interface IEventUserVenueDeskRepository : IRepository<EventUserVenueDesk, Guid>
{
    /// <summary>
    /// Retrieves a list of assignments filtered by EventUserId and/or DeskId.
    /// </summary>
    Task<List<EventUserVenueDesk>> GetListAsync(Guid? eventUserId = null, Guid? deskId = null);

    /// <summary>
    /// Checks whether an EventUser is already assigned to a specific Desk.
    /// </summary>
    Task<bool> ExistsAsync(Guid eventUserId, Guid deskId);

    /// <summary>
    /// Adds multiple assignments in bulk.
    /// </summary>
    Task AddRangeAsync(IEnumerable<EventUserVenueDesk> entities);

    /// <summary>
    /// Removes multiple assignments in bulk.
    /// </summary>
    Task RemoveRangeAsync(IEnumerable<EventUserVenueDesk> entities);
}