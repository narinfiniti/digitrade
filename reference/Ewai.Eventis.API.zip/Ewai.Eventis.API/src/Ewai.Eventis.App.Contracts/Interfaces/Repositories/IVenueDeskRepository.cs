using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IVenueDeskRepository : IRepository<VenueDesk, Guid>
{
    Task<(long, List<VenueDesk>)> GetListAsync(
        string filter = null,
        VenueDeskStatusEnum? status = null,
        VenueDeskTypeEnum? type = null,
        Guid? zoneId = null,
        Guid? venueId = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}