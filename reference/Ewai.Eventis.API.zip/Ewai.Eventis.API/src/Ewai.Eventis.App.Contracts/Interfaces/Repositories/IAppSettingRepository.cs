﻿using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IAppSettingRepository : IRepository<AppSetting, Guid>
{
    Task<(long, List<AppSetting>)> GetListAsync(
        List<string> keys = null,
        bool? isPredefined = null,
        int skip = 0, int limit = 10);
}