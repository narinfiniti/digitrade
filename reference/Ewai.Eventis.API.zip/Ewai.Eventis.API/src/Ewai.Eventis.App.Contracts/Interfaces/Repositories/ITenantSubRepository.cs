using Ewai.Eventis.Domain.Entity.Platform;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface ITenantSubRepository : IRepository<TenantSubscription, Guid>
{
    Task<(long, List<TenantSubscription>)> GetListAsync(
        string filter = null,
        Guid? tenantId = null,
        string tenantName = null,
        Guid? subId = null,
        PlatformSubscriptionTypeEnum? subType = null,
        bool? isActive = null,
        DateTime? dateStartedFrom = null,
        DateTime? dateStartedTo = null,
        DateTime? dateEndedFrom = null,
        DateTime? dateEndedTo = null,
        DateTime? dateLastPaymentFrom = null,
        DateTime? dateLastPaymentTo = null,
        DateTime? datePaymentDueFrom = null,
        DateTime? datePaymentDueTo = null,
        decimal? totalPaymentDueFrom = null,
        decimal? totalPaymentDueTo = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}