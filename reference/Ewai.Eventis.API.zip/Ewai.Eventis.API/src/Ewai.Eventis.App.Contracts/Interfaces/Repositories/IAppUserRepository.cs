﻿using Ewai.Eventis.Domain.Entity.Users;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IAppUserRepository : IRepository<User, Guid>
{
    Task AddUserRoleAsync(UserRole userRole);
    Task<User> FindUserAsync(Guid userId, string roleName = null);
    Task<User> FindUserAsync(string userName, string roleName = null);
    Task<User> FindBranchUserAsync(Guid branchId, string roleName = null);
    Task<User> FindTenantUserAsync(Guid tenantId, string roleName = null);
    Task<(long totalCount, List<User> users)> GetListAsync(
        string filter = null, string name = null,
        string roleName = null, Guid? roleId = null, RoleTypeEnum? roleType = null,
        Guid? branchId = null, Guid? tenantId = null,
        bool? isInternal = null,
        bool includeSystemAdmin = false,
        int skip = 0, int limit = 10);
    Task<List<UserRole>> GetUserRoleListAsync(
        Guid[] userIds = null,
        Guid[] roleIds = null,
        Guid? branchId = null,
        Guid? tenantId = null);
}