using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IVenueMapRepository : IRepository<VenueMap, Guid>
{
    Task<(long, List<VenueMap>)> GetListAsync(
        string filter = null,
        bool? isTemplate = null,
        Guid? mapId = null,
        Guid? venueId = null,
        Guid? tenantId = null,
        string tenantName = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}