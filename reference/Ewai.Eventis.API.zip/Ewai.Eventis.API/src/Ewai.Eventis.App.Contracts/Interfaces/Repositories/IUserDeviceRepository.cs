using Ewai.Eventis.Domain.Entity.Devices;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IUserDeviceRepository : IRepository<UserDevice, Guid>
{
    ValueTask UpdateUserDeviceAsync(UserDevice userDevice);
    ValueTask DeleteUserDeviceAsync(UserDevice userDevice);

    ValueTask<(long, List<UserDevice>)> GetListAsync(
        Guid? userId = null,
        string deviceId = null,
        string connectionId = null,
        UserDeviceTypeEnum? deviceType = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}