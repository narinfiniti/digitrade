﻿namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IDapperRepository
{
}