﻿using Ewai.Eventis.Domain.Entity.Products;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IProductCategoryRepository : IRepository<ProductCategory, Guid>
{
    Task<(long, List<ProductCategory>)> GetListAsync(
        string productCategoryName = null, int skip = 0, int limit = 10);
    Task<(List<ProductCategory>, List<ProductSubCategory>)> GetCategoriesAndSubCategoriesAsync(Guid? branchId);
}