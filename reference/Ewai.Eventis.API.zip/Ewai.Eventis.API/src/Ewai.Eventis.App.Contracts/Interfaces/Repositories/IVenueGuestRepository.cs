using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IVenueGuestRepository : IRepository<VenueGuest, Guid>
{
    Task<(long, List<VenueGuest>)> GetListAsync(
        string filter = null,
        Guid? venueId = null,
        string firstName = null,
        string lastName = null,
        string notes = null,
        string phoneNumber = null,
        string email = null,
        DateTime? dateCreatedFrom = null,
        DateTime? dateCreatedTo = null,
        DateTime? dateCheckedInFrom = null,
        DateTime? dateCheckedInTo = null,
        int skip = 0, int limit = 10,
        string sortBy = null);
}