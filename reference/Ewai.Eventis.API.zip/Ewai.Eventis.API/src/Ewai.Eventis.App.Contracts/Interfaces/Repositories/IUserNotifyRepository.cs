using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IUserNotifyRepository : IRepository<UserNotif, Guid>
{
    Task<(long, List<UserNotif>)> GetListAsync(
        string filter = null,
        UserNotifStatusEnum? status = null,
        Guid? senderUserId = null,
        Guid? eventId = null,
        Guid? venueId = null,
        Guid[] receiverUserIds = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}