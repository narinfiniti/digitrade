using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IVenueRepository : IRepository<Venue, Guid>
{
    Task<(long, List<Venue>)> GetFilterListAsync(
        string filter = null,
        VenueStatusEnum? status = null,
        string name = null,
        Guid? venueId = null,
        Guid? eventId = null,
        string eventName = null,
        Guid? locationId = null,
        string locationName = null,
        Guid? tenantId = null,
        Guid? currentUserId = null,
        string tenantName = null,
        bool? isExternal = null,
        DateTime? fromDate = null, DateTime? toDate = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
    Task<(long, List<Venue>)> GetListAsync(
        string filter = null,
        VenueStatusEnum? status = null,
        string name = null,
        Guid? venueId = null,
        Guid? eventId = null,
        string eventName = null,
        Guid? locationId = null,
        string locationName = null,
        Guid? tenantId = null,
        Guid? currentUserId = null,
        string tenantName = null,
        bool? isExternal = null,
        DateTime? fromDate = null, DateTime? toDate = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");

    Task<Venue> GetByIdAsync(Guid venueId);

    Task<(long InProgressCount, long FinishedCount)> GetCountInProgressFinishedAsync(Guid? tenantId);
}