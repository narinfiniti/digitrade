﻿using Ewai.Eventis.Domain.Entity.PermissionViews;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IPermissionViewCategoryRepository : IRepository<PermissionViewCategory, Guid>
{
    ValueTask<(long, List<PermissionViewCategory>)> GetListAsync(
        PermissionGroupEnum? group = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id asc");
}