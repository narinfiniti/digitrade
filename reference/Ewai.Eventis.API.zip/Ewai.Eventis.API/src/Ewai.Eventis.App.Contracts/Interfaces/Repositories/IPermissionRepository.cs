﻿using Ewai.Eventis.Domain.Entity.Permissions;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IPermissionRepository : IRepository<Permission, Guid>
{
    ValueTask<(long, List<Permission>)> GetListAsync(
        string name = null,
        Guid? userId = null,
        Guid? roleId = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id asc");

    ValueTask RemoveAsync(
        Guid[] ids = null,
        PermissionTypeEnum[] types = null,
        PermissionGroupEnum[] groups = null,
        PermissionTargetEnum[] targets = null,
        Guid[] targetIds = null);
}