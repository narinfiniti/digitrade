﻿using Ewai.Eventis.App.Contracts.Models.Analytics.Models;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IAnalyticRepository : IDapperRepository
{
    Task<AnalyticTotalRevenueModel> GetTotalRevenueAsync(
        Guid? tenantId,
        Guid[] eventIds = null,
        Guid[] venueIds = null,
        DateTime? fromDate = null,
        DateTime? toDate = null);

    Task<AnalyticAverageRevenueModel> GetAverageRevenueAsync(
        Guid? tenantId,
        Guid[] eventIds = null,
        Guid[] venueIds = null,
        DateTime? fromDate = null,
        DateTime? toDate = null);

    Task<AnalyticCompletedBookingsModel> GetCompletedBookingsAsync(
        Guid? tenantId,
        Guid[] eventIds = null,
        Guid[] venueIds = null,
        DateTime? fromDate = null,
        DateTime? toDate = null);
    Task<AnalyticAverageTableOccupationModel> GetAverageTableOccupationAsync(
        Guid? tenantId,
        Guid[] eventIds = null,
        Guid[] venueIds = null,
        DateTime? fromDate = null,
        DateTime? toDate = null);

    Task<AnalyticPrePaymentOnSiteRevenueModel> GetPrePaymentOnSiteRevenueAsync(
        Guid? tenantId,
        Guid[] eventIds = null,
        Guid[] venueIds = null,
        DateTime? fromDate = null,
        DateTime? toDate = null);

    Task<(long, List<AnalyticPeakTransactionTimeModel>)> GetPeakTransactionTimeAsync(Guid[] shopIds = null,
        Guid? tenantId = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        int skip = 0,
        int limit = 10);

    Task<(long, List<AnalyticSoldProductsModel>)> GetMostSoldProductsAsync(
        Guid? tenantId = null,
        Guid[] eventIds = null,
        Guid[] venueIds = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        string filter = null,
        int skip = 0,
        int limit = 10);

    Task<(long, List<AnalyticPreferredProductsModel>)> GetMostPreferredProductsAsync(
        Guid? tenantId = null,
        Guid[] eventIds = null,
        Guid[] venueIds = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        string filter = null,
        int skip = 0,
        int limit = 10);

    Task<(long, List<AnalyticAverageClientSpendModel>)> GetAverageClientSpendAsync(Guid? tenantId = null,
        Guid[] eventIds = null,
        Guid[] venueIds = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        int skip = 0,
        int limit = 10);

    Task<(long, List<AnalyticAbandonedTransactionModel>)> GetAbandonedTransactionAsync(
        Guid[] shopIds = null,
        Guid? tenantId = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        int skip = 0,
        int limit = 10);

    Task<(long, List<AnalyticAverageVenueRatingModel>)> GetAverageShopRatingAsync(
        Guid[] shopIds = null,
        Guid? tenantId = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        int skip = 0,
        int limit = 10
    );

    Task<AnalyticCustomerFeedbackModel> GetCustomerFeedbackAsync(
        Guid[] shopIds = null,
        Guid? tenantId = null,
        DateTime? fromDate = null,
        DateTime? toDate = null
    );

    Task<(long, List<AnalyticProductsSoldModel>)> GetProductsSoldAsync(
        Guid? tenantId = null,
        Guid[] eventIds = null,
        Guid[] venueIds = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        string filter = null,
        int skip = 0,
        int limit = 10);

    Task<(long, List<AnalyticRevenuePerDeskModel>)> GetRevenuePerDeskAsync(
        Guid? tenantId = null,
        Guid[] eventIds = null,
        Guid[] venueIds = null,
        Guid[] deskIds = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        int skip = 0,
        int limit = 10);

    Task<(long, List<AnalyticEventUserRevenueModel>)> GetEventUserRevenueAsync(
        Guid? tenantId = null,
        Guid[] eventIds = null,
        Guid[] venueIds = null,
        Guid[] eventUserIds = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        int skip = 0,
        int limit = 10);

    Task<(long, List<AnalyticStockModel>)> GetStockAnalyticsAsync(
        Guid? tenantId = null,
        Guid[] eventIds = null,
        Guid[] venueIds = null,
        Guid[] productIds = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        string filter = null,
        int skip = 0,
        int limit = 10);
}