﻿using Ewai.Eventis.Domain.Entity.Invoices;
using Ewai.Eventis.Domain.Enums;
using Ewai.Eventis.Domain.Models;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IInvoiceRepository : IRepository<Invoice, Guid>
{
    Task<(long, List<Invoice>)> GetListAsync(
        string filter = null,
        Guid? branchId = null,
        Guid? tenantId = null,
        Guid? venueId = null,
        string invoiceNumber = null,
        InvoiceStatusEnum? invoiceStatusId = null,
        InvoiceTypeEnum? invoiceTypeId = null,
        PaymentTypeEnum? paymentTypeId = null,
        bool? isDeleted = null,
        DateTime? creationTime = null,
        DateTime? fromCreationTime = null,
        DateTime? toCreationTime = null,
        Guid? refInvoiceId = null,
        int? authorizationCode = null,
        DateTime? paidDate = null,
        Guid? clientId = null,
        Guid? creatorId = null,
        int skip = 0, int limit = 10);

    Task<Invoice> GetWithDetailAsync(string invoiceNumber);
    ValueTask UpdateInvoiceItemsAsync(List<InvoiceItem> invoiceItems);
    Task<TransactionReportModel> GetTransactionsReportModel(
        Guid branchId,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        int skip = 0,
        int limit = 10);
}