using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IVenueMenuSubSectionRepository : IRepository<VenueMenuSubSection, Guid>
{
    Task<(long, List<VenueMenuSubSection>)> GetListAsync(
        string filter = null,
        Guid? sectionId = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}