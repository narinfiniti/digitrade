using Ewai.Eventis.App.Contracts.Models.Tenants.Models;
using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface ITenantRepository : IRepository<Tenant, Guid>
{
    Task<Tenant> GetWithBranches(Guid id);
    Task<(long, List<TenantWithUsersModel>)> GetListAsync(
        string filter = null,
        string branchName = null,
        string tenantName = null,
        string email = null,
        Guid? tenantId = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}