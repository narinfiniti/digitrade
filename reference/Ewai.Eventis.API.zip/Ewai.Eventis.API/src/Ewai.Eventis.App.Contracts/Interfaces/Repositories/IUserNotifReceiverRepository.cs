using Ewai.Eventis.Domain.Entity.AppSettings;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IUserNotifReceiverRepository : IRepository<UserNotifReceiver, Guid>
{
    /// <summary>
    /// Delete a single UserNotifReceiver by its composite key.
    /// </summary>
    ValueTask DeleteAsync(Guid notificationId, Guid receiverUserId);
}