using Ewai.Eventis.Domain.Entity.Platform;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IAppSubscriptionRepository : IRepository<PlatformSubscription, Guid>
{
    Task<(long, List<PlatformSubscription>)> GetListAsync(
        string filter = null,
        Guid? subId = null,
        PlatformSubscriptionTypeEnum? subType = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}