using Ewai.Eventis.App.Contracts.Models.Permissions.Models;
using Ewai.Eventis.Domain.Entity.TenantEvents;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IEventUserRepository : IRepository<EventUser, Guid>
{
    ValueTask<(long, List<EventUser>)> GetListAsync(
        Guid[] userIds = null,
        string filter = null,
        Guid? roleId = null, 
        Guid? eventId = null, string eventName = null,
        Guid? venueId = null, string venueName = null,
        Guid? branchId = null, string branchName = null,
        Guid? tenantId = null, string tenantName = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");

    ValueTask<List<Guid>> GetEventUserIdsAsync(
        Guid[] userIds = null, Guid[] roleIds = null, Guid[] venueIds = null,
        int skip = 0, int limit = 10);
}