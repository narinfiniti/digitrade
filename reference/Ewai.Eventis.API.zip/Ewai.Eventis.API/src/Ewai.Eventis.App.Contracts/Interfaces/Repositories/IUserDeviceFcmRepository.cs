﻿using Ewai.Eventis.Domain.Entity.Devices;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IUserDeviceFcmRepository : IRepository<UserDeviceFcm, Guid>
{
    ValueTask UpdateUserDeviceFcmAsync(UserDeviceFcm userDevice);
    ValueTask DeleteUserDeviceFcmAsync(Guid userId, string deviceId, string firebaseProjectId = null);

    ValueTask<(long, List<UserDeviceFcm>)> GetListAsync(
        Guid[] userIds = null,
        string[] deviceIds = null,
        string firebaseProjectId = null,
        int skip = 0, int limit = 10,
        string sortBy = "Id desc");
}