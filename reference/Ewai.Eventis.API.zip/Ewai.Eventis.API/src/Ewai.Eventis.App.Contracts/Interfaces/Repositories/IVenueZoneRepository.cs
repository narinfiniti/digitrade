using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IVenueZoneRepository : IRepository<VenueZone, Guid>
{
    Task<(long, List<VenueZone>)> GetListAsync(
        string filter = null,
        Guid? mapId = null,
        int skip = 0, int limit = 10);
}