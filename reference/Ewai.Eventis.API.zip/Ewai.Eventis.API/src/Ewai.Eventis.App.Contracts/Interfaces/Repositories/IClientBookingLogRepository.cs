using Ewai.Eventis.Domain.Entity.Tenants;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IClientBookingLogRepository : IRepository<ClientBookingLog, Guid>
{
    Task<(long, List<ClientBookingLog>)> GetListAsync(
        Guid? bookingId = null,
        Guid? invoiceId = null,
        Guid? deskId = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        int skip = 0, int limit = 10,
        string sortBy = "DateCreated desc");
}