using Ewai.Eventis.App.Contracts.Models.Products.Models;
using Ewai.Eventis.Domain.Entity.Products;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface ITenantProductRepository : IRepository<TenantProduct, Guid>
{
    Task<List<Guid>> ImportTenantProductsAsync(IEnumerable<ProductForTenantImportDbModel> products);
    Task<List<TenantProduct>> CreateProductsAsync(IEnumerable<ProductForTenantImportDbModel> products, Guid tenantId);
    Task<(long, List<TenantProduct>)> GetListAsync(Guid? tenantId, int skip = 0, int limit = 10);
    Task UpdateProhibitedProductsAsync(List<TenantProduct> prohibitedProducts);
}