using Ewai.Eventis.Domain.Entity.Venues;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.App.Contracts.Interfaces.Repositories;

public interface IVenueMenuSectionRepository : IRepository<VenueMenuSection, Guid>
{
    Task<(long, List<VenueMenuSection>)> GetListAsync(
        string filter = null,
        Guid? menuId = null,
        int skip = 0, int limit = 10);
}