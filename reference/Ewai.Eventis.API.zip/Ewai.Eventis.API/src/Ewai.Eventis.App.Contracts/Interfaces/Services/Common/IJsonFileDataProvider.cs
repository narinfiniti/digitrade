using System.Reflection;

namespace Ewai.Eventis.App.Contracts.Interfaces.Services.Common;

public interface IJsonFileDataProvider<TEntity>
{
    IJsonFileDataProvider<TEntity> SetData(TEntity[] data);
    TEntity[] GetData(string jsonFileName = null, Assembly assembly = null);
}