﻿using Microsoft.AspNetCore.Authorization;

namespace Ewai.Eventis.App.Contracts.Interfaces.Services.Common;

/// <summary>
/// IUserPermissionService.
/// </summary>
public interface IUserPermissionService
{
    Task<bool> IsUserAllowed(AuthorizationHandlerContext context, CancellationToken cancellationToken);
}