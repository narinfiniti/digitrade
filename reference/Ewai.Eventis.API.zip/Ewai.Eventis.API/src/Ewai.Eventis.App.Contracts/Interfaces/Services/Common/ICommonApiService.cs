﻿namespace Ewai.Eventis.App.Contracts.Interfaces.Services.Common;

/// <summary>
/// ICommonApiService.
/// </summary>
public interface ICommonApiService
{
    T GetService<T>(string serviceName);
}