namespace Ewai.Eventis.App.Contracts.Interfaces.Services.Common;

public interface IAppService { }