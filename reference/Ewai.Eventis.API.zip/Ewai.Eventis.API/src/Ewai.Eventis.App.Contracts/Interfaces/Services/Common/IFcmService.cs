using Ewai.SharedKernel.Models;

namespace Ewai.Eventis.App.Contracts.Interfaces.Services.Common;

public interface IFcmService
{
    Task SendAsync<T>(FcmModel<T> model) where T : class;

    Task SendNotifyUserFcmDeviceAsync(FcmMessage msg, Guid[] receiverIds, string[] deviceIds = null,
        string firebaseProjectId = null);
}