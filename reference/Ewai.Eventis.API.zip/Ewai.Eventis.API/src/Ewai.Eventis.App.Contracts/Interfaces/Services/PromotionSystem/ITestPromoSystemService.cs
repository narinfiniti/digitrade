﻿namespace Ewai.Eventis.App.Contracts.Interfaces.Services.PromotionSystem;

public interface ITestPromoSystemService : IPromoSystemService
{ }