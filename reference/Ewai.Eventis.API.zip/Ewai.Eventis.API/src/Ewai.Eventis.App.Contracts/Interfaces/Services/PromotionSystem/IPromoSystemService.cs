using Ewai.Eventis.App.Contracts.Models.Orders.Models;
using Ewai.Eventis.Domain.Entity.Invoices;

namespace Ewai.Eventis.App.Contracts.Interfaces.Services.PromotionSystem;

public interface IPromoSystemService
{
    ValueTask ApplyPromotionsToInvoiceItem(InvoiceItem invoiceItem,
        InvoiceCreateModel product,
        decimal vatPercent,
        decimal discount);

    ValueTask ApplyPromotionsToInvoice(Invoice invoice, decimal vatPercent, decimal discount);
}