﻿using Ewai.Eventis.App.Contracts.Models.Products.Models;

namespace Ewai.Eventis.App.Contracts.Interfaces.Services.Products;

/// <summary>
/// IProductImportService.
/// </summary>
public interface IProductImportService
{
    Task<List<ProductImportXlsxModel>> ParseProductsFromXlsx(Stream contentStream, Guid? branchId);
    List<ProductImportXlsxModel> ParseProductsFromXlsx(Stream contentStream);
    Task<Stream> GetProductsXlsxAsync(Guid? branchId);
    ValueTask<Stream> GetFileStreamAsync(string fileName);
    Stream GetProductsXlsx(List<ProductImportXlsxModel> productsInMaster, List<ProductImportXlsxModel> productsNotInMaster);
}