using Ewai.Eventis.App.Contracts.Models.PaymentSystem.Models;

namespace Ewai.Eventis.App.Contracts.Interfaces.Services.PaymentSystem;

public interface IPaySystemService
{
    ValueTask<(bool paid, string error)> TryPay(TryPayModel input);
}