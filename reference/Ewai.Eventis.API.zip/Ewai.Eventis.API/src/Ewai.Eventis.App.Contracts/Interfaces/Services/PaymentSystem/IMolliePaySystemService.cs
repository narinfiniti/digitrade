﻿namespace Ewai.Eventis.App.Contracts.Interfaces.Services.PaymentSystem;

public interface IMolliePaySystemService : IPaySystemService
{ }