﻿using Ewai.Eventis.Domain.Enums;

namespace Ewai.Eventis.App.Contracts.Interfaces.Services.Receipt;

public interface IAnalyticService
{
    Task<(Stream, Stream)> GetAnalyticFileStream(
        AnalyticReportTypeEnum analyticReportTypeEnum,
        ExportTypeEnum exportTypeEnum,
        Dictionary<Guid, string> branchDictionary,
        Guid? tenantId = null,
        DateTime? fromDate = null,
        DateTime? toDate = null,
        CancellationToken cancellation = default);
}