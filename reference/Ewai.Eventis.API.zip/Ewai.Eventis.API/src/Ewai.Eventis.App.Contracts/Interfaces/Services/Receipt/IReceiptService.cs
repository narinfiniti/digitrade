﻿using Ewai.Eventis.Domain.Entity.Invoices;

namespace Ewai.Eventis.App.Contracts.Interfaces.Services.Receipt;

public interface IReceiptService
{
    ValueTask<(Stream, Stream)> GetReceiptFileStream(
        Invoice invoice,
        string email,
        CancellationToken cancellation = default);
}