﻿namespace Ewai.Eventis.App.Contracts.Interfaces.Services.JobManager;

public interface IHangfireJobManagerDesktop
{
	Task RunDailyAsync(CancellationToken cancel = default);
	Task RunEveryHourAsync(CancellationToken cancel = default);
	Task RunEvery15MinutesAsync(CancellationToken cancel = default);
	Task RunEvery4HoursAsync(CancellationToken cancel = default);
	Task SendSmsAsync(CancellationToken cancel = default);
}