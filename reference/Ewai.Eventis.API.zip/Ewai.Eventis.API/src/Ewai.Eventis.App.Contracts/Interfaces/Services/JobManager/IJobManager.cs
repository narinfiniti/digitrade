﻿using Ewai.Eventis.App.Contracts.Models.Invoices.Dto;
using Ewai.Eventis.App.Contracts.Models.Tenants.Models;
using Ewai.Eventis.App.Contracts.Models.Users.Models;

namespace Ewai.Eventis.App.Contracts.Interfaces.Services.JobManager;

public interface IJobManager
{
	Task SendEmailAsync(SendInvoiceViaEmailDto model);
	Task SendEmailAsync4(dynamic model);
	ValueTask SendEmailAsync(UserCreatedEmailUserModel model);
	ValueTask SendEmailAsync(UserCreatedEmailCreatorModel model);
	Task SendSmsAsync(dynamic model);
	Task SendEmailAsync(dynamic model);
	Task SendEmailAsync1(dynamic model);
	Task SendEmailAsync2(dynamic model);
	Task SendEmailAsync(SendTenantEmailModel model);
	Task SendEmailAsync3(dynamic model);
}