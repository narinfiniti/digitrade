﻿namespace Ewai.Eventis.App.Contracts.Interfaces.Services.JobManager;

public interface IHangfireJobManagerCloud
{
	Task RunDailyAsync(CancellationToken cancel = default);
	Task RunEveryHourAsync(CancellationToken cancel = default);
}