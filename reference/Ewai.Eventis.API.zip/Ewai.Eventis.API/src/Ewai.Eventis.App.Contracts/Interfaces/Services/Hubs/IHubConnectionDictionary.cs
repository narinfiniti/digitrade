namespace Ewai.Eventis.App.Contracts.Interfaces.Services.Hubs;

/// <summary>
/// IConnectionDictionary.
/// </summary>
public interface IHubConnectionDictionary
{
    bool TryRemove(string key, out string value);
    bool TryGet(string key, out string value);
    bool ContainsKey(string key);
    void AddOrUpdate(string key, string value);
    int Count { get; }
}