namespace Ewai.Eventis.App.Contracts.Interfaces.Services.Hubs;

public interface IHubService
{
    ValueTask Notify(string method, string data, string conn, CancellationToken cancelToken = default);
}