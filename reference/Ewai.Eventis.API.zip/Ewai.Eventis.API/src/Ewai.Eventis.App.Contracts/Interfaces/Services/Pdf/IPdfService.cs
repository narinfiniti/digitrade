﻿using Ewai.Eventis.App.Contracts.Models.TenantEvents.Models;
using Ewai.Eventis.App.Contracts.Models.Tenants.Models;

namespace Ewai.Eventis.App.Contracts.Interfaces.Services.Pdf;

public interface IPdfService
{
	Stream GetBranchUserCredentialFile(dynamic model);
	Stream GetTenantUserCredentialFile(SendTenantModel model);
	Stream GetTenantEventUserCredentialFile(SendTenantEventModel model);
}