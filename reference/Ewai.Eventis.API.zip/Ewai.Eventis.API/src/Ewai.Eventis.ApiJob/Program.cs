using System.Diagnostics;

namespace Ewai.Eventis.ApiJob;

/// <summary>
/// Program starting point class.
/// </summary>
public class Program
{
    private static readonly string AppName = typeof(Program).Namespace;

    /// <summary>
    /// Main starting point of the application.
    /// </summary>
    public static async Task Main(string[] args)
    {
        var (configuration, env) = GetConfiguration();
        try
        {
            var host = CreateHostBuilder(args, configuration, env).Build();

            Trace.WriteLine("Starting web host ({ApplicationContext})...", AppName);
            await host.RunAsync();
        }
        catch (Exception ex)
        {
            Trace.WriteLine("Program terminated unexpectedly! \n{Error}", ex.Message);
            throw;
        }
    }

    private static IHostBuilder CreateHostBuilder(string[] args, IConfiguration configuration, string env) =>
        Host.CreateDefaultBuilder(args)
            .ConfigureWebHostDefaults(hostBuilder =>
            {
                hostBuilder
                    .CaptureStartupErrors(true)
                    .ConfigureKestrel((builderContext, options) =>
                    {

                    })
                    .UseContentRoot(Directory.GetCurrentDirectory())
                    .UseStartup<Startup>()
                    .UseConfiguration(configuration);
            });

    private static (IConfiguration, string) GetConfiguration()
    {
        var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
        var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false)
            .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: false)
            .AddUserSecrets(typeof(Program).Assembly)
            .AddEnvironmentVariables();

        return (builder.Build(), env);
    }
}