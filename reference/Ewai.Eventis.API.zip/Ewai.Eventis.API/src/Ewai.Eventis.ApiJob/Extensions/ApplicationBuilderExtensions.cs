using Ewai.Eventis.App.Extensions;

namespace Ewai.Eventis.ApiJob.Extensions;

public static class ApplicationBuilderExtensions
{
    public static void ConfigureJobAppLifetimeHandlers(this IApplicationBuilder app,
        IConfiguration config, IHostEnvironment env)
    {
        var serviceProvider = app.ApplicationServices;
        var appLifetime = serviceProvider.GetService<IHostApplicationLifetime>();
        if (appLifetime != null)
        {
            appLifetime.ApplicationStarted.Register(() =>
            {
                if (config.IsCloud())
                {
                    
                }
            });
            appLifetime.ApplicationStopping.Register(() =>
            {
                if (config.IsCloud())
                {
                    
                }
            });
        }
    }
}