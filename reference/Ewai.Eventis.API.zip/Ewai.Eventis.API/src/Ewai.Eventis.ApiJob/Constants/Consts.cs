namespace Ewai.Eventis.ApiJob.Constants;

/// <summary>
/// Route Api Constants.
/// </summary>
public static class Consts
{
    public const string ApiPrefix = "api/job";

    public class Version
    {
        public const string V1 = "1.0";
    }

    public class Route
    {
        public class AppSettings
        {
            public const string Base = ApiPrefix + "/app-settings";
        }
    }
}