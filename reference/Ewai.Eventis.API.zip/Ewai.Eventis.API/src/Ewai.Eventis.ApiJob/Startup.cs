using Ewai.Eventis.ApiJob.Extensions;
using Ewai.Eventis.App.Extensions;
using Ewai.Eventis.Hangfire.Extensions;
using Ewai.Eventis.Identity.Dependency;
using Ewai.Eventis.Infrastructure.Extensions;
using Ewai.Eventis.Persistence.Extensions;
using Ewai.SharedKernel.Extensions;

namespace Ewai.Eventis.ApiJob;

/// <summary>
/// On startup, an ASP.NET Core app builds a host.
/// The host encapsulates all of the app's resources.
/// </summary>
public class Startup
{
    /// <summary>
    /// On startup constructor configuration and the environment are injected.
    /// </summary>
    public Startup(
        IConfiguration configuration,
        IHostEnvironment environment)
    {
        Configuration = configuration;
        Environment = environment;
    }

    private IConfiguration Configuration { get; }
    private IHostEnvironment Environment { get; }
    private IServiceCollection Services { get; set; }

    // This method gets called by the runtime. Use this method to add services to the container.
    public void ConfigureServices(IServiceCollection services)
    {
        services.AddPersistence(Configuration, Environment);
        services.AddInfrastructure(Configuration, Environment);
        services.AddUseCaseDependencies(Configuration, Environment);
        services.AddHangfireJobRunner(Configuration, Environment);

        //services.AddCustomControllers(Configuration, Environment);
        services.AddIdentityDependencies(Configuration, Environment);
        //services.AddCustomAuthorization(Configuration);

        services.AddCustomCors(Configuration, Environment);
        //services.AddCustomSwagger(Configuration, Environment);
        //services.AddCustomRateLimiter(Configuration, Environment);
        Services = services;
    }

    /// <summary>
    /// This method gets called by the runtime.
    /// Use this method to configure the HTTP request pipeline.
    /// </summary>
    public void Configure(IApplicationBuilder app, IHostEnvironment env)
    {
        if (env.IsStagingOrProd())
        {
            //app.UseExceptionHandler("/Error");
            app.UseHsts(); // Browsers only
            app.UseHttpsRedirection();
        }

        //app.UseRateLimiter();
        //app.UseCustomSwagger(Configuration, Environment);
        app.UseRouting();
        app.UseCors("CorsPolicy");
        app.UseForwardedHeaders();
        //app.UseAuthentication();
        app.UseIdentityServer();
        //app.UseAuthorization();
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapHangfire(Environment);
            //endpoints.MapControllers(Environment);
        });

        app.ConfigureJobAppLifetimeHandlers(Configuration, Environment);
    }
}