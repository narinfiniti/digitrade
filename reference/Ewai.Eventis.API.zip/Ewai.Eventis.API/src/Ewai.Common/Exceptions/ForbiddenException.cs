﻿using System;
using System.Net;

namespace Ewai.Common.Exceptions;

/// <summary>
/// Necessary permissions exception.
/// </summary>
public class ForbiddenException(
    string message = "Do not have permissions for the operation.",
    Exception innerException = null)
    : StatusCodeException(message, innerException, (int)HttpStatusCode.Forbidden);