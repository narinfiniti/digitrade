using System;

namespace Ewai.Common.Attributes;

public class PermissionAttribute : Attribute
{
    public string Permission { get; set; }
    /// <summary>
    /// </summary>
    /// <param name="permission">The permission</param>
    public PermissionAttribute(string permission)
    {
        Permission = permission;
    }
}