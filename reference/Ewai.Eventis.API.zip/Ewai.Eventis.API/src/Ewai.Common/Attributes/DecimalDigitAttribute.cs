using System;
using System.ComponentModel.DataAnnotations;
using Ewai.Common.Extensions;

namespace Ewai.Common.Attributes;

/// <summary>
/// DecimalDigitAttribute.
/// </summary>
public class DecimalDigitAttribute(byte digits) : ValidationAttribute
{
    public override bool IsValid(object value)
    {
        if (value == null)
        {
            return true;
        }

        if (value.GetType() != typeof(decimal))
        {
            throw new ArgumentException("Invalid type: the argument is not of type decimal.");
        }

        return decimal.TryParse(value?.ToString(), out var val) &&
               val.HasFractionalDigits(digits);
    }
}