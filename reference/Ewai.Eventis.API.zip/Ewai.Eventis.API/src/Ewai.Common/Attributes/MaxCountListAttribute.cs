using System;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using Ewai.Common.Extensions;

namespace Ewai.Common.Attributes;

/// <summary>
/// Max Count list Attribute.
/// </summary>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter)]
public class MaxCountListAttribute(int maxCount) : ValidationAttribute
{
    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        if (value is null) return ValidationResult.Success;
        if (value is IEnumerable collection)
        {
            if (collection.Count() > maxCount)
            {
                return new ValidationResult($"Maximum count is {maxCount}.");
            }
            return ValidationResult.Success;
        }

        return new ValidationResult("Invalid list!");
    }
}