using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Ewai.Common.Extensions;

namespace Ewai.Common.Attributes;

/// <summary>
/// Non-empty list Attribute.
/// </summary>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter)]
public class NonEmptyListAttribute : ValidationAttribute
{
    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        if (value.IsNullOrEmptyList())
        {
            return new ValidationResult($"Non empty array is required: {validationContext.MemberName}.");
        }

        return ValidationResult.Success;
    }
}

public class MaxLengthValuesListAttribute : ValidationAttribute
{
    private readonly HashSet<string> _allowedValues;
    private readonly int _maxLength;

    public MaxLengthValuesListAttribute(int maxLength, params string[] withValues)
    {
        if (maxLength <= 0)
            throw new ArgumentOutOfRangeException(nameof(maxLength), "Max length must be greater than zero.");

        _maxLength = maxLength;
        withValues ??= [];
        _allowedValues = withValues.IsNotEmpty()
            ? new HashSet<string>(withValues, StringComparer.OrdinalIgnoreCase)
            : [];
    }

    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        if (value.IsNullOrEmptyList()) return ValidationResult.Success;
        if (value is not IEnumerable<string> list)
        {
            return new ValidationResult($"Non-empty list is required: {validationContext.MemberName}.");
        }

        if (_allowedValues.Any())
        {
            var invalidValues = list
                .Where(item => !_allowedValues.Contains(item))
                .ToList();

            if (invalidValues.Any())
            {
                return new ValidationResult(
                    $"Invalid values in {validationContext.MemberName}: {string.Join(", ", invalidValues)}. " +
                    $"Allowed values: {string.Join(", ", _allowedValues)}.");
            }
        }

        var overLengthItems = list
            .Where(item => item?.Length > _maxLength)
            .ToList();

        if (overLengthItems.Any())
        {
            return new ValidationResult(
                $"The following values in {validationContext.MemberName} exceed max length of {_maxLength}: {string.Join(", ", overLengthItems)}.");
        }

        return ValidationResult.Success;
    }
}