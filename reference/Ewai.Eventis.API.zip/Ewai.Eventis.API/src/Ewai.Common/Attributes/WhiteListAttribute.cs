using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Ewai.Common.Attributes;

/// <summary>
/// White list Attribute.
/// </summary>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter)]
public class WhiteListAttribute(params object[] whiteList) : ValidationAttribute
{
    private HashSet<object> WhiteList { get; } = [..whiteList];

    public override bool IsValid(object value)
    {
        return WhiteList.Contains(value);
    }

    public override string FormatErrorMessage(string name)
    {
        return $@"{name} accepts values: {string.Join(",", WhiteList)}";
    }
}