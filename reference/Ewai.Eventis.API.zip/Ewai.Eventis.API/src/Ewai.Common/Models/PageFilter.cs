using System.ComponentModel.DataAnnotations;

namespace Ewai.Common.Models;

/// <summary>
/// PageFilter.
/// </summary>
public class PageFilter : SortByFilter
{
    [Range(0, int.MaxValue)] public int Skip { get; set; } = 0;
    [Range(1, int.MaxValue)] public int Page { get; set; } = 1;
    [Range(1, int.MaxValue)] public int Limit { get; set; } = 10;
}

public class SortByFilter
{
    [MaxLength(500)] public string SortBy { get; set; } = "Id desc";
}