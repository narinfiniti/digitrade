﻿using System.Collections.Generic;
using System.Text.Json;

namespace Ewai.Common.Models;

/// <summary>
/// Items as comma joined string and vice versa.
/// </summary>
public class Items<T> : List<T>
    where T : class
{
    public Items()
    { }

    public Items(IEnumerable<T> items) : base(items)
    { }

    public override string ToString()
    {
        return JsonSerializer.Serialize(this);
    }

    public static Items<T> FromString(string value)
    {
        var items = JsonSerializer.Deserialize<IEnumerable<T>>(value);
        return new Items<T>(items);
    }

    public static implicit operator Items<T>(T[] value)
    {
        return new Items<T>(value);
    }
    public static implicit operator T[](Items<T> value)
    {
        return value.ToArray();
    }
}