﻿using System;
using System.Collections.Generic;
using System.Text.Json;
using Ewai.Common.JsonOptions;

namespace Ewai.Common.Models;

/// <summary>
/// Range model type.
/// </summary>
public class RangeOf<T>(T start, T end)
    where T : IComparable
{
    public RangeOf() : this(default, default)
    {
    }

    public static RangeOf<T> FromString(string value)
    {
        var options = JsonSettingProvider.JsonSerializerOps;
        return JsonSerializer.Deserialize<RangeOf<T>>(value, options);
    }

    public T Start { get; set; } = start;
    public T End { get; set; } = end;

    public bool IsIntersecting(RangeOf<T> other)
    {
        return Start.CompareTo(other.End) < 0 && End.CompareTo(other.Start) > 0;
    }

    public bool IsWithin(RangeOf<T> other)
    {
        return (Start.CompareTo(other.Start) > 0 && End.CompareTo(other.End) < 0) ||
               (Start.CompareTo(other.Start) >= 0 && End.CompareTo(other.End) < 0) ||
               (Start.CompareTo(other.Start) > 0 && End.CompareTo(other.End) <= 0);
    }

    public bool IsContinuationOf(RangeOf<T> other) => Start.CompareTo(other.End) == 0;

    protected bool Equals(RangeOf<T> other)
    {
        return EqualityComparer<T>.Default.Equals(Start, other.Start) &&
               EqualityComparer<T>.Default.Equals(End, other.End);
    }


    public override string ToString()
    {
        var options = JsonSettingProvider.JsonSerializerOps;
        return JsonSerializer.Serialize(this, options);
    }

    public override bool Equals(object obj)
    {
        if (obj is not RangeOf<T> ob) return false;
        return Start.CompareTo(ob.Start) == 0 &&
               End.CompareTo(ob.End) == 0;
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(Start, End);
    }
}