﻿using System;

namespace Ewai.Common.Extensions;

public static class GuidExtensions
{
    public static string GenerateRandomStringFromGuid(this Guid guid, int length = 8)
    {
        int seed = BitConverter.ToInt32(guid.ToByteArray(), 0);
        var random = new Random(seed);
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        var result = new char[length];
        for (int i = 0; i < length; i++)
        {
            result[i] = chars[random.Next(chars.Length)];
        }
        return new string(result);
    }

    public static bool IsEmpty(this Guid? guid) => guid is null || guid == Guid.Empty;
    public static bool IsNotEmpty(this Guid? guid) => !guid.IsEmpty();
    public static bool IsEmpty(this Guid guid) => guid == Guid.Empty;
    public static bool IsNotEmpty(this Guid guid) => !guid.IsEmpty();
}