﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace Ewai.Common.Extensions;

/// <summary>
/// Enumerable select extensions.
/// </summary>
public static class EnumerableExtensions
{
    public static IEnumerable<SelectResult<TSource, TResult>> TrySelect<TSource, TResult>(
        this IEnumerable<TSource> enumerable,
        Func<TSource, TResult> selector)
    {
        foreach (var element in enumerable)
        {
            SelectResult<TSource, TResult> returnedValue;
            try
            {
                returnedValue = new SelectResult<TSource, TResult>(element, selector(element), null);
            }
            catch (Exception ex)
            {
                returnedValue = new SelectResult<TSource, TResult>(element, default, ex);
            }

            yield return returnedValue;
        }
    }

    public static IEnumerable<TResult> Catch<TSource, TResult>(
        this IEnumerable<SelectResult<TSource, TResult>> enumerable,
        Func<Exception, TResult> exceptionHandler)
    {
        return enumerable.Select(x => x.CaughtException == null ? x.Result : exceptionHandler(x.CaughtException));
    }

    public static IEnumerable<TResult> Catch<TSource, TResult>(
        this IEnumerable<SelectResult<TSource, TResult>> enumerable,
        Func<TSource, Exception, TResult> exceptionHandler)
    {
        return enumerable.Select(x =>
            x.CaughtException == null ? x.Result : exceptionHandler(x.Source, x.CaughtException));
    }

    public class SelectResult<TSource, TResult>
    {
        internal SelectResult(TSource source, TResult result, Exception exception)
        {
            Source = source;
            Result = result;
            CaughtException = exception;
        }

        public TSource Source { get; private set; }
        public TResult Result { get; private set; }
        public Exception CaughtException { get; private set; }
    }

    public static bool IsNullOrEmptyList(this object list)
    {
        return list is null or Array { Length: 0 } or ICollection { Count: 0 };
    }
    public static bool IsEmpty(this IEnumerable list)
    {
        return list is null or Array { Length: 0 } or ICollection { Count: 0 };
    }
    public static bool IsNotEmpty(this IEnumerable list)
    {
        return list is Array { Length: > 0 } or ICollection { Count: > 0 };
    }

    public static string HasValue(this IEnumerable list, string result)
    {
        return list.IsNotEmpty() ? result : string.Empty;
    }

    public static int Count(this IEnumerable list)
    {
        return list switch
        {
            Array array => array.Length,
            ICollection collection => collection.Count,
            _ => 0
        };
    }

    public static bool Is(this IEnumerable list1, IEnumerable list2)
    {
        if (list1 == null || list2 == null) return false;
        var json1 = JsonSerializer.Serialize(list1);
        var json2 = JsonSerializer.Serialize(list2);
        return json1.Is(json2);
    }

    public static bool IsNot(this IEnumerable list1, IEnumerable list2)
    {
        return !list1.Is(list2);
    }
}