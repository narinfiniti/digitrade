﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.RegularExpressions;
using System.Web;

namespace Ewai.Common.Extensions;

/// <summary>
/// StringExtensions
/// </summary>
public static class StringExtensions
{
    public static string ToSpaceSeparatedString(this IEnumerable<string> list)
    {
        if (list == null)
        {
            return string.Empty;
        }

        var sb = new StringBuilder(100);

        foreach (var element in list)
        {
            sb.Append(element + " ");
        }

        return sb.ToString().Trim();
    }

    public static IEnumerable<string> FromSpaceSeparatedString(this string input)
    {
        input = input.Trim();
        return input.Split([' '], StringSplitOptions.RemoveEmptyEntries).ToList();
    }

    public static bool IsEmpty(this string str)
    {
        return string.IsNullOrEmpty(str) || string.IsNullOrWhiteSpace(str);
    }

    public static bool IsNotEmpty(this string str)
    {
        return !str.IsEmpty();
    }

    public static string HasValue(this string str, string result)
    {
        return !str.IsEmpty() ? result : string.Empty;
    }

    public static string HasValue<T>(this T? str, string result) where T : struct
    {
        return str.HasValue ? result : string.Empty;
    }

    public static List<string> ParseScopesString(this string scopes)
    {
        if (scopes.IsEmpty())
        {
            return null;
        }

        scopes = scopes.Trim();
        var parsedScopes = scopes
            .Split([' '], StringSplitOptions.RemoveEmptyEntries)
            .Distinct().ToList();

        if (parsedScopes.Any())
        {
            parsedScopes.Sort();
            return parsedScopes;
        }

        return null;
    }

    public static string ReplaceRecursive(this string value, string pattern, string val = "")
    {
        while (value.Contains(pattern))
        {
            value = value.Replace(pattern, val);
        }

        return value;
    }

    public static bool IsMissingOrTooLong(this string value, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return true;
        }

        if (value.Length > maxLength)
        {
            return true;
        }

        return false;
    }

    public static string EnsureLeadingSlash(this string url)
    {
        if (url != null && !url.StartsWith("/"))
        {
            return "/" + url;
        }

        return url;
    }

    public static string EnsureTrailingSlash(this string url)
    {
        return url?.EndsWith("/") == false ? $"{url}/" : url;
    }

    public static string RemoveLeadingSlash(this string url)
    {
        return url?.StartsWith("/") == true ? url[1..] : url;
    }

    public static string RemoveTrailingSlash(this string url)
    {
        return url?.EndsWith("/") == true ? url[..^1] : url;
    }

    public static string CleanUrlPath(this string url)
    {
        return url != "/" && url?.EndsWith("/") == true ? url[..^1] : url;
    }

    public static bool IsLocalUrl(this string url)
    {
        if (string.IsNullOrEmpty(url))
        {
            return false;
        }

        // Allows "/" or "/foo" but not "//" or "/\".
        if (url[0] == '/')
        {
            // url is exactly "/"
            if (url.Length == 1)
            {
                return true;
            }

            // url doesn't start with "//" or "/\"
            if (url[1] != '/' && url[1] != '\\')
            {
                return true;
            }

            return false;
        }

        // Allows "~/" or "~/foo" but not "~//" or "~/\".
        if (url[0] == '~' && url.Length > 1 && url[1] == '/')
        {
            // url is exactly "~/"
            if (url.Length == 2)
            {
                return true;
            }

            // url doesn't start with "~//" or "~/\"
            if (url[2] != '/' && url[2] != '\\')
            {
                return true;
            }

            return false;
        }

        return false;
    }

    public static string AddQueryString(this string url, string query)
    {
        if (!url.Contains("?"))
        {
            url += "?";
        }
        else if (!url.EndsWith("&"))
        {
            url += "&";
        }

        return url + query;
    }

    public static string AddQueryString(this string url, string name, string value)
    {
        return url.AddQueryString(name + "=" + UrlEncoder.Default.Encode(value));
    }

    public static string ToQueryString<T>(this T ob, bool lowerCase = true)
    {
        var nameValuePairs = ob.GetType().GetProperties()
            .Select(p =>
            {
                var val = p.GetValue(ob, null)?.ToString();
                return $"{p.Name}={HttpUtility.UrlEncode(val)}";
            });
        var result = $"?{string.Join("&", nameValuePairs)}";
        return lowerCase
            ? result.ToLower()
            : result;
    }

    public static string ToQueryString(this NameValueCollection pairs)
    {
        if (pairs == null) return string.Empty;

        var sb = new StringBuilder();

        foreach (string key in pairs.Keys)
        {
            if (string.IsNullOrWhiteSpace(key)) continue;

            var values = pairs.GetValues(key);
            if (values == null) continue;

            foreach (var value in values)
            {
                sb.Append(sb.Length == 0 ? "?" : "&");
                sb.AppendFormat("{0}={1}", Uri.EscapeDataString(key), Uri.EscapeDataString(value));
            }
        }

        return sb.ToString();
    }

    public static string AddHashFragment(this string url, string query)
    {
        return url.Contains('#')
            ? $"{url}{query}"
            : $"{url}#{query}";
    }

    public static string GetOrigin(this string url)
    {
        if (url == null) return null;
        try
        {
            var uri = new Uri(url);
            if (uri.Scheme is "http" or "https")
            {
                return $"{uri.Scheme}://{uri.Authority}";
            }
        }
        catch (Exception)
        {
            return null;
        }

        return null;
    }

    public static string Replace(this string input, string regex = "[^'a-zA-Z0-9 -]", string replace = "")
    {
        var whiteListRegex = new Regex(regex);
        if (!string.IsNullOrEmpty(input) && !string.IsNullOrWhiteSpace(input))
        {
            input = input.Trim();
            try
            {
                while (whiteListRegex.IsMatch(input))
                {
                    input = whiteListRegex.Replace(input, replace);
                }

                return input;
            }
            catch (Exception)
            {
                // ignored
            }
        }

        return string.Empty;
    }

    public static string AsOneLine(this string text, string separator = " ")
    {
        return Regex.Replace(text, @"(?:\n(?:\s*))+", separator).Trim();
    }
    public static string RemoveEmptyLines(this string text)
    {
        // Use Regex to match only empty lines (\r?\n for line endings, \s* for possible whitespace)
        return Regex.Replace(text, @"^\s*$[\r\n]*", string.Empty, RegexOptions.Multiline);
    }

    public static string FirstLower(this string str)
    {
        if (string.IsNullOrEmpty(str) || char.IsLower(str, 0))
        {
            return str;
        }

        return $"{char.ToLowerInvariant(str[0])}{str[1..]}";
    }

    public static string Capitalize(this string word)
    {
        return $"{char.ToUpper(word[0])}{word[1..]}";
    }

    public static string ToUpperEveryWord(this string sentence)
    {
        return sentence.IsEmpty()
            ? string.Empty
            : new CultureInfo("en-US", false).TextInfo.ToTitleCase(sentence);
    }

    public static bool ContainsAny(this string name, IEnumerable<string> blackList)
    {
        return name.IsNotEmpty() && blackList.Any(item => name.Contains(item, StringComparison.OrdinalIgnoreCase));
    }

    public static bool IsUnderscored(this string s, string val)
    {
        return s.Is(val);
    }

    public static bool Is(this string s, string val)
    {
        s = s?.Replace(" ", "_") ?? string.Empty;
        val = val?.Replace(" ", "_") ?? string.Empty;
        if(s.IsEmpty() || val .IsEmpty()) return false;
        return s.Equals(val, StringComparison.OrdinalIgnoreCase);
    }

    public static bool Includes(this string s, string val)
    {
        s = s?.Replace(" ", "_") ?? string.Empty;
        val = val?.Replace(" ", "_") ?? string.Empty;
        if(s.IsEmpty() || val .IsEmpty()) return false;
        return s.Contains(val, StringComparison.OrdinalIgnoreCase);
    }

    public static bool IsNot(this string s, string val)
    {
        return !s.Is(val);
    }

    public static string RemoveTabsAndSpacesAndQuotes(this string input)
    {
        return input.IsEmpty()
            ? input
            : Regex.Replace(input, "[\t \"']", string.Empty);
    }
}