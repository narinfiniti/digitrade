﻿using System.IO;

namespace Ewai.Common.Extensions;

public static class BlobSupabaseStorageExtensions
{
    public static byte[] ReadBytes(this Stream input)
    {
        using var ms = new MemoryStream();
        input.CopyTo(ms);
        return ms.ToArray();
    }
}