﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;

namespace Ewai.Common.Extensions;

/// <summary>
/// Enum Extensions.
/// </summary>
public static class Enum<T> where T : struct, Enum
{
    public static string GetDisplayName(Enum enumValue)
    {
        return enumValue.GetType()
            .GetMember(enumValue.ToString())
            .FirstOrDefault()?
            .GetCustomAttribute<DisplayAttribute>()?
            .GetName();
    }

    public static string GetDescription(Enum enumValue)
    {
        return enumValue.GetType()
            .GetMember(enumValue.ToString())
            .FirstOrDefault()?
            .GetCustomAttribute<DescriptionAttribute>()?
            .Description;
    }

    public static List<T> GetAllValues()
    {
        return Enum.GetValues(typeof(T)).Cast<T>().ToList();
    }

    public static T? GetValue(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            return null;

        if (Enum.TryParse<T>(name, true, out var result))
            return result;

        return null; // return null if not found
    }
}