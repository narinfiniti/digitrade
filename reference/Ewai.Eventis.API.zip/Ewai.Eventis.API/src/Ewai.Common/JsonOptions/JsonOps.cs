﻿using System.Text.Json;
using System.Text.Json.Nodes;

namespace Ewai.Common.JsonOptions;

public class JsonOps
{
    public JsonNodeOptions JsonNodeOps { get; }
    public JsonSerializerOptions Serialize { get; }
    public JsonSerializerOptions Deserialize { get; }
    public JsonOps()
    {
        JsonNodeOps = JsonSettingProvider.JsonNodeOps;
        Serialize = JsonSettingProvider.JsonSerializerOps;
        // Only place we need GetSerializerOptions().
        Deserialize = JsonSettingProvider.GetSerializerOptions();
        Deserialize.WriteIndented = true;
    }
}