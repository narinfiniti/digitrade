﻿using System.ComponentModel.DataAnnotations;
using System.Data;
using Ewai.Common.Models;
using Ewai.Eventis.Messaging.Abstractions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using ValidationException = Ewai.Common.Exceptions.ValidationException;

namespace Ewai.Eventis.Messaging.Persistence.Common;

public sealed class EventSnapshotUnitOfWork : DbContext, IEventSnapshotUnitOfWork
{
    public const string DbScheme = "msg";

    public EventSnapshotUnitOfWork(DbContextOptions<EventSnapshotUnitOfWork> options) : base(options)
    {
        ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
    }

    public Task MigrateAsync(CancellationToken cancellationToken = default)
    {
        return Database.MigrateAsync(cancellationToken);
    }

    public Task<bool> CanConnectAsync(CancellationToken cancellationToken = default)
    {
        return Database.CanConnectAsync(cancellationToken);
    }
    public async Task<bool> HasPendingMigrationsAsync(CancellationToken cancellationToken = default)
    {
        return (await Database.GetPendingMigrationsAsync(cancellationToken)).Any();
    }
    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.HasDefaultSchema(DbScheme);
        builder.ApplyConfigurationsFromAssembly(GetType().Assembly);
        //builder.ApplySoftDeleteQueryFilter();
        //builder.AddShadowProperties();
    }

    public void ValidateAggregateRootInvariantRules()
    {
        var serviceProvider = Database.GetInfrastructure();
        if (serviceProvider is null) return;

        var errors = new List<ValidationFailure>();
        var validationResults = ChangeTracker.Entries<IValidatableObject>()
            .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified)
            .SelectMany(e => e.Entity.Validate(new ValidationContext(serviceProvider)))
            .Where(r => r != ValidationResult.Success);

        foreach (var validationResult in validationResults)
        {
            var names = string.Join(", ", validationResult.MemberNames);
            errors.Add(new ValidationFailure(names, validationResult.ErrorMessage));
        }

        if (errors.Any())
        {
            throw new ValidationException(failures: errors);
        }
    }

    public async ValueTask<int> SaveAsync(CancellationToken cancellation = default)
    {
        ValidateAggregateRootInvariantRules();
        return await SaveChangesAsync(cancellation);
    }

    public async Task<bool> SaveEntitiesAsync(CancellationToken cancellation = default)
    {
        // Dispatch Domain Events collection. 
        // Choices:
        // A) Right BEFORE committing data (EF SaveChanges) into the DB will make a single transaction including  
        // side effects from the domain event handlers which are using the same DbContext with "InstancePerLifetimeScope" or "scoped" lifetime
        // B) Right AFTER committing data (EF SaveChanges) into the DB will make multiple transactions. 
        // You will need to handle eventual consistency and compensatory actions in case of failures in any of the Handlers. 
        //await _mediator.DispatchDomainEventsAsync(this);

        // After executing this line all the changes (from the Command Handler and Domain Event Handlers) 
        // performed through the DbContext will be committed
        var result = await SaveChangesAsync(cancellation);
        return result > 0;
    }

    public async ValueTask CommitAsync(
        Func<CancellationToken, Task> actionAsync,
        CancellationToken cancellationToken = default)
    {
        var database = Database;
        var strategy = database.CreateExecutionStrategy();

        await strategy.ExecuteAsync(async () =>
        {
            var transaction = CurrentTransaction ??= await database
                .BeginTransactionAsync(IsolationLevel.ReadCommitted, cancellationToken);
            try
            {
                await transaction.CreateSavepointAsync($"{transaction.TransactionId:N}", cancellationToken);
                await SaveAsync(cancellationToken);
                await actionAsync(cancellationToken);
                await transaction.CommitAsync(cancellationToken);
            }
            catch
            {
                await RollbackAsync(transaction, cancellationToken);
                throw;
            }
            finally
            {
                transaction.Dispose();
                CurrentTransaction = null;
            }
        }).ConfigureAwait(false);
    }

    public IDbContextTransaction CurrentTransaction { get; private set; }

    public bool HasActiveTransaction => CurrentTransaction != null;

    private async Task RollbackAsync(IDbContextTransaction transaction, CancellationToken cancellationToken)
    {
        try
        {
            //await transaction.RollbackAsync(cancellationToken);
            await transaction.RollbackToSavepointAsync($"{transaction.TransactionId:N}", cancellationToken);
        }
        finally
        {
            transaction?.Dispose();
        }
    }
}