﻿using Ewai.Eventis.Messaging.Persistence.Common;
using Ewai.SharedKernel.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Ewai.Eventis.Messaging.Persistence.Extensions;

/// <summary>
/// DbMigrationExtensions.
/// </summary>
public static class DbMigrationExtensions
{
    /// <summary>
    /// Migrate IdentityServer database.
    /// </summary>
    public static async Task MigrateEventBusDatabaseAsync(this IHost host, IConfiguration config)
    {
        using var scope = host.Services.CreateScope();
        var provider = scope.ServiceProvider;

        if (config.GetValue<bool>("AppOptions:RunDbMigrations"))
        {
            var env = provider.GetRequiredService<IHostEnvironment>();
            var logger = provider.GetRequiredService<ILogger<EventSnapshotUnitOfWork>>();
            if (env.IsEnvironment("Test")) return;

            logger.LogInformation("Applying Integration Event migrations");
            await provider.MigrateAsync<EventSnapshotUnitOfWork>(config, p => p.GetService<EventSnapshotUnitOfWork>().Database.MigrateAsync());
        }
    }
}