﻿using Ewai.Eventis.Messaging.Abstractions;
using Ewai.Eventis.Messaging.Persistence.Common;
using Ewai.Eventis.Messaging.Persistence.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Ewai.Eventis.Messaging.Persistence.Extensions;

public static class DependencyExtensions
{
    public static void AddEventMessagingPersistence(
        this IServiceCollection services,
        IConfiguration config, IHostEnvironment env)
    {
        var conn = config.GetConnectionString("DefaultConnection");
        if (!env.IsEnvironment("Test"))
        {
            services.AddDbContextPool<EventSnapshotUnitOfWork>(options =>
                //options.UseSqlServer(conn, b =>
                    options.UseNpgsql(conn, b =>
                    {
                        b.MigrationsAssembly(typeof(EventSnapshotUnitOfWork).Assembly.FullName);
                        // Connection Resiliency: https://docs.microsoft.com/en-us/ef/core/miscellaneous/connection-resiliency 
                        b.EnableRetryOnFailure(
                            maxRetryCount: 3,
                            maxRetryDelay: TimeSpan.FromSeconds(5),
                            errorCodesToAdd: null);
                        b.UseQuerySplittingBehavior(QuerySplittingBehavior.SingleQuery);
                    })
                    .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                    .ConfigureWarnings(x => x.Ignore(RelationalEventId.MultipleCollectionIncludeWarning)));
        }

        services.AddScoped<IEventSnapshotUnitOfWork, EventSnapshotUnitOfWork>();
        services.AddScoped<IEventSnapshotService, EventSnapshotService>();

        // services.AddTransient<Func<DbConnection, EventSnapshotService>>(
        //     sp => (DbConnection conn) => new EventSnapshotService(conn));
    }
}