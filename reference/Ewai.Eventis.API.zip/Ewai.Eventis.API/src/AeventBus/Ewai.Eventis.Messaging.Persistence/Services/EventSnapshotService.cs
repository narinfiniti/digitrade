﻿using System.Text.Json;
using Ewai.Common.Extensions;
using Ewai.Common.JsonOptions;
using Ewai.Eventis.Messaging.Abstractions;
using Ewai.Eventis.Messaging.Abstractions.Entity;
using Ewai.Eventis.Messaging.Abstractions.Enums;
using Ewai.Eventis.Messaging.Abstractions.Events;
using Ewai.Eventis.Messaging.Persistence.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace Ewai.Eventis.Messaging.Persistence.Services;

public sealed class EventSnapshotService : IEventSnapshotService, IDisposable
{
    private readonly JsonOps _jsonOps;
    private readonly ISubscriptionManager _subscriptionManager;
    private readonly EventSnapshotUnitOfWork _db;
    private readonly DbSet<IntegrationEventSnapshot> _dbSet;
    private volatile bool _disposed;

    public EventSnapshotService(
        JsonOps jsonOps,
        IEventSnapshotUnitOfWork db,
        ISubscriptionManager subscriptionManager)
    {
        _jsonOps = jsonOps;
        _subscriptionManager = subscriptionManager;
        _db = (EventSnapshotUnitOfWork)db;
        _dbSet = _db.Set<IntegrationEventSnapshot>();
    }

    public async Task<IEnumerable<IntegrationEventSnapshot>> GetEventsPendingToPublishAsync(Guid? transactionId)
    {
        var tid = transactionId?.ToString();

        var result = await _dbSet
            .OrderBy(o => o.DateCreated)
            .Where(e => e.State == EventStateEnum.NotPublished ||
                        e.State == EventStateEnum.InProgress ||
                        e.State == EventStateEnum.PublishFailed)
            .WhereIf(tid.IsNotEmpty(), e => e.TransactionId == tid)
            .ToListAsync();
        var subManager = _subscriptionManager;
        return result.Count > 0
            ? result.Select(e => DeserializeJsonContent(e, subManager.GetEventTypeByName(e.EventTypeShortName)))
            : result;
    }

    public Task SaveEventAsync(IIntegrationEvent @event, object tran = null)
    {
        Guid? transactionId = null;
        if (tran is IDbContextTransaction contextTransaction)
        {
            transactionId = contextTransaction.TransactionId;
            _db.Database.UseTransaction(contextTransaction.GetDbTransaction());
        }

        var eventSnapshot = new IntegrationEventSnapshot(@event, transactionId, _jsonOps);
        _dbSet.Add(eventSnapshot);

        return _db.SaveChangesAsync();
    }

    public Task MarkEventAsPublishedAsync(IntegrationEventSnapshot snapshot)
    {
        return UpdateEventStatus(snapshot, EventStateEnum.Published);
    }

    public Task MarkEventAsInProgressAsync(IntegrationEventSnapshot snapshot)
    {
        return UpdateEventStatus(snapshot, EventStateEnum.InProgress);
    }

    public Task MarkEventAsFailedAsync(IntegrationEventSnapshot snapshot)
    {
        return UpdateEventStatus(snapshot, EventStateEnum.PublishFailed);
    }

    private async Task UpdateEventStatus(IntegrationEventSnapshot snapshot, EventStateEnum status)
    {
        //var entity = await _dbSet.SingleOrDefaultAsync(ie => ie.Id == snapshot.Id);
        //if(entity is null) return;

        snapshot.State = status;
        if (status == EventStateEnum.InProgress && snapshot.SentCount < int.MaxValue)
        {
            snapshot.SentCount++;
        }

        _dbSet.Update(snapshot);
        await _db.SaveChangesAsync();
    }

    private IntegrationEventSnapshot DeserializeJsonContent(IntegrationEventSnapshot snapshot, Type type)
    {
        var content = JsonSerializer.Deserialize(snapshot.Content, type, _jsonOps.Deserialize);
        if (snapshot.Content != null && type != null &&
            content is IIntegrationEvent evn)
        {
            snapshot.IntegrationEvent = evn;
        }

        return snapshot;
    }
    private void Dispose(bool disposing)
    {
        if (!_disposed)
        {
            if (disposing)
            {
                _db?.Dispose();
            }


            _disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(disposing: true);
        GC.SuppressFinalize(this);
    }

    ~EventSnapshotService()
    {
        Dispose(disposing: false);
    }
}