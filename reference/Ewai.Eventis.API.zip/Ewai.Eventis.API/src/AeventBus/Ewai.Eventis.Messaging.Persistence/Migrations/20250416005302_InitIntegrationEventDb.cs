﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ewai.Eventis.Messaging.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class InitIntegrationEventDb : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "msg");

            migrationBuilder.CreateTable(
                name: "IntegrationEventSnapshot",
                schema: "msg",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    Type = table.Column<int>(type: "integer", nullable: false),
                    State = table.Column<byte>(type: "smallint", nullable: false),
                    SentCount = table.Column<int>(type: "integer", nullable: false),
                    EventTypeName = table.Column<string>(type: "varchar(500)", nullable: false),
                    DateCreated = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    TransactionId = table.Column<string>(type: "varchar(36)", nullable: true),
                    Content = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IntegrationEventSnapshot", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_IntegrationEventSnapshot_Type",
                schema: "msg",
                table: "IntegrationEventSnapshot",
                column: "Type")
                .Annotation("Npgsql:IndexInclude", new[] { "State", "SentCount", "DateCreated", "TransactionId" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "IntegrationEventSnapshot",
                schema: "msg");
        }
    }
}
