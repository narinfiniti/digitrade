﻿using Ewai.Eventis.Messaging.Abstractions.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Ewai.Eventis.Messaging.Persistence.EntityConfigurations;

public class IntegrationEventSnapshotEntityConfig : IEntityTypeConfiguration<IntegrationEventSnapshot>
{
    public void Configure(EntityTypeBuilder<IntegrationEventSnapshot> b)
    {
        b.Ignore(e => e.IntegrationEvent);
        b.Ignore(e => e.EventTypeShortName);
        b.ToTable(nameof(IntegrationEventSnapshot));
        b.HasKey(e => e.Id);
        b.HasIndex(e => e.Type).IncludeProperties(e => new { e.State, e.SentCount, e.DateCreated, e.TransactionId });

        b.Property(e => e.Id).IsRequired();
        b.Property(e => e.Type).IsRequired();
        b.Property(e => e.State).HasColumnType("smallint").IsRequired();
        b.Property(e => e.SentCount).IsRequired();
        b.Property(e => e.DateCreated).HasColumnType("timestamp without time zone").IsRequired();
        b.Property(e => e.TransactionId).HasColumnType("varchar(36)").IsRequired(false);
        b.Property(e => e.EventTypeName).HasColumnType("varchar(500)").IsRequired();
        b.Property(e => e.Content).HasColumnType("text").IsRequired(false);
    }
}