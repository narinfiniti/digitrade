﻿using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using Ewai.Common.JsonOptions;
using Ewai.Eventis.Messaging.Abstractions;
using Ewai.Eventis.Messaging.Abstractions.Config;
using Ewai.Eventis.Messaging.Abstractions.Events;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Polly;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RabbitMQ.Client.Exceptions;

namespace Ewai.Eventis.Messaging;

public class EventBusRabbitMq : IEventBus, IDisposable
{
    private const string ExchangeType = "direct";

    private readonly IRabbitMqConnection _connection;
    private readonly JsonOps _jsonOps;
    private readonly ILogger _logger;

    private readonly ISubscriptionManager _subManager;
    private readonly IServiceScopeFactory _serviceScopeFactory;
    private readonly RabbitMqOptions _mqOptions;

    private IChannel? _consumerChannel;
    private string _queueName;
    private readonly string _exchange;


    public EventBusRabbitMq(
        IServiceScopeFactory serviceScopeFactory,
        IRabbitMqConnection connection,
        JsonOps jsonOps,
        ISubscriptionManager subManager,
        ILogger<EventBusRabbitMq> logger,
        RabbitMqOptions mqOptions)
    {
        _jsonOps = jsonOps;
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _connection = connection ?? throw new ArgumentNullException(nameof(connection));
        _serviceScopeFactory = serviceScopeFactory;

        _mqOptions = mqOptions;
        _queueName = mqOptions.ClientQueueName;
        _exchange = "eventis.direct";

        _subManager = subManager;
        // _subManager.OnEventRemoved += SubManagerOnEventRemoved;
        Task.Run(CreateConsumerChannel);
    }

    public void Dispose()
    {
        _subManager.Clear();
        _consumerChannel?.Dispose();
        _consumerChannel = null;
    }

    public async ValueTask Publish(IIntegrationEvent @event)
    {
        if (!await _connection.TryConnect()) return;

        var policy = Policy
            .Handle<BrokerUnreachableException>()
            .Or<SocketException>()
            .WaitAndRetryAsync(_mqOptions.RetryCount, retryAttempt => TimeSpan.FromSeconds(2),
                (ex, time) =>
                {
                    _logger.LogWarning(ex,
                        $"Could not publish event: {@event.Id} after {time.TotalSeconds:n1}s ({ex.Message})");
                });

        var (eventName, _) = _subManager.GetEventNameWithRoutingKeys(@event.GetType());
        await policy.ExecuteAndCaptureAsync(async () =>
        {
            await using var channel = await _connection.CreateChannelAsync();
            if (channel is null)
            {
                _logger.LogError("Channel cannot be created to publish event: {EventId}", @event.Id);
                return;
            }

            await channel.ExchangeDeclareAsync(exchange: _exchange, type: ExchangeType);

            var properties = new BasicProperties
            {
                Persistent = true,
                DeliveryMode = DeliveryModes.Persistent
            };

            //using var utf8Json = new MemoryStream();
            var body = JsonSerializer.Serialize((object)@event, _jsonOps.Serialize);
            await channel.BasicPublishAsync(
                exchange: _exchange,
                routingKey: $"{eventName}_{@event.QueueName}",
                mandatory: true,
                basicProperties: properties,
                body: Encoding.UTF8.GetBytes(body));
        });
    }

    public async ValueTask Subscribe(Type eventType, Type handlerType)
    {
        if (!await _connection.TryConnect()) return;

        var (_, routingKeys) = _subManager.GetEventNameWithRoutingKeys(eventType);
        _subManager.AddEventType<IIntegrationEvent>(eventType, routingKeys);

        await using var channel = await _connection.CreateChannelAsync();
        if (channel == null) return;
        foreach (var routingKey in routingKeys)
        {
            if (_subManager.HasSubscriptionsForEvent(routingKey)) continue;
            _subManager.AddSubscription(routingKey, handlerType);
            await channel.QueueBindAsync(queue: _queueName, exchange: _exchange, routingKey: routingKey);
        }
    }

    public void Unsubscribe(Type eventType)
    {
        var (_, routingKeys) = _subManager.GetEventNameWithRoutingKeys(eventType);
        _subManager.RemoveAllSubscriptions(routingKeys);
    }

    private async ValueTask SubManagerOnEventRemoved(object? sender, List<string> routingKeys)
    {
        if (!await _connection.TryConnect()) return;

        await using var channel = await _connection.CreateChannelAsync();
        if (channel == null) return;
        foreach (var routingKey in routingKeys)
        {
            if (!_subManager.HasSubscriptionsForEvent(routingKey)) continue;
            try
            {
                await channel.QueueUnbindAsync(queue: _queueName, exchange: _exchange, routingKey: routingKey);
            }
            catch (Exception)
            {
                /*ignore*/
            }
        }

        if (_subManager.IsEmpty)
        {
            _queueName = string.Empty;
            if (_consumerChannel != null) await _consumerChannel.CloseAsync();
        }
    }

    private async ValueTask<IChannel?> CreateConsumerChannel()
    {
        if (!await _connection.TryConnect()) return null;

        _logger.LogTrace("Creating RabbitMQ consumer channel");

        var channel = await _connection.CreateChannelAsync();
        if (channel is null)
        {
            _logger.LogError($"Channel cannot be created: {nameof(CreateConsumerChannel)}");
            return null;
        }

        await channel.ExchangeDeclareAsync(exchange: _exchange, type: ExchangeType);

        await channel.QueueDeclareAsync(queue: _queueName,
            durable: true,
            exclusive: false,
            autoDelete: false,
            arguments: null);

        var logger = _logger;
        channel.CallbackExceptionAsync += async (sender, ea) =>
        {
            logger.LogWarning(ea.Exception, "Recreating RabbitMQ consumer channel");

            await channel.DisposeAsync();
            await CreateConsumerChannel();
        };
        _consumerChannel = channel;
        await StartBasicConsume();
        return channel;
    }

    private async ValueTask StartBasicConsume()
    {
        _logger.LogTrace("Starting RabbitMQ basic consume");

        if (_consumerChannel is not null)
        {
            var consumer = new AsyncEventingBasicConsumer(_consumerChannel);

            consumer.ReceivedAsync += Consumer_Received;

            await _consumerChannel.BasicConsumeAsync(queue: _queueName, autoAck: false, consumer: consumer);
        }
        else
        {
            _logger.LogError("StartBasicConsume can't call: ConsumerChannel is null");
        }
    }

    private async Task Consumer_Received(object sender, BasicDeliverEventArgs eventArgs)
    {
        try
        {
            await ProcessEvent(
                eventArgs.RoutingKey,
                Encoding.UTF8.GetString(eventArgs.Body.Span));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, $"Processing message ERROR: \"{ex.Message}\"");
        }

        // Even on exception we take the message off the queue.
        // in a REAL WORLD app this should be handled with a Dead Letter Exchange (DLX). 
        // For more information see: https://www.rabbitmq.com/dlx.html
        if (_consumerChannel != null) await _consumerChannel.BasicAckAsync(eventArgs.DeliveryTag, multiple: false);
    }

    private async ValueTask ProcessEvent(string eventName, string message)
    {
        _logger.LogTrace($"Processing RabbitMQ event: {eventName}, Message: {message}");
        if (!_subManager.HasSubscriptionsForEvent(eventName)) return;

        using var scope = _serviceScopeFactory.CreateScope();

        var subscriptions = _subManager.GetHandlersForEvents([eventName]);
        foreach (var subscription in subscriptions)
        {
            if (subscription.IsDynamic &&
                scope.ServiceProvider.GetService(subscription.HandlerType)
                    is IIntegrationEventHandlerDynamic dynamicHandler)
            {
                //using var utf8Json = new MemoryStream(messageBytes);
                var eventData = JsonSerializer.Deserialize<dynamic>(message, _jsonOps.Deserialize);

                //await Task.Yield();
                await dynamicHandler.Handle(eventData);
            }
            else
            {
                var handler = scope.ServiceProvider.GetService(subscription.HandlerType);
                if (handler is null) continue;

                var eventType = _subManager.GetEventTypeByName(eventName);
                if (eventType is not null)
                {
                    //using var utf8Json = new MemoryStream(messageBytes);
                    var eventData = JsonSerializer.Deserialize(message, eventType, _jsonOps.Deserialize);
                    var concreteType = typeof(IIntegrationEventHandler<>).MakeGenericType(eventType);

                    //await Task.Yield();
                    var handlerMethod = concreteType.GetMethod("Handle");
                    if (handlerMethod?.Invoke(handler, [eventData]) is Task result)
                    {
                        await result;
                    }
                }
            }
        }
    }
}