﻿using RabbitMQ.Client;

namespace Ewai.Eventis.Messaging;

public interface IRabbitMqConnection
    : IDisposable
{
    bool IsConnected { get; }

    ValueTask<bool> TryConnect();

    ValueTask<IChannel?> CreateChannelAsync();
}