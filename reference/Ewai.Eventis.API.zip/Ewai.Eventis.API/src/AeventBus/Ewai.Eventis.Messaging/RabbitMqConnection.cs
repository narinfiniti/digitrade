﻿using System.Net.Sockets;
using Microsoft.Extensions.Logging;
using Polly;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RabbitMQ.Client.Exceptions;

namespace Ewai.Eventis.Messaging;

public class RabbitMqConnection(
    IConnectionFactory connectionFactory,
    ILogger<RabbitMqConnection> logger)
    : IRabbitMqConnection
{
    private readonly IConnectionFactory _connectionFactory =
        connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));

    private readonly ILogger _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    private IConnection? _connection;
    private bool _disposed;
    private readonly object _syncRoot = new();
    public bool IsConnected => _connection?.IsOpen == true && !_disposed;

    public void Dispose()
    {
        if (_disposed || _connection is null) return;

        _disposed = true;

        try
        {
            _connection.Dispose();
            _connection = null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, ex.Message);
        }
    }

    public async ValueTask<IChannel?> CreateChannelAsync()
    {
        if (!IsConnected)
        {
            throw new InvalidOperationException("No RabbitMQ connections are available to perform this action");
        }

        if (_connection == null) return null;
        return await _connection.CreateChannelAsync();
    }

    public async ValueTask<bool> TryConnect()
    {
        // if(!_mqOptions.IsCloudNode &&
        //    !await _commonService.IsInternetConnected(timeout: 5000))
        // {
        //     _logger.LogInformation("RabbitMQ: No internet connection.");
        //     return false;
        // }

        if (IsConnected) return true;
        _logger.LogInformation("RabbitMQ: trying to connect...");

        var lockWasTaken = false;
        try
        {
            Monitor.Enter(_syncRoot, ref lockWasTaken);

            if (IsConnected) return true;
            var policy = Policy
                .Handle<SocketException>()
                .Or<BrokerUnreachableException>()
                .Or<Exception>()
                .WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromSeconds(2),
                    (ex, retry, time) =>
                    {
                        _logger.LogWarning($"RabbitMQ: Client reconnect: {retry}, ex: ({ex.Message})");
                    });
            //await policy.ExecuteAsync(action: () => Task.FromResult(_connection = _connectionFactory.CreateConnection()));
            await policy.ExecuteAsync(async () => _connection = await _connectionFactory.CreateConnectionAsync());

            if (_connection?.IsOpen == true)
            {
                _connection.ConnectionShutdownAsync += OnConnectionShutdownAsync;
                _connection.CallbackExceptionAsync += OnCallbackExceptionAsync;
                _connection.ConnectionBlockedAsync += OnConnectionBlockedAsync;

                _logger.LogInformation(
                    $"RabbitMQ: Client connected: {_connection.Endpoint.HostName} and subscribed to events");

                return true;
            }

            _logger.LogCritical("RabbitMQ: Not connected");
        }
        catch (Exception)
        {
            _logger.LogCritical("RabbitMQ: FATAL ERROR");
        }
        finally
        {
            if (lockWasTaken)
            {
                try
                {
                    Monitor.Exit(_syncRoot);
                }
                catch (Exception)
                {
                    // ignored
                }
            }
        }

        return false;
    }

    private async Task OnConnectionBlockedAsync(object? sender, ConnectionBlockedEventArgs e)
    {
        if (_disposed) return;

        _logger.LogWarning("A RabbitMQ connection is Blocked. Trying to re-connect...");

        await TryConnect();
    }

    private async Task OnCallbackExceptionAsync(object? sender, CallbackExceptionEventArgs e)
    {
        if (_disposed) return;

        _logger.LogWarning("A RabbitMQ connection throw Exception. Trying to re-connect...");

        await TryConnect();
    }

    private async Task OnConnectionShutdownAsync(object? sender, ShutdownEventArgs e)
    {
        if (_disposed) return;

        _logger.LogWarning("A RabbitMQ connection is on Shutdown. Trying to re-connect...");

        await TryConnect();
    }
}