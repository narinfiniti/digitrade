﻿using Ewai.Eventis.Messaging.Abstractions;
using Ewai.Eventis.Messaging.Abstractions.Config;
using Ewai.Eventis.Messaging.Persistence.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RabbitMQ.Client;

namespace Ewai.Eventis.Messaging.Extensions;

public static partial class DependencyExtensions
{
    public static IServiceCollection AddJobIntegrationEventMessaging(this IServiceCollection services,
        IConfiguration config,
        IHostEnvironment env)
    {
        var (mqOptions, factory) = ConfigureJobRabbitMqOptions(config);
        services.AddSingleton(mqOptions);
        services.AddSingleton<IConnectionFactory>(factory);
        services.AddSingleton<IRabbitMqConnection, RabbitMqConnection>();
        services.AddSingleton<ISubscriptionManager, SubscriptionsManagerInMemory>();
        services.AddSingleton<IEventBus, EventBusRabbitMq>();
        services.AddEventMessagingPersistence(config, env);
        return services;
    }

    private static (RabbitMqOptions, ConnectionFactory) ConfigureJobRabbitMqOptions(IConfiguration config)
    {
        var rabbitMqOptions = config.GetSection("RabbitMqOptions");
        var mqOptions = new RabbitMqOptions();
        rabbitMqOptions.Bind(mqOptions);
        mqOptions.IsCloudNode = config.GetValue<bool>("AppOptions:IsCloudNode");
        mqOptions.Bindings.BranchId = config.GetValue<Guid>("AppOptions:BranchId");
        mqOptions.ClientQueueName = mqOptions.IsCloudNode
            ? $"{mqOptions.ClientQueueNameCloud}"
            : $"{mqOptions.Bindings.BranchId}-job";

        var factory = new ConnectionFactory
        {
            AutomaticRecoveryEnabled = true,
            ConsumerDispatchConcurrency = 1,
            //HostName = keyVault.EventisRabbitMqHostName,
            //UserName = keyVault.EventisRabbitMqUsername,
            //Password = keyVault.EventisRabbitMqPassword,
            //VirtualHost = keyVault.EventisRabbitMqVirtualHost,
            //Port = keyVault.EventisRabbitMqPort,
            ClientProvidedName = mqOptions.ClientQueueName
        };
        rabbitMqOptions.Bind(factory);
        return (mqOptions, factory);
    }
}