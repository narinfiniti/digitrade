﻿using Ewai.Common.Extensions;
using Ewai.Eventis.Messaging.Abstractions;
using Ewai.Eventis.Messaging.Abstractions.Config;
using Ewai.Eventis.Messaging.Abstractions.Events;
using Microsoft.Extensions.Logging;

namespace Ewai.Eventis.Messaging;

public class SubscriptionsManagerInMemory(
    ILogger<SubscriptionsManagerInMemory> logger,
    RabbitMqOptions mqOptions)
    : ISubscriptionManager
{
    private readonly Dictionary<string, List<SubscriptionInfo>> _handlers = new();
    private readonly Dictionary<string, Type> _eventTypes = new();

    public event EventHandler<List<string>>? OnEventRemoved;

    public bool IsEmpty => !_handlers.Keys.Any();

    public void Clear()
    {
        foreach (var (routingKey, handlers) in _handlers)
        foreach (var handler in handlers.ToList())
        {
            RemoveAllHandlers(routingKey, handler);
        }

        _handlers.Clear();
        _eventTypes.Clear();
    }

    public void AddDynamicSubscription<THandler>(string routingKey)
        where THandler : IIntegrationEventHandlerDynamic
    {
        AddSubscription(routingKey, typeof(THandler), isDynamic: true);
    }

    public void AddSubscription(string routingKey, Type handlerType, bool isDynamic = false)
    {
        logger.LogInformation($"Subscribing: {routingKey}");
        DoAddSubscription(handlerType, routingKey, isDynamic);
    }

    public void AddEventType<TEvent>(Type? type, List<string>? routingKeys = null)
        where TEvent : IIntegrationEvent
    {
        type ??= typeof(TEvent);
        var (eventName, keys) = GetEventNameWithRoutingKeys(type);
        routingKeys ??= keys;

        _eventTypes.TryAdd(eventName, type);
        foreach (var routingKey in routingKeys)
        {
            _eventTypes.TryAdd(routingKey, type);
        }
    }

    public void RemoveSubscription<TEvent, THandler>()
        where THandler : IIntegrationEventHandler<TEvent>
        where TEvent : IIntegrationEvent
    {
        var (_, routingKeys) = GetEventNameWithRoutingKeys(typeof(TEvent));
        foreach (var routingKey in routingKeys)
        {
            RemoveSubscription(routingKey, typeof(THandler));
        }
    }

    public void RemoveSubscription(string routingKey, Type handlerType)
    {
        var handlerToRemove = FindSubscriptionToRemove(routingKey, handlerType);
        RemoveAllHandlers(routingKey, handlerToRemove);
    }

    public void RemoveAllSubscriptions(List<string> routingKeys)
    {
        foreach (var routingKey in routingKeys)
        {
            RemoveAllHandlers(routingKey);
        }
    }

    public IEnumerable<SubscriptionInfo> GetHandlersForEvents<TEvent>() where TEvent : struct
    {
        var (_, routingKeys) = GetEventNameWithRoutingKeys(typeof(TEvent));
        return GetHandlersForEvents(routingKeys);
    }

    public IEnumerable<SubscriptionInfo> GetHandlersForEvents(List<string> routingKeys)
    {
        return routingKeys.SelectMany(e => HasSubscriptionsForEvent(e)
            ? _handlers[e]
            : []);
    }

    public bool HasSubscriptionsForEvent(string routingKey) => _handlers.ContainsKey(routingKey);

    public Type? GetEventTypeByName(string routingKey) => _eventTypes.TryGetValue(routingKey, out var type) ? type : null;

    public List<Type> GetEventTypes() => _eventTypes.Values.ToList();

    public (string, List<string>) GetEventNameWithRoutingKeys(Type type)
    {
        var eventName = type.GetGenericTypeName();
        var routingKeys = mqOptions.IsCloudNode
            ? [$"{eventName}_{mqOptions.ClientQueueNameCloud}"]
            : mqOptions.RoutingKeys.Select(key => $"{eventName}_{key}").ToList();

        return (eventName, routingKeys);
    }


    private void DoAddSubscription(Type handlerType, string eventName, bool isDynamic)
    {
        _handlers.TryAdd(eventName, []);

        if (_handlers[eventName].Any(s => s.HandlerType == handlerType))
        {
            return;
        }

        _handlers[eventName].Add(isDynamic
            ? SubscriptionInfo.Dynamic(handlerType)
            : SubscriptionInfo.Typed(handlerType));
    }

    private void RemoveAllHandlers(string routingKey, SubscriptionInfo? subToRemove = null)
    {
        if (!_handlers.ContainsKey(routingKey)) return;
        logger.LogInformation($"Unsubscribing: {routingKey}");

        OnEventRemoved?.Invoke(this, [routingKey]);
        if (subToRemove is not null)
        {
            _handlers[routingKey].Remove(subToRemove);
        }
        else
        {
            _handlers[routingKey].Clear();
            _handlers.Remove(routingKey);
        }

        if (_eventTypes.ContainsKey(routingKey))
        {
            _eventTypes.Remove(routingKey);
        }
    }

    private SubscriptionInfo? FindSubscriptionToRemove(string eventName, Type handlerType)
    {
        return HasSubscriptionsForEvent(eventName)
            ? _handlers[eventName].FirstOrDefault(s => s.HandlerType == handlerType)
            : null;
    }
}