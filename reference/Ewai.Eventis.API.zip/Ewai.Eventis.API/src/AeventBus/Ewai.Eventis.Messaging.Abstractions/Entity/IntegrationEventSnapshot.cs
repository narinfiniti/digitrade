﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Ewai.Common.JsonOptions;
using Ewai.Eventis.Messaging.Abstractions.Enums;
using Ewai.Eventis.Messaging.Abstractions.Events;
using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.Messaging.Abstractions.Entity;

public class IntegrationEventSnapshot : IAggregateRoot<Guid>, IValidatableObject
{
    private IntegrationEventSnapshot()
    {
    }

    public IntegrationEventSnapshot(IIntegrationEvent @event,
        Guid? transactionId = null, JsonOps jsonOps = null)
    {
        Id = @event.Id;
        Type = @event.Type;
        State = @event.State;
        SentCount = 0;
        DateCreated = @event.DateCreated;
        TransactionId = transactionId?.ToString("N");
        EventTypeName = @event.GetType().FullName;
        Content = JsonSerializer.Serialize((object)@event, jsonOps?.Serialize);
    }

    public Guid Id { get; set; }
    public int Type { get; set; }
    public EventStateEnum State { get; set; }
    public int SentCount { get; set; }
    public string EventTypeName { get; private set; }
    public DateTime DateCreated { get; private set; }
    public string TransactionId { get; private set; }
    public string Content { get; private set; }

    public string EventTypeShortName => EventTypeName.Split('.').Last();
    public IIntegrationEvent IntegrationEvent { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (Content.Length > 4000)
            yield return new ValidationResult(
                $"Content length is greater than {4000}.",
                [$"Property: {nameof(IntegrationEventSnapshot)}.{nameof(Content)}"]
            );
        yield return ValidationResult.Success;
    }
}