﻿namespace Ewai.Eventis.Messaging.Abstractions.Enums;

public enum EventStateEnum : byte
{
    NotPublished = 0,
    InProgress = 1,
    Published = 2,
    PublishFailed = 3,
    WasOnline = 4
}