using Ewai.SharedKernel.Interfaces;

namespace Ewai.Eventis.Messaging.Abstractions;

public interface IEventSnapshotUnitOfWork : IUnitOfWork
{
}