﻿using Ewai.Eventis.Messaging.Abstractions.Entity;
using Ewai.Eventis.Messaging.Abstractions.Events;

namespace Ewai.Eventis.Messaging.Abstractions;

public interface IEventSnapshotService
{
    Task<IEnumerable<IntegrationEventSnapshot>> GetEventsPendingToPublishAsync(Guid? transactionId = null);
    Task SaveEventAsync(IIntegrationEvent @event, object transaction = null);
    Task MarkEventAsPublishedAsync(IntegrationEventSnapshot snapshot);
    Task MarkEventAsInProgressAsync(IntegrationEventSnapshot snapshot);
    Task MarkEventAsFailedAsync(IntegrationEventSnapshot snapshot);
}