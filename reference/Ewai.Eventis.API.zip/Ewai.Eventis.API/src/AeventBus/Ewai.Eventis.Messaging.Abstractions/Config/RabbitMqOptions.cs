﻿using Ewai.Common.Extensions;

namespace Ewai.Eventis.Messaging.Abstractions.Config;

/// <summary>
/// Rabbit Mq options.
/// </summary>
public class RabbitMqOptions
{
    public bool IsCloudNode { get; set; }
    public string HostName { get; set; }
    public string Username { get; set; }
    public string Password { get; set; }
    public string VirtualHost { get; set; }
    public string ClientQueueName { get; set; }
    public string ClientQueueNameCloud { get; set; }
    public int Port { get; set; }
    public int RetryCount { get; set; }
    public RabbitMqBindings Bindings { get; set; } = new();

    public IEnumerable<string> RoutingKeys
    {
        get
        {
            var bindingProperties = Bindings.GetType().GetProperties();
            foreach (var propertyInfo in bindingProperties)
            {
                var val = $"{propertyInfo.GetValue(Bindings, null)}";
                if (Guid.TryParse(val, out var guid) && guid.IsEmpty()) continue;

                if (val.IsNotEmpty())
                {
                    yield return val;
                }
            }
        }
    }
}
public class RabbitMqBindings
{
    public Guid TenantId { get; set; }
    public Guid BranchId { get; set; }
}