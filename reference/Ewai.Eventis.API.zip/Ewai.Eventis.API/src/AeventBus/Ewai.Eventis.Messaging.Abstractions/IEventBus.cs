#nullable enable
using Ewai.Eventis.Messaging.Abstractions.Events;

namespace Ewai.Eventis.Messaging.Abstractions;

/// <summary>
/// EventBus Abstraction.
/// </summary>
public interface IEventBus
{
    ValueTask Publish(IIntegrationEvent @event);

    ValueTask Subscribe(Type eventType, Type handlerType);

    public void Unsubscribe(Type eventType);
}