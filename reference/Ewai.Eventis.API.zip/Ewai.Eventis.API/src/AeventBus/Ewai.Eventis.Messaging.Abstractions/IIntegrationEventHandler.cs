using Ewai.Eventis.Messaging.Abstractions.Events;

namespace Ewai.Eventis.Messaging.Abstractions;

public interface IIntegrationEventHandler
{
}

public interface IIntegrationEventHandler<in TEvent> : IIntegrationEventHandler
    where TEvent : IIntegrationEvent
{
    Task Handle(TEvent @event);
}

public interface IIntegrationEventHandlerDynamic : IIntegrationEventHandler
{
    Task Handle(dynamic @event);
}