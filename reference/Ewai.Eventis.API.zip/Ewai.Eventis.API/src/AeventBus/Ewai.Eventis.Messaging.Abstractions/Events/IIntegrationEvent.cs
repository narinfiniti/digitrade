using Ewai.Eventis.Messaging.Abstractions.Enums;

namespace Ewai.Eventis.Messaging.Abstractions.Events;

/// <summary>
/// Integration Event abstraction.
/// </summary>
public interface IIntegrationEvent
{
    public Guid Id { get; set; }
    public Guid QueueId { get; set; }
    public string QueueName { get; set; }
    public int Type { get; set; }
    public DateTime DateCreated { get; set; }
    public EventStateEnum State { get; }
}