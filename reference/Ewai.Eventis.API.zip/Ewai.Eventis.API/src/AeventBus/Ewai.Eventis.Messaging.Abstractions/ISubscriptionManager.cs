﻿#nullable enable
using Ewai.Eventis.Messaging.Abstractions.Events;

namespace Ewai.Eventis.Messaging.Abstractions;

public interface ISubscriptionManager
{
    bool IsEmpty { get; }
    event EventHandler<List<string>>? OnEventRemoved;

    void AddDynamicSubscription<THandler>(string routingKey)
        where THandler : IIntegrationEventHandlerDynamic;

    void AddSubscription(string routingKey, Type handlerType, bool isDynamic = false);

    void AddEventType<TEvent>(Type? type, List<string>? routingKeys = null)
        where TEvent : IIntegrationEvent;

    void RemoveSubscription<TEvent, THandler>()
        where TEvent : IIntegrationEvent
        where THandler : IIntegrationEventHandler<TEvent>;
    void RemoveSubscription(string routingKey, Type handlerType);
    void RemoveAllSubscriptions(List<string> routingKeys);

    bool HasSubscriptionsForEvent(string routingKey);
    Type? GetEventTypeByName(string routingKey);
    List<Type> GetEventTypes();
    void Clear();
    IEnumerable<SubscriptionInfo> GetHandlersForEvents<TEvent>() where TEvent : struct;
    IEnumerable<SubscriptionInfo> GetHandlersForEvents(List<string> routingKeys);
    (string, List<string>) GetEventNameWithRoutingKeys(Type type);
}