using Ewai.Eventis.Api.Extensions;
using Ewai.Eventis.Api.Infrastructure.Middlewares;
using Ewai.Eventis.App.Extensions;
using Ewai.Eventis.Dependency.Extensions;
using Ewai.Eventis.Hubs.Extensions;
using Ewai.Eventis.Identity.Dependency;
using Ewai.Eventis.Infrastructure.Extensions;
using IdentityServer4.Extensions;

namespace Ewai.Eventis.Api;

/// <summary>
/// On startup, an ASP.NET Core app builds a host. The host encapsulates all of the app's resources
/// </summary>
public class Startup
{
    /// <summary>
    /// On startup constructor configuration and the environment are injected.
    /// </summary>
    public Startup(
        IConfiguration configuration,
        IWebHostEnvironment environment)
    {
        Configuration = configuration;
        Environment = environment;
    }

    private IConfiguration Configuration { get; }
    private IWebHostEnvironment Environment { get; }
    private IServiceCollection Services { get; set; }

    // This method gets called by the runtime. Use this method to add services to the container.
    public void ConfigureServices(IServiceCollection services)
    {
        services.AddCustomConfiguration(Configuration, Environment);
        services.AddDependencies(Configuration, Environment);

        services.AddApplicationInsights(Configuration, Environment);

        services.AddCustomControllers(Configuration, Environment);
        services.AddIdentityDependencies(Configuration, Environment);
        services.AddCustomAuthorization(Configuration);

        services.AddCustomCors(Configuration, Environment);
        services.AddCustomApiVersioning(Configuration);
        services.AddCustomSwagger(Configuration, Environment);
        //services.AddHealthChecks();
        //services.AddCustomRateLimiter(Configuration, Environment);
        Services = services;
    }

    /// <summary>
    /// This method gets called by the runtime.
    /// Use this method to configure the HTTP request pipeline.
    /// </summary>
    public void Configure(IApplicationBuilder app)
    {
        app.UseForwardedHeaders();
        app.Use(async (ctx, next) =>
        {
            ctx.SetIdentityServerOrigin("https://dev-api.bventis.com");
            await next();
        });
        app.UseMiddleware<ExceptionHandlingMiddleware>();

        // if (Environment.IsDevOrLocal())
        // {
        //     //app.UseDeveloperExceptionPage();
        //     if (Services != null) app.UseServicesDisplayPage(Services);
        // }
        // else if (Environment.IsStagingOrProd())
        // {
        //app.UseExceptionHandler("/Error");
        app.UseHsts(); // Browsers only
        app.UseHttpsRedirection();
        // }

        //app.UseRateLimiter();
        app.UseCustomSwagger(Configuration, Environment);
        app.UseStaticFiles();

        app.UseRouting();
        app.UseCors("CorsPolicy");
        app.UseHealthChecks("/health");
        app.UseHealthChecks("/health/db");
        app.UseAuthentication();
        app.UseIdentityServer();
        app.UseAuthorization();
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapHealthCheck();
            endpoints.MapHubs(Environment);
            //endpoints.MapGrpcServices();
            endpoints.MapControllers(Environment);
        });

        app.ConfigureAppLifetimeHandlers(Configuration, Environment);
    }
}