using System.Net;
using Ewai.Eventis.Identity.Infrastructure.Data.Extensions;
using Ewai.Eventis.Infrastructure.Extensions;
using Ewai.Eventis.Messaging.Persistence.Extensions;
using Ewai.Eventis.Persistence.Extensions;
using Ewai.SharedKernel.Extensions;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Serilog;
using ILogger = Serilog.ILogger;

namespace Ewai.Eventis.Api;

/// <summary>
/// Program starting point class.
/// </summary>
public class Program
{
    private static readonly string AppName = typeof(Program).Namespace;

    /// <summary>
    /// Main starting point of the application.
    /// </summary>
    public static async Task Main(string[] args)
    {
        var configuration = GetConfiguration();
        Log.Logger = CreateSerilogLogger(configuration);
        try
        {
            var host = CreateHostBuilder(args, configuration).Build();
            await host.MigrateAppDatabaseAsync(configuration);
            await host.MigrateIdentityServerDatabaseAsync(configuration);
            await host.MigrateEventBusDatabaseAsync(configuration);

            Log.Information("Starting web host ({ApplicationContext})...", AppName);
            await host.RunAsync();
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Program terminated unexpectedly ({ApplicationContext})!", AppName);
            throw;
        }
        finally
        {
            await Log.CloseAndFlushAsync();
        }
    }

    private static IHostBuilder CreateHostBuilder(string[] args, IConfiguration configuration) =>
        Host.CreateDefaultBuilder(args)
                .ConfigureServices((hostContext, services) =>
        {
            services.Configure<ForwardedHeadersOptions>(opts =>
            {
                opts.ForwardedHeaders =
                    ForwardedHeaders.XForwardedFor |
                    ForwardedHeaders.XForwardedProto;
                // clear the default loopback-only restrictions
                opts.KnownNetworks.Clear();
                opts.KnownProxies.Clear();
            });
        })
            .ConfigureWebHostDefaults(hostBuilder =>
            {
                hostBuilder
                    .CaptureStartupErrors(true)
                    .ConfigureKestrel((builderContext, options) =>
                    {
                        if (!builderContext.HostingEnvironment.IsDesktop()) return;

                        var (httpsPort, grpcPort) = GetDefinedPorts(configuration);
                        options.Listen(IPAddress.Any, httpsPort, ops =>
                        {
                            ops.Protocols = HttpProtocols.Http1AndHttp2AndHttp3;
                            if (!builderContext.HostingEnvironment.IsLocalhost())
                            {
                                // var x509 = Certificate.LoadVolume(builderContext.Configuration);
                                // ops.UseHttps(x509, o => o.SslProtocols = SslProtocols.Tls12);
                            }
                        });
                    })
                    .UseContentRoot(Directory.GetCurrentDirectory())
                    .UseConfiguration(configuration)
                    .UseStartup<Startup>();
            })
            .ConfigureLogging((hostContext, logBuilder) =>
            {
                // Disabling default integrated logger.
                logBuilder.ClearProviders().AddSerilog();
            })
            .UseSerilog(configuration.LoggerConfig(), preserveStaticLogger: true)
            .ConfigureAppConfiguration((context, configBuilder) =>
            {
                // var config = configBuilder.Build();
                // if(config.IsDesktopServer()) return;
                //
                // var name = config["AzureKeyVault:Name"];
                // var clientId = config["AzureKeyVault:ClientId"];
                // var clientSecret = config["AzureKeyVault:ClientSecret"];
                // configBuilder.AddAzureKeyVault($"https://{name}.vault.azure.net/", clientId, clientSecret);
            });

    private static IConfiguration GetConfiguration()
    {
        var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
        var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false)
            .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: false)
            .AddUserSecrets(typeof(Program).Assembly)
            .AddEnvironmentVariables();

        return builder.Build();
    }

    private static ILogger CreateSerilogLogger(IConfiguration config)
    {
        return new LoggerConfiguration()
            .ReadFrom.Configuration(config)
            .CreateLogger();
    }

    static (int httpPort, int grpcPort) GetDefinedPorts(IConfiguration config)
    {
        var port = config.GetValue("AppOptions:PortSsl", 443);
        var grpcPort = config.GetValue("AppOptions:PortGrpc", 5100);
        return (port, grpcPort);
    }
}