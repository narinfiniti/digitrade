﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.VenueLocations.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueLocations.Filters;
using Ewai.Eventis.App.Contracts.Models.VenueLocations.Inputs;
using Ewai.Eventis.App.UseCase.VenueLocation;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.VenueLocation.Base)]
public class VenueLocationApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.VenueLocations.GetAll)]
    public Task<ListResult<VenueLocationListDto>> GetList([FromQuery] VenueLocationGetListFilter model)
    {
        return Mediator.Send(new VenueLocationGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.VenueLocations.Create)]
    public Task<VenueLocationDto> Create([FromBody] VenueLocationCreateInput model)
    {
        return Mediator.Send(new VenueLocationCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.VenueLocations.Update)]
    public Task<VenueLocationDto> Update([FromRoute] Guid id, [FromBody] VenueLocationUpdateInput model)
    {
        return Mediator.Send(new VenueLocationUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.VenueLocations.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new VenueLocationDelete
        {
            Model = id,
        });
    }
}