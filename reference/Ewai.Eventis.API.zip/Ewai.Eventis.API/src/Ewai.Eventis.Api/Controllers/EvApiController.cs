﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.TenantEvents.Dto;
using Ewai.Eventis.App.Contracts.Models.TenantEvents.Filters;
using Ewai.Eventis.App.Contracts.Models.TenantEvents.Inputs;
using Ewai.Eventis.App.UseCase.TheEvents;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.TheEvent.Base)]
public class EvApiController : ApiController
{
    [HttpGet]
    //[Permission(Apis.TenantEvents.GetAll)]
    public Task<ListResult<TheEventListDto>> GetList([FromQuery] TheEventGetListFilter model)
    {
        return Mediator.Send(new TheEventGetList
        {
            Model = model
        });
    }

    [HttpPost]
    //[Permission(Apis.TenantEvents.Create)]
    public Task<TheEventDto> Create([FromBody] TheEventCreateInput model)
    {
        return Mediator.Send(new TheEventCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    //[Permission(Apis.TenantEvents.Update)]
    public Task<TheEventDto> Update([FromRoute] Guid id, [FromBody] TheEventUpdateInput model)
    {
        return Mediator.Send(new TheEventUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    //[Permission(Apis.TenantEvents.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new TheEventDelete
        {
            Model = id,
        });
    }
}