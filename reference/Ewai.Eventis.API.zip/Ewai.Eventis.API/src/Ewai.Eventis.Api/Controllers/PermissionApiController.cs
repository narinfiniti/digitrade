﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.Permissions.Dto;
using Ewai.Eventis.App.Contracts.Models.Permissions.Filters;
using Ewai.Eventis.App.Contracts.Models.Permissions.Inputs;
using Ewai.Eventis.App.UseCase.Permissions;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.Permissions.Base)]
public class PermissionApiController : ApiController
{
    [HttpGet("types")]
    public List<EnumListResult> GetPermissionTypes()
    {
        return Enum.GetValues<PermissionTypeEnum>()
            .Select(s => new EnumListResult
            {
                Id = (int)s,
                Name = s.ToString()
            })
            .ToList();
    }

    [HttpGet("groups")]
    public List<EnumListResult> GetPermissionGroups()
    {
        return Enum.GetValues<PermissionGroupEnum>()
            .Select(s => new EnumListResult
            {
                Id = (int)s,
                Name = s.ToString()
            })
            .ToList();
    }

    [HttpGet("targets")]
    public List<EnumListResult> GetPermissionTargets()
    {
        return Enum.GetValues<PermissionTargetEnum>()
            .Select(s => new EnumListResult
            {
                Id = (int)s,
                Name = s.ToString()
            })
            .ToList();
    }

    [HttpGet(Consts.Route.Permissions.Views)]
    // [Permission(Apis.Permissions.GetList)]
    public Task<ListResult<PermissionViewCategoryDto>> GetPermissionViews(
        [FromQuery] PermissionViewCategoryGetListFilter model)
    {
        return Mediator.Send(new PermissionViewCategoryGetList
        {
            Model = model
        });
    }

    [HttpPost(Consts.Route.Permissions.Create)]
    // [Permission(Apis.Permissions.Create)]
    public Task CreatePermissions(PermissionCreateInput[] model)
    {
        return Mediator.Send(new PermissionCreate
        {
            Model = model
        });
    }

    [HttpDelete]
    // [Permission(Apis.Permissions.Create)]
    public Task Reset(PermissionRemoveInput model)
    {
        return Mediator.Send(new PermissionRemove
        {
            Model = model
        });
    }
}