﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.TenAppSubs.Dto;
using Ewai.Eventis.App.Contracts.Models.TenAppSubs.Filters;
using Ewai.Eventis.App.Contracts.Models.TenAppSubs.Inputs;
using Ewai.Eventis.App.UseCase.TenAppSubs;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.AppSubs.Base)]
public class TenAppSubApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.AppSubs.GetAll)]
    public Task<ListResult<AppSubListDto>> GetList([FromQuery] AppSubGetListFilter model)
    {
        return Mediator.Send(new AppSubGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.AppSubs.Create)]
    public Task<AppSubDto> Create([FromBody] AppSubCreateInput model)
    {
        return Mediator.Send(new AppSubCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.AppSubs.Update)]
    public Task<AppSubDto> Update([FromRoute] Guid id, [FromBody] AppSubUpdateInput model)
    {
        return Mediator.Send(new AppSubUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.AppSubs.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new AppSubDelete
        {
            Model = id,
        });
    }
}