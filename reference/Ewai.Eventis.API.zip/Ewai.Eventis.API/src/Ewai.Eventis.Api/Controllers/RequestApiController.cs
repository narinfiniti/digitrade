﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.Orders.Dto;
using Ewai.Eventis.App.Contracts.Models.Orders.Filters;
using Ewai.Eventis.App.Contracts.Models.Orders.Inputs;
using Ewai.Eventis.App.UseCase.Orders;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.Request.Base)]
public class RequestApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.Orders.GetAll)]
    public Task<ListResult<RequestListDto>> GetList([FromQuery] RequestGetListFilter model)
    {
        return Mediator.Send(new RequestGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.Orders.Create)]
    public Task<RequestDto> Create([FromBody] RequestCreateInput model)
    {
        return Mediator.Send(new RequestCreate
        {
            Model = model
        });
    }

    [HttpPost("cashier-order")]
    // [Permission(Apis.Orders.CreateCashierOrder)]
    public Task<OrderCashierCreateDto> CreateCashierOrder([FromBody] OrderCashierCreateInput model)
    {
        return Mediator.Send(new OrderCashierCreate
        {
            Model = model
        });
    }

    [HttpPost("pre-checkout")]
    // [Permission(Apis.Orders.PreCheckout)]
    public Task<OrderPreCheckoutDto> PreCheckout([FromBody] OrderPreCheckoutInput model)
    {
        return Mediator.Send(new OrderPreCheckout
        {
            Model = model
        });
    }

    [HttpPost("checkout")]
    // [Permission(Apis.Orders.Checkout)]
    public Task<OrderCheckoutDto> Checkout([FromBody] OrderCheckoutInput model)
    {
        return Mediator.Send(new OrderCheckout
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.Orders.Update)]
    public Task<RequestDto> Update([FromRoute] Guid id, [FromBody] RequestUpdateInput model)
    {
        return Mediator.Send(new RequestUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpPut("{id}/status")]
    // [Permission(Apis.Orders.UpdateStatus)]
    public Task<RequestStatusUpdateDto> UpdateStatus([FromRoute] Guid id, [FromBody] RequestStatusUpdateInput model)
    {
        model.Id = id;
        return Mediator.Send(new RequestStatusUpdate
        {
            Model = model
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.Orders.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new RequestDelete
        {
            Model = id,
        });
    }
}