﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.Tenants.Dto;
using Ewai.Eventis.App.Contracts.Models.Tenants.Filters;
using Ewai.Eventis.App.Contracts.Models.Tenants.Inputs;
using Ewai.Eventis.App.UseCase.Tenants;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.Tenant.Base)]
public class TenantApiController : ApiController
{
    [HttpGet("section")]
    public List<EnumListResult> GetSegmentationList()
    {
        return Enum.GetValues<SegmentationTypeEnum>()
            .Select(s => new EnumListResult
            {
                Id = (int)s,
                Name = s.ToString()
            })
            .ToList();
    }

    [HttpGet]
    // [Permission(Apis.Tenants.GetAll)]
    public Task<ListResult<TenantListDto>> GetList([FromQuery] TenantGetListFilter model)
    {
        return Mediator.Send(new TenantGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.Tenants.Create)]
    public Task<TenantDto> Create([FromBody] TenantCreateInput model)
    {
        return Mediator.Send(new TenantCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.Tenants.Update)]
    public Task<TenantDto> Update([FromRoute] Guid id, [FromBody] TenantUpdateInput model)
    {
        return Mediator.Send(new TenantUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpPatch("{id}/setting")]
    // [Permission(Apis.Tenants.Update)]
    public Task<TenantDto> UpdateSetting([FromRoute] Guid id, [FromBody] TenantUpdateSettingInput model)
    {
        return Mediator.Send(new TenantUpdateSetting
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.Tenants.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new TenantDelete
        {
            Model = id,
        });
    }
}