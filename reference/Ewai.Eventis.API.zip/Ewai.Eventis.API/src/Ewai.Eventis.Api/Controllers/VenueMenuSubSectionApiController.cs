﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.VenueMenuSubSections.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueMenuSubSections.Filters;
using Ewai.Eventis.App.Contracts.Models.VenueMenuSubSections.Inputs;
using Ewai.Eventis.App.UseCase.VenueMenuSubSections;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.VenueMenuSubSection.Base)]
public class VenueMenuSubSectionApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.VenueMenuSubSections.GetAll)]
    public Task<ListResult<VenueMenuSubSectionListDto>> GetList([FromQuery] VenueMenuSubSectionGetListFilter model)
    {
        return Mediator.Send(new VenueMenuSubSectionGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.VenueMenuSubSections.Create)]
    public Task<VenueMenuSubSectionDto> Create([FromBody] VenueMenuSubSectionCreateInput model)
    {
        return Mediator.Send(new VenueMenuSubSectionCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.VenueMenuSubSections.Update)]
    public Task<VenueMenuSubSectionDto> Update([FromRoute] Guid id, [FromBody] VenueMenuSubSectionUpdateInput model)
    {
        return Mediator.Send(new VenueMenuSubSectionUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.VenueMenuSubSections.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new VenueMenuSubSectionDelete
        {
            Model = id,
        });
    }
}