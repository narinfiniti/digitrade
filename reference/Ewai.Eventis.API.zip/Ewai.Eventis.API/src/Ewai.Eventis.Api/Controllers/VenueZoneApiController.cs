﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.VenueZones.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueZones.Filters;
using Ewai.Eventis.App.Contracts.Models.VenueZones.Inputs;
using Ewai.Eventis.App.UseCase.VenueZones;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.VenueZone.Base)]
public class VenueZoneApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.VenueZones.GetAll)]
    public Task<ListResult<VenueZoneListDto>> GetList([FromQuery] VenueZoneGetListFilter model)
    {
        return Mediator.Send(new VenueZoneGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.VenueZones.Create)]
    public Task<VenueZoneDto> Create([FromBody] VenueZoneCreateInput model)
    {
        return Mediator.Send(new VenueZoneCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.VenueZones.Update)]
    public Task<VenueZoneDto> Update([FromRoute] Guid id, [FromBody] VenueZoneUpdateInput model)
    {
        return Mediator.Send(new VenueZoneUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.VenueZones.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new VenueZoneDelete
        {
            Model = id,
        });
    }
}