﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.TextMessages.Dto;
using Ewai.Eventis.App.Contracts.Models.TextMessages.Filters;
using Ewai.Eventis.App.Contracts.Models.TextMessages.Inputs;
using Ewai.Eventis.App.UseCase.TextMessages;
using Ewai.Eventis.Domain.Enums;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.TextMessage.Base)]
public class TextMessageApiController : ApiController
{
    [HttpGet("languages")]
    public List<EnumListResult> GetLanguageCodes()
    {
        return Enum.GetValues<LanguageCodeEnum>()
            .Select(s => new EnumListResult
            {
                Id = (int)s,
                Name = s.ToString()
            })
            .ToList();
    }

    [HttpGet]
    //[Permission(Apis.TextMessages.GetAll)]
    public Task<ListResult<TextMessageDto>> GetList([FromQuery] TextMessageGetListFilter model)
    {
        return Mediator.Send(new TextMessageGetList
        {
            Model = model
        });
    }

    [HttpPost]
    //[Permission(Apis.TenantEvents.Create)]
    public Task<TextMessageDto> Create([FromBody] TextMessageCreateInput model)
    {
        return Mediator.Send(new TextMessageCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    //[Permission(Apis.TenantEvents.Update)]
    public Task<TextMessageDto> Update([FromRoute] Guid id, [FromBody] TextMessageUpdateInput model)
    {
        return Mediator.Send(new TextMessageUpdate
        {
            Model = model,
            Id = id
        });
    }
    
    [HttpDelete("{id}")]
    //[Permission(Apis.TenantEvents.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new TextMessageDelete
        {
            Model = id,
        });
    }
}