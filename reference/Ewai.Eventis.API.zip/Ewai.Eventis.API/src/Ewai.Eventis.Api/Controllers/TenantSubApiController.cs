﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.TenantSubs.Dto;
using Ewai.Eventis.App.Contracts.Models.TenantSubs.Filters;
using Ewai.Eventis.App.Contracts.Models.TenantSubs.Inputs;
using Ewai.Eventis.App.UseCase.TenantSubs;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.TenantSubs.Base)]
public class TenantSubApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.TenantSubs.GetAll)]
    public Task<ListResult<TenantSubListDto>> GetList([FromQuery] TenantSubGetListFilter model)
    {
        return Mediator.Send(new TenantSubGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.TenantSubs.Create)]
    public Task<TenantSubDto> Create([FromBody] TenantSubCreateInput model)
    {
        return Mediator.Send(new TenantSubCreate
        {
            Model = model
        });
    }

    [HttpPost("payment")]
    public Task<TenantSubPaymentDto> Payment([FromBody] TenantSubPaymentInput model)
    {
        return Mediator.Send(new TenantSubPayment
        {
            Model = model,
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.TenantSubs.Update)]
    public Task<TenantSubDto> Update([FromRoute] Guid id, [FromBody] TenantSubUpdateInput model)
    {
        return Mediator.Send(new TenantSubUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpPatch("credits")]
    public Task<TenantSubDto> AddCredits([FromBody] TenantSubAddCreditsInput model)
    {
        return Mediator.Send(new TenantSubAddCredits { Model = model });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.TenantSubs.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new TenantSubDelete
        {
            Model = id,
        });
    }
}