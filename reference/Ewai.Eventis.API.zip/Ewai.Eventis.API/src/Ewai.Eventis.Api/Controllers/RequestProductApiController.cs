﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.OrderProducts.Dto;
using Ewai.Eventis.App.Contracts.Models.OrderProducts.Filters;
using Ewai.Eventis.App.Contracts.Models.OrderProducts.Inputs;
using Ewai.Eventis.App.UseCase.OrderProducts;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.RequestProduct.Base)]
public class RequestProductApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.OrderProducts.GetAll)]
    public Task<ListResult<RequestProductListDto>> GetList([FromQuery] RequestProductGetListFilter model)
    {
        return Mediator.Send(new RequestProductGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.OrderProducts.Create)]
    public Task<RequestProductDto> Create([FromBody] RequestProductCreateInput model)
    {
        return Mediator.Send(new RequestProductCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.OrderProducts.Update)]
    public Task<RequestProductDto> Update([FromRoute] Guid id, [FromBody] RequestProductUpdateInput model)
    {
        return Mediator.Send(new RequestProductUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.OrderProducts.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new RequestProductDelete
        {
            Model = id,
        });
    }
}