﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.Analytics.Dto;
using Ewai.Eventis.App.Contracts.Models.Analytics.Filters;
using Ewai.Eventis.App.UseCase.Analytics;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.Analytics.Base)]
public class AnalyticsApiController : ApiController
{
    #region GlobalFilters

    [HttpGet(Consts.Route.Analytics.GetFilterEventList)]
    //[Permission(Apis.Analytics.GetFilterEventList)]
    public Task<ListResult<AnalyticFilterEventListDto>> GetFilterEventList(
        [FromQuery] AnalyticFilterEventListGetFilter model)
    {
        return Mediator.Send(new AnalyticFilterEventListGet
        {
            Model = model
        });
    }

    [HttpGet(Consts.Route.Analytics.GetFilterVenueList)]
    //[Permission(Apis.Analytics.GetFilterEventList)]
    public Task<ListResult<AnalyticFilterVenueListDto>> GetFilterVenueList(
        [FromQuery] AnalyticFilterVenueListGetFilter model)
    {
        return Mediator.Send(new AnalyticFilterVenueListGet
        {
            Model = model
        });
    }

    #endregion

    #region BusinessOverview

    [HttpGet(Consts.Route.Analytics.GetTotalRevenue)]
    //[Permission(Apis.Analytics.GetTotalRevenue)]
    public Task<AnalyticTotalRevenueAggregateDto> GetTotalRevenue([FromQuery] AnalyticTotalRevenueGetFilter model)
    {
        return Mediator.Send(new AnalyticTotalRevenueGet
        {
            Model = model
        });
    }

    [HttpGet(Consts.Route.Analytics.GetAverageRevenue)]
    //[Permission(Apis.Analytics.GetAverageRevenue)]
    public Task<AnalyticAverageRevenueAggregateDto> GetAverageRevenue([FromQuery] AnalyticAverageRevenueGetFilter model)
    {
        return Mediator.Send(new AnalyticAverageRevenueGet
        {
            Model = model
        });
    }

    [HttpGet(Consts.Route.Analytics.GetCompletedBookings)]
    //[Permission(Apis.Analytics.GetCompletedBookings)]
    public Task<AnalyticCompletedBookingsAggregateDto> GetCompletedBookings(
        [FromQuery] AnalyticCompletedBookingsGetFilter model)
    {
        return Mediator.Send(new AnalyticCompletedBookingsGet
        {
            Model = model
        });
    }

    [HttpGet(Consts.Route.Analytics.GetAverageTableOccupation)]
    //[Permission(Apis.Analytics.GetAverageTableOccupation)]
    public Task<AnalyticAverageTableOccupationAggregateDto> GetAverageTableOccupation(
        [FromQuery] AnalyticAverageTableOccupationGetFilter model)
    {
        return Mediator.Send(new AnalyticAverageTableOccupationGet
        {
            Model = model
        });
    }

    [HttpGet(Consts.Route.Analytics.GetPrePaymentOnSiteRevenue)]
    //[Permission(Apis.Analytics.GetPrePaymentOnSiteRevenue)]
    public Task<AnalyticPrePaymentOnSiteRevenueAggregateDto> GetPrePaymentOnSiteRevenue(
        [FromQuery] AnalyticPrePaymentOnSiteRevenueGetFilter model)
    {
        return Mediator.Send(new AnalyticPrePaymentOnSiteRevenueGet
        {
            Model = model
        });
    }

    [HttpGet(Consts.Route.Analytics.GetRevenuePerDesk)]
    //[Permission(Apis.Analytics.GetRevenuePerDesk)]
    public Task<ListResult<AnalyticRevenuePerDeskDto>> GetRevenuePerDesk([FromQuery] AnalyticRevenuePerDeskGetFilter model)
    {
        return Mediator.Send(new AnalyticRevenuePerDeskGet
        {
            Model = model
        });
    }

    [HttpGet(Consts.Route.Analytics.GetEventUserRevenue)]
    //[Permission(Apis.Analytics.GetEventUserRevenue)]
    public Task<ListResult<AnalyticEventUserRevenueDto>> GetEventUserRevenue([FromQuery] AnalyticEventUserRevenueGetFilter model)
    {
        return Mediator.Send(new AnalyticEventUserRevenueGet
        {
            Model = model
        });
    }

    [HttpGet(Consts.Route.Analytics.GetStockAnalytics)]
    //[Permission(Apis.Analytics.GetStockAnalytics)]
    public Task<ListResult<AnalyticStockDto>> GetStockAnalytics([FromQuery] AnalyticStockGetFilter model)
    {
        return Mediator.Send(new AnalyticStockGet
        {
            Model = model
        });
    }

    #endregion

    // [HttpGet(Consts.Route.Analytics.GetAbandonedTransactions)]
    // //[Permission(Apis.Analytics.GetAbandonedTransactions)]
    // public Task<AnalyticAbandonedTransactionsDto> GetAbandonedTransactions(
    //     [FromQuery] AnalyticAbandonedTransactionGetFilter model)
    // {
    //     return Mediator.Send(new AnalyticAbandonedTransactionGet
    //     {
    //         Model = model
    //     });
    // }

    // [HttpGet(Consts.Route.Analytics.GetPeakTransactionTime)]
    // //[Permission(Apis.Analytics.GetPeakTransactionTime)]
    // public Task<AnalyticPeakTransactionTimeDto> GetPeakTransactionTime(
    //     [FromQuery] AnalyticPeakTimeTransactionGetFilter model)
    // {
    //     return Mediator.Send(new AnalyticPeakTimeTransactionGet
    //     {
    //         Model = model
    //     });
    // }

    [HttpGet(Consts.Route.Analytics.GetSoldProducts)]
    //[Permission(Apis.Analytics.GetSoldProducts)]
    public Task<AnalyticSoldProductAggregateDto> GetSoldProducts([FromQuery] AnalyticSoldProductsGetFilter model)
    {
        return Mediator.Send(new AnalyticSoldProductGet
        {
            Model = model
        });
    }

    // [HttpGet(Consts.Route.Analytics.GetPreferredProducts)]
    // //[Permission(Apis.Analytics.GetPreferredProducts)]
    // public Task<AnalyticPreferredProductAggregateDto> GetPreferredProducts([FromQuery] AnalyticPreferredProductsGetFilter model)
    // {
    //     return Mediator.Send(new AnalyticPreferredProductGet
    //     {
    //         Model = model
    //     });
    // }

    // [HttpGet(Consts.Route.Analytics.GetAverageClientSpend)]
    // //[Permission(Apis.Analytics.GetAverageClientSpend)]
    // public Task<AnalyticAverageClientSpendAggregateDto> GetAverageClientSpend(
    //     [FromQuery] AnalyticAverageClientSpendGetFilter model)
    // {
    //     return Mediator.Send(new AnalyticAverageClientSpendGet
    //     {
    //         Model = model
    //     });
    // }

    // [HttpGet(Consts.Route.Analytics.GetAverageVenueRating)]
    // //[Permission(Apis.Analytics.GetAverageVenueRating)]
    // public Task<AnalyticAverageVenueRatingsDto> GetAverageVenueRating(
    //     [FromQuery] AnalyticAverageVenueRatingGetFilter model)
    // {
    //     return Mediator.Send(new AnalyticAverageVenueRatingGet
    //     {
    //         Model = model
    //     });
    // }

    // [HttpGet(Consts.Route.Analytics.GetCustomerFeedback)]
    // //[Permission(Apis.Analytics.GetCustomerFeedback)]
    // public Task<AnalyticsCustomerFeedbackDto> GetCustomerFeedback(
    //     [FromQuery] AnalyticsCustomerFeedbackGetFilter model)
    // {
    //     return Mediator.Send(new AnalyticsCustomerFeedbackGet
    //     {
    //         Model = model
    //     });
    // }

    // [HttpPost(Consts.Route.Analytics.Export)]
    // //[Permission(Apis.Analytics.Export)]
    // public Task Export([FromBody] AnalyticsExportGetFilter model)
    // {
    //     return Mediator.Send(new AnalyticsExportGet
    //     {
    //         Model = model
    //     });
    // }
}