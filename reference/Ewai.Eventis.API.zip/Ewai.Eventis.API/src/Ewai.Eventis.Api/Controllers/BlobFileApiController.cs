﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.BlobFiles.Dto;
using Ewai.Eventis.App.Contracts.Models.BlobFiles.Filters;
using Ewai.Eventis.App.Contracts.Models.BlobFiles.Inputs;
using Ewai.Eventis.App.UseCase.BlobFiles;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.BlobFile.Base)]
public class BlobFileApiController : ApiController
{
    [HttpGet]
    //[Permission(Apis.BlobFile.GetAll)]
    public Task<ListResult<BlobFileListDto>> GetList([FromQuery] BlobFileGetListQueryFilter model)
    {
        return Mediator.Send(new BlobFileGetList
        {
            Model = model
        });
    }

    [HttpPost]
    //[Permission(Apis.BlobFile.Upload)]
    public Task<BlobFileUploadDto> Upload([FromForm] BlobFileUploadInput model)
    {
        return Mediator.Send(new BlobFileUpload
        {
            Model = model
        });
    }

    [HttpDelete("{id}")]
    //[Permission(Apis.BlobFile.Remove)]
    public Task Remove(Guid id)
    {
        return Mediator.Send(new BlobFileRemove
        {
            Model = id
        });
    }

    /// <summary>
    /// Copy blob images.
    /// </summary>
    [HttpPost("copy")]
    public Task BlobImageCopy([FromBody] BlobImageCopyInput model)
    {
        return Mediator.Send(new BlobImageCopy
        {
            Model = model
        });
    }

    /// <summary>
    /// Sync blob files with Azure blob storage.
    /// </summary>
    [HttpPost("sync")]
    public Task BlobFileSync([FromBody] BlobFileSyncInput model)
    {
        return Mediator.Send(new BlobFileSync
        {
            Model = model
        });
    }
}