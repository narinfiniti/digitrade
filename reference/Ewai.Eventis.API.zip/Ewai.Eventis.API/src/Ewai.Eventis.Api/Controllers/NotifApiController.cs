﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.Notifs.Dto;
using Ewai.Eventis.App.Contracts.Models.Notifs.Filters;
using Ewai.Eventis.App.Contracts.Models.Notifs.Inputs;
using Ewai.Eventis.App.Contracts.Models.Orders.Dto;
using Ewai.Eventis.App.Contracts.Models.Orders.Inputs;
using Ewai.Eventis.App.UseCase.Notifs;
using Ewai.Eventis.App.UseCase.Orders;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.Notif.Base)]
public class NotifApiController : ApiController
{
    [HttpGet]
    //[Permission(Apis.TenantEvents.GetAll)]
    public Task<ListResult<UserNotifListDto>> GetList([FromQuery] UserNotifGetListFilter model)
    {
        return Mediator.Send(new UserNotifGetList
        {
            Model = model
        });
    }

    // [HttpPost]
    // [Permission(Apis.TenantEvents.Create)]
    // public Task<UserNotifDto> Create([FromBody] UserNotifCreateInput model)
    // {
    //     return Mediator.Send(new UserNotifCreate
    //     {
    //         Model = model
    //     });
    // }

    [HttpPut("{id}")]
    //[Permission(Apis.TenantEvents.Update)]
    public Task<UserNotifDto> Update([FromRoute] Guid id, [FromBody] UserNotifUpdateInput model)
    {
        return Mediator.Send(new UserNotifUpdate
        {
            Model = model,
            Id = id
        });
    }

    /// <summary>
    /// Claim a notification: set it to InProgress and remove other receivers.
    /// </summary>
    [HttpPut("{id:guid}/claimInProgress")]
    public Task<UserNotifClaimInProgressDto> ClaimInProgress(
        [FromRoute] Guid id,
        [FromBody] UserNotifClaimInProgressInput model
    )
    {
        return Mediator.Send(new UserNotifClaimInProgress
        {
            Id = id,
            Model = model
        });
    }

    [HttpDelete("{id}")]
    //[Permission(Apis.TenantEvents.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new UserNotifDelete
        {
            Model = id
        });
    }

    [HttpPost("order-status-update")]
    public Task<RequestStatusUpdateDto> ChangeRequestStatus([FromBody] RequestStatusUpdateInput model)
    {
        return Mediator.Send(new RequestStatusUpdate
        {
            Model = model
        });
    }

    [HttpPost("to-waiter")]
    public Task<UserToWaiterNotifyDto> NotifyToWaiter([FromBody] UserToWaiterNotifyInput model)
    {
        return Mediator.Send(new UserToWaiterNotify
        {
            Model = model
        });
    }

    [HttpPost("to-head-waiter")]
    public Task<UserToHeadWaiterNotifyDto> NotifyToHeadWaiter([FromBody] UserToHeadWaiterNotifyInput model)
    {
        return Mediator.Send(new UserToHeadWaiterNotify
        {
            Model = model
        });
    }

    [HttpPost("to-bottle-waiter")]
    public Task<UserToBottleWaiterNotifyDto> NotifyToBottleWaiter([FromBody] UserToBottleWaiterNotifyInput model)
    {
        return Mediator.Send(new UserToBottleWaiterNotify
        {
            Model = model
        });
    }

    [HttpPost("to-cave-waiter")]
    public Task<UserToCaveWaiterNotifyDto> NotifyToCaveWaiter([FromBody] UserToCaveWaiterNotifyInput model)
    {
        return Mediator.Send(new UserToCaveWaiterNotify
        {
            Model = model
        });
    }

    [HttpPost("to-hostess")]
    public Task<UserToHostessNotifyDto> NotifyToHostess([FromBody] UserToHostessNotifyInput model)
    {
        return Mediator.Send(new UserToHostessNotify
        {
            Model = model
        });
    }

    [HttpPost("to-cashier")]
    public Task<UserToCashierNotifyDto> NotifyToCashier([FromBody] UserToCashierNotifyInput model)
    {
        return Mediator.Send(new UserToCashierNotify
        {
            Model = model
        });
    }

    [HttpPost("to-event-manager")]
    public Task<UserToEventManagerNotifyDto> NotifyToEventManager([FromBody] UserToEventManagerNotifyInput model)
    {
        return Mediator.Send(new UserToEventManagerNotify
        {
            Model = model
        });
    }

    [HttpPost("to-public-relation")]
    public Task<UserToPublicRelationNotifyDto> NotifyToPublicRelation([FromBody] UserToPublicRelationNotifyInput model)
    {
        return Mediator.Send(new UserToPublicRelationNotify
        {
            Model = model
        });
    }

    [HttpPost("to-tenant-admin")]
    public Task<UserToTenantAdminNotifyDto> NotifyToTenantAdmin([FromBody] UserToTenantAdminNotifyInput model)
    {
        return Mediator.Send(new UserToTenantAdminNotify
        {
            Model = model
        });
    }

    [HttpPost("to-system-admin")]
    public Task<UserToSystemAdminNotifyDto> NotifyToSystemAdmin([FromBody] UserToSystemAdminNotifyInput model)
    {
        return Mediator.Send(new UserToSystemAdminNotify
        {
            Model = model
        });
    }

    [HttpPost("to-system-manager")]
    public Task<UserToSystemManagerNotifyDto> NotifyToSystemManager([FromBody] UserToSystemManagerNotifyInput model)
    {
        return Mediator.Send(new UserToSystemManagerNotify
        {
            Model = model
        });
    }

    [HttpPost("to-system-operator")]
    public Task<UserToSystemOperatorNotifyDto> NotifyToSystemOperator([FromBody] UserToSystemOperatorNotifyInput model)
    {
        return Mediator.Send(new UserToSystemOperatorNotify
        {
            Model = model
        });
    }
}