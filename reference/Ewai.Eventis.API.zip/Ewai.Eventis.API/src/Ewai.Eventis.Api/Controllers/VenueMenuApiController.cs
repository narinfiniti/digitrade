﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.VenueMenus.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueMenus.Filters;
using Ewai.Eventis.App.Contracts.Models.VenueMenus.Inputs;
using Ewai.Eventis.App.UseCase.VenueMenus;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.VenueMenu.Base)]
public class VenueMenuApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.VenueMenus.GetAll)]
    public Task<ListResult<VenueMenuListDto>> GetList([FromQuery] VenueMenuGetListFilter model)
    {
        return Mediator.Send(new VenueMenuGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.VenueMenus.Create)]
    public Task<VenueMenuDto> Create([FromBody] VenueMenuCreateInput model)
    {
        return Mediator.Send(new VenueMenuCreate
        {
            Model = model
        });
    }

    [HttpPost("assign")]
    // [Permission(Apis.VenueMenus.Create)]
    public Task<VenueMenuDto> Assign([FromBody] VenueMenuAssignInput model)
    {
        return Mediator.Send(new VenueMenuAssign
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.VenueMenus.Update)]
    public Task<VenueMenuDto> Update([FromRoute] Guid id, [FromBody] VenueMenuUpdateInput model)
    {
        return Mediator.Send(new VenueMenuUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.VenueMenus.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new VenueMenuDelete
        {
            Model = id,
        });
    }
}