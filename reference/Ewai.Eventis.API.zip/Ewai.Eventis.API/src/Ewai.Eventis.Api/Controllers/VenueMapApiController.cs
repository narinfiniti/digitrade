﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.VenueMaps.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueMaps.Filters;
using Ewai.Eventis.App.Contracts.Models.VenueMaps.Inputs;
using Ewai.Eventis.App.UseCase.VenueMaps;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.VenueMap.Base)]
public class VenueMapApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.VenueMaps.GetAll)]
    public Task<ListResult<VenueMapListDto>> GetList([FromQuery] VenueMapGetListFilter model)
    {
        return Mediator.Send(new VenueMapGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.VenueMaps.Create)]
    public Task<VenueMapDto> Create([FromBody] VenueMapCreateInput model)
    {
        return Mediator.Send(new VenueMapCreate
        {
            Model = model
        });
    }
    
    [HttpPost("assign")]
    // [Permission(Apis.VenueMenus.Create)]
    public Task<VenueMapDto> Assign([FromBody] VenueMapAssignInput model)
    {
        return Mediator.Send(new VenueMapAssign
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.VenueMaps.Update)]
    public Task<VenueMapDto> Update([FromRoute] Guid id, [FromBody] VenueMapUpdateInput model)
    {
        return Mediator.Send(new VenueMapUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.VenueMaps.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new VenueMapDelete
        {
            Model = id,
        });
    }
}