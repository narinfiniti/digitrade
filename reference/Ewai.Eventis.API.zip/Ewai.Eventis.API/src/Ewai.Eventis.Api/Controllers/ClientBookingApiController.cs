﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.ClientBookingLogs.Dto;
using Ewai.Eventis.App.Contracts.Models.ClientBookingLogs.Filters;
using Ewai.Eventis.App.Contracts.Models.ClientBookings.Dto;
using Ewai.Eventis.App.Contracts.Models.ClientBookings.Filters;
using Ewai.Eventis.App.Contracts.Models.ClientBookings.Inputs;
using Ewai.Eventis.App.UseCase.TenantClientBookingLogs;
using Ewai.Eventis.App.UseCase.TenantClientBookings;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.ClientBooking.Base)]
public class ClientBookingApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.ClientBookings.GetAll)]
    public Task<ListResult<ClientBookingListDto>> GetList([FromQuery] ClientBookingGetListFilter model)
    {
        return Mediator.Send(new ClientBookingGetList
        {
            Model = model
        });
    }

    [HttpGet("logs")]
    // [Permission(Apis.ClientBookings.GetAll)]
    public Task<ListResult<ClientBookingLogListDto>> GetList([FromQuery] ClientBookingLogGetListFilter model)
    {
        return Mediator.Send(new ClientBookingLogGetList
        {
            Model = model
        });
    }

    [HttpGet("{id}")]
    //[Permission(Apis.EventVenues.GetById)]
    public Task<ClientBookingListDto> GetById([FromRoute] Guid id)
    {
        return Mediator.Send(new ClientBookingGetById
        {
            ClientBookingId = id
        });
    }

    [HttpPost]
    // [Permission(Apis.ClientBookings.Create)]
    public Task<ClientBookingDto> Create([FromBody] ClientBookingCreateInput model)
    {
        return Mediator.Send(new ClientBookingCreate
        {
            Model = model
        });
    }

    [HttpPost("assign-table")]
    // [Permission(Apis.ClientBookings.AssignTable)]
    public Task<ClientBookingAssignTableDto> AssignTable([FromBody] ClientBookingAssignTableInput model)
    {
        return Mediator.Send(new ClientBookingAssignTable
        {
            Model = model
        });
    }

    [HttpPost("unassign-table")]
    // [Permission(Apis.ClientBookings.UnassignTable)]
    public Task<ClientBookingAssignTableDto> UnassignTable([FromBody] ClientBookingUnassignTableInput model)
    {
        return Mediator.Send(new ClientBookingUnassignTable
        {
            Model = model
        });
    }

    [HttpPost("arrived-people")]
    // [Permission(Apis.ClientBookings.AssignTable)]
    public Task<ClientBookingUpdateArrivedPeopleDto> ArrivedPeople([FromBody] ClientBookingUpdateArrivedPeopleInput model)
    {
        return Mediator.Send(new ClientBookingUpdateArrivedPeople
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.ClientBookings.Update)]
    public Task<ClientBookingDto> Update([FromRoute] Guid id, [FromBody] ClientBookingUpdateInput model)
    {
        return Mediator.Send(new ClientBookingUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.ClientBookings.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new ClientBookingDelete
        {
            Model = id,
        });
    }
}