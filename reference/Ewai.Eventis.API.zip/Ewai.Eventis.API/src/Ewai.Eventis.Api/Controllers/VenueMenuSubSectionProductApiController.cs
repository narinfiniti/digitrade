﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.VenueMenuSubSectionProducts.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueMenuSubSectionProducts.Filters;
using Ewai.Eventis.App.Contracts.Models.VenueMenuSubSectionProducts.Inputs;
using Ewai.Eventis.App.UseCase.VenueMenuSubSectionProducts;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.VenueMenuSubSectionProduct.Base)]
public class VenueMenuSubSectionProductApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.VenueMenuSubSectionProducts.GetAll)]
    public Task<ListResult<VenueMenuProductListDto>> GetList([FromQuery] VenueMenuProductGetListFilter model)
    {
        return Mediator.Send(new MenuSubSectionProductGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.VenueMenuSubSectionProducts.Create)]
    public Task<VenueMenuProductDto> Create([FromBody] VenueMenuProductCreateInput model)
    {
        return Mediator.Send(new MenuSubSectionProductCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.VenueMenuSubSectionProducts.Update)]
    public Task<VenueMenuProductDto> Update([FromRoute] Guid id, [FromBody] VenueMenuProductUpdateInput model)
    {
        return Mediator.Send(new MenuSubSectionProductUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.VenueMenuSubSectionProducts.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new MenuSubSectionProductDelete
        {
            Model = id,
        });
    }
}