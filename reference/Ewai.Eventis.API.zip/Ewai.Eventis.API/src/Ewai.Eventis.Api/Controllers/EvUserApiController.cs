﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.EventUsers.Dto;
using Ewai.Eventis.App.Contracts.Models.EventUsers.Filters;
using Ewai.Eventis.App.Contracts.Models.EventUsers.Inputs;
using Ewai.Eventis.App.Contracts.Models.TenantEvents.Inputs;
using Ewai.Eventis.App.UseCase.EventUsers;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.EvUser.Base)]
public class EvUserApiController : ApiController
{
    [HttpGet]
    //[Permission(Apis.EventUsers.GetAll)]
    public Task<ListResult<EventUserListDto>> GetList([FromQuery] EventUserGetListFilter model)
    {
        return Mediator.Send(new TheEventUserGetList
        {
            Model = model
        });
    }

    [HttpPost]
    //[Permission(Apis.EventUsers.Create)]
    public Task<EventUserDto> Create([FromBody] EventUserCreateInput model)
    {
        return Mediator.Send(new TheEventUserCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    //[Permission(Apis.EventUsers.Update)]
    public Task<EventUserDto> Update([FromRoute] Guid id, [FromBody] EventUserUpdateInput model)
    {
        return Mediator.Send(new TheEventUserUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    //[Permission(Apis.EventUsers.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new TheEventUserDelete
        {
            Model = id,
        });
    }

    [HttpPost("assign")]
    //[Permission(Apis.EventUsers.Create)]
    public Task<List<EventUserDto>> Create([FromBody] TheEventAssignWorkerInput model)
    {
        return Mediator.Send(new TheEventAssignUser
        {
            Model = model
        });
    }

    [HttpPut("assign-desk")]
    public async Task<DataResult<bool>> AssignDesk([FromBody] TheEventUserAssignDeskInput model)
    {
        var success = await Mediator.Send(new TheEventUserAssignDesk { Model = model });
        return new DataResult<bool>(true);
    }
}