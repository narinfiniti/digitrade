﻿using Ewai.Eventis.Api.Infrastructure.Filters;
using MediatR;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers.Base;

/// <summary>
/// Base WebAPI controller.
/// </summary>
[ApiController]
[EnableCors("CorsPolicy")]
//[TypeFilter(typeof(ValidateModelActionFilter))]
[TypeFilter(typeof(ResponseResultFilter))]
public class ApiController : ControllerBase
{
    private IMediator _mediator;

    /// <summary>
    /// The mediator to send a command or a query.
    /// </summary>
    protected IMediator Mediator => _mediator ??= HttpContext.RequestServices.GetService<IMediator>();
}