﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.Invoices.Dto;
using Ewai.Eventis.App.Contracts.Models.Invoices.Filters;
using Ewai.Eventis.App.UseCase.Invoices;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

/// <summary>
/// InvoiceApiController.
/// </summary>
[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.Invoice.Base)]
public class InvoiceApiController : ApiController
{
    #region invoice

    [HttpGet]
    //[Permission(Apis.Invoices.GetAll)]
    public Task<ListResult<InvoiceListDto>> GetList([FromQuery] InvoiceGetListFilter model)
    {
        return Mediator.Send(new InvoiceGetList
        {
            Model = model
        });
    }

    // [HttpPost]
    // public Task<InvoiceDto> Create([FromBody] InvoiceCreateInput model)
    // {
    //     return Mediator.Send(new InvoiceCreate
    //     {
    //         Model = model,
    //     });
    // }

    [HttpGet("{invoiceId:guid}/desk")]
    public Task<InvoiceDeskDto> GetDeskByInvoiceId([FromRoute] Guid invoiceId)
    {
        return Mediator.Send(new InvoiceDeskGetByInvoiceId
        {
            Model = invoiceId
        });
    }

    [HttpDelete("{id:guid}")]
    //[Permission(Apis.Invoices.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new InvoiceDelete
        {
            Model = id,
        });
    }

    #endregion
}