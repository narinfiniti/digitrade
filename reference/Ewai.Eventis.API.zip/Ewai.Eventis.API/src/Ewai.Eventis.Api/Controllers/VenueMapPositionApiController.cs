﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.VenueMapPositions.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueMapPositions.Filters;
using Ewai.Eventis.App.Contracts.Models.VenueMapPositions.Inputs;
using Ewai.Eventis.App.UseCase.VenueMapPositions;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.VenueMapPosition.Base)]
public class VenueMapPositionApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.VenueMapPositions.GetAll)]
    public Task<ListResult<VenueMapPositionListDto>> GetList([FromQuery] VenueMapPositionGetListFilter model)
    {
        return Mediator.Send(new VenueMapPositionGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.VenueMapPositions.Create)]
    public Task<VenueMapPositionDto> Create([FromBody] VenueMapPositionCreateInput model)
    {
        return Mediator.Send(new VenueMapPositionCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.VenueMapPositions.Update)]
    public Task<VenueMapPositionDto> Update([FromRoute] Guid id, [FromBody] VenueMapPositionUpdateInput model)
    {
        return Mediator.Send(new VenueMapPositionUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.VenueMapPositions.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new VenueMapPositionDelete
        {
            Model = id,
        });
    }
}