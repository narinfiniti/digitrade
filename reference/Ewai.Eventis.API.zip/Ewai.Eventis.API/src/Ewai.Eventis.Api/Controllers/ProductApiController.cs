﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.Products.Dto;
using Ewai.Eventis.App.Contracts.Models.Products.Filters;
using Ewai.Eventis.App.Contracts.Models.Products.Inputs;
using Ewai.Eventis.App.UseCase.Products;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

/// <summary>
/// ProductApiController.
/// </summary>
[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.Product.Base)]
public class ProductApiController : ApiController
{
    #region products
    [HttpGet]
    // [Permission(Apis.Products.GetAll)]
    public Task<ListResult<ProductListDto>> GetList([FromQuery] ProductQueryGetListFilter model)
    {
        return Mediator.Send(new ProductQueryGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.Products.Create)]
    public Task<ProductListDto> Create([FromBody] ProductCreateInput model)
    {
        return Mediator.Send(new ProductCreate
        {
            Model = model,
        });
    }

    [HttpPut("{id:guid}")]
    // [Permission(Apis.Products.Update)]
    public Task<ProductListDto> Update([FromRoute] Guid id, [FromBody] ProductUpdateInput model)
    {
        return Mediator.Send(new ProductUpdate
        {
            Model = model,
            Id = id
        });
    }

    // [HttpPut(Consts.Route.Product.MakeProductsProhibited)]
    // public Task MarkProductsProhibited([FromBody] ProductMakeProhibitedInput model)
    // {
    //     return Mediator.Send(new ProductMakeProhibited
    //     {
    //         Model = model,
    //     });
    // }

    [HttpDelete("{id:guid}")]
    // [Permission(Apis.Products.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new ProductDelete
        {
            Model = id,
        });
    }

    #endregion
    
    // [HttpDelete("shopping-bags/{id:guid}")]
    // [Permission(Apis.Products.DeleteShoppingBag)]
    // public Task DeleteShoppingBag([FromRoute] Guid id)
    // {
    //     return Mediator.Send(new ProductDelete
    //     {
    //         Model = id,
    //     });
    // }

    #region product-import-export

    [HttpPost("import")]
    // [Permission(Apis.Products.Import)]
    public Task ProductImport([FromForm] ProductImportFileInput model)
    {
        return Mediator.Send(new ProductImportList
        {
            Model = model,
        });
    }

    [HttpPost("images/import")]
    // [Permission(Apis.Products.Import)]
    [RequestSizeLimit(268_435_456)]
    [RequestFormLimits(MultipartBodyLengthLimit = 268_435_456)]
    public Task ProductImagesImport([FromForm] ProductImagesImportInput model)
    {
        return Mediator.Send(new ProductImagesImportList
        {
            Model = model,
            Files = Request.Form?.Files
        });
    }

    [HttpGet("export")]
    // [Permission(Apis.Products.Export)]
    public Task<FileStreamResult> ProductExport([FromQuery] ProductExportFileInput model)
    {
        return Mediator.Send(new ProductExportList
        {
            Model = model,
        });
    }

    #endregion
}