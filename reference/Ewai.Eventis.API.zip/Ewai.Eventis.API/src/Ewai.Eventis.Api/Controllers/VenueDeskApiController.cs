﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.VenueDesks.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueDesks.Filters;
using Ewai.Eventis.App.Contracts.Models.VenueDesks.Inputs;
using Ewai.Eventis.App.UseCase.VenueDesks;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.VenueDesk.Base)]
public class VenueDeskApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.VenueDesks.GetAll)]
    public Task<ListResult<VenueDeskListDto>> GetList([FromQuery] VenueDeskGetListFilter model)
    {
        return Mediator.Send(new VenueDeskGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.VenueDesks.Create)]
    public Task<VenueDeskDto> Create([FromBody] VenueDeskCreateInput model)
    {
        return Mediator.Send(new VenueDeskCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.VenueDesks.Update)]
    public Task<VenueDeskDto> Update([FromRoute] Guid id, [FromBody] VenueDeskUpdateInput model)
    {
        return Mediator.Send(new VenueDeskUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.VenueDesks.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new VenueDeskDelete
        {
            Model = id,
        });
    }
}