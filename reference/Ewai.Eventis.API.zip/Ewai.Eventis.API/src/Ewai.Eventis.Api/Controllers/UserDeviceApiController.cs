﻿using System.ComponentModel.DataAnnotations;
using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.Devices.Dto;
using Ewai.Eventis.App.Contracts.Models.Devices.Filters;
using Ewai.Eventis.App.Contracts.Models.DevicesFcm.Dto;
using Ewai.Eventis.App.Contracts.Models.DevicesFcm.Filters;
using Ewai.Eventis.App.Contracts.Models.DevicesFcm.Inputs;
using Ewai.Eventis.App.UseCase.Devices;
using Ewai.Eventis.App.UseCase.DevicesFcm;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

/// <summary>
/// UserDeviceApiController.
/// </summary>
[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.UserDevice.Base)]
public class UserDeviceApiController : ApiController
{
    [HttpGet("signalr")]
    //[Permission(Apis.UserDevices.GetAll)]
    public Task<ListResult<UserDeviceDto>> GetList([FromQuery] UserDeviceGetListFilter model)
    {
        return Mediator.Send(new UserDeviceGetList
        {
            Model = model
        });
    }

    [HttpGet("fcm")]
    //[Permission(Apis.UserDevices.GetAll)]
    public Task<ListResult<UserDeviceFcmDto>> GetList([FromQuery] UserDeviceFcmGetListFilter model)
    {
        return Mediator.Send(new UserDeviceFcmGetList
        {
            Model = model
        });
    }

    [HttpPost("register-fcm")]
    public Task<UserDeviceFcmRegisterDto> Create([FromBody] UserDeviceFcmRegisterInput model)
    {
        return Mediator.Send(new UserDeviceFcmRegister
        {
            Model = model,
        });
    }

    [HttpDelete("unregister-fcm/{id}")]
    //[Permission(Apis.UserDevices.Delete)]
    public Task Delete([FromRoute, MaxLength(1000)] string id)
    {
        return Mediator.Send(new UserDeviceFcmUnregister
        {
            DeviceId = id,
        });
    }
}