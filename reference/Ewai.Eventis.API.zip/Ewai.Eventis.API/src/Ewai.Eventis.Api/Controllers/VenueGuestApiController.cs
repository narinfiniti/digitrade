﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.VenueGusts.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueGusts.Filters;
using Ewai.Eventis.App.Contracts.Models.VenueGusts.Inputs;
using Ewai.Eventis.App.UseCase.VenueGuests;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.VenueGuest.Base)]
public class VenueGuestApiController : ApiController
{
    [HttpGet]
    //[Permission(Apis.VenueGuests.GetAll)]
    public Task<ListResult<VenueGuestListDto>> GetList([FromQuery] VenueGuestGetListFilter model)
    {
        return Mediator.Send(new VenueGuestGetList
        {
            Model = model
        });
    }

    [HttpPost]
    //[Permission(Apis.VenueGuests.Create)]
    public Task<VenueGuestDto> Create([FromBody] VenueGuestCreateInput model)
    {
        return Mediator.Send(new VenueGuestCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    //[Permission(Apis.VenueGuests.Update)]
    public Task<VenueGuestDto> Update([FromRoute] Guid id, [FromBody] VenueGuestUpdateInput model)
    {
        return Mediator.Send(new VenueGuestUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    //[Permission(Apis.VenueGuests.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new VenueGuestDelete
        {
            Model = id,
        });
    }
}