﻿using Ewai.Eventis.Api.Constants;
using Ewai.Common.Exceptions;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.Venues.Dto;
using Ewai.Eventis.App.Contracts.Models.Venues.Filters;
using Ewai.Eventis.App.Contracts.Models.Venues.Inputs;
using Ewai.Eventis.App.UseCase.Venues;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.Venue.Base)]
public class VenueApiController : ApiController
{
    [HttpGet]
    //[Permission(Apis.EventVenues.GetAll)]
    public Task<ListResult<VenueListDto>> GetList([FromQuery] VenueGetListFilter model)
    {
        return Mediator.Send(new EventVenueGetList
        {
            Model = model
        });
    }

    [HttpGet("{id}")]
    //[Permission(Apis.EventVenues.GetById)]
    public async Task<ActionResult<VenueListDto>> GetById([FromRoute] Guid id)
    {
        try
        {
            var result = await Mediator.Send(new EventVenueGetById
            {
                VenueId = id
            });

            return Ok(result);
        }
        catch (NotFoundException ex)
        {
            return NotFound(new { message = ex.Message });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = "An unexpected error occurred.", details = ex.Message });
        }
    }

    [HttpPost]
    //[Permission(Apis.EventVenues.Create)]
    public Task<VenueDto> Create([FromBody] VenueCreateInput model)
    {
        return Mediator.Send(new EventVenueCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    //[Permission(Apis.EventVenues.Update)]
    public Task<VenueDto> Update([FromRoute] Guid id, [FromBody] VenueUpdateInput model)
    {
        return Mediator.Send(new EventVenueUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    //[Permission(Apis.EventVenues.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new EventVenueDelete
        {
            Model = id,
        });
    }
}