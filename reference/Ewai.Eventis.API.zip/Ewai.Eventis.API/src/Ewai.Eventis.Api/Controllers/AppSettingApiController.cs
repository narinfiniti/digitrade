﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.AppSettings.Dto;
using Ewai.Eventis.App.Contracts.Models.AppSettings.Filters;
using Ewai.Eventis.App.Contracts.Models.AppSettings.Inputs;
using Ewai.Eventis.App.UseCase.AppSettings;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.AppSettings.Base)]
public class AppSettingApiController : ApiController
{
    [HttpGet]
    //[Permission(Apis.AppSettings.GetAll)]
    public Task<ListResult<AppSettingListDto>> GetList([FromQuery] AppSettingGetListFilter model)
    {
        return Mediator.Send(new AppSettingGetList
        {
            Model = model
        });
    }

    [HttpPost]
    //[Permission(Apis.AppSettings.Create)]
    public Task<List<AppSettingDto>> Create(List<AppSettingCreateInput> model)
    {
        return Mediator.Send(new AppSettingCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    //[Permission(Apis.AppSettings.Update)]
    public Task<AppSettingDto> Update(Guid id, AppSettingUpdateInput model)
    {
        return Mediator.Send(new AppSettingUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    //[Permission(Apis.AppSettings.Delete)]
    public Task Remove(Guid id)
    {
        return Mediator.Send(new AppSettingRemove
        {
            Model = id
        });
    }
}