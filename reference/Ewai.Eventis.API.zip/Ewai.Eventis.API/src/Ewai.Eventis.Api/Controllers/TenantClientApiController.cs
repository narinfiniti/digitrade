﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.TenantClients.Dto;
using Ewai.Eventis.App.Contracts.Models.TenantClients.Filters;
using Ewai.Eventis.App.Contracts.Models.TenantClients.Inputs;
using Ewai.Eventis.App.UseCase.TenantClients;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.TenantClient.Base)]
public class TenantClientApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.TenantClients.GetAll)]
    public Task<ListResult<TenantClientListDto>> GetList([FromQuery] TenantClientGetListFilter model)
    {
        return Mediator.Send(new TenantClientGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.TenantClients.Create)]
    public Task<TenantClientDto> Create([FromBody] TenantClientCreateInput model)
    {
        return Mediator.Send(new TenantClientCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.TenantClients.Update)]
    public Task<TenantClientDto> Update([FromRoute] Guid id, [FromBody] TenantClientUpdateInput model)
    {
        return Mediator.Send(new TenantClientUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.TenantClients.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new TenantClientDelete
        {
            Model = id,
        });
    }
}