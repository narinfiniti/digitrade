﻿using Ewai.Eventis.Api.Constants;
using Ewai.Eventis.Api.Controllers.Base;
using Ewai.Eventis.App.Contracts.Models.VenueMenuSections.Dto;
using Ewai.Eventis.App.Contracts.Models.VenueMenuSections.Filters;
using Ewai.Eventis.App.Contracts.Models.VenueMenuSections.Inputs;
using Ewai.Eventis.App.UseCase.VenueMenuSections;
using Ewai.SharedKernel.Models.Response;
using Microsoft.AspNetCore.Mvc;

namespace Ewai.Eventis.Api.Controllers;

[ApiVersion(Consts.Version.V1)]
[Route(Consts.Route.VenueMenuSection.Base)]
public class VenueMenuSectionApiController : ApiController
{
    [HttpGet]
    // [Permission(Apis.VenueMenuSections.GetAll)]
    public Task<ListResult<VenueMenuSectionListDto>> GetList([FromQuery] VenueMenuSectionGetListFilter model)
    {
        return Mediator.Send(new VenueMenuSectionGetList
        {
            Model = model
        });
    }

    [HttpPost]
    // [Permission(Apis.VenueMenuSections.Create)]
    public Task<VenueMenuSectionDto> Create([FromBody] VenueMenuSectionCreateInput model)
    {
        return Mediator.Send(new VenueMenuSectionCreate
        {
            Model = model
        });
    }

    [HttpPut("{id}")]
    // [Permission(Apis.VenueMenuSections.Update)]
    public Task<VenueMenuSectionDto> Update([FromRoute] Guid id, [FromBody] VenueMenuSectionUpdateInput model)
    {
        return Mediator.Send(new VenueMenuSectionUpdate
        {
            Model = model,
            Id = id
        });
    }

    [HttpDelete("{id}")]
    // [Permission(Apis.VenueMenuSections.Delete)]
    public Task Delete([FromRoute] Guid id)
    {
        return Mediator.Send(new VenueMenuSectionDelete
        {
            Model = id,
        });
    }
}