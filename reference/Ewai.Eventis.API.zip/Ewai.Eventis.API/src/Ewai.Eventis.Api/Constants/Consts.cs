namespace Ewai.Eventis.Api.Constants;

/// <summary>
/// Route Api Constants.
/// </summary>
public static class Consts
{
    private const string ApiPrefix = "api/app";

    public static class Version
    {
        public const string V1 = "1.0";
    }

    public static class Route
    {
        public static class AppSettings
        {
            public const string Base = ApiPrefix + "/app-settings";
        }

        public class Analytics
        {
            public const string Base = ApiPrefix + "/analytics";
            public const string GetFilterEventList = "filter-events";
            public const string GetFilterVenueList = "filter-parties";

            public const string GetTotalRevenue = "total-revenue";
            public const string GetAverageRevenue = "average-revenue";
            public const string GetCompletedBookings = "completed-bookings";
            public const string GetAverageTableOccupation = "average-table-occupation";
            public const string GetPrePaymentOnSiteRevenue = "prepayment-onsite-revenue";
            public const string GetRevenuePerDesk = "revenue-per-desk";
            public const string GetEventUserRevenue = "event-user-revenue";
            public const string GetStockAnalytics = "stock-analytics";

            public const string GetFailedTransactions = "failed-transactions";
            public const string GetPeakTransactionTime = "peak-transaction-time";
            public const string GetSoldProducts = "most-sold-product";
            public const string GetPreferredProducts = "most-preferred-product";
            public const string GetAverageClientSpend = "average-basket-size";
            public const string GetAbandonedTransactions = "abandoned-transactions";
            public const string GetAverageVenueRating = "party-average-rating";
            public const string GetCustomerFeedback = "customer-feedback";
            public const string Export = "export";
        }

        public static class HealthChecks
        {
            public const string Base = ApiPrefix + "/health-checks";
            public const string ServerStatus = "server-status";
        }

        public static class Permissions
        {
            public const string Base = ApiPrefix + "/permissions";
            public const string Views = "views";
            public const string Create = "create";
            public const string Reset = "reset";
        }

        public static class User
        {
            public const string Base = ApiPrefix + "/users";
            public const string Id = "id";
        }

        public static class UserDevice
        {
            public const string Base = ApiPrefix + "/user-devices";
            public const string Id = "id";
        }

        public static class Invoice
        {
            public const string Base = ApiPrefix + "/invoices";
            public const string Id = "id";
        }

        public static class Request
        {
            public const string Base = ApiPrefix + "/requests";
            public const string Id = "id";
        }

        public static class RequestProduct
        {
            public const string Base = ApiPrefix + "/request-products";
            public const string Id = "id";
        }

        public static class Product
        {
            public const string Base = ApiPrefix + "/products";
            public const string Id = "id";
            public const string MakeProductsProhibited = "make-products-prohibited";
        }

        public static class Tenant
        {
            public const string Base = ApiPrefix + "/tenants";
            public const string Id = "id";
        }

        public static class TenantClient
        {
            public const string Base = ApiPrefix + "/tenant-clients";
            public const string Id = "id";
        }

        public static class TenantSubs
        {
            public const string Base = ApiPrefix + "/tenant-subs";
            public const string Id = "id";
        }

        public static class AppSubs
        {
            public const string Base = ApiPrefix + "/app-subs";
            public const string Id = "id";
        }

        public static class TenantBranch
        {
            public const string Base = ApiPrefix + "/tenant-branches";
            public const string Id = "id";
        }

        public static class TheEvent
        {
            public const string Base = ApiPrefix + "/tenant-events";
            public const string Id = "id";
        }

        public static class Notif
        {
            public const string Base = ApiPrefix + "/notifs";
            public const string Id = "id";
        }

        public static class EvUser
        {
            public const string Base = ApiPrefix + "/event-users";
            public const string Id = "id";
        }

        public static class Venue
        {
            public const string Base = ApiPrefix + "/parties";
            public const string Id = "id";
        }

        public static class VenueDesk
        {
            public const string Base = ApiPrefix + "/venue-desks";
            public const string Id = "id";
        }

        public static class VenueGuest
        {
            public const string Base = ApiPrefix + "/venue-guests";
            public const string Id = "id";
        }

        public static class VenueZone
        {
            public const string Base = ApiPrefix + "/venue-zones";
            public const string Id = "id";
        }

        public static class VenueMap
        {
            public const string Base = ApiPrefix + "/venue-maps";
            public const string Id = "id";
        }

        public static class VenueMenu
        {
            public const string Base = ApiPrefix + "/venue-menus";
            public const string Id = "id";
        }

        public static class VenueMenuSection
        {
            public const string Base = ApiPrefix + "/venue-menu-sections";
            public const string Id = "id";
        }

        public static class VenueMenuSubSection
        {
            public const string Base = ApiPrefix + "/venue-menu-sub-sections";
            public const string Id = "id";
        }

        public static class VenueMenuSubSectionProduct
        {
            public const string Base = ApiPrefix + "/venue-menu-sub-section-products";
            public const string Id = "id";
        }

        public static class VenueMapPosition
        {
            public const string Base = ApiPrefix + "/venue-map-positions";
            public const string Id = "id";
        }

        public static class VenueLocation
        {
            public const string Base = ApiPrefix + "/venue-locations";
            public const string Id = "id";
        }

        public static class ClientBooking
        {
            public const string Base = ApiPrefix + "/client-bookings";
            public const string Id = "id";
        }

        public static class BlobFile
        {
            public const string Base = ApiPrefix + "/blob-files";
            public const string Id = "id";
        }

        public static class TextMessage
        {
            public const string Base = ApiPrefix + "/text-messages";
            public const string Id = "id";
        }
    }
}