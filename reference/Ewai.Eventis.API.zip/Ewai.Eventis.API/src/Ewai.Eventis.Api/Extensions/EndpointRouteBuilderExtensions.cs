﻿using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;

namespace Ewai.Eventis.Api.Extensions;

/// <summary>
/// Extensions for adding dependencies into service collection.
/// </summary>
public static class EndpointRouteBuilderExtensions
{
    public static IEndpointRouteBuilder MapHealthCheck(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapHealthChecks("/health", new HealthCheckOptions
        {
            Predicate = r => r.Name.Contains("health"),
            ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
        });
        //.RequireAuthorization(new AuthorizeAttribute() { Roles = "1", });
        endpoints.MapHealthChecks("/health/db", new HealthCheckOptions
        {
            Predicate = r => r.Name.Contains("db"),
            ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
        });

        return endpoints;
    }

    public static ControllerActionEndpointConventionBuilder MapControllers(
        this IEndpointRouteBuilder endpoints, IHostEnvironment env)
    {
        return endpoints.MapControllers().RequireAuthorization();
        // return endpoints.MapControllers().RequireAuthorization(nameof(ApiPermissionRequirement));
    }
}