using Ewai.Eventis.Api.Infrastructure.Bindings;
using Ewai.Eventis.Hubs.Infrastructure.Auth;
using Ewai.Eventis.Identity.Infrastructure.Auth;
using Ewai.SharedKernel.Models.Configs;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;

namespace Ewai.Eventis.Api.Extensions;

/// <summary>
/// Extensions for service collection
/// </summary>
public static class DependencyExtensions
{
    /// <summary>
    /// AddCustomConfiguration.
    /// </summary>
    public static IServiceCollection AddCustomConfiguration(this IServiceCollection services,
        IConfiguration config, IHostEnvironment env)
    {
        services.Configure<FormOptions>(options => { options.MultipartBodyLengthLimit = 268_435_456; });
        services.Configure<KeyVaultOptions>(options =>
        {
            options.EventisRabbitMqHostName = config[nameof(options.EventisRabbitMqHostName)];
            options.EventisRabbitMqVirtualHost = config[nameof(options.EventisRabbitMqVirtualHost)];
            options.EventisRabbitMqPort = config.GetValue<int>(nameof(options.EventisRabbitMqPort));
            options.EventisRabbitMqPassword = config[nameof(options.EventisRabbitMqPassword)];
            options.EventisRabbitMqUsername = config[nameof(options.EventisRabbitMqUsername)];
            options.EventisSlackApiKey = config[nameof(options.EventisSlackApiKey)];
        });

        return services;
    }

    /// <summary>
    /// AddApplicationInsights.
    /// </summary>
    public static IServiceCollection AddApplicationInsights(this IServiceCollection services,
        IConfiguration config, IHostEnvironment env)
    {
        //services.AddApplicationInsightsTelemetry(config);

        return services;
    }

    /// <summary>
    /// AddCustomControllers.
    /// </summary>
    public static IServiceCollection AddCustomControllers(this IServiceCollection services,
        IConfiguration config, IHostEnvironment env)
    {
        services.AddControllers(options =>
        {
            options.Filters.Add(new ProducesAttribute("application/json"));
            options.Conventions.Add(new SparseQueryParamConvention());
        });

        return services;
    }

    /// <summary>
    /// AddCustomAuthorization.
    /// </summary>
    public static IServiceCollection AddCustomAuthorization(
        this IServiceCollection services, IConfiguration config)
    {
        services.AddAuthorization(options =>
        {
            var builder = new AuthorizationPolicyBuilder()
                .AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme)
                .RequireAuthenticatedUser()
                .RequireScope("identityapi");
            options.DefaultPolicy = builder.Build();
            options.FallbackPolicy = options.DefaultPolicy;

            options.AddPolicy(nameof(HubAuthRequirement), b =>
            {
                b.AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme);
                b.RequireAuthenticatedUser();
                b.RequireScope("identityapi");
                b.AddRequirements(new HubAuthRequirement());
            });
            options.AddPolicy(nameof(ApiPermissionRequirement), b =>
            {
                b.AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme);
                b.RequireAuthenticatedUser();
                b.RequireScope("identityapi");
                b.AddRequirements(new ApiPermissionRequirement());
            });
        });

        return services;
    }

    /// <summary>
    /// AddCustomApiVersioning.
    /// </summary>
    public static IServiceCollection AddCustomApiVersioning(this IServiceCollection services,
        IConfiguration config)
    {
        services.AddApiVersioning(options =>
        {
            //o.Conventions.Controller<UserController>().HasApiVersion(1, 0);
            options.RegisterMiddleware = true;
            options.ReportApiVersions = true;
            options.AssumeDefaultVersionWhenUnspecified = true;
            options.DefaultApiVersion = default!;
            options.ApiVersionSelector = new CurrentImplementationApiVersionSelector(options);
            //o.ApiVersionReader = new UrlSegmentApiVersionReader();
            options.ApiVersionReader = new MediaTypeApiVersionReader("v");
        });
        services.AddVersionedApiExplorer(options =>
        {
            // version as "'v'major[.minor][-status]"
            options.GroupNameFormat = "'v'VVV";
            // only necessary when versioning by url segment.
            // the SubstitutionFormat can also be used to control the
            // format of the API version in route templates
            options.SubstituteApiVersionInUrl = false;
        });

        return services;
    }
}