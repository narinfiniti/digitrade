using Ewai.Eventis.Api.Infrastructure.Bindings;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Ewai.Eventis.Api.Infrastructure.Attributes;

[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
public class SeparatedQueryStringAttribute : Attribute, IResourceFilter
{
    private readonly SeparatedValueProviderFactory _factory;

    public SeparatedQueryStringAttribute(string separator = ",")
    {
        _factory = new SeparatedValueProviderFactory(separator);
    }

    public SeparatedQueryStringAttribute(string key, string separator)
    {
        _factory = new SeparatedValueProviderFactory(key, separator);
    }

    public void OnResourceExecuted(ResourceExecutedContext context)
    {
    }

    public void OnResourceExecuting(ResourceExecutingContext context)
    {
        context.ValueProviderFactories.Insert(0, _factory);
    }
    /// <summary>
    /// Adds additional strings to the keys to be used in SeparatedValueProviderFactory
    /// </summary>
    /// <param name="key"></param>
    public void AddKey(string key)
    {
        _factory.AddKey(key);
    }
}