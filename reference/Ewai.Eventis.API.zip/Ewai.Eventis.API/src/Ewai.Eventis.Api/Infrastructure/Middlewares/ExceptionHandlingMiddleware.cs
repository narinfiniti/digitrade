﻿using System.Diagnostics;
using Ewai.Eventis.Infrastructure.Extensions;

namespace Ewai.Eventis.Api.Infrastructure.Middlewares;

/// <summary>
/// Custom middleware for exception handling.
/// </summary>
public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;

    /// <summary>
    /// Exception handling middleware.
    /// </summary>
    public ExceptionHandlingMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var logInfo = await context.RequestLog();

        var timer = new Stopwatch();
        timer.Start();
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            logInfo.Exception = ex;
        }
        finally
        {
            timer.Stop();
            logInfo.ExecutionDuration = timer.Elapsed.TotalMilliseconds;
            await context.HandleRequestAsync(logInfo);
        }
    }
}